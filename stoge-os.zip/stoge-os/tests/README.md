# Tests

Simulierter Durchlauf des Spiels in jsdom (kein echtes Electron).

    cd tests
    npm install jsdom --no-save
    node test8.js        (oder test2 bis test7)

Die Tests nutzen `window.__SPEED` (Zeit-Raffer) und eine Attrappe für `window.sys`.
Beim ersten Start nach langer Pause kann das Laden länger dauern, dann Wartezeit am Testanfang erhöhen.
