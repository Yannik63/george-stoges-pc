# Tests

Simulierter Durchlauf des Spiels in jsdom (kein echtes Electron).

    cd tests
    npm install jsdom --no-save
    node test8.js        (oder test2 bis test7)

Die Tests nutzen `window.__SPEED` (Zeit-Raffer) und eine Attrappe für `window.sys`.
Beim ersten Start nach langer Pause kann das Laden länger dauern, dann Wartezeit am Testanfang erhöhen.

- test9.js: Liv kommentiert nach längerer Stille, abgelehnte Berechtigung über liv.exe nachholen
- test10.js: Echo zerstört das Tagebuch, Rätsel wr_acc in liv.cfg, Task-Manager, Lautstärke

- test12.js: Echo-Intro (Popup, Liv lagt/stürzt ab/kommt zurück), Tagebuch verschwindet sichtbar, Zurück-Pfeil, echte Fenster-Hänger, Notfallcode-Teile, Sägescare-Clip
- test8.js deckt zusätzlich Infiltration, Echos Bitte, normales Ende, Abbrechen und wahres Ende ab.

- test13.js: Sprech-Warteschlange, Pause (blur/focus), Bruno- und Kamerabild, Idle nach dem Glitch, gesperrte Fenster, Klone, Ruckel-Streifen, unschließbares Popup, versteckter Kurier, Standup-Team, Living Echo

- test14.js: Reuter als Zahnarzt, eigene Firmenseiten, Abbrechen und Foltern, Prüfstein-Profil, keine Echo-Popups nach der Übernahme, Livs Text pausiert, Bereinigung mit Logo-Wechsel, Teleport und Helligkeit

- test11.js: Echo-Dateiangriffe, Drohmail mit echtem Namen, Malware-Popups, Kurier versteckt, Echo-Seite, Tageszeit-Kommentar
