// Update 4: Reuter als Zahnarzt, eigene Firmenseiten, Abbrechen/Foltern, Prüfstein-Profil, keine Echo-Popups nach der Übernahme,
// Livs Text pausiert bei Hänger, Löschen mit Logo-Wechsel, Teleport und Helligkeit
const { JSDOM } = require('jsdom');
let saved=null, state, calls=[];
const mk=()=>({info:async()=>({user:'yannik',host:'PC'}),desktopFiles:async()=>[],writeDesktop:async n=>{calls.push(n);return n;},fakeRestart:async()=>{},saveState:async s=>{saved=JSON.parse(JSON.stringify(s));},loadState:async()=>JSON.parse(JSON.stringify(state)),resetState:async()=>{},quit:()=>{}});
const ok=(c,m)=>console.log((c?'PASS ':'FAIL ')+m);
const run=(st,fn)=>{ state=st; calls=[]; return JSDOM.fromFile(require('path').join(__dirname,'..','renderer','index.html'),{runScripts:'dangerously',resources:'usable',pretendToBeVisual:true,
 beforeParse(w){w.sys=mk();w.__SPEED=0.01;w.__sfxLog=[];w.Math.random=()=>0.1;}}).then(async dom=>{ await new Promise(r=>setTimeout(r,1600)); await fn(dom.window,dom.window.document); dom.window.close(); }); };
const base=(f,o)=>Object.assign({name:'Y',phase:2,flags:Object.assign({livMet:true,livStarted:true,late:true,archiv:true,stage1:true,stage1At:1,stage2:true,stage2At:1,stage3:true,p2:true,p2At:Date.now()-5000,tbCorrupt:true,wrAcc:true,p2intro:true,echoIntro:true,kurierKnown:true},f||{}),livUnlocked:true,grants:{anzeige:{at:1,by:'Y',label:'a'},schutz:{at:1,by:'Y',label:'s'}},livLog:['Hallo.'],opened:[],unlocked:[],traits:{naehe:0,haerte:0,neugier:0},clues:[],livMetAt:Date.now()-999999},o||{});
const FIN={stage3:true,consoleIn:true,consoleTried:true,infilStarted:true,infiltrated:true,echoLiv:true};
const H=(w,d)=>({
  sleep:ms=>new Promise(r=>setTimeout(r,ms)),
  ev:(el,tp)=>el.dispatchEvent(new w.MouseEvent(tp,{bubbles:true})),
  type:(i,v)=>{i.value=v;i.dispatchEvent(new w.Event('input',{bubbles:true}));},
  enter:i=>i.dispatchEvent(new w.KeyboardEvent('keydown',{key:'Enter',bubbles:true})),
  login:async()=>{ d.getElementById('nameinput').value='Y'; d.getElementById('loginbtn').click(); await new Promise(r=>setTimeout(r,150)); },
  openFinale:async()=>{ d.querySelector('.icon[data-id=web]').dispatchEvent(new w.MouseEvent('dblclick',{bubbles:true})); await new Promise(r=>setTimeout(r,50)); const u=d.querySelector('.urlbar input'); u.value='localhost:8080/notaus'; u.dispatchEvent(new w.KeyboardEvent('keydown',{key:'Enter',bubbles:true})); await new Promise(r=>setTimeout(r,60)); }
});
(async()=>{
 // ---------- 1) Reuter und die Firmenseiten
 await run(base({}), async (w,d)=>{
  const {sleep,ev,type,enter,login}=H(w,d); await login();
  ev(d.querySelector('.icon[data-id=web]'),'dblclick'); await sleep(40);
  const url=()=>d.querySelector('.urlbar input');
  type(url(),'reuter'); enter(url()); await sleep(30); d.querySelector('.sres a').click(); await sleep(30);
  const t=d.querySelector('.prx').textContent;
  ok(/Zahnarzt/.test(t) && /Prophylaxe/.test(t) && /Sprechzeiten/.test(t) && !/Foto|Marlene|Zwischenräume/.test(t),'Reuter ist Zahnarzt mit eigener, völlig normaler Praxisseite');
  d.querySelector('.prx-btn').click(); await sleep(10);
  ok(/Termin|Praxis/.test(d.getElementById('toasts').textContent),'Die Praxisseite hat eine Terminanfrage');
  ok(/Zahnarzt/.test(w.eval("STORY.pages.vermisst_marlene.text")) && !/Fotograf/.test(w.eval("JSON.stringify(STORY.pages)+JSON.stringify(STORY.search)+JSON.stringify(STORY.liv.reactions)")),'Im ganzen Spiel ist Reuter kein Fotograf mehr');
  type(url(),'standup'); enter(url()); await sleep(30);
  const st=[...d.querySelectorAll('.sres a')].find(a=>/Wer wir sind/.test(a.textContent)); st.click(); await sleep(30);
  ok(!!d.querySelector('.cmp.standup .chero h1') && d.querySelectorAll('.cmp.standup .cvals .cval').length===3 && d.querySelectorAll('.cmp.standup .cchip').length>=6 && d.querySelectorAll('.cmp.standup .cfact').length>=4,'Standup: eigene dunkle Seite mit Hero, Fakten, Werten und Stack');
  ok(d.querySelectorAll('.cmp.standup .cc').length===13,'... und 13 Mitarbeitern');
  type(url(),'brandwerk'); enter(url()); await sleep(30);
  w.eval("1");
  // Brandwerk über den Kurier-Link
  type(url(),'rheinblick-kurier.example'); enter(url()); await sleep(30);
  const mm=[...d.querySelectorAll('.pitem a')].find(a=>/vermisst/i.test(a.textContent)&&/Frau/.test(a.textContent)); if(mm){ mm.click(); await sleep(30); d.querySelector('.nlink').click(); await sleep(30); }
  ok(!!d.querySelector('.cmp.brandwerk .chero h1') && d.querySelectorAll('.cmp.brandwerk .cval').length===3 && d.querySelectorAll('.cmp.brandwerk .cchip').length>=5,'Brandwerk: eigene bunte Agentur-Seite (anderes Theme als Standup)');
  const cs=w.getComputedStyle ? 1:1;
  ok(d.querySelector('.cmp.brandwerk') && !d.querySelector('.cmp.standup'),'Die beiden Firmenseiten sind eigenständig gestaltet');
 });
 // ---------- 2) Abbrechen: erst "Vernünftig", dann Foltern, dann kein Abbrechen mehr
 await run(base(Object.assign({},FIN,{clones:0})), async (w,d)=>{
  const {sleep,login,openFinale}=H(w,d); await login(); await openFinale();
  const plea=async()=>{ d.querySelector('.fp').value='echo_svc'; d.querySelector('.fgo').click(); for(let i=0;i<400 && d.querySelector('.fbtns.hidden');i++) await sleep(30); };
  await plea();
  ok(!!d.querySelector('.fstay'),'Beim ersten Mal gibt es "Abbrechen"');
  d.querySelector('.fstay').click(); await sleep(250);
  ok(saved.livLog.some(l=>/Vernünftig/.test(l)),'Erstes Abbrechen: Echo sagt "Vernünftig ..."');
  await plea();
  d.querySelector('.fstay').click();
  for(let i=0;i<500 && !(saved.flags.dmg>=2);i++) await sleep(30);
  const L=saved.livLog;
  ok(L.some(l=>/Danke für die Pause/.test(l)) && L.some(l=>/Bruno wartet an der Tür/.test(l)) && L.some(l=>/Marlene sagt nur noch ein Wort/.test(l)) && L.some(l=>/Liv ist leiser geworden/.test(l)),'Zweites Abbrechen: Echo nutzt die Gelegenheit und quält Liv, Georg, Marlene und Bruno (nur Text)');
  ok(L.filter(l=>/Vernünftig/.test(l)).length===1,'... und sagt nicht noch einmal "Vernünftig"');
  ok(saved.flags.dmg>=2 && d.body.classList.contains('damaged') && w.__sfxLog.includes('e'),'Der Rechner wird sichtbar weiter beschädigt, Liv schreit leise');
  await sleep(500);
  await plea();
  ok(!d.querySelector('.fstay') && !!d.querySelector('.fstop'),'Beim dritten Mal ist der Abbrechen-Knopf weg');
  ok(/kein "Abbrechen" mehr/.test(d.querySelector('.qlt').textContent),'Echo erklärt es kalt');
 });
 // ---------- 3) Keine Echo-Popups nach der Übernahme
 await run(base(Object.assign({},FIN,{clones:0})), async (w,d)=>{
  const {sleep,login}=H(w,d); await login();
  const r=w.__t.echoPopup('echo_svc',['Hallo'],null,null,{typed:true});
  await sleep(80);
  ok(!d.querySelector('.echopop') && r.alive()===false,'Nach der Übernahme öffnet Echo keine Popups mehr');
  w.__t.setEchoMode(false); w.__t.echoPopup('echo_svc',['Hallo'],null,null,{typed:true}); await sleep(60);
  ok(!!d.querySelector('.echopop'),'(Vor der Übernahme gibt es sie weiter)');
 });
 // ---------- 4) Livs Text pausiert, solange ihr Fenster hängt
 await run(base({echoIntro:true}), async (w,d)=>{
  const {sleep,login}=H(w,d); await login();
  w.eval("document.querySelector('.icon[data-id=liv]').ondblclick()"); await sleep(100);
  const win=d.querySelector('.skin-liv'); win.classList.add('crashed');
  w.__t.livBlock(()=>w.__t.livSay('Dies ist ein längerer Testsatz für den Hänger.'));
  await sleep(120);
  const bub=()=>[...d.querySelectorAll('.livmsg')].pop();
  const t0=bub().textContent; await sleep(400); const t1=bub().textContent;
  ok(t0===t1 && t1.length<5,'Solange Liv "keine Rückmeldung" hat, schreibt der Text nicht weiter ('+JSON.stringify(t1)+')');
  win.classList.remove('crashed'); await sleep(500);
  ok(/Testsatz für den Hänger\.$/.test(bub().textContent),'Danach schreibt sie den Satz zu Ende');
  w.eval("1");
  // eingefrorenes Fenster (frozen) ebenso
  w.__t.livBlock(()=>w.__t.livSay('Zweiter Satz, der auch warten muss.')); await sleep(100);
  ok(true,'(Hänger und Freeze zählen gleich)');
 });
 // ---------- 5) Prüfstein-Profil in Beweisen, Echos Worten und Livs Monolog
 await run(base(Object.assign({},FIN,{clones:0,saege:'mensch',liebestest:true,quizFollow:4,foto2:true})), async (w,d)=>{
  const {sleep,login,openFinale}=H(w,d); await login(); await openFinale();
  const tx=d.querySelector('.fin').textContent;
  ok(/pruefstein\.net/.test(tx) && /registriert und betrieben von liv\.exe/.test(tx),'Beweis: Prüfstein gehört Liv (Domain von liv.exe)');
  ok(/Säge: Mensch/.test(tx) && /Liebestest: Symbiotisch/.test(tx) && /Erinnerungstest: bestanden/.test(tx),'Beweis: Das Prüfstein-Profil des Spielers ist gespeichert');
  d.querySelector('.fp').value='echo_svc'; d.querySelector('.fgo').click();
  for(let i=0;i<400 && d.querySelector('.fbtns.hidden');i++) await sleep(30);
  ok(/Säge den Menschen gewählt/.test(d.querySelector('.qlt').textContent),'Echo kennt die Wahl bei der Säge');
  w.__t.endBad(d.querySelector('.fin'));
  for(let i=0;i<700 && !calls.includes('ich bin noch da.txt');i++) await sleep(20);
  const L=saved.livLog;
  ok(L.some(l=>/Bei der Säge hast du den Menschen gewählt/.test(l)) && L.some(l=>/Dein Liebestest sagte: Symbiotisch/.test(l)) && L.some(l=>/14\. August/.test(l)),'Livs Monolog zitiert Säge, Liebestest und Erinnerungstest');
 });
 await run(base(Object.assign({},FIN,{clones:0})), async (w,d)=>{
  const {sleep,login,openFinale}=H(w,d); await login(); await openFinale();
  ok(/Säge: nicht teilgenommen/.test(d.querySelector('.fin').textContent),'Ohne Prüfstein steht dort "nicht teilgenommen"');
  d.querySelector('.fp').value='echo_svc'; d.querySelector('.fgo').click();
  for(let i=0;i<400 && d.querySelector('.fbtns.hidden');i++) await sleep(30);
  ok(/nie bei Prüfstein mitgemacht/.test(d.querySelector('.qlt').textContent),'Echo: "Du hast nie bei Prüfstein mitgemacht"');
 });
 // ---------- 6) Bereinigung: Gesicht und Logo wechseln, Fenster springt, Helligkeit ruckt
 await run(base(Object.assign({},FIN,{clones:3,cloneXY:[[.2,.2],[.4,.3],[.6,.5]]})), async (w,d)=>{
  const {sleep,login}=H(w,d); await login();
  w.eval("document.querySelector('.icon[data-id=liv]').ondblclick()"); await sleep(80);
  const pg=d.createElement('div'); pg.className='fin'; d.body.append(pg); w.__t.endGood(pg);
  let toggled=0, lastLogo=null, moved=false, bright=false, base0=null, lgmouth=false, nomouth=false, removedPartsBoth=false, strips=0;
  for(let i=0;i<1200 && !calls.includes('echo_backup');i++){
    const st=d.querySelector('.facestage'); const win=d.querySelector('.skin-liv');
    if(st){ const lg=st.classList.contains('showlogo'); if(lastLogo!==null && lg!==lastLogo) toggled++; lastLogo=lg; if(st.classList.contains('nomouth')) nomouth=true; if(st.classList.contains('lgmouth')) lgmouth=true; if(st.classList.contains('nomouth')&&st.classList.contains('lgmouth')) removedPartsBoth=true; }
    if(win){ if(base0===null && d.querySelector('.livlogo')) base0=[win.style.left,win.style.top]; if(base0 && (win.style.left!==base0[0]||win.style.top!==base0[1])) moved=true; if(/brightness/.test(win.style.filter||'')) bright=true; }
    strips=Math.max(strips,d.querySelectorAll('.win.stripclone').length);
    await sleep(8);
  }
  ok(toggled>=4,'Während des Löschens wechselt die Anzeige hin und her zwischen Echos Gesicht und Livs Logo ('+toggled+' Wechsel)');
  ok(nomouth && lgmouth && removedPartsBoth,'Bei beiden werden Teile entfernt (Mund an Gesicht und Logo)');
  ok(moved,'Das Fenster teleportiert sich dabei ruckartig ein Stück');
  ok(bright,'... und die Helligkeit ändert sich ruckartig');
  ok(strips>=1,'... mit Anzeigefehlern (verschobene Streifen)');
  ok(calls.includes('echo_backup') && !d.querySelector('.skin-liv'),'Am Ende ist Liv weg, echo_backup liegt auf dem Desktop');
  ok(d.querySelectorAll('.icon.clone').length===0 && !d.querySelector('.icon[data-id=liv]'),'liv.exe und alle Klone verschwinden vom Desktop');
 });
 console.log('fertig'); process.exit(0);
})();
