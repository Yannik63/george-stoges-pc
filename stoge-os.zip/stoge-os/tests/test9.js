// Liv: Kommentare nach längerer Stille, Berechtigungen nach zwei Absagen über liv.exe erneut anbieten
const { JSDOM } = require('jsdom');
let saved=null;
const mk=()=>({info:async()=>({user:'yannik',host:'PC'}),desktopFiles:async()=>[],writeDesktop:async n=>n,fakeRestart:async()=>{},saveState:async s=>{saved=JSON.parse(JSON.stringify(s));},loadState:async()=>JSON.parse(JSON.stringify(state)),quit:()=>{}});
let state;
const ok=(c,m)=>console.log((c?'PASS ':'FAIL ')+m);
const run=(st,fn)=>{ state=st; return JSDOM.fromFile(require('path').join(__dirname,'..','renderer','index.html'),{runScripts:'dangerously',resources:'usable',pretendToBeVisual:true,
 beforeParse(w){w.sys=mk();w.__SPEED=0.01;w.Math.random=()=>0.1;}}).then(async dom=>{ await new Promise(r=>setTimeout(r,1600)); await fn(dom.window,dom.window.document); dom.window.close(); }); };
const base=(extra)=>Object.assign({name:'Y',phase:1,flags:{livMet:true,livStarted:true},livLog:['Georg?','Hallo.'],opened:[],unlocked:[],traits:{naehe:0,haerte:0,neugier:0},clues:[],livUnlocked:true,livMetAt:Date.now()-900000,lastLivAt:Date.now()-900000},extra);
(async()=>{
 await run(base({}), async (w,d)=>{
  const sleep=ms=>new Promise(r=>setTimeout(r,ms));
  const bubbles=()=>[...d.querySelectorAll('.livmsg')].map(b=>b.textContent).join(' | ');
  d.getElementById('nameinput').value='Y'; d.getElementById('loginbtn').click(); await sleep(80); w.eval("document.querySelector('.icon[data-id=liv]').ondblclick()"); await sleep(600);
  for(let i=0;i<60 && !/Schön, dass du wieder da bist/.test(bubbles());i++) await sleep(50);
  ok(/Schön, dass du wieder da bist/.test(bubbles()),'liv.exe nach langer Stille: Liv kommentiert');
 });
 await run(base({flags:{livMet:true,livStarted:true,'dec:anzeige':2},lastLivAt:Date.now()}), async (w,d)=>{
  const sleep=ms=>new Promise(r=>setTimeout(r,ms));
  d.getElementById('nameinput').value='Y'; d.getElementById('loginbtn').click(); await sleep(80); w.eval("document.querySelector('.icon[data-id=liv]').ondblclick()"); await sleep(500);
  for(let i=0;i<100 && !d.querySelector('.permdlg .pyes');i++) await sleep(50);
  ok(!!d.querySelector('.permdlg .pyes'),'Nach zwei Absagen bietet Liv die Berechtigung über liv.exe erneut an');
  d.querySelector('.permdlg .pyes').click(); await sleep(100);
  ok(saved.grants&&saved.grants.anzeige,'Berechtigung lässt sich über liv.exe nachholen (kein Softlock)');
 });
 console.log('fertig'); process.exit(0);
})();
