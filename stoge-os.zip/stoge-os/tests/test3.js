const { JSDOM } = require('jsdom');
let saved=null;
const stub={info:async()=>({user:'yannik',host:'PC'}),desktopFiles:async()=>[],writeDesktop:async n=>n,fakeRestart:async()=>{},saveState:async s=>{saved=JSON.parse(JSON.stringify(s));},loadState:async()=>null,resetState:async()=>{},quit:async()=>{}};
const errors=[];
JSDOM.fromFile(require('path').join(__dirname,'..','renderer','index.html'),{runScripts:'dangerously',resources:'usable',pretendToBeVisual:true,
 beforeParse(w){w.sys=stub;w.__SPEED=0.01;w.Math.random=()=>0.1;w.addEventListener('error',e=>errors.push(e.message));}})
.then(async dom=>{
 const w=dom.window,d=w.document,sleep=ms=>new Promise(r=>setTimeout(r,ms));
 const ok=(c,m)=>console.log((c?'PASS ':'FAIL ')+m);
 const ev=(el,t)=>el.dispatchEvent(new w.MouseEvent(t,{bubbles:true}));
 const dbl=s=>ev(d.querySelector(s),'dblclick');
 const byText=(s,t)=>[...d.querySelectorAll(s)].find(e=>e.textContent.includes(t));
 const rows=()=>[...d.querySelectorAll('.frow')].map(r=>r.textContent.replace(/^\S+?(?=[A-Za-z])/,'').trim());
 await sleep(900); d.getElementById('nameinput').value='Y'; d.getElementById('loginbtn').click(); await sleep(50);

 // --- Mail ---
 dbl('.icon[data-id=mail]'); await sleep(30);
 const folderCounts=async f=>{ byText('.mfolder',f).click(); await sleep(20); return d.querySelectorAll('.mrow').length; };
 ok(d.querySelectorAll('.mrow').length===10,'Posteingang: '+d.querySelectorAll('.mrow').length+' Mails');
 ok(await folderCounts('Gesendet')===3,'Gesendet zeigt zunächst 3 Mails');
 ok(await folderCounts('Entwürfe')===1,'Entwürfe: 1');
 ok(await folderCounts('Spam')===2,'Spam: 2');
 byText('.mfolder','Posteingang').click(); await sleep(20);
 byText('.mrow','Notebook').click(); await sleep(10);
 ok(!!d.querySelector('.mbody .mad .mcta') && /Abmelden/.test(d.querySelector('.madf').textContent),'Werbemail im Newsletter-Layout mit CTA und Abmelden-Footer');
 byText('.mrow','Impfung').click(); await sleep(10);
 ok(!!d.querySelector('.mlh') && /Impressum/.test(d.querySelector('.mimp').textContent),'Tierarzt-Mail mit Briefkopf und Impressum');
 const dates=[...d.querySelectorAll('.mrow small')].map(s=>s.textContent);
 ok(dates.every(x=>/^\d\d\.\d\d\.\d{4}, \d\d:\d\d$/.test(x)),'Mail-Daten absolut: '+dates[0]);
 // Compose
 d.querySelector('.mnew').click(); await sleep(20);
 ok(!!d.querySelector('.compose .cto'),'"E-Mail schreiben" öffnet Schreibfenster');
 d.querySelector('.csend').click(); await sleep(60);
 ok(/gesperrt/.test(d.querySelector('.cstat').textContent),'Senden schlägt fehl (Konto gesperrt)');

 // --- Verlauf: keine relativen Wörter ---
 dbl('.icon[data-id=web]'); await sleep(30);
 const small=[...d.querySelectorAll('.hrow small')].map(s=>s.textContent).join(' ');
 ok(!/heute|gestern|vor \d+ Tagen/.test(small),'Verlauf ohne "heute/gestern": '+small.slice(0,70));
 byText('.hrow a','Rauchmelder').click(); await sleep(20);
 ok(![...d.querySelectorAll('.pmeta')].some(p=>/heute|gestern/.test(p.textContent)),'Forum-Daten absolut: '+d.querySelector('.pmeta').textContent);

 // --- Versteckte Inhalte ---
 dbl('.icon[data-id=docs]'); await sleep(30);
 ok(!rows().some(r=>r.includes('Archiv')),'Archiv anfangs unsichtbar');
 ev(byText('.frow','Arbeit'),'dblclick'); await sleep(20);
 ok(rows().includes('standup_notizen.txt'),'standup-Datei umbenannt: standup_notizen.txt');
 d.querySelector('.pathbar button').click(); await sleep(10);
 ev(byText('.frow','privat'),'dblclick'); await sleep(20);
 let pw=d.querySelector('.pw input'); pw.value='bruno2019'; byText('.pw button','Öffnen').click(); await sleep(20);
 ok(!rows().some(r=>r==='M'),'M-Ordner anfangs unsichtbar');
 ev(byText('.frow','chat_marlene_export'),'dblclick'); await sleep(40);
 ok(rows().some(r=>r==='M'),'M-Ordner erscheint, nachdem der Export gelesen wurde');
 ev(byText('.frow','M'),'dblclick'); await sleep(20);
 pw=d.querySelector('.pw input'); pw.value='0000'; byText('.pw button','Öffnen').click(); await sleep(10);
 ok(/Falsch/.test(d.querySelector('.pwmsg').textContent),'M-Ordner: falsches Passwort');
 const b=new Date(); b.setDate(b.getDate()+2); const code=String(b.getDate()).padStart(2,'0')+String(b.getMonth()+1).padStart(2,'0');
 pw.value=code; byText('.pw button','Öffnen').click(); await sleep(20);
 ok(rows().includes('briefe_nicht_abgeschickt.txt'),'M-Ordner öffnet mit Geburtstags-Code '+code);

 // Kalender liefert den Code
 ev(d.getElementById('clock'),'click'); await sleep(10);
 const nav=()=>d.querySelector('[data-nav="1"]');
 let found=false; for(let i=0;i<2&&!found;i++){ const cell=[...d.querySelectorAll('.cd')].find(c=>c.dataset.k===`${b.getFullYear()}-${String(b.getMonth()+1).padStart(2,'0')}-${String(b.getDate()).padStart(2,'0')}`); if(cell){cell.click(); found=true;} else {nav().click();} await sleep(10); }
 ok(found && /Marlene: Geburtstag/.test(d.querySelector('.calev').textContent),'Kalender zeigt Marlenes Geburtstag am selben Datum');
 ev(d.body,'mousedown');

 // Liv-Kette: Versprecher -> Archiv -> Changelog -> liv_svc -> Log -> Gesendet
 d.querySelector('.pathbar button')?.click();
 dbl('.icon[data-id=docs]'); await sleep(20);
 ev(byText('.frow','privat'),'dblclick'); await sleep(10);
 ev(byText('.frow','readme_liv'),'dblclick'); await sleep(200);
 dbl('.icon[data-id=liv]'); await sleep(50);
 for(let i=0;i<200 && !saved.flags.nameSlip;i++) await sleep(100);
 for(let i=0;i<60;i++) await sleep(100);
 for(let i=0;i<60 && !saved.livLog.some(l=>l.includes('Archiv'));i++) await sleep(100);
 ok(saved.flags.nameSlip && saved.livLog.some(l=>l.includes('gegessen, Y?')) && !saved.livLog.some(l=>l.includes('yannik')),'Versprecher wird von Liv still auf den Login-Namen zurückgeändert + Hinweis auf Archiv');
 dbl('.icon[data-id=docs]'); await sleep(30);
 ok(rows().includes('Archiv'),'Archiv erscheint nach dem Versprecher');
 ev(byText('.frow','Archiv'),'dblclick'); await sleep(20);
 ev(byText('.frow','liv_changelog'),'dblclick'); await sleep(40);
 ok(saved.flags.stage1===true && saved.flags.late===true,'Stufe 1 ausgelöst (Changelog gelesen)');
 dbl('.icon[data-id=sys]'); await sleep(30);
 ok(rows().includes('liv_svc'),'System/liv_svc erscheint nach Stufe 1');
 ev(byText('.frow','liv_svc'),'dblclick'); await sleep(20);
 ev(byText('.frow','beobachtungen_marlene'),'dblclick'); await sleep(40);
 ok(saved.flags.stage2===true,'Stufe 2 ausgelöst (Beobachtungslog gelesen)');
 // Mail neu öffnen
 d.querySelector('.win.skin-mail .wbtns button:last-child').click();
 dbl('.icon[data-id=mail]'); await sleep(30);
 ok(await folderCounts('Gesendet')===7,'Gesendet zeigt nach Stufe 2 jetzt 7 Mails (Liv schrieb als Georg)');
 console.log('JS-Fehler:',errors.length?errors:'keine');
 process.exit(0);
});
