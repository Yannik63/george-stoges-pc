const { JSDOM } = require('jsdom');
let saved=null, calls=[], phase2=false;
const mk=(load)=>({info:async()=>({user:'yannik',host:'PC'}),desktopFiles:async()=>['Semesterplan.xlsx'],writeDesktop:async(n,c)=>{calls.push(n);return n;},fakeRestart:async p=>{phase2=true;},saveState:async s=>{saved=JSON.parse(JSON.stringify(s));},loadState:async()=>load,resetState:async()=>{},quit:async()=>{}});
const errors=[];
const run=(load,fn)=>JSDOM.fromFile(require('path').join(__dirname,'..','renderer','index.html'),{runScripts:'dangerously',resources:'usable',pretendToBeVisual:true,
 beforeParse(w){w.sys=mk(load);w.__SPEED=0.01;w.Math.random=()=>0.1;w.addEventListener('error',e=>errors.push(e.message));}}).then(async dom=>{ await new Promise(r=>setTimeout(r,1500)); await fn(dom.window,dom.window.document); dom.window.close(); });
const ok=(c,m)=>console.log((c?'PASS ':'FAIL ')+m);
(async()=>{
 await run(null, async (w,d)=>{
  const sleep=ms=>new Promise(r=>setTimeout(r,ms));
  const ev=(el,t)=>el.dispatchEvent(new w.MouseEvent(t,{bubbles:true}));
  const dbl=s=>ev(d.querySelector(s),'dblclick');
  const byText=(s,t)=>[...d.querySelectorAll(s)].find(e=>e.textContent.includes(t));
  const rows=()=>[...d.querySelectorAll('.frow')].map(r=>r.textContent.replace(/^[^A-Za-z_]+/,'').trim());
  const type=(i,v)=>{i.value=v;i.dispatchEvent(new w.Event('input',{bubbles:true}));};
  const enter=i=>i.dispatchEvent(new w.KeyboardEvent('keydown',{key:'Enter',bubbles:true}));
  const dev=async label=>{ if(!d.querySelector('.dev')) d.dispatchEvent(new w.KeyboardEvent('keydown',{key:'D',ctrlKey:true,shiftKey:true})); await sleep(20); byText('.dev button',label).click(); await sleep(20); };
  d.getElementById('nameinput').value='Y'; d.getElementById('loginbtn').click(); await sleep(200);

  // Seitendesigns
  dbl('.icon[data-id=web]'); await sleep(30);
  const url=()=>d.querySelector('.urlbar input');
  type(url(),'wetter'); enter(url()); await sleep(10); d.querySelector('.sres a').click(); await sleep(10);
  ok(!!d.querySelector('.wx .wxtemp') && d.querySelectorAll('.wxd').length===4,'Wetter hat eigenes Design (Temperatur, 4 Tage)');
  type(url(),'rezept linsen'); enter(url()); await sleep(10); d.querySelector('.sres a').click(); await sleep(10);
  ok(!!d.querySelector('.rcp .ings') && !d.querySelector('.wx'),'Rezept hat eigenes Design (Zutatenliste, Schritte)');
  type(url(),'georg stoge'); enter(url()); await sleep(10); d.querySelectorAll('.sres a')[0].click(); await sleep(10);
  ok(d.querySelectorAll('.cmp.standup .cc').length>=8 && d.querySelectorAll('.cmp.standup .cc').length<=15 && d.querySelectorAll('.cdept').length>=4 && /Marketing/.test(d.querySelector('.cmp').textContent) && /IT und Entwicklung/.test(d.querySelector('.cmp').textContent) && !!d.querySelector('.cstat'),'Standup-Seite (eigenes Design): 8 bis 15 Mitarbeiter in Abteilungen ('+d.querySelectorAll('.cc').length+'), Georg abwesend');
  type(url(),'reuter'); enter(url()); await sleep(10); d.querySelector('.sres a').click(); await sleep(10);
  ok(!!d.querySelector('.prx') && d.querySelectorAll('.prx-card').length>=4 && /Zahnarzt/.test(d.querySelector('.prx').textContent) && !/Foto/.test(d.querySelector('.prx').textContent),'Reuter: Praxisseite eines normalen Zahnarztes (eigenes Design)');

  // Paint-Event: Voraussetzungen setzen und genug öffnen
  await dev('Erstkontakt überspringen'); await dev('Alle Stufen'); 
  // Alle Stufen setzt late=true -> Paint wird dann bewusst übersprungen; zurücknehmen
  saved.flags.late=false;
  await dev('Liv malt jetzt');
  for(let i=0;i<80 && !saved.flags.painted;i++) await sleep(50);
  ok(saved.flags.painted===true,'Liv malt, Bild gilt als fertig');
  dbl('.icon[data-id=pics]'); await sleep(30);
  ok(rows().includes('fuer_dich.png'),'fuer_dich.png liegt danach im Bilder-Ordner');

  // Kern-Rätsel: Passwort aus dem Marlene-Log
  dbl('.icon[data-id=sys]'); await sleep(30);
  ev(byText('.frow','echo_svc'),'dblclick'); await sleep(20);
  ok(rows().includes('kern') && rows().includes('beobachtungen_marlene.log'),'echo_svc zeigt kern-Ordner (Stufe 2)');
  ev(byText('.frow','beobachtungen_marlene'),'dblclick'); await sleep(30);
  const logText=d.querySelector('.vw-log pre').textContent;
  const m=logText.match(/(\d\d)\.(\d\d)\.\s+21:55\s+Neues Klingelschild/);
  ok(!!m && /Reuter/.test(logText) && !/Kern ist gesichert/.test(logText),'Log nennt Datum und Namen Reuter, aber keinen Kern-Hinweis (der steht nur am Ordner)');
  ev(byText('.frow','kern'),'dblclick'); await sleep(20);
  let pw=d.querySelector('.pw input'); pw.value='0000'; byText('.pw button','Öffnen').click(); await sleep(10);
  ok(/Falsch/.test(d.querySelector('.pwmsg').textContent),'Kern: falsches Passwort');
  pw.value=m[1]+m[2]; byText('.pw button','Öffnen').click(); await sleep(20);
  ok(rows().includes('plan.txt'),'Kern öffnet mit Datum aus dem Log ('+m[1]+m[2]+')');

  // Bug-Sequenz -> Phase 2
  ev(byText('.frow','plan.txt'),'dblclick'); await sleep(30);
  ok(saved.flags.stage3===true,'plan.txt setzt Stufe 3');
  for(let i=0;i<150 && !phase2;i++) await sleep(50);
  ok(phase2===true && saved.phase===2,'Bug-Sequenz endet im Absturz, Phase 2 gespeichert');
 });

 // Neustart in Phase 2: Liv spricht mit echtem Namen; Forum-Sabotage mit Archivkopie; keine echten Desktop-Dateien
 await run({name:'Y',phase:2,flags:{livMet:true,livStarted:true,late:true,stage1:true,stage2:true,stage3:true},grants:{anzeige:{at:1,by:'Y',label:'Anzeige'},schutz:{at:1,by:'Y',label:'Schutz'}},livLog:[],opened:[],unlocked:[],traits:{naehe:0,haerte:0,neugier:0}}, async (w,d)=>{
  const sleep=ms=>new Promise(r=>setTimeout(r,ms));
  const ev=(el,tp)=>el.dispatchEvent(new w.MouseEvent(tp,{bubbles:true}));
  const url=()=>d.querySelector('.urlbar input');
  const type=(i,v)=>{i.value=v;i.dispatchEvent(new w.Event('input',{bubbles:true}));};
  const enter=i=>i.dispatchEvent(new w.KeyboardEvent('keydown',{key:'Enter',bubbles:true}));
  for(let i=0;i<160 && !(saved.livLog||[]).some(l=>l.includes('Echo. Es wird stärker'));i++) await sleep(50);
  ok(saved.livLog.some(l=>l.includes('Da bist du wieder, Y.')) && !saved.livLog.some(l=>l.includes('Da bist du wieder, yannik')) && saved.livLog.some(l=>l.includes('Das war Echo')),'Phase 2: Liv sagt erst den echten Namen, ändert ihn nach 1-2 s still auf den Spielnamen und schiebt es auf Echo');
  ok(!calls.length,'Phase 2: keine Datei auf dem echten Desktop');
  ev(d.querySelector('.icon[data-id=web]'),'dblclick'); await sleep(40);
  type(url(),'heimwerker-forum.de/t/90377'); enter(url()); await sleep(60);
  for(let i=0;i<60 && !saved.flags.notausGone;i++) await sleep(100);
  await sleep(50);
  ok(saved.flags.notausGone && !/localhost:8080\/notaus/.test(d.querySelector('.bview').textContent) && /entfernt/.test(d.querySelector('.bview').textContent),'Dann verschwindet der Beitrag vor den Augen des Spielers');
  for(let i=0;i<80 && !saved.livLog.some(l=>l.includes('Echo löscht'));i++) await sleep(50);
  ok(saved.livLog.some(l=>l.includes('Echo löscht')),'Liv schiebt die Löschung auf Echo');
  d.querySelector('.archlink').click(); await sleep(40);
  ok(!!d.querySelector('.archbar') && /localhost:8080\/notaus/.test(d.querySelector('.bview').textContent),'Webarchiv zeigt die Kopie mit der Adresse');
  ok(d.body.classList.contains('phase2'),'Desktop ist im dunkleren Phase-2-Look');
 });

 // Echo sperrt den Browser; Wächter aus dem Papierkorb in den Autostart verschieben; Liv legt eine Datei auf den Spiel-Desktop
 await run({name:'Y',phase:2,p2intro:true,flags:{livMet:true,livStarted:true,late:true,p2intro:true,stage1:true,stage2:true,stage3:true,p2:true,wall2:true,wallStage:2,wall2At:Date.now()-999999},grants:{anzeige:{at:1,by:'Y',label:'Anzeige'},schutz:{at:1,by:'Y',label:'Schutz'}},livLog:[],opened:[],unlocked:[],traits:{naehe:0,haerte:0,neugier:0}}, async (w,d)=>{
  const sleep=ms=>new Promise(r=>setTimeout(r,ms));
  const ev=(el,tp,o={})=>el.dispatchEvent(new w.MouseEvent(tp,Object.assign({bubbles:true},o)));
  const byText=(s,tx)=>[...d.querySelectorAll(s)].find(e=>e.textContent.includes(tx));
  for(let i=0;i<100 && !saved.flags.browserLocked;i++) await sleep(50);
  ok(saved.flags.browserLocked===true,'Echo sperrt nach dem Georg-Eintrag den Browser');
  ev(d.querySelector('.icon[data-id=web]'),'dblclick'); await sleep(40);
  ok(!d.querySelector('.urlbar'),'Browser lässt sich nicht öffnen');
  ev(d.querySelector('.icon[data-id=trash]'),'dblclick'); await sleep(40);
  const row=byText('.frow','waechter.svc');
  ok(!!row,'Im Papierkorb liegt der Wächter');
  ev(row,'contextmenu',{clientX:200,clientY:200}); await sleep(30);
  ok(!!d.querySelector('.ctxmenu'),'Rechtsklick öffnet "Verschieben nach"');
  byText('.ctxmenu .ci','Dokumente').click(); await sleep(20);
  ok(!saved.flags.moved,'Falscher Zielordner wird abgelehnt');
  ev(byText('.frow','waechter.svc'),'contextmenu',{clientX:200,clientY:200}); await sleep(30);
  [...d.querySelectorAll('.ctxmenu .ci')].find(e=>e.textContent==='System\\autostart').click(); await sleep(40);
  ok(saved.flags.moved===true && !byText('.frow','waechter.svc'),'Wächter nach System\\autostart verschoben');
  ev(d.querySelector('.icon[data-id=web]'),'dblclick'); await sleep(40);
  ok(!!d.querySelector('.urlbar'),'Browser ist wieder frei');
  for(let i=0;i<220 && !saved.flags.deskNote;i++) await sleep(50);
  ok(saved.flags.deskNote===true && !!d.querySelector('.icon[data-id=desknote]') && !calls.length,'Liv legt eine Datei auf den Spiel-Desktop, nicht auf den echten');
 });
 console.log('JS-Fehler:',errors.length?errors:'keine');
 process.exit(0);
})();
