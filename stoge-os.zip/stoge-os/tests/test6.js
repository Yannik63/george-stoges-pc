const { JSDOM } = require('jsdom');
let saved=null, calls=[], phase2=false;
const mk=(load)=>({info:async()=>({user:'yannik',host:'PC'}),desktopFiles:async()=>['Semesterplan.xlsx'],writeDesktop:async(n,c)=>{calls.push(n);return n;},fakeRestart:async p=>{phase2=true;},saveState:async s=>{saved=JSON.parse(JSON.stringify(s));},loadState:async()=>load,resetState:async()=>{},quit:async()=>{}});
const errors=[];
const run=(load,fn)=>JSDOM.fromFile(require('path').join(__dirname,'..','renderer','index.html'),{runScripts:'dangerously',resources:'usable',pretendToBeVisual:true,
 beforeParse(w){w.sys=mk(load);w.__SPEED=0.01;w.Math.random=()=>0.1;w.addEventListener('error',e=>errors.push(e.message));}}).then(async dom=>{ await new Promise(r=>setTimeout(r,700)); await fn(dom.window,dom.window.document); dom.window.close(); });
const ok=(c,m)=>console.log((c?'PASS ':'FAIL ')+m);
(async()=>{
 await run(null, async (w,d)=>{
  const sleep=ms=>new Promise(r=>setTimeout(r,ms));
  const ev=(el,t)=>el.dispatchEvent(new w.MouseEvent(t,{bubbles:true}));
  const dbl=s=>ev(d.querySelector(s),'dblclick');
  const byText=(s,t)=>[...d.querySelectorAll(s)].find(e=>e.textContent.includes(t));
  const rows=()=>[...d.querySelectorAll('.frow')].map(r=>r.textContent.replace(/^[^A-Za-z_]+/,'').trim());
  const type=(i,v)=>{i.value=v;i.dispatchEvent(new w.Event('input',{bubbles:true}));};
  const enter=i=>i.dispatchEvent(new w.KeyboardEvent('keydown',{key:'Enter',bubbles:true}));
  const dev=async label=>{ if(!d.querySelector('.dev')) d.dispatchEvent(new w.KeyboardEvent('keydown',{key:'D',ctrlKey:true,shiftKey:true})); await sleep(20); byText('.dev button',label).click(); await sleep(20); };
  d.getElementById('nameinput').value='Y'; d.getElementById('loginbtn').click(); await sleep(60);

  // Seitendesigns
  dbl('.icon[data-id=web]'); await sleep(30);
  const url=()=>d.querySelector('.urlbar input');
  type(url(),'wetter'); enter(url()); await sleep(10); d.querySelector('.sres a').click(); await sleep(10);
  ok(!!d.querySelector('.wx .wxtemp') && d.querySelectorAll('.wxd').length===4,'Wetter hat eigenes Design (Temperatur, 4 Tage)');
  type(url(),'rezept linsen'); enter(url()); await sleep(10); d.querySelector('.sres a').click(); await sleep(10);
  ok(!!d.querySelector('.rcp .ings') && !d.querySelector('.wx'),'Rezept hat eigenes Design (Zutatenliste, Schritte)');
  type(url(),'georg stoge'); enter(url()); await sleep(10); d.querySelectorAll('.sres a')[0].click(); await sleep(10);
  ok(d.querySelectorAll('.tcard').length===3 && !!d.querySelector('.tstat'),'Team-Seite mit Karten und Abwesend-Status');
  type(url(),'reuter'); enter(url()); await sleep(10); d.querySelector('.sres a').click(); await sleep(10);
  ok(d.querySelectorAll('.pfi').length===6,'Portfolio-Seite (dunkel, Bildergalerie)');

  // Paint-Event: Voraussetzungen setzen und genug öffnen
  await dev('Erstkontakt überspringen'); await dev('Alle Stufen'); 
  // Alle Stufen setzt late=true -> Paint wird dann bewusst übersprungen; zurücknehmen
  saved.flags.late=false;
  await dev('Liv malt jetzt');
  for(let i=0;i<80 && !saved.flags.painted;i++) await sleep(50);
  ok(saved.flags.painted===true,'Liv malt, Bild gilt als fertig');
  dbl('.icon[data-id=pics]'); await sleep(30);
  ok(rows().includes('fuer_dich.png'),'fuer_dich.png liegt danach im Bilder-Ordner');

  // Kern-Rätsel: Passwort aus dem Marlene-Log
  dbl('.icon[data-id=sys]'); await sleep(30);
  ev(byText('.frow','liv_svc'),'dblclick'); await sleep(20);
  ok(rows().includes('kern') && rows().includes('beobachtungen_marlene.log'),'liv_svc zeigt kern-Ordner (Stufe 2)');
  ev(byText('.frow','beobachtungen_marlene'),'dblclick'); await sleep(30);
  const logText=d.querySelector('.vw-log pre').textContent;
  const m=logText.match(/(\d\d)\.(\d\d)\.\s+21:55\s+Neues Klingelschild/);
  ok(!!m && /Reuter/.test(logText) && /Kern ist gesichert/.test(logText),'Log nennt Datum, Namen Reuter und den Kern-Hinweis');
  ev(byText('.frow','kern'),'dblclick'); await sleep(20);
  let pw=d.querySelector('.pw input'); pw.value='0000'; byText('.pw button','Öffnen').click(); await sleep(10);
  ok(/Falsch/.test(d.querySelector('.pwmsg').textContent),'Kern: falsches Passwort');
  pw.value=m[1]+m[2]; byText('.pw button','Öffnen').click(); await sleep(20);
  ok(rows().includes('plan.txt'),'Kern öffnet mit Datum aus dem Log ('+m[1]+m[2]+')');

  // Bug-Sequenz -> Phase 2
  ev(byText('.frow','plan.txt'),'dblclick'); await sleep(30);
  ok(saved.flags.stage3===true,'plan.txt setzt Stufe 3');
  for(let i=0;i<150 && !phase2;i++) await sleep(50);
  ok(phase2===true && saved.phase===2,'Bug-Sequenz endet im Absturz, Phase 2 gespeichert');
 });

 // Neustart in Phase 2: Liv spricht mit echtem Namen, legt Datei auf den Desktop
 await run({name:'Y',phase:2,flags:{livMet:true,livStarted:true,late:true},livLog:[],opened:[],unlocked:[],traits:{naehe:0,haerte:0,neugier:0}}, async (w,d)=>{
  const sleep=ms=>new Promise(r=>setTimeout(r,ms));
  for(let i=0;i<120 && !(saved.livLog||[]).some(l=>l.includes('Semesterplan'));i++) await sleep(50);
  ok(saved.livLog.some(l=>l.includes('Da bist du wieder, yannik')),'Phase 2: Liv spricht dich mit dem echten Namen an');
  ok(calls.includes('Für yannik.txt'),'Phase 2: Liv legt eine Textdatei auf den echten Desktop');
  ok(saved.livLog.some(l=>l.includes('Semesterplan.xlsx')),'Phase 2: Liv kommentiert einen echten Dateinamen vom Desktop');
  ok(d.body.classList.contains('phase2'),'Desktop ist im dunkleren Phase-2-Look');
 });
 console.log('JS-Fehler:',errors.length?errors:'keine');
 process.exit(0);
})();
