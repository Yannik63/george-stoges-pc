const { JSDOM } = require('jsdom');
const stub={info:async()=>({user:'y',host:'PC'}),desktopFiles:async()=>[],writeDesktop:async n=>n,fakeRestart:async()=>{},saveState:async()=>{},loadState:async()=>null,resetState:async()=>{},quit:async()=>{}};
const rec={lineTo:0,moveTo:0,stroke:0,fillText:[],fillRect:0};
JSDOM.fromFile(require('path').join(__dirname,'..','renderer','index.html'),{runScripts:'dangerously',resources:'usable',pretendToBeVisual:true,
 beforeParse(w){w.sys=stub;w.__SPEED=0.01;
  w.HTMLCanvasElement.prototype.getContext=function(){ return { fillRect(){rec.fillRect++}, beginPath(){}, moveTo(){rec.moveTo++}, lineTo(){rec.lineTo++}, stroke(){rec.stroke++}, fillText(t){rec.fillText.push(t)}, set fillStyle(v){}, set strokeStyle(v){}, set lineWidth(v){}, set lineCap(v){}, set lineJoin(v){}, set font(v){} }; };}})
.then(async dom=>{
 const w=dom.window,d=w.document,sleep=ms=>new Promise(r=>setTimeout(r,ms));
 await sleep(700); d.getElementById('nameinput').value='Y'; d.getElementById('loginbtn').click(); await sleep(60);
 d.dispatchEvent(new w.KeyboardEvent('keydown',{key:'D',ctrlKey:true,shiftKey:true})); await sleep(30);
 [...d.querySelectorAll('.dev button')].find(b=>b.textContent.includes('Erstkontakt')).click(); await sleep(20);
 [...d.querySelectorAll('.dev button')].find(b=>b.textContent.includes('Liv malt')).click();
 await sleep(3500);
 console.log('lineTo:',rec.lineTo,'strokes:',rec.stroke,'Text:',rec.fillText.join(' | '));
 console.log(rec.lineTo>200 && rec.fillText.includes('für dich') ? 'PASS Zeichnung wird Strich für Strich aufgebaut und signiert' : 'FAIL Zeichnung');
 process.exit(0);
});
