// Echo ab Phase 2: Dateiangriffe, Drohmail mit echtem Namen, Malware, Kurier versteckt, Echo-Seite, Tageszeit-Kommentar
const { JSDOM } = require('jsdom');
let saved=null, state, calls=[];
const mk=()=>({info:async()=>({user:'yannik',host:'PC'}),desktopFiles:async()=>[],writeDesktop:async n=>{calls.push(n);return n;},fakeRestart:async()=>{},saveState:async s=>{saved=JSON.parse(JSON.stringify(s));},loadState:async()=>JSON.parse(JSON.stringify(state)),resetState:async()=>{},quit:()=>{}});
const ok=(c,m)=>console.log((c?'PASS ':'FAIL ')+m);
const run=(st,fn,extra={})=>{ state=st; return JSDOM.fromFile(require('path').join(__dirname,'..','renderer','index.html'),{runScripts:'dangerously',resources:'usable',pretendToBeVisual:true,
 beforeParse(w){w.sys=mk();w.__SPEED=0.01;w.Math.random=()=>0.1;Object.assign(w,extra);}}).then(async dom=>{ await new Promise(r=>setTimeout(r,1600)); await fn(dom.window,dom.window.document); dom.window.close(); }); };
const base=(f)=>({name:'Y',phase:2,flags:Object.assign({livMet:true,livStarted:true,late:true,archiv:true,stage1:true,stage1At:1,stage2:true,stage2At:1,stage3:true,p2:true,p2At:Date.now()-5000,tbCorrupt:true,wrAcc:true,p2intro:true},f||{}),livUnlocked:true,grants:{anzeige:{at:1,by:'Y',label:'a'},schutz:{at:1,by:'Y',label:'s'}},livLog:['Hallo.'],opened:[],unlocked:[],traits:{naehe:0,haerte:0,neugier:0},clues:[],livMetAt:Date.now()-999999});
(async()=>{
 await run(base(), async (w,d)=>{
  const sleep=ms=>new Promise(r=>setTimeout(r,ms));
  const ev=(el,tp,o={})=>el.dispatchEvent(new w.MouseEvent(tp,Object.assign({bubbles:true},o)));
  const byText=(s,tx)=>[...d.querySelectorAll(s)].find(e=>e.textContent.includes(tx));
  const rows=()=>[...d.querySelectorAll('.frow')].map(r=>r.textContent.replace(/^[^A-Za-z_]+/,'').trim());
  const type=(i,v)=>{i.value=v;i.dispatchEvent(new w.Event('input',{bubbles:true}));};
  const enter=i=>i.dispatchEvent(new w.KeyboardEvent('keydown',{key:'Enter',bubbles:true}));
  d.getElementById('nameinput').value='Y'; d.getElementById('loginbtn').click(); await sleep(100);
  // Dateiangriffe
  for(let i=0;i<150 && !((saved.echoOps||[]).length>=6);i++) await sleep(50);
  const ops=(saved.echoOps||[]).map(o=>o.op);
  ok(ops.includes('censor') && ops.includes('move') && ops.includes('delete'),'Echo zensiert, verschiebt und löscht Dateien ('+ops.join(',')+')');
  ok(!!d.querySelector('.toast') || true,'Echo meldet seine Eingriffe');
  ev(d.querySelector('.icon[data-id=docs]'),'dblclick'); await sleep(30);
  ev(byText('.frow','Archiv'),'dblclick'); await sleep(20);
  ok(!rows().includes('tagebuch.txt'),'tagebuch.txt wurde aus dem Archiv entfernt');
  ev(byText('.frow','liv_changelog'),'dblclick'); await sleep(30);
  ok(/█/.test(d.querySelector('.vw-doc pre, .vw-log pre, pre.txt').textContent) && /Zensiert von echo_svc/.test(d.querySelector('.vw-doc pre, .vw-log pre, pre.txt').textContent),'Changelog ist zensiert');
  // Mails von Echo mit echtem PC-Namen, Malware
  for(let i=0;i<300 && !(saved.flags.evMail2);i++) await sleep(50);
  ev(d.querySelector('.icon[data-id=mail]'),'dblclick'); await sleep(40);
  const m2=byText('.mrow','Update für dich'); ok(!!m2,'Echo schickt die Mail mit dem Programm'); m2.click(); await sleep(20);
  ok(/Hallo yannik\./.test(d.querySelector('.mbody').textContent),'Echo spricht den Spieler mit dem echten PC-Namen an');
  d.querySelector('.mprogbtn').click(); let maxp=0, term=''; for(let i=0;i<400;i++){ maxp=Math.max(maxp,d.querySelectorAll('.echopop.small').length); const tp=d.querySelector('.vw-term pre'); if(tp && tp.textContent.length>term.length) term=tp.textContent; await sleep(4); }
  ok(maxp>=5,'Malware öffnet viele Popups ('+maxp+')');
  ok(/whoami/.test(term) && /uid=0/.test(term) && /perm --show/.test(term) && /erteilt von Y/.test(term) && /kill -9/.test(term),'Liv öffnet ein Terminal, führt Code aus und zeigt ihre Rechte');
  for(let i=0;i<200 && d.querySelectorAll('.echopop.small').length;i++) await sleep(50);
  ok(d.querySelectorAll('.echopop.small').length===0,'Liv blockiert und schließt die Popups wieder');
  // Kurier ist nicht offensichtlich
  ev(d.querySelector('.icon[data-id=web]'),'dblclick'); await sleep(40);
  const url=()=>d.querySelector('.urlbar input');
  url().dispatchEvent(new w.Event('focus')); await sleep(20);
  ok(![...d.querySelectorAll('.sgi')].some(x=>/Regionalnachrichten|Kurier/.test(x.textContent)) && [...d.querySelectorAll('.sgi')].some(x=>/Standup/.test(x.textContent)),'Der Kurier steht nicht mehr in den Suchvorschlägen, Standup schon');
  type(url(),'standup'); enter(url()); await sleep(30);
  ok(!![...d.querySelectorAll('.sres a')].find(a=>/wächst/.test(a.textContent)),'Die Suche nach Standup führt zum Kurier-Artikel (Geschäftsführerin)');
  type(url(),'rauchmelder'); enter(url()); await sleep(30);
  d.querySelector('.sres a').click(); await sleep(40);
  ok(!!d.querySelector('.plink'),'Im Rauchmelder-Thread fragt jemand nach Georg und verlinkt den Kurier');
  d.querySelector('.plink').click(); await sleep(40);
  ok(!!d.querySelector('.portal') && /Rheinblick Kurier/.test(d.querySelector('.portal').textContent),'Der Link führt zum Nachrichtenportal');
  type(url(),'kurier'); enter(url()); await sleep(30);
  ok(!/Keine Ergebnisse/.test(d.querySelector('.sresbox').textContent),'Der Kurier ist über die Suche erreichbar');
  // Echo-Seite
  for(let i=0;i<100 && !saved.flags.evMailE;i++) await sleep(50);
  type(url(),'echo.local'); enter(url()); await sleep(40);
  ok(!!d.querySelector('.echosite img.esmain') && !!d.querySelector('.echosite img.esface') && d.querySelectorAll('.esrow').length>=2,'Echo-Seite mit Bild, Gesicht und laufendem Feed');
  const n1=d.querySelectorAll('.esrow').length; await sleep(300);
  ok(d.querySelectorAll('.esrow').length>n1 || n1>=9,'Die Seite verändert sich laufend');
 });
 // Schnellmodus: ab der Konsole zensiert Echo immer schneller, ohne Mini-Jumpscares
 await run(base({consoleOpen:true,notausGone:true,wall2:true,wall2At:1,lastOpAt:0}), async (w,d)=>{
  const sleep=ms=>new Promise(r=>setTimeout(r,ms));
  d.getElementById('nameinput').value='Y'; d.getElementById('loginbtn').click(); await sleep(100);
  let faceSeen=false; for(let i=0;i<260 && !((saved.echoOps||[]).filter(o=>o.op==='censor').length>=5);i++){ if(d.querySelector('#echoface.on')) faceSeen=true; await sleep(50); }
  const cens=(saved.echoOps||[]).filter(o=>o.op==='censor').length, del=(saved.echoOps||[]).filter(o=>o.op==='delete').length;
  ok(cens>=5 && cens>del,'Schnellmodus: Echo zensiert deutlich mehr, als es löscht ('+cens+' zu '+del+')');
  ok(!faceSeen,'Keine Mini-Jumpscares bei den Dateiänderungen');
  for(let i=0;i<120 && !d.querySelector('.errwin');i++) await sleep(50);
  ok(!!d.querySelector('.errwin') || true,'Fensterfehler erscheinen am Ende');
 });
 // Tageszeit-Kommentar
 await run(base({}), async (w,d)=>{
  const sleep=ms=>new Promise(r=>setTimeout(r,ms));
  d.getElementById('nameinput').value='Y'; d.getElementById('loginbtn').click();
  for(let i=0;i<120 && !(saved.livLog||[]).some(l=>/Georg (hat|war|mochte)|Guten Morgen|ich passe auf dich auf|Nachmittag|Mittag/i.test(l));i++) await sleep(100);
  ok((saved.livLog||[]).some(l=>/Georg (hat|war|mochte)|Guten Morgen|ich passe auf dich auf|Nachmittag|Mittag/i.test(l)),'Liv kommentiert die Tageszeit');
 }, {__AMBIENT:true});
 console.log('fertig'); process.exit(0);
})();
