const { JSDOM } = require('jsdom');
let saved = null;
const stub = { info: async()=>({user:'yannik',host:'MAINZ-PC'}), desktopFiles: async()=>[], writeDesktop: async n=>n, fakeRestart: async()=>{}, saveState: async s=>{saved=JSON.parse(JSON.stringify(s));}, loadState: async()=>null, resetState: async()=>{}, quit: async()=>{ saved.__quit=true; } };
const errors=[];
JSDOM.fromFile(require('path').join(__dirname,'..','renderer','index.html'),{runScripts:'dangerously',resources:'usable',pretendToBeVisual:true,
 beforeParse(w){ w.sys=stub; w.__SPEED=0.01; w.Math.random=()=>0.1; w.addEventListener('error',e=>errors.push(e.message)); }})
.then(async dom=>{
  const w=dom.window,d=w.document,sleep=ms=>new Promise(r=>setTimeout(r,ms));
  const ok=(c,m)=>console.log((c?'PASS ':'FAIL ')+m);
  const ev=(el,t)=>el.dispatchEvent(new w.MouseEvent(t,{bubbles:true}));
  const dbl=s=>ev(d.querySelector(s),'dblclick');
  const byText=(s,t)=>[...d.querySelectorAll(s)].find(e=>e.textContent.includes(t));
  const rows=()=>[...d.querySelectorAll('.frow')].map(r=>r.textContent.trim());
  await sleep(900);
  d.getElementById('nameinput').value='Yannik'; d.getElementById('loginbtn').click(); await sleep(50);

  // Startmenü
  ev(d.getElementById('startbtn'),'click'); await sleep(20);
  const sm=[...d.querySelectorAll('.smi')].map(e=>e.textContent.trim());
  ok(!d.getElementById('startmenu').classList.contains('hidden') && sm.some(x=>x.includes('Kalender')) && sm.some(x=>x.includes('Spiel beenden')), 'Startmenü öffnet: '+sm.join(', '));
  byText('.smi','Spiel beenden').click(); await sleep(20);
  ok(saved.__quit===true, 'Startmenü "Spiel beenden" ruft quit');

  // Kalender
  ev(d.getElementById('clock'),'click'); await sleep(20);
  ok(!d.getElementById('calpop').classList.contains('hidden') && d.querySelector('.cd.today'), 'Kalender öffnet, heute markiert');
  ok(/Wartung/.test(d.querySelector('.calev').textContent), 'Termine des Tages sichtbar: '+d.querySelector('.calev').textContent.slice(0,60));
  ev(d.body,'mousedown'); await sleep(10);
  ok(d.getElementById('calpop').classList.contains('hidden'), 'Klick daneben schließt Kalender');

  // Mail-Sortierung
  dbl('.icon[data-id=mail]'); await sleep(30);
  const first=()=>d.querySelector('.mrow b').textContent;
  ok(first()==='Mama','Mail neueste zuerst: '+first());
  const sel=d.querySelector('.mtool select'); sel.value='old'; sel.onchange(); ok(first()==='Marlene','Mail älteste zuerst: '+first());
  sel.value='from'; sel.onchange(); ok(first()==='Jonas (Arbeit)','Mail Absender A–Z: '+first());

  // Browser
  dbl('.icon[data-id=web]'); await sleep(30);
  const titles=[...d.querySelectorAll('.hrow a')].map(a=>a.textContent);
  ok(titles.length===7 && titles[0].includes('marlene') && titles.findIndex(t=>t.includes('sägen'))===4,'Verlauf: Säge ist Eintrag '+(titles.findIndex(t=>t.includes('sägen'))+1)+' von '+titles.length);
  byText('.hrow a','Rauchmelder').click(); await sleep(20);
  ok(d.querySelectorAll('.post').length===5,'Forum zeigt 5 Beiträge mit Avataren');
  d.querySelector('.urlbar button').click();
  byText('.hrow a','Eigene Chat').click(); await sleep(20);
  ok(!!d.querySelector('.qa .qrow'),'Q&A-Seite rendert');

  // Explorer: System vs Papierkorb
  dbl('.icon[data-id=sys]'); await sleep(30); const sysRows=rows();
  dbl('.icon[data-id=trash]'); await sleep(30); const trashRows=rows();
  ok(!sysRows.some(r=>r.includes('anmeldung')) && sysRows.length===2,'System ohne anmeldung.log: '+sysRows.join(' | '));
  ok(trashRows.length===2 && !trashRows.some(r=>r.includes('anmeldung')),'Papierkorb: '+trashRows.join(' | '));

  // Rätselkette -> liv.exe
  dbl('.icon[data-id=docs]'); await sleep(30);
  ev(byText('.frow','privat'),'dblclick'); await sleep(30);
  const pw=d.querySelector('.pw input'); pw.value='bruno2019'; byText('.pw button','Öffnen').click(); await sleep(30);
  ev(byText('.frow','readme_liv.txt'),'dblclick'); await sleep(60);
  ok(!!d.querySelector('.skin-note'),'Datei öffnet im Editor-Stil');
  await sleep(150);
  const ic=d.querySelector('.icon[data-id=liv]');
  ok(!!ic && !ic.classList.contains('liv') && !!ic.querySelector('svg.livface'),'liv.exe-Icon mit Avatar, ohne kollidierende Klasse');

  // Liv öffnen, Erstkontakt
  ev(ic,'dblclick'); await sleep(50);
  ok(!!d.querySelector('.skin-liv svg.livface'),'Liv-Fenster mit Avatar');
  for(let i=0;i<60 && !(saved.flags&&saved.flags.livMet);i++) await sleep(100);
  ok(saved.flags.livMet===true && saved.livLog.length>=9,'Erstkontakt komplett, '+saved.livLog.length+' Zeilen im Log');
  ok(!/Yannik|yannik/.test(saved.livLog.join(' ')),'Liv nennt zu Beginn KEINEN Namen');
  // Versprecher
  for(let i=0;i<80 && !saved.flags.nameSlip;i++) await sleep(100);
  await sleep(300);
  ok(saved.flags.nameSlip===true && saved.livLog.some(l=>l.includes('gegessen, Yannik?')),'Versprecher mit echtem Windows-Namen kam später');
  dbl('.icon[data-id=sys]'); await sleep(30);
  ok(rows().some(r=>r.includes('anmeldung.log')),'anmeldung.log erscheint erst NACH dem Versprecher');

  // Säge
  dbl('.icon[data-id=web]'); await sleep(30);
  d.querySelector('.urlbar button').click();
  byText('.hrow a','Probesägen').click(); await sleep(20);
  ok(d.querySelectorAll('.pruef .opt svg').length===3 && !!d.querySelector('.pruef svg.saw'),'Säge-Seite mit Säge-Grafik und 3 gezeichneten Optionen');
  byText('.opt','Mensch').click(); await sleep(20);
  ok(['black','scareimg'].includes(d.getElementById('overlay').className),'Schwarzbild/Augen-Scare bei Mensch');
  await sleep(150);
  ok(d.getElementById('overlay').className==='hidden' && /notiert/.test(d.querySelector('.pruef').textContent),'danach Abschlusstext');
  ok(saved.traits.haerte===2,'Wert gespeichert');
  console.log('JS-Fehler:',errors.length?errors:'keine');
  process.exit(0);
});
