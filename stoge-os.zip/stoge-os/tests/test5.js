const { JSDOM } = require('jsdom');
let saved=null;
const stub={info:async()=>({user:'yannik',host:'PC'}),desktopFiles:async()=>[],writeDesktop:async n=>n,fakeRestart:async()=>{},saveState:async s=>{saved=JSON.parse(JSON.stringify(s));},loadState:async()=>null,resetState:async()=>{},quit:async()=>{}};
JSDOM.fromFile(require('path').join(__dirname,'..','renderer','index.html'),{runScripts:'dangerously',resources:'usable',pretendToBeVisual:true,
 beforeParse(w){w.sys=stub;w.__SPEED=1;w.Math.random=()=>0.1;}})
.then(async dom=>{
 const w=dom.window,d=w.document,sleep=ms=>new Promise(r=>setTimeout(r,ms));
 const ok=(c,m)=>console.log((c?'PASS ':'FAIL ')+m);
 const byText=(s,t)=>[...d.querySelectorAll(s)].find(e=>e.textContent.includes(t));
 await sleep(900); d.getElementById('nameinput').value='Y'; d.getElementById('loginbtn').click(); await sleep(50);
 d.dispatchEvent(new w.KeyboardEvent('keydown',{key:'D',ctrlKey:true,shiftKey:true})); await sleep(30);
 byText('.dev button','liv.exe sofort').click(); await sleep(30);
 d.querySelector('.icon[data-id=liv]').dispatchEvent(new w.MouseEvent('dblclick',{bubbles:true})); await sleep(60);
 const pup=()=>d.querySelector('.skin-liv .pupil');
 d.dispatchEvent(new w.MouseEvent('mousemove',{clientX:400,clientY:300,bubbles:true})); await sleep(60);
 ok(pup().style.transform==='', 'Augen folgen im Normalzustand NICHT (Transform leer)');
 byText('.dev button','Augen-Scare').click(); await sleep(80);
 ok(pup().style.transform!=='', 'Augen-Scare: Pupillen bewegen sich: '+pup().style.transform);
 await sleep(9500);
 ok(pup().style.transform==='', 'Nach dem Scare wieder normal');
 byText('.dev button','Alle Stufen').click(); await sleep(30);
 d.dispatchEvent(new w.MouseEvent('mousemove',{clientX:500,clientY:200,bubbles:true})); await sleep(60);
 ok(pup().style.transform==='', 'Ab Stufe 1: Augen folgen noch NICHT dauerhaft (Liv bleibt freundlich)');
 byText('.dev button','Phase 2 direkt').click(); await sleep(30);
 d.dispatchEvent(new w.MouseEvent('mousemove',{clientX:520,clientY:210,bubbles:true})); await sleep(60);
 ok(pup().style.transform==='', 'Auch in Phase 2 noch keine dauerhaften Augen');
 byText('.dev button','Augen dauerhaft').click(); await sleep(30);
 d.dispatchEvent(new w.MouseEvent('mousemove',{clientX:540,clientY:220,bubbles:true})); await sleep(60);
 ok(pup().style.transform!=='', 'Nach der Desktop-Berechtigung: Augen dauerhaft aktiv');
 process.exit(0);
});
