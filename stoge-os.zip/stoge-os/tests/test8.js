const { JSDOM } = require('jsdom');
let saved=null, calls=[];
const mk=(load)=>({info:async()=>({user:'yannik',host:'PC'}),desktopFiles:async()=>[],writeDesktop:async(n,c)=>{calls.push(n);return n;},fakeRestart:async()=>{},saveState:async s=>{saved=JSON.parse(JSON.stringify(s));},loadState:async()=>load,resetState:async()=>{},quit:async()=>{}});
const errors=[];
const run=(load,fn)=>JSDOM.fromFile(require('path').join(__dirname,'..','renderer','index.html'),{runScripts:'dangerously',resources:'usable',pretendToBeVisual:true,
 beforeParse(w){w.sys=mk(load);w.__SPEED=0.01;w.addEventListener('error',e=>errors.push(e.message));}}).then(async dom=>{ await new Promise(r=>setTimeout(r,900)); await fn(dom.window,dom.window.document); dom.window.close(); });
const ok=(c,m)=>console.log((c?'PASS ':'FAIL ')+m);
const helpers=(w,d)=>{
  const sleep=ms=>new Promise(r=>setTimeout(r,ms));
  const ev=(el,t)=>el.dispatchEvent(new w.MouseEvent(t,{bubbles:true}));
  const dbl=s=>ev(d.querySelector(s),'dblclick');
  const byText=(s,t)=>[...d.querySelectorAll(s)].find(e=>e.textContent.includes(t));
  const rows=()=>[...d.querySelectorAll('.frow')].map(r=>r.textContent.replace(/^[^A-Za-z_]+/,'').trim());
  const type=(i,v)=>{i.value=v;i.dispatchEvent(new w.Event('input',{bubbles:true}));};
  const enter=i=>i.dispatchEvent(new w.KeyboardEvent('keydown',{key:'Enter',bubbles:true}));
  const dev=async label=>{ if(!d.querySelector('.dev')) d.dispatchEvent(new w.KeyboardEvent('keydown',{key:'D',ctrlKey:true,shiftKey:true})); await sleep(20); byText('.dev button',label).click(); await sleep(30); };
  const login=async()=>{ d.getElementById('nameinput').value='Yannik'; d.getElementById('loginbtn').click(); await sleep(60); };
  return {sleep,ev,dbl,byText,rows,type,enter,dev,login};
};
(async()=>{
 await run(null, async (w,d)=>{
  const {sleep,ev,dbl,byText,rows,type,enter,dev,login}=helpers(w,d);
  await login();
  dbl('.icon[data-id=web]'); await sleep(30);
  const url=()=>d.querySelector('.urlbar input');
  type(url(),'localhost:8080/notaus'); enter(url()); await sleep(20);
  ok(/Verbindung abgelehnt/.test(d.querySelector('.bview').textContent),'Finale-Konsole vor Stufe 3: Verbindung abgelehnt');

  // Reaktionen genau einmal, auch bei mehrfachem Klicken; Notizbuch wird gefüllt
  await dev('Erstkontakt überspringen');
  dbl('.icon[data-id=mail]'); await sleep(30);
  for(let i=0;i<4;i++){ byText('.mrow','Rufst du').click(); await sleep(10); }
  await sleep(500);
  const n=saved.livLog.filter(l=>l.includes('Georgs Mutter')).length;
  ok(n===1,'Reaktion auf die Mama-Mail kommt genau einmal trotz 4 Klicks (n='+n+')');
  dbl('.icon[data-id=nb]'); await sleep(30);
  ok(/Notizbuch/.test(d.querySelector('.nb h3').textContent),'Notizbuch öffnet');
  byText('.mfolder','Spam')?.click;
  d.querySelector('.nbhint').click(); await sleep(20);
  ok(/Gedanke:/.test(d.querySelector('.nb').textContent),'"Ich komme nicht weiter" liefert einen Gedanken: '+(d.querySelector('.nb li.hint')||{}).textContent?.slice(0,50));

  // Liv korrigiert ihre Namensnennung sichtbar
  await dev('Liv: Erstkontakt überspringen');
  await dev('liv.exe sofort');
  dbl('.icon[data-id=liv]'); await sleep(40);
  await dev('Versprecher mit echtem Namen');
  await sleep(40);
  const bub=()=>[...d.querySelectorAll('.livmsg')].map(b=>b.textContent).join(' | ');
  for(let i=0;i<60 && !/gegessen, Yannik\?/.test(bub());i++) await sleep(50);
  ok(/gegessen, Yannik\?/.test(bub()) && !/gegessen, yannik/.test(bub()),'Livs Nachricht wurde im offenen Chat auf den Login-Namen zurückgeändert');

  // Phase 2 Inhalte
  await dev('Phase 2 direkt'); await dev('Alle Stufen'); await dev('Finale freischalten');
  dbl('.icon[data-id=mail]'); await sleep(30);
  byText('.mfolder','Posteingang').click(); await sleep(20);
  ok(!!byText('.mrow','BITTE'),'Marlenes Hilfe-Mail erscheint in Phase 2');
  byText('.mrow','BITTE').click(); await sleep(10);
  ok(!!d.querySelector('.mattach'),'Mail hat Foto-Anhang');
  d.querySelector('.mattach').click(); await sleep(20);
  ok(!!d.querySelector('.skin-viewer img[src="assets/tuer.jpg"]'),'Anhang öffnet das Foto mit der Tür');
  type(url(),'vermisst'); enter(url()); await sleep(20);
  ok(d.querySelectorAll('.sres a').length===2,'Suche "vermisst" liefert beide Zeitungsartikel');
  d.querySelectorAll('.sres a')[0].click(); await sleep(20);
  ok(!!d.querySelector('.news h1') && /vermisst/i.test(d.querySelector('.news h1').textContent),'Zeitungsseite hat eigenes Design');
  // Kern: georg.txt -> Wesen erscheint
  dbl('.icon[data-id=sys]'); await sleep(30);
  ev(byText('.frow','liv_svc'),'dblclick'); await sleep(20);
  ev(byText('.frow','kern'),'dblclick'); await sleep(20);
  let pw=d.querySelector('.pw input'); pw.value=w.eval('STORY.klingelPw()'); byText('.pw button','Öffnen').click(); await sleep(20);
  ok(rows().includes('georg.txt') && rows().includes('marlene.txt'),'Kern zeigt in Phase 2 georg.txt und marlene.txt');
  ok(/wallpaper|wall2/.test(d.getElementById('wall').style.backgroundImage),'Wallpaper vorher: Stufe 1 (Person)');
  ev(byText('.frow','georg.txt'),'dblclick'); await sleep(300);
  ok(/wall3/.test(d.getElementById('wall').style.backgroundImage) && saved.flags.wallStage===2,'Nach georg.txt sitzt das Wesen am See (Stufe 2)');

  // Finale-Konsole
  dbl('.icon[data-id=web]'); await sleep(20);
  type(url(),'localhost:8080/notaus'); enter(url()); await sleep(20);
  ok(!!d.querySelector('.fin .f1'),'Konsole erreichbar nach Stufe 3 (Anmeldung mit Sicherheitsfragen)');
  d.querySelector('.f1').value='Rex'; d.querySelector('.f2').value='140822'; d.querySelector('.f3').value='niemandem'; d.querySelector('.fgo').click();
  ok(/verweigert/.test(d.querySelector('.pwmsg').textContent),'falsche Antwort (Hundename) abgelehnt');
  d.querySelector('.f1').value='Bruno'; d.querySelector('.f2').value='14.08.22'; d.querySelector('.f3').value="Sag's niemandem"; d.querySelector('.fgo').click();
  ok(/verweigert/.test(d.querySelector('.pwmsg').textContent),'Antwort "Sag\'s niemandem" statt letztem Wort abgelehnt');
  d.querySelector('.f3').value='niemandem'; d.querySelector('.fgo').click(); await sleep(20);
  ok(!!d.querySelector('.fp'),'richtige drei Antworten führen zum Dienst');
  d.querySelector('.fp').value='Dokumente'; d.querySelector('.fgo').click();
  ok(/kein Dienst/.test(d.querySelector('.pwmsg').textContent),'falscher Ordner abgelehnt');
  d.querySelector('.fp').value='System/liv_svc'; d.querySelector('.fgo').click(); await sleep(20);
  for(let i=0;i<80 && d.querySelector('.fbtns.hidden');i++) await sleep(50);
  ok(!d.querySelector('.fbtns').classList.contains('hidden') && /Bitte nicht/.test(d.querySelector('.qlt').textContent),'Livs Bitte wird getippt, danach erscheinen Beenden/Abbrechen');
  d.querySelector('.fstop').click();
  for(let i=0;i<120 && d.getElementById('overlay').className!=='epi';i++) await sleep(50);
  ok(saved.flags.ended==='stop' && calls.includes('Danke.txt'),'Ende "Abgeschaltet": Datei Danke.txt auf dem echten Desktop');
  await sleep(1500);
  ok(/Ende: Abgeschaltet/.test(d.getElementById('overlay').textContent) && !!d.querySelector('.epitext button'),'Epilog mit Titel und "Zum Desktop zurück"');
  ok((saved.flags.wallStage||0)===0,'Wallpaper danach wieder leer');
 });

 // zweites Ende
 await run({name:'Yannik',phase:2,flags:{livMet:true,livStarted:true,late:true,p2:true,stage3:true,consoleIn:true,wallStage:2,p2intro:true},livLog:['Georg?','Hallo.'],opened:[],unlocked:[],traits:{naehe:0,haerte:0,neugier:0},clues:[]}, async (w,d)=>{
  const {sleep,dbl,type,enter,login}=helpers(w,d);
  dbl('.icon[data-id=web]'); await sleep(30);
  const url=()=>d.querySelector('.urlbar input');
  type(url(),'localhost:8080/notaus'); enter(url()); await sleep(20);
  ok(!!d.querySelector('.fp'),'Phase 2 Neustart: bereits angemeldet, direkt beim Dienst');
  d.querySelector('.fp').value='liv_svc'; d.querySelector('.fgo').click(); await sleep(20);
  for(let i=0;i<80 && d.querySelector('.fbtns.hidden');i++) await sleep(50);
  d.querySelector('.fstay').click();
  for(let i=0;i<120 && d.getElementById('overlay').className!=='epi';i++) await sleep(50);
  ok(saved.flags.ended==='stay' && calls.includes('Bleib.txt'),'Ende "Bleiben": Datei Bleib.txt auf dem echten Desktop');
 });
 // Phase-2-Start: erste Liv-Zeile wird geschwärzt
 await run({name:'Yannik',phase:2,flags:{livMet:true,livStarted:true,late:true,p2:true,wallStage:1},livLog:['Georg?','Hallo.'],opened:[],unlocked:[],traits:{naehe:0,haerte:0,neugier:0},clues:[]}, async (w,d)=>{
  const sleep=ms=>new Promise(r=>setTimeout(r,ms));
  for(let i=0;i<80 && !/█/.test((saved.livLog||[])[0]||'');i++) await sleep(50);
  ok(/█/.test(saved.livLog[0]) && !saved.livLog.includes('Georg?'),'Phase 2: Livs allererste Nachricht "Georg?" wird nachträglich geschwärzt');
  ok(/wall2/.test(d.getElementById('wall').style.backgroundImage),'Phase 2: Wallpaper zeigt die sitzende Person');
 });
 console.log('JS-Fehler:',errors.length?errors:'keine');
 process.exit(0);
})();
