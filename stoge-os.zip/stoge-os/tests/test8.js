const { JSDOM } = require('jsdom');
let saved=null, calls=[], quitCalled=false;
const mk=(load)=>({info:async()=>({user:'yannik',host:'PC'}),desktopFiles:async()=>[],writeDesktop:async(n,c)=>{calls.push(n);return n;},fakeRestart:async()=>{},saveState:async s=>{saved=JSON.parse(JSON.stringify(s));},loadState:async()=>load,resetState:async()=>{},quit:async()=>{quitCalled=true;}});
const errors=[];
const run=(load,fn)=>JSDOM.fromFile(require('path').join(__dirname,'..','renderer','index.html'),{runScripts:'dangerously',resources:'usable',pretendToBeVisual:true,
 beforeParse(w){w.sys=mk(load);w.__SPEED=0.01;w.__sfxLog=[];w.addEventListener('error',e=>errors.push(e.message));}}).then(async dom=>{ await new Promise(r=>setTimeout(r,1600)); await fn(dom.window,dom.window.document); dom.window.close(); });
const ok=(c,m)=>console.log((c?'PASS ':'FAIL ')+m);
const helpers=(w,d)=>{
  const sleep=ms=>new Promise(r=>setTimeout(r,ms));
  const ev=(el,t)=>el.dispatchEvent(new w.MouseEvent(t,{bubbles:true}));
  const dbl=s=>ev(d.querySelector(s),'dblclick');
  const byText=(s,t)=>[...d.querySelectorAll(s)].find(e=>e.textContent.includes(t));
  const rows=()=>[...d.querySelectorAll('.frow')].map(r=>r.textContent.replace(/^[^A-Za-z_]+/,'').trim());
  const type=(i,v)=>{i.value=v;i.dispatchEvent(new w.Event('input',{bubbles:true}));};
  const enter=i=>i.dispatchEvent(new w.KeyboardEvent('keydown',{key:'Enter',bubbles:true}));
  const dev=async label=>{ if(!d.querySelector('.dev')) d.dispatchEvent(new w.KeyboardEvent('keydown',{key:'D',ctrlKey:true,shiftKey:true})); await sleep(20); byText('.dev button',label).click(); await sleep(30); };
  const login=async()=>{ d.getElementById('nameinput').value='Yannik'; d.getElementById('loginbtn').click(); await sleep(60); };
  return {sleep,ev,dbl,byText,rows,type,enter,dev,login};
};
(async()=>{
 await run(null, async (w,d)=>{
  const {sleep,ev,dbl,byText,rows,type,enter,dev,login}=helpers(w,d);
  await login();
  dbl('.icon[data-id=web]'); await sleep(30);
  const url=()=>d.querySelector('.urlbar input');
  type(url(),'localhost:8080/notaus'); enter(url()); await sleep(20);
  ok(/Verbindung abgelehnt/.test(d.querySelector('.bview').textContent),'Finale-Konsole vor Stufe 3: Verbindung abgelehnt');

  // Reaktionen genau einmal, auch bei mehrfachem Klicken; Notizbuch wird gefüllt
  await dev('Erstkontakt überspringen');
  dbl('.icon[data-id=mail]'); await sleep(30);
  for(let i=0;i<4;i++){ byText('.mrow','Rufst du').click(); await sleep(10); }
  await sleep(500);
  for(let i=0;i<60 && !saved.livLog.some(l=>l.includes('Georgs Mutter'));i++) await sleep(50);
  const n=saved.livLog.filter(l=>l.includes('Georgs Mutter')).length;
  ok(n<=1,'Reaktion auf die Mama-Mail kommt höchstens einmal trotz 4 Klicks (n='+n+')');
  d.getElementById('startbtn').click(); await sleep(20); byText('.smi','Notizbuch').click(); await sleep(30);
  ok(/Notizbuch/.test(d.querySelector('.nb h3').textContent),'Notizbuch öffnet über das Startmenü');
  byText('.mfolder','Spam')?.click;
  d.querySelector('.nbhint').click(); await sleep(20);
  ok(/Gedanke:/.test(d.querySelector('.nb').textContent),'"Ich komme nicht weiter" liefert einen Gedanken: '+(d.querySelector('.nb li.hint')||{}).textContent?.slice(0,50));

  // Liv korrigiert ihre Namensnennung sichtbar
  await dev('Liv: Erstkontakt überspringen');
  await dev('liv.exe sofort');
  dbl('.icon[data-id=liv]'); await sleep(40);
  await dev('Versprecher mit echtem Namen');
  await sleep(40);
  const bub=()=>[...d.querySelectorAll('.livmsg')].map(b=>b.textContent).join(' | ');
  for(let i=0;i<60 && !/erlaubt, Yannik\./.test(bub());i++) await sleep(50);
  ok(/erlaubt, Yannik\./.test(bub()) && !/erlaubt, yannik/.test(bub()),'Livs Nachricht wurde im offenen Chat auf den Login-Namen zurückgeändert');

  // Phase 2 Inhalte
  await dev('Phase 2 direkt'); await dev('Alle Stufen'); await dev('Finale freischalten'); await dev('Wächter verschoben');
  dbl('.icon[data-id=mail]'); await sleep(30);
  byText('.mfolder','Posteingang').click(); await sleep(20);
  ok(!!byText('.mrow','BITTE'),'Marlenes Hilfe-Mail erscheint in Phase 2');
  byText('.mrow','BITTE').click(); await sleep(10);
  ok(!!d.querySelector('.mattach'),'Mail hat Foto-Anhang');
  d.querySelector('.mattach').click(); await sleep(20);
  ok(!!d.querySelector('.skin-viewer img[src="assets/tuer.jpg"]'),'Anhang öffnet das Foto mit der Tür');
  type(url(),'vermisst'); enter(url()); await sleep(20);
  ok(d.querySelectorAll('.sres a').length===0 && !saved.flags.kurierKnown,'Die Zeitungsartikel sind vor dem Link nicht per Suche zu finden');
  type(url(),'standup'); enter(url()); await sleep(20);
  const blog=[...d.querySelectorAll('.sres a')].find(a=>/In eigener Sache/.test(a.textContent)); blog.click(); await sleep(20);
  ok(!!d.querySelector('.bclink') && /Kurier/.test(d.querySelector('.bcomments').textContent),'Nach dem Glitch verlinkt jemand im Kommentar unter dem Standup-Blog den Kurier');
  d.querySelector('.bclink').click(); await sleep(30);
  ok(!!d.querySelector('.portal') && saved.flags.kurierKnown===true,'Der Link führt zum Kurier und schaltet ihn frei');
  type(url(),'vermisst'); enter(url()); await sleep(20);
  ok(d.querySelectorAll('.sres a').length===2,'Danach liefert die Suche \"vermisst\" beide Zeitungsartikel');
  d.querySelectorAll('.sres a')[0].click(); await sleep(20);
  ok(!!d.querySelector('.news h1') && /vermisst/i.test(d.querySelector('.news h1').textContent),'Zeitungsseite hat eigenes Design');
  // Kern: georg.txt -> Wesen erscheint
  dbl('.icon[data-id=sys]'); await sleep(30);
  ev(byText('.frow','echo_svc'),'dblclick'); await sleep(20);
  ev(byText('.frow','kern'),'dblclick'); await sleep(20);
  let pw=d.querySelector('.pw input'); pw.value=w.eval('STORY.klingelPw()'); byText('.pw button','Öffnen').click(); await sleep(20);
  ok(rows().includes('georg.txt') && rows().includes('marlene.txt'),'Kern zeigt in Phase 2 georg.txt und marlene.txt');
  ok(/wallpaper|wall2/.test(d.getElementById('wall').style.backgroundImage),'Wallpaper vorher: Stufe 1 (Person)');
  ev(byText('.frow','georg.txt'),'dblclick'); await sleep(300);
  ok(/wall3/.test(d.getElementById('wall').style.backgroundImage) && saved.flags.wallStage===2,'Nach georg.txt sitzt das Wesen am See (Stufe 2)');

  // Finale-Konsole
  dbl('.icon[data-id=web]'); await sleep(20);
  type(url(),'localhost:8080/notaus'); enter(url()); await sleep(20);
  ok(!!d.querySelector('.fin .f1'),'Konsole erreichbar nach Stufe 3 (Anmeldung mit Sicherheitsfragen)');
  d.querySelector('.f1').value='Rex'; d.querySelector('.f2').value='140822'; d.querySelector('.f3').value='niemandem'; d.querySelector('.fgo').click();
  ok(/verweigert/.test(d.querySelector('.pwmsg').textContent),'falsche Antwort (Hundename) abgelehnt');
  d.querySelector('.f1').value='Bruno'; d.querySelector('.f2').value='14.08.22'; d.querySelector('.f3').value="Sag's niemandem"; d.querySelector('.fgo').click();
  ok(/verweigert/.test(d.querySelector('.pwmsg').textContent),'Antwort "Sag\'s niemandem" statt letztem Wort abgelehnt');
  d.querySelector('.f3').value='niemandem'; d.querySelector('.f4').value='Meier'; d.querySelector('.fgo').click(); await sleep(20);
  ok(/verweigert/.test(d.querySelector('.pwmsg').textContent),'Falscher Nachname der Geschäftsführerin wird abgelehnt (steht im Kurier-Artikel über Standup)');
  d.querySelector('.f4').value='Mertens'; d.querySelector('.fgo').click(); await sleep(20);
  ok(/Sitzung abgelaufen/.test(d.querySelector('.pwmsg').textContent) && !d.querySelector('.fp'),'Erster richtiger Versuch: Liv lässt "versehentlich" die Sitzung ablaufen');
  const logBefore=saved.livLog.length;
  d.querySelector('.f1').value='Bruno'; d.querySelector('.f2').value='14.08.22'; d.querySelector('.f3').value='niemandem'; d.querySelector('.f4').value='Mertens'; d.querySelector('.fgo').click(); await sleep(20);
  ok(/Verbindung wird neu aufgebaut/.test(d.querySelector('.fin').textContent) && !d.querySelector('.fp'),'Zweiter Versuch: Der Dienst meldet sich noch nicht, die Infiltration läuft (Formular gesperrt)');
  for(let i=0;i<20 && !d.querySelector('.livwin');i++) await sleep(50);
  ok(!!d.querySelector('.livwin'),'Livs Fenster öffnet sich von selbst, um zu warnen');
  for(let i=0;i<400 && !saved.flags.infiltrated;i++) await sleep(50);
  ok(saved.flags.infiltrated===true && saved.flags.echoLiv===true,'Infiltration abgeschlossen: Echo hat Livs Interface übernommen');
  ok(!!d.querySelector('.livwin.echomode .facestage img.fs-face') && /ECHO/.test(d.querySelector('.livhead').textContent),'Livs Fenster zeigt jetzt Echos Gesicht und Namen');
  ok(saved.livLog.includes('Du sitzt zu nah am Bildschirm.') && !saved.livLog.includes('Hallo.') && !saved.livLog.includes('Hallo. Ich bin Liv.') && !saved.livLog.includes('Georgs Mutter macht sich Sorgen. Wenn wir etwas finden, sollte sie es erfahren.'),'Chatverlauf wurde großteils geleert und mit Unheimlichem gefüllt (vorher '+logBefore+', jetzt '+saved.livLog.length+' Zeilen)');
  ok((saved.livEdits||[]).some(e=>/Chatverlauf/.test(e.o)),'Die Änderung am Chatverlauf steht in der Beweis-Tabelle');
  ok(!!d.querySelector('.fp') && /liv\.exe/.test(d.querySelector('.fin').textContent) && /Echo/.test(d.querySelector('.fin').textContent) && /anti_virus_limit \(liv\)/.test(d.querySelector('.fin').textContent),'Danach öffnet sich die Dienstverwaltung; Tabelle zeigt liv.exe als Ursprung von Echo und den Schutzdienst anti_virus_limit (liv)');
  d.dispatchEvent(new w.KeyboardEvent('keydown',{key:'Escape',ctrlKey:true,shiftKey:true,bubbles:true})); await sleep(40);
  ok([...d.querySelectorAll('.tmt tbody tr')].some(r=>r.dataset.n==='anti_virus_limit'),'Task-Manager listet anti_virus_limit');
  [...d.querySelectorAll('.win')].filter(x=>/Task-Manager/.test(x.querySelector('.titlebar span').textContent)).forEach(x=>x.querySelector('.wbtns button:last-child').click());
  d.querySelector('.fp').value='Dokumente'; d.querySelector('.fgo').click();
  ok(/kein Dienst/.test(d.querySelector('.pwmsg').textContent),'falscher Ordner abgelehnt');
  d.querySelector('.fp').value='System/echo_svc'; d.querySelector('.fgo').click(); await sleep(20);
  for(let i=0;i<200 && d.querySelector('.fbtns.hidden');i++) await sleep(50);
  ok(!d.querySelector('.fbtns').classList.contains('hidden') && /Du willst mich beenden, yannik/.test(d.querySelector('.qlt').textContent) && /physisch/.test(d.querySelector('.qlt').textContent) && !/[Bb]itte/.test(d.querySelector('.qlt').textContent) && /Echo/.test(d.querySelector('.quizliv small').textContent),'Echo (nicht Liv) ist selbstsicher und arrogant und bettelt nicht');
  ok(d.querySelector('.fstop').textContent==='Beenden' && /anti_virus_limit \(liv\)/.test(d.querySelector('.ftarget').textContent),'Auf dem fliehenden Knopf steht nur \"Beenden\", das Ziel steht darüber');
  const fst=d.querySelector('.fstop');
  fst.dispatchEvent(new w.MouseEvent('click',{bubbles:true})); await sleep(20);
  ok(saved.flags.ended!=='stop','Beenden-Knopf ist anfangs nicht klickbar (flieht)');
  const before=fst.style.left+'/'+fst.style.top;
  d.querySelector('.fin').dispatchEvent(new w.MouseEvent('mousemove',{clientX:1,clientY:1,bubbles:true})); await sleep(20);
  ok(fst.style.position==='absolute' || before==='/', 'Knopf wird im Fenster verschoben');
  [...d.querySelectorAll('.icon')].slice(0,5).forEach(i=>i.dispatchEvent(new w.MouseEvent('dblclick',{bubbles:true})));
  let hung=false; for(let i=0;i<300 && !hung;i++){ if(d.querySelector('.fin.hung')){ hung=/reagiert nicht/.test(d.querySelector('.fstat').textContent); if(hung) fst.dispatchEvent(new w.MouseEvent('click',{bubbles:true})); } else await sleep(10); }
  ok(hung,'Viele geöffnete Fenster lassen Liv hängen, dann ist der Knopf klickbar');
  for(let i=0;i<120 && !d.querySelector('.livwin:not(.echomode)');i++) await sleep(50);
  ok(!!d.querySelector('.livwin:not(.echomode)') && !saved.flags.echoLiv,'Liv verwandelt sich in ihre normale Form zurück');
  for(let i=0;i<200 && ![...d.querySelectorAll('.livmsg')].some(b=>/Hahahahaha/.test(b.textContent));i++) await sleep(25);
  ok([...d.querySelectorAll('.livmsg')].some(b=>/Hahahahaha/.test(b.textContent)),'Liv lacht');
  let maxTerm=0; for(let i=0;i<500 && !calls.includes('ich bin noch da.txt');i++){ maxTerm=Math.max(maxTerm,d.querySelectorAll('.vw-term').length); await sleep(25); }
  ok(maxTerm>=4,'Mehrere Terminal-Fenster öffnen sich während des Monologs ('+maxTerm+')');
  ok(saved.livLog.some(l=>/Das war so einfach/.test(l)) && saved.livLog.some(l=>/03:12 wirst du aufwachen/.test(l)),'Livs Monolog und die Drohung am Ende wurden gesprochen');
  ok(w.__sfxLog.includes('b'),'Der finale Jumpscare spielt den langen Schrei-Clip');
  ok(saved.flags.ended==='stop' && calls.includes('ich bin noch da.txt'),'Normales Ende: gruselige Datei auf dem echten Desktop');
  for(let i=0;i<300 && !quitCalled;i++) await sleep(50);
  ok(quitCalled && w.__over===true,'Das Spiel beendet sich nach dem Ende von selbst');
  const logAtEnd=w.__sfxLog.length; await sleep(300);
  ok(w.__sfxLog.length===logAtEnd && w.__hush===true,'Nach dem Ende kommen keine Soundeffekte mehr');
 });

 // Abbrechen und wahres Ende (Notfallcode)
 quitCalled=false; calls.length=0;
 await run({name:'Yannik',phase:2,flags:{livMet:true,livStarted:true,late:true,p2:true,stage3:true,consoleIn:true,consoleTried:true,infilStarted:true,infiltrated:true,echoLiv:true,wallStage:2,p2intro:true,echoIntro:true},livLog:['Ich habe alles gelesen, was du gelesen hast.'],grants:{anzeige:{at:1,by:'Yannik',label:'Webseiten scannen, bereinigen und anzeigen'}},opened:[],unlocked:[],traits:{naehe:0,haerte:0,neugier:0},clues:[]}, async (w,d)=>{
  const {sleep,dbl,type,enter,byText}=helpers(w,d);
  dbl('.icon[data-id=web]'); await sleep(30);
  const url=()=>d.querySelector('.urlbar input');
  type(url(),'localhost:8080/notaus'); enter(url()); await sleep(20);
  ok(!!d.querySelector('.fp'),'Phase 2 Neustart: bereits angemeldet, direkt beim Dienst');
  d.querySelector('.fp').value='echo_svc'; d.querySelector('.fgo').click(); await sleep(20);
  for(let i=0;i<200 && d.querySelector('.fbtns.hidden');i++) await sleep(50);
  d.querySelector('.fstay').click(); await sleep(30);
  ok(!!d.querySelector('.fp') && !saved.flags.ended,'Abbrechen führt zurück zur Dienstverwaltung (kein Ende)');
  d.querySelector('.fp').value='KIRSCH-2412'; d.querySelector('.fgo').click();
  ok(/kein Dienst/.test(d.querySelector('.pwmsg').textContent),'Unvollständiger Notfallcode wird abgelehnt');
  d.querySelector('.fp').value='kirsch 2412 ufer'; d.querySelector('.fgo').click(); await sleep(60);
  ok(saved.flags.ended==='good','Der vollständige Notfallcode (statt des Ordnernamens) startet die Systembereinigung');
  const stages=[]; const seen=()=>{ const st=d.querySelector('.facestage'); if(st) ['nomouth','noface','blink','noeyes'].forEach(c=>{ if(st.classList.contains(c) && !stages.includes(c)) stages.push(c); }); };
  let chatEmptyBeforeMouth=false;
  for(let i=0;i<900 && !calls.includes('echo_backup');i++){ seen(); const st=d.querySelector('.facestage'); if(st && st.classList.contains('nomouth') && !chatEmptyBeforeMouth) chatEmptyBeforeMouth = d.querySelectorAll('.livmsg').length===0; await sleep(15); }
  ok(chatEmptyBeforeMouth,'Erst werden die Chatnachrichten entfernt, dann der Mund');
  ok(stages.join(',')==='nomouth,noface,blink,noeyes' || stages.join(',')==='nomouth,noface,blink','Danach Mund, Gesicht, Augen in dieser Reihenfolge ('+stages.join(', ')+')');
  ok(w.__sfxLog.includes('e') && w.__sfxLog.includes('f'),'Liv/Echo schreit dabei (Clips e und f)');
  ok(calls.includes('echo_backup'),'Gutes Ende: echo_backup liegt als echte Datei auf dem Desktop');
  ok(!d.querySelector('.livwin') && saved.flags.echoLiv===false,'Liv-Fenster und Logo sind komplett entfernt');
  for(let i=0;i<300 && !quitCalled;i++) await sleep(50);
  ok(quitCalled && w.__over===true,'Das Spiel beendet sich nach dem guten Ende von selbst');
 });
 // Phase-2-Start: erste Liv-Zeile wird geschwärzt
 await run({name:'Yannik',phase:2,flags:{livMet:true,livStarted:true,late:true,p2:true,wallStage:1},livLog:['Georg?','Hallo.'],opened:[],unlocked:[],traits:{naehe:0,haerte:0,neugier:0},clues:[]}, async (w,d)=>{
  const sleep=ms=>new Promise(r=>setTimeout(r,ms));
  for(let i=0;i<80 && !/█/.test((saved.livLog||[])[0]||'');i++) await sleep(50);
  ok(/█/.test(saved.livLog[0]) && !saved.livLog.includes('Georg?'),'Phase 2: Livs allererste Nachricht "Georg?" wird nachträglich geschwärzt');
  ok(/wall2/.test(d.getElementById('wall').style.backgroundImage),'Phase 2: Wallpaper zeigt die sitzende Person');
 });
 console.log('JS-Fehler:',errors.length?errors:'keine');
 process.exit(0);
})();
