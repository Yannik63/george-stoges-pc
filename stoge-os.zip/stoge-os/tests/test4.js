const { JSDOM } = require('jsdom');
let saved=null;
const stub={info:async()=>({user:'yannik',host:'PC'}),desktopFiles:async()=>[],writeDesktop:async n=>n,fakeRestart:async()=>{},saveState:async s=>{saved=JSON.parse(JSON.stringify(s));},loadState:async()=>null,resetState:async()=>{},quit:async()=>{}};
const errors=[];
JSDOM.fromFile(require('path').join(__dirname,'..','renderer','index.html'),{runScripts:'dangerously',resources:'usable',pretendToBeVisual:true,
 beforeParse(w){w.sys=stub;w.__SPEED=0.01;w.Math.random=()=>0.1;w.addEventListener('error',e=>errors.push(e.message));}})
.then(async dom=>{
 const w=dom.window,d=w.document,sleep=ms=>new Promise(r=>setTimeout(r,ms));
 const ok=(c,m)=>console.log((c?'PASS ':'FAIL ')+m);
 const ev=(el,t)=>el.dispatchEvent(new w.MouseEvent(t,{bubbles:true}));
 const dbl=s=>ev(d.querySelector(s),'dblclick');
 const byText=(s,t)=>[...d.querySelectorAll(s)].find(e=>e.textContent.includes(t));
 const rows=()=>[...d.querySelectorAll('.frow')].map(r=>r.textContent.replace(/^[^A-Za-z_]+/,'').trim());
 const type=(inp,v)=>{inp.value=v; inp.dispatchEvent(new w.Event('input',{bubbles:true}));};
 const enter=inp=>inp.dispatchEvent(new w.KeyboardEvent('keydown',{key:'Enter',bubbles:true}));
 await sleep(900); d.getElementById('nameinput').value='Y'; d.getElementById('loginbtn').click(); await sleep(50);

 ok(!!d.getElementById('wall'),'Wallpaper-Ebene vorhanden');
 ok(d.querySelectorAll('.icon').length===7 && !!d.querySelector('.icon[data-id=pics]'),'Desktop hat Bilder-Icon (7 Icons)');

 // Augen: standardmäßig aus
 // Bilder + Foto-Datum
 dbl('.icon[data-id=pics]'); await sleep(30);
 ok(rows().includes('IMG_0412.jpg') && !rows().includes('privat'),'Bilder: Foto da, privat-Ordner noch nicht');
 ev(byText('.frow','IMG_0412'),'dblclick'); await sleep(30);
 ok(!!d.querySelector('.skin-viewer img') && /14\/08\/'22/.test(d.querySelector('.stamp').textContent),'Bildbetrachter zeigt Foto mit Kodak-Datum');
 d.querySelector('.imgprop').click();
 ok(/14\.08\.2022/.test(d.querySelector('.imgprops').textContent) && !d.querySelector('.imgprops').classList.contains('hidden'),'Eigenschaften zeigen Aufnahmedatum');

 // Dateivarianten
 dbl('.icon[data-id=docs]'); await sleep(30);
 ev(byText('.frow','todo.txt'),'dblclick'); await sleep(20);
 ok(!!d.querySelector('.skin-sticky .vw-sticky'),'todo.txt als Klebezettel');
 ev(byText('.frow','Rechnungen'),'dblclick'); await sleep(20);
 ev(byText('.frow','tierarzt_rechnung'),'dblclick'); await sleep(20);
 ok(!!d.querySelector('.skin-doc .vw-doc'),'Rechnung als Dokument');

 // Mails: Prüfstein-Logik
 dbl('.icon[data-id=mail]'); await sleep(30);
 byText('.mfolder','Spam').click(); await sleep(20);
 let spam=[...d.querySelectorAll('.mrow')].map(r=>r.textContent);
 ok(spam.length===2 && spam.some(s=>s.includes('Gewinnen Sie eine Säge')) && !spam.some(s=>s.includes('Auswahl wurde gespeichert')),'Spam vor dem Test: nur die Werbemail');
 byText('.mrow','Gewinnen Sie').click(); await sleep(10);
 ok(/PS-7291/.test(d.querySelector('.mbody').textContent) && /pruefstein\.net\/code/.test(d.querySelector('.mbody').textContent),'Werbemail enthält Code und Adresse');

 // Browser: Eingabe, Code-Kette
 dbl('.icon[data-id=web]'); await sleep(30);
 const url=()=>d.querySelector('.urlbar input');
 url().dispatchEvent(new w.Event('focus')); await sleep(10);
 ok(d.querySelectorAll('.sgi').length===4 && !d.querySelector('.sugg').classList.contains('hidden'),'Vorschlagsliste ohne Liebestest (4), solange Liv nicht da ist');
 type(url(),'liebestest'); enter(url()); await sleep(10);
 ok(/Keine Ergebnisse/.test(d.querySelector('.sresbox').textContent),'Liebestest per Suche gesperrt ohne Liv');
 type(url(),'pruefstein.net/code'); enter(url()); await sleep(20);
 ok(!!d.querySelector('.pform input'),'Adresse eintippen öffnet Code-Seite');
 type(d.querySelector('.pform input'),'falsch'); d.querySelector('.frmrow button').click();
 ok(/ungültig/.test(d.querySelector('.pwmsg').textContent),'falscher Code abgelehnt');
 type(d.querySelector('.pform input'),'PS-7291'); d.querySelector('.frmrow button').click(); await sleep(20);
 ok(!!d.querySelector('.blurimg') && /TTMMJJ/.test(d.querySelector('.pform').textContent),'richtiger Code führt zum Erinnerungstest mit verpixeltem Foto');
 type(d.querySelector('.pform input'),'010101'); d.querySelector('.frmrow button').click();
 ok(/falsch/.test(d.querySelector('.pwmsg').textContent),'falsches Datum abgelehnt');
 type(d.querySelector('.pform input'),'140822'); d.querySelector('.frmrow button').click(); await sleep(30);
 ok(saved.flags.foto2===true && /Richtig/.test(d.querySelector('.pform').textContent),'richtiges Datum aus dem Foto löst Rätsel');
 dbl('.icon[data-id=pics]'); await sleep(30);
 ok(rows().includes('privat'),'Bilder/privat erscheint nach dem Rätsel');
 ev(byText('.frow','privat'),'dblclick'); await sleep(20);
 ok(rows().includes('sprachnachricht_marlene.txt'),'Sprachnachricht liegt im neuen Ordner');

 // Suche und Begriff
 url().focus; type(url(),'Stoppschalter'); enter(url()); await sleep(20);
 ok(d.querySelectorAll('.sres a').length===1,'Suche "Stoppschalter" liefert 1 Treffer');
 d.querySelector('.sres a').click(); await sleep(20);
 ok(d.querySelectorAll('.post').length===5 && /STOP/.test(d.querySelector('.forum').textContent),'Treffer öffnet Forum mit STOP-Datei-Hinweis');
 type(url(),'asdfgh'); enter(url()); await sleep(10);
 ok(/Keine Ergebnisse/.test(d.querySelector('.sresbox').textContent),'Unbekannter Begriff: keine Ergebnisse');
 type(url(),'marlene'); enter(url()); await sleep(10);
 d.querySelectorAll('.sres a')[0].click(); await sleep(20);
 ok(!!d.querySelector('.prof img.big'),'Marlenes Profilseite mit Profilbild');

 // Liebestest (erst nach Liv)
 d.dispatchEvent(new w.KeyboardEvent('keydown',{key:'D',ctrlKey:true,shiftKey:true})); await sleep(30);
 byText('.dev button','Erstkontakt überspringen').click(); await sleep(20);
 d.dispatchEvent(new w.KeyboardEvent('keydown',{key:'D',ctrlKey:true,shiftKey:true})); await sleep(30);
 type(url(),'liebestest'); enter(url()); await sleep(10);
 d.querySelector('.sres a').click(); await sleep(20);
 for(let i=0;i<4;i++){ d.querySelector('.qopt').click(); await sleep(10); }
 ok(/Ergebnis:/.test(d.querySelector('.pquiz').textContent) && saved.flags.liebestest===true,'Liebestest läuft durch und zeigt Ergebnis');

 // Säge -> erst danach die Spam-Mail
 type(url(),'pruefstein'); enter(url()); await sleep(10);
 d.querySelectorAll('.sres a')[0].click(); await sleep(20);
 byText('.opt','Baum').click(); await sleep(20);
 ok(!!saved.flags.saegeAt,'Säge-Zeitpunkt gespeichert');
 d.querySelector('.win.skin-mail .wbtns button:last-child').click();
 dbl('.icon[data-id=mail]'); await sleep(30);
 byText('.mfolder','Spam').click(); await sleep(20);
 spam=[...d.querySelectorAll('.mrow')].map(r=>r.textContent);
 ok(spam.length===3 && spam.some(s=>s.includes('Auswahl wurde gespeichert')),'Nach dem Test erscheint die "Auswahl gespeichert"-Mail im Spam');
 ok([...d.querySelectorAll('.svg.livface .pupil')].length===0,'(Augen-Check übersprungen: Liv noch nicht offen)');

 // Dev: Wallpaper-Glitch
 d.dispatchEvent(new w.KeyboardEvent('keydown',{key:'D',ctrlKey:true,shiftKey:true})); await sleep(30);
 byText('.dev button','Wallpaper').click(); await sleep(120);
 ok(true,'Wallpaper-Glitch lief ohne Fehler');
 console.log('JS-Fehler:',errors.length?errors:'keine');
 process.exit(0);
});
