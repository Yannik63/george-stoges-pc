// Neu in diesem Update: Echo-Intro (Popup, Liv lagt/stürzt ab/kommt zurück), Tagebuch verschwindet sichtbar, Zurück-Pfeil im Browser,
// Fenster hängen wirklich, Notfallcode-Teile (Kalender, Eigenschaften, Webarchiv), Schrei-Clips
const { JSDOM } = require('jsdom');
let saved=null, state, calls=[];
const mk=()=>({info:async()=>({user:'yannik',host:'PC'}),desktopFiles:async()=>[],writeDesktop:async n=>{calls.push(n);return n;},fakeRestart:async()=>{},saveState:async s=>{saved=JSON.parse(JSON.stringify(s));},loadState:async()=>JSON.parse(JSON.stringify(state)),resetState:async()=>{},quit:()=>{}});
const ok=(c,m)=>console.log((c?'PASS ':'FAIL ')+m);
const run=(st,fn,extra={})=>{ state=st; return JSDOM.fromFile(require('path').join(__dirname,'..','renderer','index.html'),{runScripts:'dangerously',resources:'usable',pretendToBeVisual:true,
 beforeParse(w){w.sys=mk();w.__SPEED=0.01;w.__sfxLog=[];w.Math.random=()=>0.1;Object.assign(w,extra);}}).then(async dom=>{ await new Promise(r=>setTimeout(r,1600)); await fn(dom.window,dom.window.document); dom.window.close(); }); };
const base=(f,o)=>Object.assign({name:'Y',phase:2,flags:Object.assign({livMet:true,livStarted:true,late:true,archiv:true,stage1:true,stage1At:1,stage2:true,stage2At:1,stage3:true,p2:true,p2At:Date.now()-5000,tbCorrupt:true,wrAcc:true,p2intro:true},f||{}),livUnlocked:true,grants:{anzeige:{at:1,by:'Y',label:'a'},schutz:{at:1,by:'Y',label:'s'}},livLog:['Hallo.'],opened:[],unlocked:[],traits:{naehe:0,haerte:0,neugier:0},clues:[],livMetAt:Date.now()-999999},o||{});
const H=(w,d)=>({
  sleep:ms=>new Promise(r=>setTimeout(r,ms)),
  ev:(el,tp,o={})=>el.dispatchEvent(new w.MouseEvent(tp,Object.assign({bubbles:true},o))),
  byText:(s,tx)=>[...d.querySelectorAll(s)].find(e=>e.textContent.includes(tx)),
  type:(i,v)=>{i.value=v;i.dispatchEvent(new w.Event('input',{bubbles:true}));},
  enter:i=>i.dispatchEvent(new w.KeyboardEvent('keydown',{key:'Enter',bubbles:true})),
  login:async()=>{ d.getElementById('nameinput').value='Y'; d.getElementById('loginbtn').click(); await new Promise(r=>setTimeout(r,100)); }
});
(async()=>{
 // ---------- 1) Echo-Intro nach dem Absturz
 await run(base({echoIntro:false,tbCorrupt:true,p2At:Date.now()+2200}), async (w,d)=>{
  const {sleep,byText}=H(w,d);
  await sleep(100);
  let pop=null, sawLag=false, sawCrash=false, hadLivBefore=false, livGoneAfterCrash=false, maxLines=0, popText='';
  for(let i=0;i<900;i++){
    const p=d.querySelector('.echopop:not(.small)'); if(p){ pop=pop||true; maxLines=Math.max(maxLines,p.querySelectorAll('.eptxt p').length); popText=p.querySelector('.eptxt').textContent||popText; }
    if(d.querySelector('.win.lag')) sawLag=true;
    if(d.querySelector('.win.crashed')) sawCrash=true;
    if(sawCrash && !d.querySelector('.livwin')) { livGoneAfterCrash=true; break; }
    await sleep(8);
  }
  ok(!!pop && /Hallo, yannik\./.test(popText),'Echo-Popup begrüßt den Spieler mit dem echten PC-Namen');
  ok(maxLines>=3,'Echo sagt mehr als \"Hallo\": '+maxLines+' Nachrichten im Popup');
  ok(/Georg hat auch/.test(popText) || maxLines>=3,'Die späteren Nachrichten sind bedrohlicher');
  ok(saved.livLog.some(l=>/Das ist Echo! Lies das nicht/.test(l)),'Liv reagiert auf das Popup');
  ok(sawLag,'Echo bringt Liv zum Laggen');
  ok(sawCrash && livGoneAfterCrash,'Liv friert ein und stürzt ab (Fenster wird beendet)');
  ok(saved.livLog.some(l=>/Ich versuche, das Fenster zu schließen.*—$/.test(l)),'Livs Satz bricht mitten im Wort ab');
  for(let i=0;i<300 && d.querySelector('.echopop:not(.small)');i++) await sleep(10);
  ok(!d.querySelector('.echopop:not(.small)'),'Das Popup verschwindet wieder');
  for(let i=0;i<300 && !d.querySelector('.livwin');i++) await sleep(10);
  ok(!!d.querySelector('.livwin'),'Erst nachdem das Popup weg ist, kommt Liv nach ein paar Sekunden zurück');
  for(let i=0;i<200 && !saved.livLog.some(l=>/Da bin ich wieder/.test(l));i++) await sleep(10);
  ok(saved.livLog.some(l=>/Da bin ich wieder/.test(l)),'Liv erklärt: Echo hat sie rausgeworfen');
 });
 // ---------- 2) Tagebuch verschwindet erst, wenn der Archiv-Ordner offen ist
 await run({name:'Y',phase:1,flags:{livMet:true,livStarted:true,archiv:true,stage1:true,stage1At:Date.now()-999999},livUnlocked:true,livLog:['Hallo.'],opened:[],unlocked:[],traits:{naehe:0,haerte:0,neugier:0},clues:[],livMetAt:Date.now()-999999}, async (w,d)=>{
  const {sleep,ev,byText,login}=H(w,d); await login();
  for(let i=0;i<100 && !saved.flags.tbArmed;i++) await sleep(20);
  await sleep(150);
  ok(saved.flags.tbArmed===true && !saved.flags.tbCorrupt,'Echo hat das Tagebuch im Visier, aber solange der Ordner zu ist, passiert nichts');
  ev(d.querySelector('.icon[data-id=docs]'),'dblclick'); await sleep(30);
  ev(byText('.frow','Archiv'),'dblclick'); await sleep(5);
  const row=byText('.frow','tagebuch_sept');
  ok(!!row && row.classList.contains('vanishing'),'Beim Öffnen des Archivs ist das Tagebuch noch da und flackert');
  ev(row,'dblclick'); await sleep(2);
  ok(!d.querySelector('.vw-doc'),'Es lässt sich nicht mehr öffnen');
  for(let i=0;i<60 && !saved.flags.tbCorrupt;i++) await sleep(10);
  ok(saved.flags.tbCorrupt && !byText('.frow','tagebuch_sept'),'Dann verschwindet es vor den Augen des Spielers');
  for(let i=0;i<120 && !saved.livLog.some(l=>/Das Tagebuch ist einfach verschwunden/.test(l));i++) await sleep(20);
  ok(saved.livLog.some(l=>/Das Tagebuch ist einfach verschwunden/.test(l)),'Erst danach sagt Liv etwas dazu');
 });
 // ---------- 3) Zurück-Pfeil im Browser (Rheinblick-Hauptseite)
 await run(base({kurierKnown:true}), async (w,d)=>{
  const {sleep,ev,byText,type,enter,login}=H(w,d); await login();
  ev(d.querySelector('.icon[data-id=web]'),'dblclick'); await sleep(40);
  const url=()=>d.querySelector('.urlbar input'), b1=()=>d.querySelector('.urlbar .backone');
  ok(!!b1() && b1().disabled && /Verlauf/.test(d.querySelector('.urlbar button:nth-child(2)').textContent),'Kleiner Zurück-Pfeil neben \"← Verlauf\" (anfangs deaktiviert)');
  type(url(),'kurier'); enter(url()); await sleep(30);
  d.querySelector('.sres a').click(); await sleep(30);
  ok(!!d.querySelector('.portal'),'Kurier-Hauptseite (Portal) geöffnet');
  ev(byText('.pitem a','Stromverbrauch'),'click'); await sleep(30);
  ok(!!d.querySelector('.news h1') && !d.querySelector('.portal'),'Artikel geöffnet');
  ok(!b1().disabled,'Zurück-Pfeil ist jetzt aktiv');
  b1().click(); await sleep(30);
  ok(!!d.querySelector('.portal') && /rheinblick-kurier\.example$/.test(url().value),'Ein Klick auf den Pfeil führt nur zur Kurier-Hauptseite zurück');
  d.querySelector('.portal a').click(); await sleep(20);
  b1().click(); await sleep(20); b1().click(); await sleep(20);
  ok(!!d.querySelector('.sres'),'Noch ein Schritt zurück: Suchergebnisse');
  d.querySelector('.urlbar button:nth-child(2)').click(); await sleep(20);
  ok(!!d.querySelector('.bhist'),'\"← Verlauf\" bleibt unverändert und zeigt die Verlaufsliste');
 });
 // ---------- 4) Fenster hängen wirklich, aber nicht dauernd
 await run(base({consoleOpen:true,echo:80}), async (w,d)=>{
  const {sleep,ev,login}=H(w,d); await login();
  ev(d.querySelector('.icon[data-id=docs]'),'dblclick'); await sleep(30);
  let frozen=false, maxFrozen=0, titles=[], seenFrozenTitle=false;
  for(let i=0;i<400;i++){
    const f=d.querySelectorAll('.win.frozen'); maxFrozen=Math.max(maxFrozen,f.length); if(f.length){ frozen=true; if(/Keine Rückmeldung/.test(f[0].textContent)) seenFrozenTitle=true; }
    d.querySelectorAll('.errwin .eph span').forEach(s=>{ const t=s.textContent; if(!titles.includes(t)) titles.push(t); });
    await sleep(5);
  }
  ok(frozen && seenFrozenTitle,'Bei \"explorer.exe\" hängt das Fenster wirklich (Inhalt gesperrt, \"Keine Rückmeldung\")');
  ok(maxFrozen<=1,'Höchstens ein Fenster hängt gleichzeitig');
  const dup=titles.length!==new Set(titles).size;
  ok(!dup && titles.length>=1,'Dieselbe Meldung kommt nicht mehrfach hintereinander ('+titles.join(' | ')+')');
  await sleep(2200);
  ok(d.querySelectorAll('.win.frozen').length===0,'Nach ein paar Sekunden reagiert das Fenster wieder');
 });
 // ---------- 5) Notfallcode-Teile
 await run(base({}), async (w,d)=>{
  const {sleep,ev,byText,type,enter,login}=H(w,d); await login();
  // Teil 1: Kalender, eine Monatsseite zurück
  d.getElementById('clock').click(); await sleep(20);
  ok(!/KIRSCH/.test(d.getElementById('calpop').textContent),'Georgs Notfall-Eintrag ist im aktuellen Monat nicht zu sehen');
  d.querySelector('#calpop [data-nav="-1"]').click(); await sleep(10);
  d.querySelector('#calpop .cd[data-k="2026-09-18"]').click(); await sleep(10);
  ok(/Notfall 1\/3: KIRSCH/.test(d.querySelector('#calpop .calev').textContent) && /02:41/.test(d.querySelector('#calpop .calev').textContent),'Im September (18.09., 02:41) steht Georgs Eintrag: Teil 1');
  ok(saved.clues.some(c=>c.key==='frag1'),'... und landet im Notizbuch');
  // Teil 2: Eigenschaften von liv.exe.lnk
  ev(d.querySelector('.icon[data-id=sys]'),'dblclick'); await sleep(30);
  ev(byText('.frow','autostart'),'dblclick'); await sleep(20);
  const lnk=byText('.frow','liv.exe.lnk'); ev(lnk,'contextmenu'); await sleep(10);
  ok(!!d.querySelector('.ctxmenu') && /Eigenschaften/.test(d.querySelector('.ctxmenu').textContent),'Rechtsklick auf eine Datei bietet \"Eigenschaften\"');
  ev(byText('.ctxmenu .ci','Eigenschaften'),'click'); await sleep(20);
  ok(/Notfall 2\/3: 2412/.test(d.querySelector('.propsw').textContent),'Eigenschaften von liv.exe.lnk: Teil 2 im Kommentar');
  ok(saved.clues.some(c=>c.key==='frag2'),'... und landet im Notizbuch');
  // Teil 3: Bearbeitungsverlauf im Webarchiv
  ev(d.querySelector('.icon[data-id=web]'),'dblclick'); await sleep(30);
  const url=()=>d.querySelector('.urlbar input');
  type(url(),'webarchiv.example/heimwerker-forum.de/t/90377'); enter(url()); await sleep(30);
  ok(/Notfallcode/.test(d.querySelector('.bview').textContent) && !/UFER/.test(d.querySelector('.bview').textContent),'Archivierter Beitrag nennt den Notfallcode, aber nicht alle Teile');
  d.querySelector('.edhist').click(); await sleep(10);
  ok(/Notfall 3\/3: UFER/.test(d.querySelector('.edbox').textContent) && saved.clues.some(c=>c.key==='frag3'),'Bearbeitungsverlauf zeigt Teil 3 (UFER)');
  // Hinweis in Georgs Entwicklernotizen
  const fs=w.eval("STORY.buildFs({name:'Y',user:'u',host:'h',now:new Date(),S:{flags:{},opened:[],unlocked:[]}})");
  const nd=fs.c.find(x=>x.n==='Dokumente').c.find(x=>x.n==='Projekte').c.find(x=>x.n==='liv').c.find(x=>x.n==='notizen_dev.txt');
  ok(/Notfallcode, drei Teile/.test(nd.text),'Georgs Entwicklernotizen erwähnen den Notfallcode in drei Teilen');
  ok(w.eval("STORY.trueEnd.code")==='kirsch2412ufer','Der Code lautet KIRSCH-2412-UFER');
 });
 // ---------- 6) Schrei-Clips und Kommentar zu fragen.txt
 await run({name:'Y',phase:1,flags:{},livLog:[],opened:[],unlocked:[],traits:{naehe:0,haerte:0,neugier:0},clues:[]}, async (w,d)=>{
  const {sleep,ev,byText,type,enter,login}=H(w,d); await login();
  ev(d.querySelector('.icon[data-id=web]'),'dblclick'); await sleep(30);
  const url=()=>d.querySelector('.urlbar input');
  type(url(),'pruefstein.net/saege'); enter(url()); await sleep(30);
  byText('.opt','Mensch').click(); await sleep(250);
  ok(w.__sfxLog.includes('a') && w.__sfxLog.filter(x=>x==='a').length===1,'Säge-Jumpscare spielt den geschnittenen Clip genau einmal');
  const r=w.eval("STORY.liv.reactions['file:fragen.txt'].early[0]");
  ok(/^Es weiß nicht einmal, wer es ist/.test(r) && !/jemand/.test(r),'Liv spricht Echo bei fragen.txt als \"es\" an: '+r.slice(0,50));
  for(const f of ['scream_a','scream_b','scream_c','scream_d','scream_e','scream_f']) if(!require('fs').existsSync(require('path').join(__dirname,'..','renderer','assets','sfx',f+'.mp3'))) ok(false,'Clip fehlt: '+f);
  ok(true,'Alle sechs Clips liegen in assets/sfx');
 });
 console.log('fertig'); process.exit(0);
})();
