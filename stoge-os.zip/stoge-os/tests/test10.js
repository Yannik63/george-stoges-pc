// Echo greift an (Tagebuch), Rätsel: wr_acc in liv.cfg auf true; Task-Manager; Lautstärke
const { JSDOM } = require('jsdom');
let saved=null, state;
const mk=()=>({info:async()=>({user:'yannik',host:'PC'}),desktopFiles:async()=>[],writeDesktop:async n=>n,fakeRestart:async()=>{},saveState:async s=>{saved=JSON.parse(JSON.stringify(s));},loadState:async()=>JSON.parse(JSON.stringify(state)),quit:()=>{}});
const ok=(c,m)=>console.log((c?'PASS ':'FAIL ')+m);
const run=(st,fn)=>{ state=st; return JSDOM.fromFile(require('path').join(__dirname,'..','renderer','index.html'),{runScripts:'dangerously',resources:'usable',pretendToBeVisual:true,
 beforeParse(w){w.sys=mk();w.__SPEED=0.01;w.Math.random=()=>0.1;}}).then(async dom=>{ await new Promise(r=>setTimeout(r,1600)); await fn(dom.window,dom.window.document); dom.window.close(); }); };
(async()=>{
 await run({name:'Y',phase:1,flags:{livMet:true,livStarted:true,archiv:true,stage1:true,stage1At:Date.now()-999999},livUnlocked:true,livLog:['Hallo.'],opened:[],unlocked:[],traits:{naehe:0,haerte:0,neugier:0},clues:[],livMetAt:Date.now()-999999}, async (w,d)=>{
  const sleep=ms=>new Promise(r=>setTimeout(r,ms));
  const ev=(el,tp,o={})=>el.dispatchEvent(new w.MouseEvent(tp,Object.assign({bubbles:true},o)));
  const byText=(s,tx)=>[...d.querySelectorAll(s)].find(e=>e.textContent.includes(tx));
  d.getElementById('nameinput').value='Y'; d.getElementById('loginbtn').click(); await sleep(100);
  ev(d.querySelector('.icon[data-id=docs]'),'dblclick'); await sleep(30);
  ev(byText('.frow','Archiv'),'dblclick'); await sleep(20);
  ok(!!byText('.frow','tagebuch_sept') && !saved.flags.tbCorrupt,'Vor dem Eingriff liegt das Tagebuch normal im Archiv');
  let sawVanishing=false; for(let i=0;i<150 && !saved.flags.tbCorrupt;i++){ if(byText('.frow.vanishing','tagebuch_sept')) sawVanishing=true; await sleep(5); }
  ok(sawVanishing,'Das Tagebuch flackert kurz in der Liste (nicht anklickbar)');
  await sleep(20);
  ok(saved.flags.tbCorrupt===true && !byText('.frow','tagebuch_sept'),'Dann verschwindet es sichtbar, sobald der Archiv-Ordner offen ist');
  d.querySelector('.pathbar button').click(); await sleep(10);
  ev(byText('.frow','Projekte'),'dblclick'); await sleep(10);
  ev(byText('.frow','liv'),'dblclick'); await sleep(10);
  ev(byText('.frow','liv.cfg'),'dblclick'); await sleep(30);
  const sp=d.querySelector('.edwrap .edval');
  ok(!!sp && sp.contentEditable==='true' && sp.textContent==='false' && !d.querySelector('.edwrap textarea'),'liv.cfg: nur der Wert von wr_acc ist änderbar (kein freies Textfeld)');
  sp.textContent='bla'; sp.dispatchEvent(new w.Event('input',{bubbles:true})); d.querySelector('.edsave').click(); await sleep(30);
  ok(!saved.flags.wrAcc && /Ungültig/.test(d.querySelector('.edmsg').textContent),'Falscher Wert wird abgelehnt');
  sp.textContent='true'; d.querySelector('.edsave').click(); await sleep(50);
  ok(saved.flags.wrAcc===true,'Gespeichert: wr_acc = true, Flag gesetzt');
  [...d.querySelectorAll('.win')].filter(x=>/liv\.cfg – Editor|liv\.cfg/.test(x.querySelector('.titlebar span').textContent)).forEach(x=>x.querySelector('.wbtns button:last-child').click());
  ev(byText('.frow','liv.cfg'),'dblclick'); await sleep(30);
  ok(d.querySelector('.edwrap .edval').contentEditable!=='true' && d.querySelector('.edsave').disabled,'Danach ist die Datei wieder schreibgeschützt');
  for(let i=0;i<80 && !saved.livLog.some(l=>l.includes('Tagebuch wiederhergestellt'));i++) await sleep(50);
  ok(saved.livLog.some(l=>l.includes('Tagebuch wiederhergestellt')),'Liv bedankt sich und stellt das Tagebuch wieder her');
  // Task-Manager
  d.dispatchEvent(new w.KeyboardEvent('keydown',{key:'Escape',ctrlKey:true,shiftKey:true,bubbles:true})); await sleep(40);
  const names=[...d.querySelectorAll('.tmt tbody tr')].map(r=>r.dataset.n);
  ok(names.includes('echo_svc') && names.includes('liv.exe'),'Task-Manager zeigt echo_svc und liv.exe ('+names.join(', ')+')');
  ok(/System/.test(byText('.tmt tbody tr','echo_svc').textContent),'echo_svc hat vor dem Finale "System" als übergeordneten Prozess');
  ev(byText('.tmt tbody tr','echo_svc'),'click'); await sleep(10); d.querySelector('.tmend').click(); await sleep(10);
  ok(/verweigert/.test(d.querySelector('.tmmsg').textContent),'echo_svc lässt sich nicht beenden');
  // Lautstärke
  d.getElementById('vol').click(); await sleep(20);
  ok(!d.getElementById('volpop').classList.contains('hidden') && !!d.querySelector('#volpop .vrange'),'Lautstärke-Regler öffnet sich in der Taskleiste');
  d.querySelector('#volpop .vmute').click(); await sleep(20);
  ok(saved.muted===true && d.getElementById('vol').textContent==='🔇','Stummschalten funktioniert');
 });
 console.log('fertig'); process.exit(0);
})();
