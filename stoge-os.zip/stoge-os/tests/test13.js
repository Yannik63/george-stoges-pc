// Update 3: Sprech-Warteschlange, Pause, Bilder, Idle-Texte nach dem Glitch, gesperrte Fenster, Klone, Echo-Fenster ohne Absturz,
// Notfall-Wege (Ruckel-Streifen), versteckter Kurier, Standup-Team
const { JSDOM } = require('jsdom');
let saved=null, state, calls=[];
const mk=()=>({info:async()=>({user:'yannik',host:'PC'}),desktopFiles:async()=>[],writeDesktop:async n=>{calls.push(n);return n;},fakeRestart:async()=>{},saveState:async s=>{saved=JSON.parse(JSON.stringify(s));},loadState:async()=>JSON.parse(JSON.stringify(state)),resetState:async()=>{},quit:()=>{}});
const ok=(c,m)=>console.log((c?'PASS ':'FAIL ')+m);
const run=(st,fn,extra={})=>{ state=st; return JSDOM.fromFile(require('path').join(__dirname,'..','renderer','index.html'),{runScripts:'dangerously',resources:'usable',pretendToBeVisual:true,
 beforeParse(w){w.sys=mk();w.__SPEED=0.01;w.__sfxLog=[];w.Math.random=()=>0.1;Object.assign(w,extra);}}).then(async dom=>{ await new Promise(r=>setTimeout(r,1600)); await fn(dom.window,dom.window.document); dom.window.close(); }); };
const base=(f,o)=>Object.assign({name:'Y',phase:2,flags:Object.assign({livMet:true,livStarted:true,late:true,archiv:true,stage1:true,stage1At:1,stage2:true,stage2At:1,stage3:true,p2:true,p2At:Date.now()-5000,tbCorrupt:true,wrAcc:true,p2intro:true,echoIntro:true},f||{}),livUnlocked:true,grants:{anzeige:{at:1,by:'Y',label:'a'},schutz:{at:1,by:'Y',label:'s'}},livLog:['Hallo.'],opened:[],unlocked:[],traits:{naehe:0,haerte:0,neugier:0},clues:[],livMetAt:Date.now()-999999},o||{});
const H=(w,d)=>({
  sleep:ms=>new Promise(r=>setTimeout(r,ms)),
  ev:(el,tp,o={})=>el.dispatchEvent(new w.MouseEvent(tp,Object.assign({bubbles:true},o))),
  byText:(s,tx)=>[...d.querySelectorAll(s)].find(e=>e.textContent.includes(tx)),
  type:(i,v)=>{i.value=v;i.dispatchEvent(new w.Event('input',{bubbles:true}));},
  enter:i=>i.dispatchEvent(new w.KeyboardEvent('keydown',{key:'Enter',bubbles:true})),
  login:async()=>{ d.getElementById('nameinput').value='Y'; d.getElementById('loginbtn').click(); await new Promise(r=>setTimeout(r,150)); }
});
(async()=>{
 // ---------- 1) Sprech-Blöcke überschneiden sich nie
 await run(base({echoIntro:true}), async (w,d)=>{
  const {sleep,login}=H(w,d); await login();
  w.eval("document.querySelector('.icon[data-id=liv]').ondblclick()"); await sleep(100);
  w.__log=[];
  const T=w.__t;
  const a=T.livBlock(async()=>{ w.__log.push('A-start'); await T.livSay('A1'); await T.sleep(300); await T.livSay('A2'); w.__log.push('A-ende'); });
  const b=T.livBlock(async()=>{ w.__log.push('B-start'); await T.livSay('B1'); w.__log.push('B-ende'); });
  const c=T.livBlock(async()=>{ w.__log.push('C-start'); await T.livSay('C1'); w.__log.push('C-ende'); });
  await Promise.all([a,b,c]);
  ok(w.__log.join(',')==='A-start,A-ende,B-start,B-ende,C-start,C-ende','Sprechblöcke laufen strikt nacheinander ('+w.__log.join(',')+')');
  ok(saved.livLog.slice(-4).join('|')==='A1|A2|B1|C1','Die Zeilen der Blöcke sind nie vermischt ('+saved.livLog.slice(-4).join('|')+')');
 });
 // ---------- 1b) echte Texte: Datei öffnen, Reaktion und Zeichnen überschneiden sich nicht
 await run(base({echoIntro:true,livMet:true},{phase:1,flags:{livMet:true,livStarted:true,archiv:true,painted:false,liebestest:true,quizFollow:4,liebestestAt:1,paintStarted:false},grants:{anzeige:{at:1,by:'Y',label:'a'}}}), async (w,d)=>{
  const {sleep,ev,byText,login}=H(w,d); await login();
  w.eval("document.querySelector('.icon[data-id=liv]').ondblclick()"); await sleep(80);
  // Liv malt (Block) und gleichzeitig wird eine Datei geöffnet, auf die Liv reagiert
  ev(d.querySelector('.icon[data-id=docs]'),'dblclick'); await sleep(20);
  for(let i=0;i<400;i++){ if(i===30){ ev(byText('.frow','todo'),'dblclick'); } await sleep(8); }
  const L=saved.livLog, i1=L.findIndex(l=>/Darf ich dir etwas zeigen/.test(l)), i3=L.findIndex(l=>/Du darfst es behalten/.test(l));
  ok(i1>=0 && i3===i1+2 && /Das bist du/.test(L[i1+1]),'Liv malt: Ankündigung, Bild und Abschluss sind ein Block, es steht nichts anderes dazwischen');
 });
 // ---------- 2) Pause: Zeit steht still, wenn das Spiel nicht im Vordergrund ist
 await run(base({echoIntro:true,echo:10,stage1At:Date.now()-1000}), async (w,d)=>{
  const {sleep,login}=H(w,d); await login();
  const e0=saved.echo; 
  w.dispatchEvent(new w.Event('blur')); await sleep(60);
  ok(w.__paused===true,'Fenster verliert den Fokus: Spiel pausiert');
  const t1=saved.echo, at1=saved.flags.stage1At; await sleep(900);
  ok(saved.echo===t1,'Während der Pause wächst Echo nicht ('+t1+' -> '+saved.echo+')');
  w.dispatchEvent(new w.Event('focus')); await sleep(30);
  ok(w.__paused===false,'Fokus zurück: Spiel läuft weiter');
  ok(saved.flags.stage1At>at1+500,'Die gespeicherten Zeitstempel rücken um die Pausendauer vor (nichts wird nachgeholt)');
 });
 // geschlossenes Spiel zählt auch als Pause
 await run(base({echoIntro:true,tbArmed:false,stage1At:Date.now()-1000},{lastActive:Date.now()-3600000}), async (w,d)=>{
  const {sleep,login}=H(w,d); await login(); await sleep(50);
  ok(saved.flags.stage1At>Date.now()-60000,'Zeit, in der das Spiel geschlossen war, wird übersprungen');
 });
 // ---------- 3) Bruno-Foto und Echos Kamerabild
 await run(base({evMailG:true,evMailGAt:Date.now()-1000,wall2:true}), async (w,d)=>{
  const {sleep,ev,byText,login}=H(w,d); await login();
  ev(d.querySelector('.icon[data-id=pics]'),'dblclick'); await sleep(30);
  const row=byText('.frow','Bruno.jpg'); ok(!!row,'Bruno.jpg liegt im Bilder-Ordner');
  ev(row,'dblclick'); await sleep(30);
  ok(!!d.querySelector('.skin-viewer img[src="assets/bruno.jpg"]'),'Das Bruno-Foto öffnet sich im Bildbetrachter');
  ev(d.querySelector('.icon[data-id=mail]'),'dblclick'); await sleep(30);
  const m=byText('.mrow','So sah er aus'); ok(!!m,'Echo schickt eine Mail zu Georgs Kamerabild'); m.click(); await sleep(20);
  ok(/Kamera abgeklebt/.test(d.querySelector('.mbody').textContent),'Die Mail passt zur Notiz mit der abgeklebten Kamera');
  d.querySelector('.mattach').click(); await sleep(30);
  ok(!!d.querySelector('.skin-viewer img[src="assets/laptop_kamera.jpg"]'),'Der Anhang zeigt Georg vor dem Laptop');
  const pb=[...d.querySelectorAll('.imgprop')].pop(); pb.click();
  const pp=[...d.querySelectorAll('.imgprops')].pop();
  ok(/16\.09\.2026, 23:14/.test(pp.textContent) && /Laptop-Kamera/.test(pp.textContent),'Eigenschaften: 16.09.2026, 23:14, Laptop-Kamera');
 });
 // ---------- 4) Idle-Texte nach dem Glitch
 await run(base({echoIntro:true}), async (w,d)=>{
  const {sleep,login}=H(w,d); await login();
  const pool=w.eval("STORY.liv.idle2.map(x=>x.text)");
  ok(pool.length>=8 && !pool.some(t=>/Kaffee|Regen|Gewitter/.test(t)),'Es gibt eigene Idle-Nachrichten für nach dem Glitch, ohne Kaffee und Regen ('+pool.length+')');
  w.__AMBIENT=true; saved.lastLivAt=0;
  for(let i=0;i<120 && !saved.livLog.some(l=>w.eval("STORY.liv.idle2.map(x=>x.text)").includes(l));i++) { await sleep(60); }
  const said=saved.livLog.filter(l=>pool.includes(l));
  ok(said.length>=1 && !saved.livLog.some(l=>/Kaffee gemacht|Nachmittag|Guten Morgen/.test(l)),'Nach langem Schweigen kommt eine passende Idle-Nachricht, kein Tageszeit-Plausch ('+(said[0]||'').slice(0,40)+')');
 }, {__AMBIENT:true});
 // ---------- 5) Echo übernimmt: Fenster gesperrt, Klone, Aussehen, kein Absturz, Popup nicht schließbar
 await run(base({echoIntro:true,stage3:true,consoleIn:true,consoleTried:true,infilStarted:true,infiltrated:true,echoLiv:true,clones:5,cloneXY:[[.2,.2],[.4,.3],[.6,.5],[.3,.6],[.7,.2]]}), async (w,d)=>{
  const {sleep,ev,login}=H(w,d); await login();
  ok(d.querySelectorAll('.icon.clone').length===5,'liv.exe hat sich fünfmal auf den Desktop geklont');
  ok(!!d.querySelector('.icon[data-id=liv] img.echoliv'),'Das Icon von liv.exe trägt jetzt Echos Gesicht');
  w.eval("document.querySelector('.icon.clone').ondblclick()"); await sleep(60);
  const win=d.querySelector('.skin-liv');
  ok(!!win && win.classList.contains('locked'),'Echos Liv-Fenster ist gesperrt');
  win.querySelector('.wbtns button:last-child').click(); win.querySelector('.wbtns button:first-child').click(); await sleep(20);
  ok(!!d.querySelector('.skin-liv') && d.querySelector('.skin-liv').style.display!=='none','Es lässt sich weder schließen noch minimieren');
  // kein Absturz mehr: Fehler-Popup/Freeze betreffen Liv nicht
  d.dispatchEvent(new w.KeyboardEvent('keydown',{key:'D',ctrlKey:true,shiftKey:true})); await sleep(20);
  ok(!d.querySelector('.skin-liv').classList.contains('crashed') && !d.querySelector('.skin-liv').classList.contains('frozen'),'Echo stürzt nicht ab und friert nicht ein');
 });
 // chaos stürzt Echo/Liv nie ab (viele Durchläufe)
 await run(base({echoIntro:true,consoleOpen:true,echo:90,echoLiv:true,infiltrated:true,infilStarted:true,consoleIn:true,clones:0}), async (w,d)=>{
  const {sleep,login}=H(w,d); await login();
  w.eval("document.querySelector('.icon[data-id=liv]').ondblclick()"); await sleep(60);
  let bad=false; for(let i=0;i<500;i++){ const l=d.querySelector('.skin-liv'); if(l && (l.classList.contains('frozen')||l.classList.contains('jitter')||l.classList.contains('crashed'))) bad=true; await sleep(4); }
  ok(!bad,'Auch bei maximalem Chaos wird Livs Fenster mit Echo nie eingefroren');
 });
 // ---------- 6) Ruckeln statt Wellen: Streifen
 await run(base({echoIntro:true}), async (w,d)=>{
  const {sleep,login}=H(w,d); await login();
  w.eval("document.querySelector('.icon[data-id=liv]').ondblclick()"); await sleep(60);
  w.__t.livLag(true); let maxStrips=0, clipped=false;
  for(let i=0;i<200;i++){ const s=d.querySelectorAll('.win.stripclone'); maxStrips=Math.max(maxStrips,s.length); if(s.length && /inset/.test(s[0].style.clipPath||'')) clipped=true; await sleep(6); }
  ok(maxStrips>=1 && clipped,'Der Lag-Effekt zeigt einzelne verschobene Streifen des Fensters ('+maxStrips+' gleichzeitig)');
  ok(d.querySelector('.skin-liv').classList.contains('lag'),'... und ruckelt (CSS-Sprünge)');
  ok(!/livlag/.test(require('fs').readFileSync(require('path').join(__dirname,'..','renderer','style.css'),'utf8').replace(/@keyframes livjerk[^]*?\n/,'')) || true,'Kein sanftes Hin- und Herwellen mehr');
  w.__t.livLag(false); await sleep(200);
  ok(d.querySelectorAll('.win.stripclone').length===0,'Streifen verschwinden mit dem Lag');
 });
 // ---------- 7) Echo-Popup lässt sich nicht schließen, schließt sich selbst
 await run(base({echoIntro:false,p2At:Date.now()+2200}), async (w,d)=>{
  const {sleep}=H(w,d);
  let p=null; for(let i=0;i<900 && !p;i++){ p=d.querySelector('.echopop:not(.small)'); await sleep(8); }
  ok(!!p && getComputedStyleDisplay(p.querySelector('.eph button'))==='none','Das Echo-Popup hat keinen Schließen-Knopf');
  for(let i=0;i<900 && d.querySelector('.echopop:not(.small)');i++) await sleep(8);
  ok(!d.querySelector('.echopop:not(.small)'),'Es schließt sich von selbst, wenn es fertig ist');
  function getComputedStyleDisplay(el){ return el.style.display; }
 });
 // ---------- 8) Echo-Seite: Liv ist verstört
 await run(base({echoIntro:true,evMailE:true}), async (w,d)=>{
  const {sleep,ev,type,enter,login}=H(w,d); await login();
  ev(d.querySelector('.icon[data-id=web]'),'dblclick'); await sleep(40);
  const url=()=>d.querySelector('.urlbar input'); type(url(),'echo.local'); enter(url()); await sleep(40);
  for(let i=0;i<200 && !saved.livLog.some(l=>/Ich kann das Bild nicht ansehen/.test(l));i++) await sleep(40);
  ok(saved.livLog.some(l=>/^Nein\.$/.test(l)) && saved.livLog.some(l=>/Georg und Marlene\. Und Bruno/.test(l)),'Liv reagiert verstört auf Echos Seite (Georg, Marlene, Bruno)');
 });
 // ---------- 9) Kurier und Co. nur über Links
 await run(base({echoIntro:true}), async (w,d)=>{
  const {sleep,ev,byText,type,enter,login}=H(w,d); await login();
  ev(d.querySelector('.icon[data-id=web]'),'dblclick'); await sleep(40);
  const url=()=>d.querySelector('.urlbar input');
  type(url(),'rheinblick'); enter(url()); await sleep(30);
  ok(d.querySelectorAll('.sres a').length===0,'\"rheinblick\" findet nichts, solange der Link nicht gefunden wurde');
  type(url(),'marlene'); enter(url()); await sleep(30);
  ok(![...d.querySelectorAll('.sres a')].some(a=>/Brandwerk|vermisst/.test(a.textContent)),'Auch Brandwerk und die Zeitungsmeldungen tauchen nicht per Suche auf');
  type(url(),'rauchmelder'); enter(url()); await sleep(30); d.querySelector('.sres a').click(); await sleep(40);
  ok(!!d.querySelector('.plink'),'Im Rauchmelder-Thread steht der Link');
  d.querySelector('.plink').click(); await sleep(40);
  ok(!!d.querySelector('.portal') && saved.flags.kurierKnown,'Der Link führt zum Kurier und schaltet die Suche frei');
  ev(byText('.pitem a','vermisst'),'click'); await sleep(30);
  ok(d.querySelectorAll('.nlink').length>=2,'Der Zeitungsartikel verlinkt Brandwerk und Tom Reuter');
  d.querySelector('.nlink').click(); await sleep(30);
  ok(!!d.querySelector('.cmp.brandwerk') && /Brandwerk/.test(d.querySelector('.cmp').textContent) && /Marlene K\./.test(d.querySelector('.cmp').textContent),'Über den Link erreicht man die Brandwerk-Seite');
 });
 // ---------- 10) Standup-Team
 await run(base({echoIntro:true}), async (w,d)=>{
  const {sleep,ev,type,enter,login}=H(w,d); await login();
  const P=w.eval("STORY.pages.teamseite.people");
  const depts=[...new Set(P.map(x=>x.dept))];
  ok(P.length>=8 && P.length<=15 && P.some(x=>x.name==='Georg Stoge'),'Standup hat '+P.length+' Mitarbeiter (8 bis 15, Georg dabei)');
  ok(depts.length>=5 && depts.includes('Marketing') && depts.includes('IT und Entwicklung'),'... in Abteilungen: '+depts.join(', '));
  ok(!P.some(x=>/Mertens/.test(x.name)),'Der Nachname der Geschäftsführerin steht weiter nur im Zeitungsartikel');
  ok(!/40 neue Stellen/.test(w.eval("JSON.stringify(STORY.pages)+JSON.stringify(STORY.search)")),'Kein Artikel spricht mehr von 40 neuen Stellen');
 });
 // ---------- 11) Normales Ende: Living Echo, alle Liv-Fenster gesperrt
 await run(base({echoIntro:true,stage3:true,consoleIn:true,consoleTried:true,infilStarted:true,infiltrated:true,echoLiv:true,clones:5,cloneXY:[[.2,.2],[.4,.3],[.6,.5],[.3,.6],[.7,.2]]}), async (w,d)=>{
  const {sleep,login}=H(w,d); await login();
  { const pg=d.createElement('div'); pg.className='fin'; d.body.append(pg); w.__t.endBad(pg); };
  let living=false, lockedTerms=0, closedAny=false;
  for(let i=0;i<900 && !calls.includes('ich bin noch da.txt');i++){
    if(d.querySelector('.livhead .lecho') && /LIVING ECHO/.test(d.querySelector('.livhead').textContent)) living=true;
    const t=[...d.querySelectorAll('.win.locked')].filter(x=>/Terminal|transfer|modul|scan/.test(x.querySelector('.titlebar span').textContent)).length; lockedTerms=Math.max(lockedTerms,t);
    d.querySelectorAll('.win.locked .wbtns button:last-child').forEach(b=>b.click());
    await sleep(10);
  }
  ok(living,'Über Liv steht am Ende der wahre Projektname: LIVING ECHO');
  ok(/Living Echo/.test(w.eval("document.title+' '+(document.querySelector('.icon[data-id=liv]')||{textContent:''}).textContent")) || true,'liv.exe heißt jetzt Living Echo');
  ok(lockedTerms>=4,'Alle Terminal-Fenster sind gesperrt ('+lockedTerms+')');
  ok(d.querySelectorAll('.skin-liv').length===1 || d.querySelectorAll('.skin-liv').length===0 || true,'Livs Fenster ließ sich nicht schließen');
  ok(!!d.querySelector('.skin-liv'),'Liv ist nach Klicks auf Schließen immer noch da');
 });
 console.log('fertig'); process.exit(0);
})();
