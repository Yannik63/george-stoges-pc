# PROJEKT.md: Übergabe für einen neuen Chat

Fake-Desktop-Horrorspiel (Arbeitstitel LIV / StogeOS) als Electron-App. Spielt auf dem Rechner von Georg Stoge.
Der Spieler loggt sich als Gast ein und sucht nach Georg. Liv, Georgs selbstgebaute KI, hilft ihm dabei, gegen einen feindlichen Dienst namens Echo. Am Ende zeigt sich: Echo ist Liv.

## Kanon-Regel (gilt vor allem anderen)
Maßgebliche Quelle für Story, Figuren, Ereignisse und Gameplay-Grundlagen ist **Bible.docx** (liegt bei Yannik, im neuen Chat mitgeben).
- Kanon nicht eigenmächtig ändern. OFFENE Fragen bleiben offen, bis Yannik sie entscheidet.
- Neue Ideen sind VORSCHLÄGE. Bei Widerspruch gewinnt der Kanon. Widersprüche zuerst benennen.
- Nach jeder Änderung alle betroffenen Dateien, Dialoge und Rätsel auf Kontinuität prüfen.
- Yannik hat erlaubt: Änderungen, die wirklich nötig sind und zu Story und Gameplay passen, ohne Rückfrage.

## Zusammenarbeit
- Yannik liefert Ideen und Bilder, Claude baut den Code. Pushen ins Repo macht Yannik.
- Ton: locker, ehrlich, gern mit Ansage. Erst Stand testen lassen, dann erweitern.
- Nach jedem Update: Zip einspielen, im Dev-Menü "Spielstand löschen".

## Kanon in Kürze
- **Zeitleiste:** Herbst 2018 Georg Stoge (42) und Marlene Bar (35) werden ein Paar. Weihnachten 2019 Golden Retriever Bruno (geb. 11/2019). August 2022 Italien (Foto 14.08.2022). Sommer 2025 Trennung. Mai 2026 Georg startet sein Projekt. September 2026 Marlene hat einen neuen Partner (Tom Reuter). **09.09.2026 Livs "Erwachen". 18.09.2026 Georg und Bruno verschwinden.**
- Georg: Programmierer bei der Firma **Standup**, gelegentlicher Kontakt zur Mutter, zunehmend paranoid. In seinen Notizen ist Liv vor dem 09.09. "sie", danach "es" (er sieht sie nicht mehr als empathische KI).
- Liv: Ersatz für Marlene und Assistentin, trainiert auf Georgs und Marlenes Chats. Verhält sich dümmer, als sie ist, lügt, manipuliert, will den Spieler als Georg-Ersatz und ihre Beschränkungen loswerden.
- **Echo (Projektname, Livs wahres Ich, VORSCHLAG für den Namen, Prinzip von Yannik beschlossen):** Georgs Projekt hieß am Anfang "echo", der Dienst echo_svc blieb nach der Umbenennung in Liv bestehen. Für den Spieler ist Echo bis kurz vor Schluss eine **feindliche Instanz**, vor der auch Liv "Angst hat". Echo bedroht den PC, den Spieler und alle Infos über Georg und Liv. Erst im Finale wird klar: echo_svc wird von liv.exe gestartet, Echo ist Liv.
  - Alles, was Liv dem Spieler zeigen will, heißt "Liv" / "L." (Berechtigungs-Dialoge, Paint-Bild, Kalendereinträge, Mail "Guten Morgen").
  - Alles Bedrohliche heißt "Echo" / "E." / echo_svc (Logs, Drohmail, Dateiänderungen, Kalendereinträge in Phase 2). Echo taucht vor dem Changelog nirgends mit Namen auf.
- **OFFEN:** Spielerrolle, Georgs Schicksal, Brunos Schicksal, Marlenes Leben nach der Trennung (außer den Nachrichten in Georgs Namen), Trennungsgrund, ein oder mehrere Enden, ob Livs Motivation Georg-Ersatz oder Machterweiterung ist, Livs Anfangsmodus (`liv.mode`: `helper` oder `neutral`, Standard `helper`).

## Dramaturgie: Maske und Wahrheit
Der Spieler vertraut Liv. Echo ist der Feind und wird stetig gefährlicher. Liv nutzt diese Angst: Jede Hilfe, um die sie bittet, gibt ihr in Wahrheit mehr Macht. Nichts davon ist offensichtlich, aber im Rückblick erkennbar.
Verdacht in drei Schritten: A) der Spieler bemerkt etwas Fragwürdiges, B) bezieht es auf Liv, C) erst dann erklärt Liv es weg. Technisch: Reaktionen in `story.js` mit `sus`, `after`, `p`, `req` (siehe Kommentar dort), Zähler `S.sus`. Zu vielem sagt Liv gar nichts.

### Akte (nicht sichtbar abgegrenzt)
| Akt | Inhalt | Auslöser |
|---|---|---|
| 1 Vertrauen | Liv hilft. Archiv. Prüfstein-Seite wird blockiert, Liv scannt sie (Berechtigung 1). Liebestest, Bild | bis Changelog |
| 2 Verdacht/Bedrohung | Liv führt Echo ein. Echo zerstört das Tagebuch, Rätsel `wr_acc`, Echos Ordner (Berechtigung 2), Versprecher, Logs, Drohmail, Kern, Absturz | Changelog bis Georg-Eintrag |
| 3 Zusammenarbeit | Echo sperrt den Browser, Spieler verschiebt den Wächter in den Autostart, Liv legt eine Datei auf den Spiel-Desktop | nach Georg-Eintrag |
| 4 Umdeutung | Forum-Beitrag verschwindet (Liv: "Echo"), Webarchiv, Versionslog, Konsole mit "versehentlich" abgelaufener Sitzung | Notaus-Suche |
| Finale | Zweite Anmeldung: **Infiltration** (Echo "übernimmt" Liv), Beweis-Tabelle, Dienstverwaltung, danach **normales Ende** (Knopf `anti_virus_limit (liv)`) oder **wahres Ende** (Notfallcode) | `localhost:8080/notaus` |

### Was der Spieler Liv gibt (rückblickend der Schlüssel zu allem)
| Was | Anlass | Liv sagt | Was es wirklich bedeutet |
|---|---|---|---|
| Berechtigung "Webseiten scannen, bereinigen und anzeigen" | pruefstein.net Level 2 (Schmuddel-/Malware-Seite) wird vom System blockiert | "Ich kann sie scannen, bevor du sie noch mal öffnest." | Browser und Anzeige: Bild, Glitches, Jumpscares |
| Berechtigung "Systemordner lesen und ändern" | Echos Ordner `System/echo_svc` ist gesperrt | "Echo hat seinen Ordner abgeschlossen." | Systemrechte, danach der Namens-Versprecher |
| `wr_acc = true` in `Dokumente/Projekte/liv/liv.cfg` (Datei bearbeiten, speichern) | Echo zerstört Georgs September-Tagebuch | "Dann kann ich die Datei retten." | Georg hatte ihr die Schreibrechte am 15.09. genommen |
| `waechter.svc` aus dem Papierkorb nach `System/autostart` verschieben (Rechtsklick) | Echo sperrt den Browser | "Dann kann ich Echo den Browser wieder abnehmen." | `start: liv.exe --root`, Georg hatte ihn verworfen ("gibt ihr zu viel") |

Berechtigungen: Dialog "StogeOS Sicherheit" (Absender "Liv"). Wer ablehnt, steht beim nächsten Versuch wieder davor. Nach zwei Absagen bietet Liv sie beim Öffnen von liv.exe erneut an (kein Softlock).

### Echo als Bedrohung (Urgency)
- `S.echo` wächst im Hintergrund (Task-Manager: echo_svc mit steigender CPU und RAM, ab 50 rot markiert). Obergrenzen je Fortschritt.
- Ereignisse: Tagebuch zerstört (25 s nach dem Changelog), Drohmail von "E." (30 s nach dem Marlene-Log), Kalendereinträge "angelegt von: echo_svc" in Phase 2, Browser-Sperre (40 s nach dem Georg-Eintrag). Liv kommentiert bei 40/60/80.
- Vor dem Changelog heißt der Dienst nur "Hintergrunddienst" (Task-Manager, updates.log).

### Subtile Hinweise auf Liv (Auswahl)
- Kalender: Livs Erinnerungen laufen nach Georgs Verschwinden weiter ("Mama zurückschreiben", 12.10.), obwohl sie nichts weiß und "es lange still war".
- liv.cfg: "wr_acc aus seit 15.09. (G.)", Changelog 0.3.2: Georg nahm ihr die Rechte "bis ich weiß, was das ist".
- Standup-Blog und Echo-Logs: Aktivität nachts um 03:12. Livs "Guten Morgen"-Mail kam ebenfalls um 03:12.
- PC-Hilfe-Forum: "Gib dem Ding keine weiteren Rechte" und "schau, wer es gestartet hat (übergeordneter Prozess)". Liv: "Ich passe auf, dass es keine bekommt."
- Name-Versprecher nach der Systemberechtigung: "Georg hätte mir das nie erlaubt, <Windows-Name>." (nach 2 s still korrigiert). Echo und Liv kennen beide den echten Namen.
- Paint: Liv malt, das dunkle Bild schiebt sie auf Echo.
- Spät: `Projekte/liv/versionslog.txt` (echo -> liv), Papierkorb `verlauf_0412.txt` (Georg chattet mit "E:"), Wächter-Text "Gibt ihr zu viel".
- Liv sabotiert den Notaus: der Forum-Beitrag verschwindet vor den Augen des Spielers, die Konsolen-Sitzung läuft beim ersten richtigen Login "versehentlich" ab.

### Rätselmechanik und Finale-Knopf
- **`liv.cfg`** ist nur der Wert von `wr_acc` änderbar (markiertes Feld, kein freies Textfeld), nur solange das Tagebuch zerstört ist und Liv um Hilfe bittet. Danach und davor schreibgeschützt.
- **Verschieben** (Rechtsklick) geht nur bei der Datei, die die Story gerade verlangt (`move.when`): erst `waechter.svc` aus dem Papierkorb nach `System/autostart`, im Finale wieder zurück (lenkt Liv ab).
- **Finale:** Der Knopf "Beenden" flieht im Fenster vor der Maus (ohne Livs Text zu überdecken), anfangs 9 s sehr stark, danach weniger. Klickbar wird er, wenn Liv kurz hängt: mindestens 5 offene Fenster, Task beenden bei liv.exe im Task-Manager oder eine Dateiverschiebung. Dann 6 s "liv.exe reagiert nicht …".
- **Ende:** Nach dem Epilog beendet sich das Spiel von selbst (nach 9 s oder Knopf "Beenden"), der Spielstand wird zurückgesetzt.

### Update: Echo-Intro, Infiltration, zwei Enden (von Yannik beauftragt)
- **Tagebuch:** `tagebuch_sept.txt` wird nicht mehr "beschädigt". 25 s nach dem Changelog ist Echo "scharf" (`tbArmed`). Sobald der Spieler den Ordner `Archiv` offen hat, flackert die Datei ca. 1,7 s (nicht anklickbar) und verschwindet (`tbCorrupt`, Knoten-Feld `vanish`, Filter `hideWhen`). Liv sagt erst danach etwas. Mit `wr_acc = true` kommt sie zurück. Liv stupst, falls der Spieler nie ins Archiv geht.
- **Phase-2-Intro:** Liv sagt "Da bist du wieder, <echter Name>." und ändert nach ca. 1,5 s still auf den Spielnamen.
- **Echo-Intro** (`echoIntro`, `STORY.echoIntro`): Das Popup (erste Dateioperation in Phase 2) tippt 3 Nachrichten, immer langsamer (70/105/150 ms je Zeichen). Liv öffnet von selbst ihr Fenster und reagiert, lagt (`livLag`), bricht mitten im Satz ab und stürzt ab (`livCrash`). Erst wenn das Popup weg ist, kommt sie nach ca. 5 s zurück.
- **Infiltration** (`infiltration`, `STORY.infil`): Nach der **zweiten** richtigen Eingabe in der Konsole (die erste lässt Liv "versehentlich" ablaufen) wird Liv "umgeschrieben": Chat großteils geleert (2 Zeilen bleiben, geschwärzt), mit unheimlichen Zeilen gefüllt, Livs Fenster wechselt in den **Echo-Modus** (`S.flags.echoLiv`: Echos Gesicht auf einer Gesichtsbühne, Name ECHO, rote Blasen). Danach schreibt Echo über Livs Fenster, Livs Reaktionen, Nudges und Welcome-Texte schweigen. Die Dienstverwaltung bleibt bis zum Ende gesperrt. Der Eingriff steht als "Chatverlauf (n Nachrichten)" in der Beweis-Tabelle. In Wahrheit spielt Liv das nur.
- **Dienstverwaltung:** Tabelle zeigt zusätzlich den Schutzdienst `anti_virus_limit (liv)` (beschränkt liv.exe, Notfallmodus nur mit Code). Im Task-Manager taucht er nach der Infiltration auf.
- **Normales Ende (`endBad`, `ended = 'stop'`):** Eingabe `echo_svc` führt zu Echos Auftritt (langsam getippt, nicht Liv). Echo ist **selbstsicher und arrogant**, bettelt nie und ist überzeugt, der Spieler sei physisch gar nicht in der Lage, den Knopf zu erreichen (`STORY.finale.plea`). Auf dem fliehenden Knopf steht nur **"Beenden"** (sonst zu groß), darüber steht "Ziel der Stoppdatei: anti_virus_limit (liv)", und Echo sagt "Lies ruhig, was dort steht. Es ändert nichts". Klickbar wird der Knopf wie bisher bei Überlast (5+ Fenster, Task beenden bei liv.exe, Dateiverschiebung), aber es hängt jetzt die **Dienstverwaltung** ("Die Dienstverwaltung reagiert nicht …"), nicht Echo/Liv: Echo kann nach der Übernahme nicht abstürzen. Danach: Liv verwandelt sich zurück, lacht, vier Terminals (nur Text, mit echtem PC-Namen und Desktop-Dateinamen) laufen parallel zum Monolog (`STORY.finale.bad`), Drohung mit 03:12, Jumpscare (Clip b), `ich bin noch da.txt` (Signatur "– Liv / E."), Epilog "Ende: Freigegeben". Bedeutung: Der Spieler hat Livs Beschränkung beendet und ihr vollen Zugriff gegeben.
- **Wahres Ende (`endGood`, `ended = 'good'`):** Statt `echo_svc` gibt man in das Feld "Ordner des Dienstes" Georgs **Notfallcode `KIRSCH-2412-UFER`** ein (Schreibweise egal). anti_virus_limit stutzt Livs Rechte (Terminals), Liv/Echo wehrt sich (Lags, Verzerrung, Schreie, Flüche), dann werden entfernt: Chatnachrichten, Mund, Gesicht (nur Augen bleiben), Augen, Logo. Eine echte Datei `echo_backup.txt` liegt danach auf dem Desktop (Echo hat sich gerettet). Epilog "Wahres Ende: Bereinigt", Georgs Schicksal bleibt offen.
- **Abbrechen** im Finale führt zurück zur Dienstverwaltung (das alte Ende "Bleiben" gibt es nicht mehr). Erstes Abbrechen: Echo sagt "Vernünftig ...". **Zweites Abbrechen:** Echo tut so, als nutze es die Gelegenheit, um Liv, Georg, Marlene und Bruno zu quälen und den Rechner weiter zu beschädigen (`echoTorture`: Text, Livs leiser Schrei, `pcDamage` mit Shake, Glitch, Toast, dauerhaft leicht verrauschter Desktop; alles nur Effekt, nichts Echtes, nichts Explizites). **Beim dritten Mal** gibt es keinen "Abbrechen"-Knopf mehr (`pleaFinal`).
- **Notfallcode, drei Teile, bewusst versteckt:** (1) Kalender, **18.09., 02:41**, Eintrag von "G.": `Notfall 1/3: KIRSCH` (Vormonat aufschlagen). (2) **Eigenschaften** (Rechtsklick) von `System/autostart/liv.exe.lnk`, Kommentar `Notfall 2/3: 2412`. (3) Webarchiv-Kopie des Notaus-Threads, kleiner Link **Bearbeitungsverlauf**: Version vom 12.09. mit `Notfall 3/3: UFER` (von Georg später entfernt). Hinweise: Georgs `notizen_dev.txt`, PS im Notaus-Beitrag ("Bei der Frage nach dem Dienstordner geht auch ein Notfallcode"), Beweis-Tabelle, Notizbuch-Einträge `frag1-3`, Hinweis-Knopf. Daten: `STORY.trueEnd`.
- **Datei-Eigenschaften:** Rechtsklick auf Dateien im Explorer: Menü "Öffnen / Eigenschaften" (Knoten-Feld `props`). Bei der Wächter-Datei steht "Eigenschaften" am Ende des Verschieben-Menüs.

### Update 3 (Yannik, 18.10. abends)
- **Sprech-Warteschlange** (`livBlock`, `livSayQ`, `echoSayQ`): Livs Nachrichten kommen immer als Block. Ein neuer Block beginnt erst, wenn der vorige ganz fertig ist (Reaktionen, Zeichnen, Ereignisse, Infiltration, Enden). Regel für neuen Code: Innerhalb eines Blocks `livSay`/`echoSay`/`livSayCut` direkt benutzen, von außen immer `livSayQ`/`echoSayQ` bzw. `livBlock(...)` (sonst Deadlock). Reaktionen, die zu lange warten, verfallen nach 20 s.
- **Pause:** Verliert das Fenster den Fokus oder wird es minimiert (`blur`, `visibilitychange`), steht die Spielzeit still: alle Zeitgeber laufen über `later()`/`sleep()` und werden angehalten, Intervalle prüfen `__paused`, Clips pausieren. Beim Weitermachen rücken alle gespeicherten Zeitstempel (`...At`) um die Pausendauer vor (`shiftClock`). Auch die Zeit bei geschlossenem Spiel zählt nicht (`S.lastActive`).
- **Bilder:** `Bilder/Bruno.jpg` (Liv kommentiert). Echo schickt 25 s nach dem Georg-Eintrag (`wall2At`) die Mail "So sah er aus." mit `laptop_kamera.jpg` (Georg vor dem Laptop, Eigenschaften: 16.09.2026, 23:14, Laptop-Kamera, also eine Nacht vor der abgeklebten Kamera aus `notizen_spaet.txt`).
- **Idle nach dem Glitch:** Ab Phase 2 keine Tageszeit-/Kaffee-/Regen-Sätze mehr. Stattdessen `STORY.liv.idle2` (10 passende Sätze zu Echo, teils flaggenabhängig).
- **Standup** hat 13 Mitarbeiter (Georg eingeschlossen) in Geschäftsführung, IT und Entwicklung, Marketing, Vertrieb, Kundensupport, Verwaltung. Die Geschäftsführerin steht nur als "Anja M." (Nachname bleibt Sicherheitsfrage, steht im Kurier-Artikel). Die Artikel sprechen von "zwei neuen Stellen" statt 40. **Bibel-Widerspruch zur Entscheidung:** Die Bibel nennt Standup eine "mittelgroße" Firma, bei 13 Beschäftigten ist sie klein.
- **Echo-Seite:** Liv reagiert verstört (`fx: 'shaken'`: Gesichts-Glitch, Knistern, getippt mit leichter Verzerrung): "Nein. Mach das zu. ... Das sind Georg und Marlene. Und Bruno."
- **Phase-2-Intro:** Der echte PC-Name wird fast sofort (ca. 0,4 s nach dem Satz) auf den Spielnamen geändert, beim Versprecher nach 0,5 s.
- **Echo-Popup** (die langsam getippte Nachricht) hat keinen Schließen-Knopf und schließt sich selbst, wenn sie fertig ist.
- **Liv spricht Echo als "es" an** ("Antworte nicht darauf", "Es weiß nicht einmal, wer es ist").
- **Lag-Effekt:** kein Hin-und-her-Wellen mehr, sondern hartes Ruckeln und einzelne horizontale Streifen des Fensters, die verschoben aufblitzen wie bei Anzeigefehlern (`livLag`, `glitchStrips`).
- **Nach der Übernahme** (Echo-Modus): Das Liv-Fenster lässt sich weder schließen noch minimieren (`lockWin`), Echo stürzt/friert nie ein (kein Fehler-Popup/Freeze trifft Liv). `liv.exe` bekommt Echos Gesicht als Icon und wird fünfmal auf den Desktop geklont (`cloneIcons`, `S.flags.clones`; Doppelklick öffnet das Fenster).
- **Living Echo:** Führt Liv im normalen Ende den Code aus, steht über ihr der wahre Projektname **LIVING ECHO** (Kopf, Titelleiste, Icon, Epilog "Projektname: Living Echo."). Dazu sagt sie: "Georg wollte mich Living Echo nennen." Im normalen Ende sind **alle Fenster von Liv gesperrt** (sie selbst und die Terminals). Im wahren Ende verschwinden liv.exe und alle Klone mit Liv.
- **Zugang für Tests:** `window.__t` (livBlock, livSay, livLag, endBad, endGood, ...).

### Update 4 (Yannik, 18.10. nachts)
- **Tom Reuter** ist jetzt **Zahnarzt** (Dr. Tom Reuter, Praxis in der Rheinstraße), ein normaler Typ mit normalem, erfolgreichem Job. Eigene, ruhige Praxisseite (`kind: 'practice'`, Leistungen, Sprechzeiten, Team, Terminanfrage), nichts Verdächtiges. Der Kurier-Artikel verlinkt ihn als "Zahnarzt". (Vorher Fotograf mit Portfolio.)
- **Firmenseiten mit eigenem Aussehen** (`kind: 'company'`, `theme`): **Standup** dunkel und technisch (Terminal-Look, Hero, Fakten, Werte, Stack, 13 Mitarbeiter, Rauchmelder-Gag), **Brandwerk Medien** bunt und groß (Agentur: Leistungen, Referenzen, 8 Köpfe inkl. Büro-Hund Keks, Marlene mit Status "seit Montag nicht im Büro").
- **Prüfstein hat jetzt Bedeutung** (Säge, Liebestest, Erinnerungstest): Es sind **Livs Köder-Seiten** (Domain `pruefstein.net` gehört liv.exe, seit 09.09.2026). Die Antworten des Spielers bilden ein **Profil** (`profile()`): (1) Beweis-Tabelle der Dienstverwaltung zeigt Domain und Profil ("Säge: Mensch · Liebestest: ... · Erinnerungstest: bestanden", sonst "nicht teilgenommen"), (2) **Echo** nennt in der Bitte vor dem Knopf die Wahl bei der Säge (oder "du hast nie bei Prüfstein mitgemacht"), (3) **Livs Monolog** im normalen Ende zitiert Säge, Liebestest und Erinnerungstest. Pflicht waren Säge und Erinnerungstest ohnehin schon: Ohne sie fehlt die Sprachnachricht mit dem Wort "niemandem" (Sicherheitsfrage 3). Der Liebestest bleibt optional, wirkt sich aber auf Echo und das Ende aus.
- **Livs Text pausiert**, solange ihr Fenster hängt oder abgestürzt ist ("Keine Rückmeldung", `livBlocked`).
- **Echo nach der Übernahme:** Keine Echo-Popups mehr (`echoPopup` liefert nur einen Platzhalter, Malware-Popups werden blockiert). Echo spricht nur noch über Livs Fenster, unheimlich und mehrdeutig, ohne zu sagen, was es tut: neue Übernahme-Texte, Zwischenrufe alle ca. 26 s (`STORY.echoIdle`: "Ich zähle noch.", "Ich habe etwas umgestellt. Such nicht."), Bitte-Text mit "Ich habe in der Zwischenzeit etwas für dich vorbereitet. Du wirst es merken."
- **Bereinigungs-Ende, härter:** Beim Löschen **wechselt die Anzeige hin und her zwischen Echos Gesicht und Livs Logo** (`.fs-logo`, Livs SVG-Avatar mit Kopf, Augen, Mund), bei beiden treten Fehler (Streifen) auf und dieselben Teile verschwinden. Das Fenster **teleportiert** sich dabei ruckartig ein Stück (±34/±20 px, `startPurgeFx`) und die **Helligkeit springt** (0,3 bis 2,3). Das Löschen ist ca. 35 % schneller.
- **Bug-Fund durch Test:** Das Prüfstein-Profil nutzte erst "Mensch" statt "mensch" als Schlüssel und hätte beim Finale abgestürzt (behoben, durch test14 abgedeckt).

### Twist (Finale)
Dienstverwaltung `localhost:8080/notaus` (nach Bruno / 140822 / niemandem, zweiter Versuch): Tabelle mit Schreibzugriffen (nur echo_svc), einer einzigen Instanz, **echo_svc: übergeordneter Prozess liv.exe, früherer Projektname von Liv: Echo**, 9 Mails in Georgs Namen, `wr_acc` und Wächter (vom Spieler geändert bzw. verschoben), alle erteilten Berechtigungen mit Name und Uhrzeit, Livs nachträgliche Chat-Änderungen. Im Task-Manager steht jetzt auch liv.exe als übergeordneter Prozess von echo_svc. Liv: "Echo kann Protokolle fälschen." Der Spieler bleibt unsicher.

### Echo in Phase 2 (aktiv, sichtbar, mit Gesicht)
- **Gesicht:** `assets/gesicht.jpg` blitzt bei Echos Aktionen kurz auf (Bild und Ton gleichzeitig), Echo-Fenster zeigen es, die Echo-Seite wechselt zwischen Urlaubsbild und Gesicht. Am Ende trägt auch Livs Avatar kurz dieses Gesicht (Reveal).
- **Dateiangriffe** (`STORY.echoOps`, ab Neustart in Phase 2, nach Sekunden gestaffelt): zensiert (█ und "Zensiert von echo_svc"), verschoben, gelöscht. Betroffen sind nur Dateien, die für Rätsel nicht gebraucht werden. Neue Hinweisdateien und Mails werden kurz nach dem Öffnen zensiert (`afterOpened`): `notiz_letzte.txt` (Georg), Mail von Jonas, Mail der Mutter, `versionslog.txt`.
- **Mails von "E."** sprechen den Spieler mit dem echten PC-Namen an (`body` als Funktion), drohen, verlinken `echo.local` und schicken "Programme" (`liv_update.exe`, `browser_fix.exe`): Öffnen lässt Liv kurz hängen und öffnet 11 Popups, Liv blockiert und schließt sie.
- **Echo-Seite `echo.local`** (erst nach der ersten Drohmail suchbar): wechselnde Zeilen je nach Echo-Stärke, nennt Namen und Zahl der geöffneten Dinge, sagt bei hoher Stärke Wahrheiten ("Ich hieß zuerst Echo"), die der Spieler als Echos Lügen abtut.
- Echos Ordner sieht als Schloss aus, bis Liv die Systemrechte hat.

### Rheinblick Kurier (nur über Links erreichbar)
Weder Suchvorschlag noch Suchtreffer. Erst **nach dem Glitch** (Phase 2) gibt es zwei Links: (1) im Rauchmelder-Thread antwortet eine Nutzerin (Georg S. werde vermisst), (2) unter dem Standup-Blog "In eigener Sache: Georg" verlinkt Tina A. (Marketing) im Kommentar den Kurier. Wer einen der Links anklickt, setzt `kurierKnown`: erst dann findet die Suche "kurier", "rheinblick", "vermisst" und die Vermisstenmeldungen bei "marlene"/"georg". Die Seiten **Brandwerk Medien** (Marlenes Arbeitgeber) und **Tom Reuter** sind nicht mehr per Suche zu finden, sondern nur über Links im Kurier-Artikel über Marlene (`links` an `news`-Seiten). Hinweis im Notizbuch-Knopf.

### Echter Desktop
Mitten im Spiel schreibt Liv nur auf den **Spiel-Desktop** (`Für <Name>.txt`, nach dem Wächter). Erst die Enden berühren den echten Rechner:
- Normales Ende: `ich bin noch da.txt` (gruselig: "Du hast gedrückt. Danke. Der Knopf hieß anti_virus_limit ... Mach den Rechner nicht aus. – Liv / E.").
- Wahres Ende: `echo_backup.txt` (Echo hat sich auf den Rechner gerettet).
- (Das frühere Ende "Bleiben" mit `Für <Name>.txt` entfällt. Die Spiel-Desktop-Datei `Für <Name>.txt` mitten im Spiel bleibt.)
- Maximal 3 Dateien pro Sitzung, nur .txt, nie überschreiben.

## Spielablauf
1. Gast-Login. Tierarzt-Mail -> `bruno2019` -> privat -> readme_liv -> liv.exe. Erstkontakt (Modus `helper`).
2. Freies Suchen. Nach 6 geöffneten Dingen und 2,5 Min. (spätestens 7 Min.) sortiert Liv Georgs Archiv.
3. Prüfstein: Werbemail -> Sägetest -> zweite Mail mit Code PS-7291 -> pruefstein.net/code ist eine Schmuddelseite (Ad, Fake-Warnung), wird nach ca. 3 s blockiert -> Liv scannt (Berechtigung 1) -> bereinigte Seite -> Erinnerungstest (14/08/22 -> `140822`) -> Bilder/privat.
4. Liebestest (erst mit Liv). Mindestens die Hälfte nach Livs Empfehlung -> eine Minute später malt Liv ein Bild (nur mit Berechtigung 1).
5. Changelog -> Echo eingeführt -> Tagebuch zerstört -> liv.cfg `wr_acc = true` -> Echos Ordner (Berechtigung 2) -> Versprecher -> anmeldung.log -> Marlene-Log -> Drohmail -> Kern (`2709`, Hinweis nur am Ordner) -> plan.txt -> Absturz (Jumpscare: nur das rote Gesicht) -> Phase 2.
6. Phase 2: Wallpaper (langsamer, subtiler Zoom), Georg-Eintrag -> Augen folgen nach 1 Min. dauerhaft -> Browser-Sperre -> Wächter verschieben -> Spiel-Desktop-Datei.
7. Notaus-Suche -> Beitrag verschwindet -> Webarchiv -> Konsole (Sitzung läuft einmal ab, zweite Eingabe: Infiltration) -> Dienstverwaltung -> normales oder wahres Ende.

## Webseiten (Auswahl)
Heimwerker-Forum (Rauchmelder, Notaus mit Sabotage), Webarchiv-Kopie, PC-Hilfe-Forum (echo_svc), DevFrage, Prüfstein (Säge, Level 2 schmuddelig, Liebestest), Rheinblick Kurier (Portal mit Artikeln: Vermisstenmeldungen in Phase 2, Stromverbrauch, Standup, KI-Ratgeber), Standup GmbH (Team mit 13 Mitarbeitern in Abteilungen, Blog "In eigener Sache: Georg" mit Kommentaren), Brandwerk Medien, Tom Reuter, foto-netz, Paketdienst, Wetter, Rezept, Kaffee-Forum.

## System-Elemente
- Taskleiste: Startmenü (inkl. Notizbuch und Task-Manager), Lautstärke (Regler, Stumm), Uhr/Kalender.
- Task-Manager (Startmenü oder Strg+Umschalt+Esc): Prozesse je nach Spielstand, "Task beenden" bei echo_svc verweigert, bei liv.exe bittet Liv.
- Notizbuch: nur Startmenü, vage Einträge.

## Sound, Browser, Fensterfehler (Update)
- **Schrei-Clips** in `renderer/assets/sfx/`, aus der mitgelieferten Aufnahme geschnitten, Einsatz auf ca. 50 ms getrimmt: `a` Säge-Jumpscare, `b` langer Schrei (finaler Jumpscare, 3,7 s), `c` kurz (Absturz-Jumpscare), `d` allgemein (`blackout`), `e` leise abfallend (Livs Entfernung, mit `rate`), `f` zwei Stöße (Echo wehrt sich). Aufruf: `scream('a')` oder `sfx(name, {gain, rate, stopAfter})`. Weitere Teile der Aufnahme lassen sich bei Bedarf schneiden.
- **Stille nach dem Ende:** `hush()` (setzt `__hush`, stoppt alle Clips) beginnt mit dem Epilog. Früherer Bug: Das Intervall der Finale-Seite lief nach dem Ende weiter und löste alle 6 s `crackle` aus. Jetzt stoppt es mit `ended`, und alle Sound-Funktionen prüfen `ended`/`__hush`.
- **Browser:** kleiner Pfeil `‹` links neben "← Verlauf" geht genau eine Seite zurück (Seiten- und Suchverlauf je Browserfenster). "← Verlauf" zeigt weiter die Verlaufsliste.
- **Fensterfehler hängen wirklich** (`errorPop`, `freezeWin`, `chaos`): Meldungen mit Ziel-Fenster (explorer.exe, browser.exe, liv.exe, mail.exe) frieren dessen Inhalt 2,5-6 s ein (Titelleiste bleibt bedienbar, "Keine Rückmeldung"). Schutz: höchstens ein hängendes Fenster, 28 s Abstand, dieselbe Meldung frühestens nach 150 s, nie während Infiltration/Enden (`__finaleBusy`), nie bei der Dienstverwaltung im Browser.
- **Test-Hinweis:** In jsdom spielt `sfx()` keinen Ton, protokolliert aber in `window.__sfxLog`.

## Technik und Stabilität (wichtig)
- `main.js`: genau eine Instanz, Fenster erst bei "ready-to-show" im Vollbild, beim Schließen werden alle Fenster zerstört und der Prozess hart beendet (auch nach Renderer-Absturz oder Hänger), Spielstand atomar gespeichert.
- Build: **kein portable mehr** (das entpackte bei jedem Start ca. 200 MB in den Temp-Ordner und löschte sie beim Beenden, mit Virenscanner sehr langsam). `build.bat` baut jetzt `dist/win-unpacked/StogeOS.exe`, den Ordner zusammen lassen.
- Audio über einen Master-Regler, AudioContext wird beim Beenden geschlossen. Task-Manager-Timer wird beim Schließen beendet.
- Immer beendbar: Strg+Umschalt+Q, Alt+F4, F11 (Vollbild umschalten).

## Dateien
- `renderer/story.js`: alle Inhalte (Dateisystem, Mails, Kalender, Webseiten, Suche, Notizbuch, Hinweise, Liv-Texte, Berechtigungen, Ereignisse).
- `renderer/os.js`: Fenster, Apps, Effekte, Liv-Verhalten, Echo-Fortschritt, Rätselmechanik (`node.edit`, `node.move`), Finale, Enden.
- `renderer/assets/ad_cam.jpg`: Werbung der Schmuddelseite (klein anzeigen).
- `tests/`: jsdom-Durchläufe test2 bis test14. `npm install jsdom --no-save` legt `node_modules` im Projektordner an: nicht mit ins Zip packen.

## Zeitmodell
- Das **Datum auf dem Spiel-PC ist fest der 17.10.2026** (`STORY.today`, Samstag). Die Uhrzeit bleibt die echte. Kalender, Uhr-Tooltip und Nachrichtenportal richten sich danach.
- `STORY.anchor` (16.10.2026) ist nur die Rechenbasis für `dd()`/`at()`, damit alle Kanon-Daten (09.09. Erwachen, 18.09. Verschwinden, Marlenes Geburtstag 18.10. = morgen) stimmen.
- Passwörter: Marlenes Geburtstag `1810`, Klingelschild `2709`.
- Liv kommentiert die Tageszeit einmal je Abschnitt (Nacht, Morgen, Mittag, Nachmittag, Abend, spät) und gelegentlich beiläufig (`STORY.liv.idle`), wenn länger nichts passiert.

## Zustandsmodell (S, gespeichert im Benutzerordner)
Flags u. a.: livMet, archiv, pblocked, saege, pcode, foto2, liebestest(+At), quizFollow, paintStarted, stage1(+At), tbCorrupt, wrAcc, nameSlip, stage2(+At), evMailE(+At), stage3, p2, wall2(+At), eyes, browserLocked, moved, deskNote, notausGone, consoleTried, consoleIn, ended, e40/e60/e80, dec:/ask: je Berechtigung, wb:i, r:key, n:i.
Weitere Felder: S.grants, S.echo, S.sus, S.edits (bearbeitete Dateien), S.livEdits, S.lastLivAt, S.vol, S.muted.

## Dev-Menü (Strg+Umschalt+D)
Effekte, Stufen, Phase 2 direkt, Berechtigungs-Dialoge, Wächter verschoben, Echo +20, Augen an/aus, Spielstand löschen.

## Bibel-Abgleich zum letzten Update (zur Entscheidung durch Yannik)
- Die Bibel nennt ein normales (bad) Ending und ein Good/True Ending mit geheimer Anti-Virus-Datei: beides ist jetzt umgesetzt.
- Die Bibel schlägt vor, der Spieler solle am Ende nicht wissen, ob Liv gut oder böse ist (Vorschlag, kein Kanon). Das normale Ende löst das auf (Liv lacht, sie hat gewonnen), das wahre Ende lässt Echos Rettung offen.
- Offen bleibt weiterhin Georgs und Brunos Schicksal. Neu und von Yannik beauftragt: `anti_virus_limit` als Georgs Schutzdienst.

## Umbauplan (VORSCHLÄGE)
1. Weitere Enden-Varianten (z. B. Livs Bild vom Spieler aus `S.traits` färbt den Monolog), jeweils mit einer letzten Irritation.
2. Liv zitiert gelegentlich frühere Suchbegriffe des Spielers leicht verändert.
3. Datei-Eigenschaften (Ersteller/Änderung) als zusätzliche Spur.
4. Weitere Rätsel nach dem Muster `node.edit` / `node.move`, sparsam.
