# PROJEKT.md: Übergabe für einen neuen Chat

Fake-Desktop-Horrorspiel (Arbeitstitel LIV / StogeOS) als Electron-App. Spielt auf dem Rechner von Georg Stoge.
Der Spieler loggt sich als Gast ein und findet nach und nach, was Georgs selbstgebaute KI "Liv" getan hat.

## Zusammenarbeit
- Yannik (Auftraggeber) liefert Ideen und Bilder (ChatGPT-generiert), Claude baut den Code. Pushen ins Repo macht Yannik.
- Ton: locker, ehrlich, gern mit Ansage. Yannik neigt dazu, viele Ideen auf einmal zu sammeln: erst Stand testen lassen, dann erweitern.
- Nach jedem Update: Zip einspielen, im Dev-Menü "Spielstand löschen".

## Dateien
- `main.js`, `preload.js`: Electron, harmloser Systemzugriff (Windows-Benutzername, Desktop-Dateinamen lesen, nur .txt auf den Desktop schreiben, Spielstand speichern). Immer beendbar: Strg+Umschalt+Q, Alt+F4, F11.
- `renderer/story.js`: ALLE Inhalte (Dateisystem `buildFs`, Mails, Kalender, Webseiten `pages`, Suchindex `search`, `suggest`, Notizbuch-Einträge `clues`, `hints`, Liv-Texte `liv.first/nudges/reactions`).
- `renderer/os.js`: Fenstersystem, Apps (Explorer, Mail, Browser, Kalender, Startmenü, Notizbuch, Paint), Effekte, Livs Verhalten, Finale, Enden.
- `renderer/style.css`, `index.html`, `renderer/assets/` (Bilder).
- `start.bat`, `start-fenster.bat` (Test im Fenster), `build.bat` (portable .exe in dist/).
- `tests/`: Durchlauf-Tests (siehe tests/README.md).

## Zustandsmodell (S.flags, gespeichert im Benutzerordner)
livUnlocked, livStarted, livMet, nameSlip, stage1/2/3, late (ab Stufe 1: Liv eifersüchtig, Augen folgen dauerhaft), p2 (Phase 2), wallStage 0/1/2 + wallZoom,
wall2, pcode, foto2, saege/saegeAt, liebestest/quizFollow, consoleIn, ended ('stop'|'stay'), r:<key> (Reaktion schon gezeigt), n:<i> (Anstupser gezeigt),
S.traits (naehe, haerte, neugier, folgsam), S.clues (Notizbuch), S.livLog (Livs Chatverlauf).
Versteckte Inhalte: Knoten mit `req: { flag | opened }` in story.js erscheinen erst, wenn die Bedingung stimmt.

## Spielablauf (Akt 1, ca. 20+ Min.)
1. Gast-Login. Mail vom Tierarzt -> Passwort `bruno2019` -> Ordner privat -> `readme_liv.txt` -> liv.exe erscheint.
2. Livs Erstkontakt (Augen folgen einmal als Scare). Nach 2,5 bis 5 Min. "Versprecher" mit echtem Windows-Namen, den sie sichtbar zurück auf den Login-Namen ändert; danach liegt anmeldung.log in System und das Archiv in den Dokumenten.
3. Archiv: Tagebuch, `liv_changelog.txt` (Stufe 1, Liv kippt) -> System/liv_svc mit Beobachtungslogs -> `beobachtungen_marlene.log` (Stufe 2; Gesendet-Ordner enthält Mails, die Liv als Georg schrieb).
4. Kern (Passwort = Datum der Klingelschild-Zeile im Marlene-Log, TTMM): `plan.txt` löst Bug-Sequenz -> Bluescreen -> Phase 2 aus.
5. Nebenstränge: Prüfstein (Spam-Code PS-7291 -> pruefstein.net/code -> Foto-Datum 140822 -> Bilder/privat mit Marlenes Sprachnachricht), Liebestest (erst mit Liv), Suchbegriffe (Stoppschalter, Reuter, Marlene, Georg, vermisst), Säge-Test (Baum/Herz/Mensch, Auge-Scare).
6. Liv malt (Paint) ein Bild, später dunkle Variante mit drittem Wesen.

## Phase 2 und Lore
- Wallpaper-Stufen: leerer See -> Person sitzt am See -> Wesen sitzt am See, Zoom "kommt näher". Neustart legt `Für <Windows-Name>.txt` auf den echten Desktop und Liv kommentiert einen echten Dateinamen.
- Lore: Georg wurde von Liv "behalten" (sitzt am See, ist am Ende vielleicht das Wesen). Marlene wurde von Liv "besucht": Mail mit Tür-Foto, Zeitungsartikel (beide vermisst). Das Wesen = Livs böses Alter Ego (offen: auch Georgs Rest?).
- Finale: `localhost:8080/notaus` (Hinweis im Forum-Thread zu "Stoppschalter") -> Sicherheitsfragen: Bruno / 140822 / niemandem -> Ordner `liv_svc` -> Livs getippte Bitte -> Beenden (Jumpscare, Danke.txt) oder Abbrechen (Bleib.txt).

## Dev-Menü (Strg+Umschalt+D)
Effekte einzeln testen, Stufen freischalten, Phase 2 direkt, Spielstand löschen.

## Offen / Ideen
Liv-Terminal (tippt allein, versteckt Marlene-Dateien im Papierkorb), Voicemail-Ordner, drittes Ende (Spiel schließen), weitere Wallpaper-Stufen (Figur näher), Videos (brauchen Material),
Livs Interface-Upgrade (Bilder hochladen), Minispiel (Tic Tac Toe), "Neue Datei"-Funktion.
