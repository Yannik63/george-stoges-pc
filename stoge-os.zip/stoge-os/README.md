# StogeOS / LIV

Fake-Desktop-Horrorspiel als Electron-App.

## Starten (zum Testen)
1. Einmalig Node.js (LTS) installieren: https://nodejs.org
2. Doppelklick auf `start-fenster.bat` (Fenster, zum Testen) oder `start.bat` (Vollbild).
   Beim ersten Mal wird automatisch `npm install` ausgeführt.

## Fertige .exe bauen
Doppelklick auf `build.bat`. Die portable `StogeOS.exe` liegt danach in `dist\`.
Windows zeigt beim Start eventuell eine SmartScreen-Warnung (App ist nicht signiert):
"Weitere Informationen" -> "Trotzdem ausführen".

## Tasten
- `Strg+Umschalt+Q`: Spiel sofort beenden (geht immer, ebenso Alt+F4)
- `F11`: Vollbild an/aus
- `Strg+Umschalt+D`: Dev-Menü (alle Effekte testen, Werte ansehen, Spielstand löschen)

## Wo liegt was
- `renderer/story.js`: ALLE Inhalte (Dateien, Mails, Verlauf, Szenen, Livs Texte)
- `renderer/os.js`: Fenster, Apps, Effekte, Spiellogik
- `main.js`: Zugriff auf den echten Rechner (Name, Desktop-Dateinamen, .txt auf den Desktop)

## Was das Spiel am echten Rechner tut
Nur: Windows-Benutzername und Rechnername lesen, Dateinamen vom Desktop lesen (nie Inhalte),
.txt-Dateien auf den Desktop legen (überschreibt nie etwas), einen Spielstand im
Benutzerordner speichern. Keine Kamera, kein Mikrofon, kein Netzwerk.

## Enden (Kurzüberblick)
- Normales Ende: im Finale den Dienst `echo_svc` beenden. Der Knopf trägt in Wahrheit den Namen `anti_virus_limit (liv)`.
- Wahres Ende: statt des Ordnernamens Georgs Notfallcode eingeben (drei Teile, verstreut, siehe PROJEKT.md).
- Auf den echten Desktop schreibt das Spiel höchstens eine `.txt` (`ich bin noch da.txt` bzw. `echo_backup.txt`).
