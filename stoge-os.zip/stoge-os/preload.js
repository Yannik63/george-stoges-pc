const { contextBridge, ipcRenderer } = require('electron');

contextBridge.exposeInMainWorld('sys', {
  info: () => ipcRenderer.invoke('sys:info'),
  desktopFiles: () => ipcRenderer.invoke('sys:desktopFiles'),
  writeDesktop: (name, content) => ipcRenderer.invoke('sys:writeDesktop', name, content),
  fakeRestart: phase => ipcRenderer.invoke('sys:fakeRestart', phase),
  saveState: s => ipcRenderer.invoke('sys:saveState', s),
  loadState: () => ipcRenderer.invoke('sys:loadState'),
  resetState: () => ipcRenderer.invoke('sys:resetState'),
  quit: () => ipcRenderer.invoke('sys:quit')
});
