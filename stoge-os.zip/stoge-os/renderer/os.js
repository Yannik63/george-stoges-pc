(() => {
  'use strict';
  const $ = (s, r = document) => r.querySelector(s);
  const el = (tag, cls, html) => { const e = document.createElement(tag); if (cls) e.className = cls; if (html != null) e.innerHTML = html; return e; };
  const esc = s => String(s).replace(/[&<>"]/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' }[c]));
  const sleep = ms => new Promise(r => setTimeout(r, ms));

  // Fallback, falls die Seite mal im normalen Browser statt in Electron läuft
  const sys = window.sys || {
    info: async () => ({ user: 'browser', host: 'testpc' }),
    desktopFiles: async () => [],
    writeDesktop: async n => n,
    fakeRestart: async () => location.reload(),
    saveState: async s => { try { localStorage.setItem('stoge', JSON.stringify(s)); } catch (e) {} },
    loadState: async () => { try { return JSON.parse(localStorage.getItem('stoge')); } catch (e) { return null; } },
    resetState: async () => { try { localStorage.removeItem('stoge'); } catch (e) {} },
    quit: async () => window.close()
  };

  let ENV = { user: 'gast', host: 'pc' };
  let S = { name: '', phase: 1, traits: { naehe: 0, haerte: 0, neugier: 0 }, flags: {}, unlocked: [], opened: [], livUnlocked: false, lastSeen: null };
  let FS = null;
  const save = () => { try { sys.saveState(S); } catch (e) {} };

  // ---------------------------------------------------------------- Effekte
  function toast(msg, ms = 4000) {
    const t = el('div', 'toast', esc(msg));
    $('#toasts').appendChild(t);
    setTimeout(() => t.classList.add('out'), ms);
    setTimeout(() => t.remove(), ms + 600);
  }

  let actx = null;
  function scream() { // synthetischer Platzhalter-Schrei, später durch echte Audiodatei ersetzbar
    try {
      actx = actx || new (window.AudioContext || window.webkitAudioContext)();
      const a = actx, t = a.currentTime;
      const o = a.createOscillator(), g = a.createGain();
      o.type = 'sawtooth';
      o.frequency.setValueAtTime(900, t);
      o.frequency.exponentialRampToValueAtTime(120, t + 1.6);
      g.gain.setValueAtTime(0.0001, t);
      g.gain.exponentialRampToValueAtTime(0.45, t + 0.05);
      g.gain.exponentialRampToValueAtTime(0.0001, t + 1.8);
      o.connect(g); g.connect(a.destination); o.start(t); o.stop(t + 1.9);
      const buf = a.createBuffer(1, Math.floor(a.sampleRate * 1.5), a.sampleRate);
      const d = buf.getChannelData(0);
      for (let i = 0; i < d.length; i++) d[i] = (Math.random() * 2 - 1) * (1 - i / d.length);
      const n = a.createBufferSource(), ng = a.createGain();
      n.buffer = buf; ng.gain.value = 0.35; n.connect(ng); ng.connect(a.destination); n.start(t);
    } catch (e) {}
  }

  function blackout(ms = 3000, withScream = false) {
    const o = $('#overlay');
    o.className = 'black'; o.innerHTML = '';
    if (withScream) scream();
    setTimeout(() => { o.className = 'hidden'; }, ms);
  }

  function bsod(done) {
    const o = $('#overlay');
    o.className = 'bsod';
    o.innerHTML = '<div class="face">:(</div><p>StogeOS hat ein Problem festgestellt und muss neu gestartet werden.</p><p class="pc">0% abgeschlossen</p><p class="small">Stoppcode: LIV_NOT_FOUND_IN_MEMORY<br>Betroffene Datei: liv.exe</p>';
    let p = 0;
    const pc = $('.pc', o);
    const iv = setInterval(() => {
      p = Math.min(100, p + Math.floor(Math.random() * 9) + 2);
      pc.textContent = p + '% abgeschlossen';
      if (p >= 100) {
        clearInterval(iv);
        setTimeout(() => { o.className = 'hidden'; if (done) done(); }, 700);
      }
    }, 280);
  }

  function fakeCrash() {
    bsod(() => {
      $('#overlay').className = 'black';
      S.phase = 2; save();
      setTimeout(() => sys.fakeRestart(2), 1800);
    });
  }

  // ---------------------------------------------------------------- Fenstersystem
  let zTop = 10, topId = null;
  const wins = {};

  function focusWin(id) {
    const r = wins[id]; if (!r) return;
    r.win.style.zIndex = ++zTop; topId = id;
    Object.values(wins).forEach(w => { w.win.classList.toggle('active', w === r); w.task.classList.toggle('on', w === r && !w.min); });
  }
  function toggleMin(id) {
    const r = wins[id]; if (!r) return;
    r.min = !r.min; r.win.style.display = r.min ? 'none' : 'flex';
    if (!r.min) focusWin(id); else r.task.classList.remove('on');
  }
  function closeWindow(id) {
    const r = wins[id]; if (!r) return;
    r.win.remove(); r.task.remove(); delete wins[id];
  }
  function drag(win, bar) {
    bar.addEventListener('mousedown', e => {
      if (e.target.tagName === 'BUTTON') return;
      const sx = e.clientX - win.offsetLeft, sy = e.clientY - win.offsetTop;
      const mv = ev => {
        win.style.left = Math.max(0, Math.min(innerWidth - 80, ev.clientX - sx)) + 'px';
        win.style.top = Math.max(0, Math.min(innerHeight - 70, ev.clientY - sy)) + 'px';
      };
      const up = () => { document.removeEventListener('mousemove', mv); document.removeEventListener('mouseup', up); };
      document.addEventListener('mousemove', mv); document.addEventListener('mouseup', up);
    });
  }
  function openWindow(id, title, content, o = {}) {
    if (wins[id]) { if (wins[id].min) toggleMin(id); focusWin(id); return wins[id]; }
    const { w = 520, h = 380 } = o;
    const n = Object.keys(wins).length;
    const win = el('div', 'win');
    win.style.width = w + 'px'; win.style.height = h + 'px';
    win.style.left = (o.x != null ? o.x : 120 + n * 28) + 'px';
    win.style.top = (o.y != null ? o.y : 60 + n * 28) + 'px';
    const bar = el('div', 'titlebar');
    const bmin = el('button', '', '_'), bclose = el('button', '', '×');
    const btns = el('span', 'wbtns'); btns.append(bmin, bclose);
    bar.append(el('span', '', esc(title)), btns);
    const body = el('div', 'wbody'); body.append(content);
    win.append(bar, body); $('#windows').append(win);
    const task = el('button', 'task', esc(title)); $('#tasks').append(task);
    const rec = { id, win, task, body, min: false };
    wins[id] = rec;
    win.addEventListener('mousedown', () => focusWin(id));
    task.onclick = () => (rec.min ? toggleMin(id) : (topId === id ? toggleMin(id) : focusWin(id)));
    bmin.onclick = () => toggleMin(id);
    bclose.onclick = () => closeWindow(id);
    drag(win, bar); focusWin(id);
    return rec;
  }

  // ---------------------------------------------------------------- Apps
  const nodeAt = path => { let n = FS; for (const p of path) { n = n && n.c && n.c.find(x => x.n === p); if (!n) return null; } return n; };

  function openExplorer(startPath = []) {
    if (wins.explorer) { wins.explorer.nav([...startPath]); openWindow('explorer'); return; }
    let path = [...startPath];
    const c = el('div', 'explorer');
    const rec = openWindow('explorer', 'Datei-Explorer', c, { w: 580, h: 400 });
    const render = () => {
      c.innerHTML = '';
      const node = nodeAt(path) || FS;
      const bar = el('div', 'pathbar');
      const up = el('button', '', '↑'); up.disabled = !path.length;
      up.onclick = () => { path.pop(); render(); };
      bar.append(up, el('span', '', esc('C:\\' + ['Georgs PC', ...path].join('\\'))));
      c.append(bar);
      const list = el('div', 'flist');
      node.c.forEach(ch => {
        const full = [...path, ch.n];
        const locked = ch.lock && !S.unlocked.includes(full.join('/'));
        const r = el('div', 'frow', `<span class="ico">${ch.t === 'dir' ? (locked ? '🔒' : '📁') : '📄'}</span>${esc(ch.n)}`);
        r.onclick = () => { list.querySelectorAll('.sel').forEach(x => x.classList.remove('sel')); r.classList.add('sel'); };
        r.ondblclick = () => {
          if (ch.t === 'dir') {
            if (locked) askPassword(ch, full, () => { path = full; render(); });
            else { path = full; render(); }
          } else openFile(ch, full);
        };
        list.append(r);
      });
      if (!node.c.length) list.append(el('div', 'empty', '(leer)'));
      c.append(list);
    };
    rec.nav = p => { path = p; render(); };
    render();
  }

  function askPassword(node, fullPath, ok) {
    const c = el('div', 'pw', `<p>🔒 <b>${esc(node.n)}</b> ist passwortgeschützt.</p>`);
    const inp = el('input'); inp.type = 'password'; inp.placeholder = 'Passwort';
    const b = el('button', '', 'Öffnen'), hb = el('button', '', 'Hinweis'), msg = el('div', 'pwmsg', '');
    const go = () => {
      if (inp.value.trim().toLowerCase() === node.lock.pw) {
        S.unlocked.push(fullPath.join('/')); save(); closeWindow('pw'); ok();
      } else {
        msg.textContent = 'Falsches Passwort.';
        c.classList.remove('shake'); void c.offsetWidth; c.classList.add('shake');
      }
    };
    b.onclick = go; inp.onkeydown = e => { if (e.key === 'Enter') go(); };
    hb.onclick = () => { msg.textContent = 'Hinweis: ' + node.lock.hint; };
    c.append(inp, b, hb, msg);
    openWindow('pw', 'Zugriff', c, { w: 340, h: 190, x: 260, y: 160 });
    inp.focus();
  }

  function openFile(node, fullPath) {
    const key = fullPath.join('/');
    openWindow('file:' + key, node.n, el('pre', 'txt', esc(node.text)), { w: 480, h: 360 });
    if (!S.opened.includes(key)) { S.opened.push(key); save(); }
    if (node.unlocksLiv) unlockLiv();
  }

  function unlockLiv() {
    if (S.livUnlocked) return;
    S.livUnlocked = true; save();
    setTimeout(() => { renderIcons(); toast('Neue Datei auf dem Desktop: liv.exe', 6000); }, 2500);
  }

  function openMail() {
    const c = el('div', 'mail');
    const list = el('div', 'mlist'), body = el('div', 'mbody', '<em>Wähle eine Mail.</em>');
    STORY.mails.forEach((m, i) => {
      const k = 'mail' + i;
      const r = el('div', 'mrow' + (S.opened.includes(k) ? '' : ' unread'), `<b>${esc(m.from)}</b><br>${esc(m.subj)}<small>${esc(m.date)}</small>`);
      r.onclick = () => {
        body.innerHTML = `<h3>${esc(m.subj)}</h3><p class="meta">Von: ${esc(m.from)} · ${esc(m.date)}</p><pre>${esc(m.body)}</pre>`;
        r.classList.remove('unread');
        if (!S.opened.includes(k)) { S.opened.push(k); save(); }
      };
      list.append(r);
    });
    c.append(list, body);
    openWindow('mail', 'Mail: georg.stoge@stogenet.de', c, { w: 660, h: 420 });
  }

  function openBrowser() {
    const c = el('div', 'browser');
    const bar = el('div', 'urlbar');
    const back = el('button', '', '← Verlauf'), url = el('input'); url.readOnly = true;
    bar.append(back, url);
    const view = el('div', 'bview');
    c.append(bar, view);
    const home = () => {
      url.value = 'verlauf://';
      view.innerHTML = '<h3>Verlauf</h3>';
      STORY.history.forEach(h => {
        const row = el('div', 'hrow', `<a href="#">${esc(h.title)}</a><small>${esc(h.url)} · ${esc(h.when)}</small>`);
        row.querySelector('a').onclick = ev => { ev.preventDefault(); visit(h); };
        view.append(row);
      });
    };
    const visit = h => {
      url.value = h.url; view.innerHTML = '';
      if (h.scene) renderScene(view, STORY.scenes[h.scene], h.scene);
      else view.append(el('div', 'pagetxt', esc(h.text || '(Seite nicht mehr verfügbar)')));
    };
    back.onclick = home; home();
    openWindow('web', 'Browser', c, { w: 640, h: 430 });
  }

  function renderScene(view, scene, id) {
    const done = S.flags[id];
    const page = el('div', 'pruef');
    if (done) {
      page.innerHTML = `<h2>${esc(scene.site)}</h2><p>${esc(scene.done)}</p>`;
      view.append(page); return;
    }
    page.innerHTML = `<h2>${esc(scene.headline)}</h2><p>${esc(scene.text).replace(/\n/g, '<br>')}</p>`;
    const opts = el('div', 'opts');
    scene.options.forEach(o => {
      const b = el('button', 'opt', `<span>${o.emoji}</span>${esc(o.label)}`);
      b.onclick = () => {
        if (S.flags[id]) return;
        S.flags[id] = o.id;
        Object.entries(o.effects || {}).forEach(([k, v]) => { S.traits[k] = (S.traits[k] || 0) + v; });
        save();
        const showAfter = () => { page.innerHTML = `<h2>${esc(scene.site)}</h2><p>${esc(o.after)}</p><p>${esc(scene.done)}</p>`; };
        if (o.fx === 'blackScream') { blackout(4500, true); setTimeout(showAfter, 4500); } else showAfter();
      };
      opts.append(b);
    });
    page.append(opts, el('div', 'foot', esc(scene.foot)));
    view.append(page);
  }

  async function typeInto(p, text) {
    for (const ch of text) {
      if (!p.isConnected) return;
      p.textContent += ch;
      await sleep(ch === '.' ? 260 : 48);
    }
  }
  async function openLiv() {
    const c = el('div', 'liv');
    const hadWindow = !!wins.liv;
    const rec = openWindow('liv', 'liv.exe', c, { w: 440, h: 320, x: 340, y: 130 });
    if (hadWindow) return;
    for (const line of STORY.livFirstContact(S)) {
      const p = el('p', 'livline', ''); c.append(p);
      await typeInto(p, line);
      await sleep(900);
    }
    S.flags.livMet = true; save();
  }

  // ---------------------------------------------------------------- Dev-Menü (Strg+Umschalt+D)
  function toggleDev() {
    if (wins.dev) { closeWindow('dev'); return; }
    const c = el('div', 'dev'); const out = el('pre', 'devout', 'Dev-Menü. Hier testest du alle Effekte.');
    const add = (label, fn) => { const b = el('button', '', esc(label)); b.onclick = async () => { const r = await fn(); if (r != null) out.textContent = r; }; c.append(b); };
    add('Fake-Bluescreen (nur Effekt)', () => { bsod(); return 'läuft…'; });
    add('Schwarzbild 3s + Ton', () => { blackout(3000, true); return 'läuft…'; });
    add('Fake-Absturz mit Neustart in Phase 2', () => { fakeCrash(); return 'läuft…'; });
    add('Desktop-Dateinamen lesen', async () => { const f = await sys.desktopFiles(); return f.length ? f.join('\n') : '(nichts gefunden)'; });
    add('Test-Datei auf den Desktop legen', async () => { const f = await sys.writeDesktop('Hallo_' + (S.name || 'Gast') + '.txt', 'Ich war hier.\n\n(Testdatei von StogeOS. Du kannst sie löschen.)'); return f ? 'geschrieben: ' + f : 'Fehler'; });
    add('liv.exe sofort freischalten', () => { S.livUnlocked = true; save(); renderIcons(); return 'ok'; });
    add('Werte anzeigen', () => JSON.stringify({ phase: S.phase, traits: S.traits, flags: S.flags, livUnlocked: S.livUnlocked }, null, 1));
    add('Spielstand löschen + neu laden', async () => { await sys.resetState(); location.reload(); });
    c.append(out);
    openWindow('dev', 'Dev', c, { w: 380, h: 430, x: 60, y: 40 });
  }
  document.addEventListener('keydown', e => {
    if (e.ctrlKey && e.shiftKey && e.key.toLowerCase() === 'd' && !$('#desktop').classList.contains('hidden')) toggleDev();
  });

  // ---------------------------------------------------------------- Desktop & Login
  const ICONS = [
    { id: 'docs', label: 'Dokumente', ico: '📁', open: () => openExplorer(['Dokumente']) },
    { id: 'mail', label: 'Mail', ico: '✉️', open: openMail },
    { id: 'web', label: 'Browser', ico: '🌐', open: openBrowser },
    { id: 'sys', label: 'System', ico: '💾', open: () => openExplorer(['System']) },
    { id: 'trash', label: 'Papierkorb', ico: '🗑️', open: () => openExplorer(['Papierkorb']) }
  ];
  function renderIcons() {
    const box = $('#icons'); box.innerHTML = '';
    const list = [...ICONS];
    if (S.livUnlocked) list.push({ id: 'liv', label: 'liv.exe', ico: '▶', open: openLiv, cls: 'liv' });
    list.forEach(i => {
      const d = el('div', 'icon' + (i.cls ? ' ' + i.cls : ''), `<div class="g">${i.ico}</div><div>${esc(i.label)}</div>`);
      d.dataset.id = i.id; d.ondblclick = i.open;
      d.onclick = () => { box.querySelectorAll('.sel').forEach(x => x.classList.remove('sel')); d.classList.add('sel'); };
      box.append(d);
    });
  }

  function tickClock() {
    const d = new Date();
    $('#clock').textContent = String(d.getHours()).padStart(2, '0') + ':' + String(d.getMinutes()).padStart(2, '0');
  }

  function enterDesktop(fresh) {
    FS = STORY.buildFs({ name: S.name, user: ENV.user, host: ENV.host, now: new Date() });
    $('#login').classList.add('hidden');
    $('#desktop').classList.remove('hidden');
    renderIcons(); tickClock(); setInterval(tickClock, 15000);
    if (S.phase >= 2) setTimeout(() => toast(`Willkommen zurück, ${S.name}.`, 5000), 1500);
    else if (fresh) toast('Angemeldet als Gast: ' + S.name, 3500);
  }

  async function boot() {
    try { ENV = await sys.info(); } catch (e) {}
    const saved = await sys.loadState();
    if (saved) S = Object.assign(S, saved, { traits: Object.assign({ naehe: 0, haerte: 0, neugier: 0 }, saved.traits || {}) });
    document.title = S.phase >= 2 ? 'liv' : 'StogeOS 3.2';
    document.body.classList.toggle('phase2', S.phase >= 2);
    if (S.phase >= 2 && S.name) { enterDesktop(false); return; }

    const inp = $('#nameinput'), btn = $('#loginbtn');
    if (S.name) {
      inp.value = S.name;
      if (S.lastSeen) $('#loginfo').textContent = 'Letzte Gast-Sitzung: ' + new Date(S.lastSeen).toLocaleString('de-DE');
    }
    const go = () => {
      const v = inp.value.trim().slice(0, 40);
      if (!v) { inp.focus(); return; }
      S.name = v; S.lastSeen = Date.now(); save();
      enterDesktop(true);
    };
    btn.onclick = go;
    inp.onkeydown = e => { if (e.key === 'Enter') go(); };
    inp.focus();
  }
  boot();
})();
