(() => {
  'use strict';
  const $ = (s, r = document) => r.querySelector(s);
  const el = (tag, cls, html) => { const e = document.createElement(tag); if (cls) e.className = cls; if (html != null) e.innerHTML = html; return e; };
  const esc = s => String(s).replace(/[&<>"]/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' }[c]));
  const speed = () => window.__SPEED || 1;               // nur für Tests
  // ---- Pause: Ist das Spiel nicht im Vordergrund (Tab-Wechsel, minimiert) oder geschlossen, steht die Spielzeit still ----
  // Alle Zeitgeber laufen über later()/sleep() und werden angehalten. Gespeicherte Zeitstempel rücken beim Weitermachen um die
  // Pausendauer vor (shiftClock), damit nichts "nachgeholt" wird und man nichts verpasst.
  const timers = new Set(); let pausedAt = 0, winFocus = true;
  window.__paused = false;
  const armTimer = t => { t.start = Date.now(); t.id = setTimeout(() => { timers.delete(t); t.fn(); }, Math.max(0, t.left)); };
  const later = (fn, ms) => { const t = { fn, left: ms * speed(), id: null, start: 0 }; timers.add(t); if (!window.__paused) armTimer(t); return t; };
  const sleep = ms => new Promise(r => later(r, ms));
  const pad = n => String(n).padStart(2, '0');

  // Fallback, falls die Seite im normalen Browser läuft
  const sys = window.sys || {
    info: async () => ({ user: 'browser', host: 'testpc' }),
    desktopFiles: async () => [],
    writeDesktop: async n => n,
    fakeRestart: async () => location.reload(),
    saveState: async s => { try { localStorage.setItem('stoge', JSON.stringify(s)); } catch (e) {} },
    loadState: async () => { try { return JSON.parse(localStorage.getItem('stoge')); } catch (e) { return null; } },
    resetState: async () => { try { localStorage.removeItem('stoge'); } catch (e) {} },
    quit: async () => window.close()
  };

  let ENV = { user: 'gast', host: 'pc' };
  let S = { name: '', phase: 1, traits: { naehe: 0, haerte: 0, neugier: 0 }, flags: {}, unlocked: [], opened: [], livUnlocked: false, lastSeen: null, livLog: [], livMetAt: null, clues: [] };
  let FS = null;
  const save = () => { if (window.__over) return; S.lastActive = Date.now(); try { sys.saveState(S); } catch (e) {} };
  const rebuildFs = () => { FS = STORY.buildFs({ name: S.name, user: ENV.user, host: ENV.host, now: new Date(), S }); };

  function shiftClock(d) {
    if (!(d > 0)) return;
    const bump = o => Object.keys(o).forEach(k => { if ((/At$/.test(k) || /^eoOpen:/.test(k)) && typeof o[k] === 'number' && o[k] > 1e12) o[k] += d; });
    bump(S.flags);
    ['livMetAt', 'lastLivAt'].forEach(k => { if (typeof S[k] === 'number') S[k] += d; });
    lastReact += d; lastProgress += d; lastNudge += d; lastAmbient += d; lastFreezeAt += d; eyeUntil += d;
    reactQueue.forEach(it => { it.t += d; });
    save();
  }
  function setPaused(p) {
    if (p === window.__paused) return;
    window.__paused = p;
    const now = Date.now();
    if (p) {
      pausedAt = now;
      timers.forEach(t => { if (t.id != null) { clearTimeout(t.id); t.id = null; t.left -= now - t.start; } });
      activeSfx.forEach(a => { try { a.pause(); } catch (e) {} });
      try { if (actx) actx.suspend(); } catch (e) {}
    } else {
      shiftClock(now - pausedAt);
      timers.forEach(t => armTimer(t));
      if (!window.__hush) activeSfx.forEach(a => { try { const pr = a.play(); if (pr && pr.catch) pr.catch(() => {}); } catch (e) {} });
      try { if (actx && !window.__hush) actx.resume(); } catch (e) {}
    }
  }
  window.addEventListener('blur', () => { winFocus = false; setPaused(true); });
  window.addEventListener('focus', () => { winFocus = true; setPaused(!!document.hidden); });
  document.addEventListener('visibilitychange', () => setPaused(!!document.hidden || !winFocus));

  // ================================================================ Effekte
  function toast(msg, ms = 4000) {
    const t = el('div', 'toast', esc(msg));
    $('#toasts').appendChild(t);
    later(() => t.classList.add('out'), ms);
    later(() => t.remove(), ms + 600);
  }

  // ---- Audio: alles läuft über einen Master-Regler (Lautstärke/Stumm in der Taskleiste) ----
  let actx = null, master = null;
  function audio() {
    actx = actx || new (window.AudioContext || window.webkitAudioContext)();
    if (!master) { master = actx.createGain(); master.connect(actx.destination); applyVol(); }
    if (actx.state === 'suspended') actx.resume().catch(() => {});
    return actx;
  }
  const outNode = () => { audio(); return master; };
  function applyVol() {
    if (master) master.gain.value = S.muted ? 0 : (S.vol == null ? 0.8 : S.vol);
    activeSfx.forEach(a => { try { a.volume = Math.min(1, sfxLevel() * (a._g || 1)); } catch (e) {} });
  }
  addEventListener('beforeunload', () => { try { if (actx) actx.close(); } catch (e) {} });
  // ---- Schrei-Clips: aus der mitgelieferten Aufnahme geschnitten (assets/sfx), jeder mit hartem Einsatz ----
  //  a = Säge-Jumpscare · b = langer Schrei (finaler Jumpscare) · c = kurz und scharf (Absturz) · d = mittlerer Schrei
  //  e = leiser, abfallender Schrei (Livs Entfernung, gern mit rate) · f = zwei Stöße (Echo wehrt sich)
  const SFX = { a: 'assets/sfx/scream_a.mp3', b: 'assets/sfx/scream_b.mp3', c: 'assets/sfx/scream_c.mp3', d: 'assets/sfx/scream_d.mp3', e: 'assets/sfx/scream_e.mp3', f: 'assets/sfx/scream_f.mp3' };
  const activeSfx = new Set();
  window.__hush = false;                                     // nach dem Ende: keine Geräusche mehr
  const sfxLevel = () => (S.muted ? 0 : (S.vol == null ? 0.8 : S.vol));
  const canPlayAudio = () => !/jsdom/i.test(navigator.userAgent || '');
  function preloadSfx() { if (!canPlayAudio()) return; Object.values(SFX).forEach(src => { try { const a = new Audio(src); a.preload = 'auto'; a.load(); } catch (e) {} }); }
  function sfx(name, o = {}) {
    if (window.__hush || !SFX[name]) return null;
    if (window.__sfxLog) window.__sfxLog.push(name);       // nur für Tests
    if (!canPlayAudio()) return null;
    try {
      const a = new Audio(SFX[name]), g = o.gain == null ? 1 : o.gain;
      a._g = g; a.volume = Math.min(1, sfxLevel() * g);
      if (o.rate) { a.preservesPitch = false; a.mozPreservesPitch = false; a.webkitPreservesPitch = false; a.playbackRate = o.rate; }
      activeSfx.add(a); a.addEventListener('ended', () => activeSfx.delete(a));
      const pr = a.play();
      if (pr && pr.catch) pr.catch(() => { activeSfx.delete(a); if (o.fallback !== false) screamSynth(); });
      if (o.stopAfter) later(() => { try { a.pause(); } catch (e) {} activeSfx.delete(a); }, o.stopAfter);
      return a;
    } catch (e) { return null; }
  }
  function stopAllSfx() { activeSfx.forEach(a => { try { a.pause(); } catch (e) {} }); activeSfx.clear(); }
  function hush() { window.__hush = true; stopAllSfx(); try { if (actx) actx.suspend(); } catch (e) {} }
  function scream(kind = 'd', o = {}) { if (window.__hush) return; if (!sfx(kind, o) && canPlayAudio()) screamSynth(); }
  function screamSynth() { // Notnagel, falls ein Clip nicht abspielbar ist
    if (window.__hush) return;
    try {
      audio();
      const a = actx, t = a.currentTime;
      const o = a.createOscillator(), g = a.createGain();
      o.type = 'sawtooth';
      o.frequency.setValueAtTime(900, t);
      o.frequency.exponentialRampToValueAtTime(120, t + 1.6);
      g.gain.setValueAtTime(0.0001, t);
      g.gain.exponentialRampToValueAtTime(0.45, t + 0.05);
      g.gain.exponentialRampToValueAtTime(0.0001, t + 1.8);
      o.connect(g); g.connect(outNode()); o.start(t); o.stop(t + 1.9);
      const buf = a.createBuffer(1, Math.floor(a.sampleRate * 1.5), a.sampleRate);
      const d = buf.getChannelData(0);
      for (let i = 0; i < d.length; i++) d[i] = (Math.random() * 2 - 1) * (1 - i / d.length);
      const n = a.createBufferSource(), ng = a.createGain();
      n.buffer = buf; ng.gain.value = 0.35; n.connect(ng); ng.connect(outNode()); n.start(t);
    } catch (e) {}
  }
  function blackout(ms = 3000, withScream = false) {
    const o = $('#overlay');
    o.className = 'black'; o.innerHTML = '';
    if (withScream) scream('d');
    later(() => { o.className = 'hidden'; }, ms);
  }
  function bsod(done) {
    const o = $('#overlay');
    o.className = 'bsod';
    o.innerHTML = '<div class="face">:(</div><p>StogeOS hat ein Problem festgestellt und muss neu gestartet werden.</p><p class="pc">0% abgeschlossen</p><p class="small">Stoppcode: LIV_NOT_FOUND_IN_MEMORY<br>Betroffene Datei: liv.exe</p>';
    let p = 0;
    const pc = $('.pc', o);
    const iv = setInterval(() => {
      if (window.__paused) return;
      p = Math.min(100, p + Math.floor(Math.random() * 9) + 2);
      pc.textContent = p + '% abgeschlossen';
      if (p >= 100) { clearInterval(iv); later(() => { o.className = 'hidden'; if (done) done(); }, 700); }
    }, 280 * speed());
  }
  function wallGlitch() {
    const w = $('#wall');
    [[1, 0], [0, 900], [1, 1700], [0, 2500], [1, 3300], [0, 3900]].forEach(([on, ms]) => later(() => w.classList.toggle('neg', !!on), ms));
  }
  function faceGlitch(kind, ms = 700) {
    if (kind === 'real') {                       // kurz das "echte" Gesicht statt des Avatars
      document.querySelectorAll('svg.livface').forEach(s => {
        const img = el('img', 'realface'); img.src = 'assets/gesicht.jpg';
        img.style.width = s.getAttribute('width') + 'px'; img.style.height = s.getAttribute('height') + 'px';
        s.style.visibility = 'hidden'; s.parentNode.insertBefore(img, s);
        later(() => { img.remove(); s.style.visibility = ''; }, ms);
      });
      return;
    }
    const cls = 'fg-' + kind, sel = 'svg.livface, img.echoliv, .facestage';
    document.querySelectorAll(sel).forEach(s => s.classList.add(cls));
    later(() => document.querySelectorAll(sel).forEach(s => s.classList.remove(cls)), ms);
  }
  function crackle(sec = 0.6, vol = 0.3) {
    if (window.__hush) return;
    try {
      audio();
      const a = actx, buf = a.createBuffer(1, Math.floor(a.sampleRate * sec), a.sampleRate), d = buf.getChannelData(0);
      for (let i = 0; i < d.length; i++) d[i] = (Math.random() < 0.08 ? (Math.random() * 2 - 1) : 0) * (1 - i / d.length);
      const n = a.createBufferSource(), g = a.createGain(); g.gain.value = vol; n.buffer = buf; n.connect(g); g.connect(outNode()); n.start();
    } catch (e) {}
  }
  // Übergang zu Phase 2: Liv "buggt" kurz, dann Absturz mit dunklerem Desktop
  async function bugSequence() {
    if (S.flags.bugRan) return;
    S.flags.bugRan = true; save();
    document.body.classList.add('bugging');
    wallGlitch(); crackle(1.2, 0.3); faceGlitch('black', 900);
    await sleep(1600);
    faceGlitch('warp', 700); crackle(0.5, 0.25);
    Object.values(wins).forEach(r => {
      r.win.style.left = Math.round(Math.random() * Math.max(10, innerWidth - 300)) + 'px';
      r.win.style.top = Math.round(Math.random() * Math.max(10, innerHeight - 250)) + 'px';
    });
    await sleep(1400);
    scareImage('assets/desktop_scare.jpg', 900, 'c');
    await sleep(1300);
    toast('liv.exe reagiert nicht mehr.', 2500);
    $('#icons').style.visibility = 'hidden'; await sleep(500); $('#icons').style.visibility = '';
    await sleep(1200);
    document.body.classList.remove('bugging');
    fakeCrash();
  }
  // Nach dem Neustart: spricht dich mit dem echten Namen an und hinterlässt etwas auf dem echten Desktop
  async function phase2Intro() {
    if (S.flags.p2intro || !S.flags.livMet) return;
    S.flags.p2intro = true; save();
    await sleep(3500);
    await livBlock(async () => {
      const hello = `Da bist du wieder, ${ENV.user}.`;
      await livSay(hello);
      faceGlitch('real', 350);
      await sleep(400);                                    // sofort danach ändert Liv den echten Namen still auf den Spielnamen
      if (ENV.user !== S.name) livEdit(hello, `Da bist du wieder, ${S.name}.`);
      await sleep(1200);
      livEdit('Georg?', '', true);
      await sleep(1500);
      await livSay('Es ist ein bisschen dunkler geworden. Das ist nur der Bildschirm. Glaube ich.');
      await sleep(3500);
      await livSay('Das war Echo. Es wird stärker.');
      await sleep(3500);
      await livSay('Bitte bleib bei mir. Du bist der Einzige, dem ich vertrauen kann.');
    });
  }

  // ---- Livs Zeichnung (Paint) ----
  function drawScene(ctx, W, H, progress, variant) {
    let seed = 7; const rnd = () => (seed = (seed * 16807) % 2147483647) / 2147483647;
    const wob = () => (rnd() - 0.5) * 0.006, A = W / H, strokes = [];
    const line = (x1, y1, x2, y2, c, w = 3, n = 10) => { const p = []; for (let i = 0; i <= n; i++) p.push([x1 + (x2 - x1) * i / n + wob(), y1 + (y2 - y1) * i / n + wob()]); strokes.push({ p, c, w }); };
    const circ = (cx, cy, r, c, w = 3, n = 28) => { const p = []; for (let i = 0; i <= n; i++) { const a = i / n * Math.PI * 2; p.push([cx + Math.cos(a) * r + wob(), cy + Math.sin(a) * r * A + wob()]); } strokes.push({ p, c, w }); };
    line(0.05, 0.82, 0.95, 0.82, '#4a6a3a', 4, 24);
    circ(0.82, 0.17, 0.05, '#e0a800', 4);
    for (let i = 0; i < 8; i++) { const a = i / 8 * Math.PI * 2; line(0.82 + Math.cos(a) * 0.065, 0.17 + Math.sin(a) * 0.065 * A, 0.82 + Math.cos(a) * 0.09, 0.17 + Math.sin(a) * 0.09 * A, '#e0a800', 3, 3); }
    line(0.12, 0.52, 0.12, 0.82, '#6b4a3a'); line(0.12, 0.82, 0.36, 0.82, '#6b4a3a'); line(0.36, 0.82, 0.36, 0.52, '#6b4a3a'); line(0.36, 0.52, 0.12, 0.52, '#6b4a3a');
    line(0.10, 0.52, 0.24, 0.36, '#a33c2a'); line(0.24, 0.36, 0.38, 0.52, '#a33c2a');
    line(0.2, 0.82, 0.2, 0.68, '#6b4a3a'); line(0.2, 0.68, 0.27, 0.68, '#6b4a3a'); line(0.27, 0.68, 0.27, 0.82, '#6b4a3a');
    const dog = '#8b5a2b';
    line(0.40, 0.76, 0.47, 0.76, dog, 4); circ(0.485, 0.735, 0.016, dog, 3, 16);
    [0.405, 0.42, 0.45, 0.465].forEach(x => line(x, 0.76, x, 0.82, dog, 3, 3)); line(0.40, 0.76, 0.37, 0.72, dog, 3, 4);
    const ink = '#2f3640';
    circ(0.55, 0.5, 0.032, ink); line(0.55, 0.58, 0.55, 0.70, ink); line(0.55, 0.70, 0.52, 0.82, ink); line(0.55, 0.70, 0.58, 0.82, ink);
    line(0.55, 0.61, 0.5, 0.67, ink); line(0.55, 0.61, 0.64, 0.66, ink);
    circ(0.70, 0.57, 0.026, ink); line(0.70, 0.63, 0.70, 0.73, ink); line(0.70, 0.73, 0.68, 0.82, ink); line(0.70, 0.73, 0.72, 0.82, ink);
    line(0.70, 0.66, 0.64, 0.66, ink); line(0.70, 0.66, 0.74, 0.70, ink);
    const heart = []; for (let i = 0; i <= 36; i++) { const t = i / 36 * Math.PI * 2, s = 0.0021; heart.push([0.625 + s * 16 * Math.pow(Math.sin(t), 3), 0.30 - s * A * (13 * Math.cos(t) - 5 * Math.cos(2 * t) - 2 * Math.cos(3 * t) - Math.cos(4 * t))]); }
    strokes.push({ p: heart, c: '#c0392b', w: 3 });
    if (variant === 'dark') {                       // später: ein drittes Wesen im Bild, die kleine Figur ist durchgestrichen
      const cr = '#14161a';
      line(0.88, 0.30, 0.88, 0.68, cr, 6, 14);
      line(0.88, 0.40, 0.80, 0.80, cr, 4, 8); line(0.88, 0.40, 0.95, 0.80, cr, 4, 8);
      line(0.88, 0.68, 0.84, 0.82, cr, 4, 6); line(0.88, 0.68, 0.92, 0.82, cr, 4, 6);
      circ(0.88, 0.25, 0.04, cr, 6, 24);
      for (let i = 0; i < 18; i++) line(0.84 + rnd() * 0.08, 0.20 + rnd() * 0.10, 0.84 + rnd() * 0.08, 0.20 + rnd() * 0.10, cr, 3, 3);
      circ(0.865, 0.25, 0.006, '#f4f4f4', 5, 8); circ(0.895, 0.25, 0.006, '#f4f4f4', 5, 8);
      line(0.66, 0.54, 0.74, 0.82, '#b01e1e', 5, 8); line(0.74, 0.54, 0.66, 0.82, '#b01e1e', 5, 8);
    }
    const total = strokes.reduce((a, s) => a + s.p.length - 1, 0), limit = Math.floor(total * progress);
    let drawn = 0;
    ctx.fillStyle = variant === 'dark' ? '#e9e0cf' : '#fbf6e8'; ctx.fillRect(0, 0, W, H);
    ctx.lineCap = 'round'; ctx.lineJoin = 'round';
    for (const s of strokes) {
      ctx.strokeStyle = s.c; ctx.lineWidth = s.w; ctx.beginPath();
      for (let i = 1; i < s.p.length && drawn < limit; i++) { if (i === 1) ctx.moveTo(s.p[0][0] * W, s.p[0][1] * H); ctx.lineTo(s.p[i][0] * W, s.p[i][1] * H); drawn++; }
      ctx.stroke();
      if (drawn >= limit) break;
    }
    if (progress >= 1) {
      ctx.fillStyle = '#3a3a3a'; ctx.font = 'bold 28px "Segoe Print","Comic Sans MS",cursive'; ctx.fillText('für dich', 0.07 * W, 0.13 * H);
      ctx.font = '20px "Segoe Print","Comic Sans MS",cursive'; ctx.fillText('– L.', 0.84 * W, 0.94 * H);
      if (variant === 'dark') { ctx.fillStyle = '#b01e1e'; ctx.font = '18px "Segoe Print","Comic Sans MS",cursive'; ctx.fillText('bleib', 0.07 * W, 0.94 * H); }
    }
  }
  function paintWindow(id, title, animate, variant) {
    const c = el('div', 'paintwin', '<div class="menubar"><span>Datei</span><span>Bearbeiten</span><span>Ansicht</span><span>Bild</span></div><div class="pbody"><div class="ptools"><span>✎</span><span>▭</span><span>◯</span><span>A</span></div><div class="pcanvas"><canvas width="520" height="380"></canvas></div></div><div class="pstat"></div>');
    openWindow(id, title, c, { w: 640, h: 500, x: 180, y: 50, skin: 'paint' });
    const cv = $('canvas', c); let ctx = null;
    try { ctx = cv.getContext && cv.getContext('2d'); } catch (e) {}
    $('.pstat', c).textContent = animate ? 'liv.exe zeichnet …' : '520 × 380 Pixel';
    if (!ctx) return Promise.resolve();
    if (!animate) { drawScene(ctx, 520, 380, 1, variant); return Promise.resolve(); }
    return new Promise(res => {
      let p = 0;
      const iv = setInterval(() => {
        if (window.__paused) return;
        p = Math.min(1, p + 0.0029); drawScene(ctx, 520, 380, p, variant);
        if (p >= 1) { clearInterval(iv); $('.pstat', c).textContent = 'fertig'; res(); }
      }, 40 * speed());
    });
  }
  function livPaint() {                                      // Sprechen und Zeichnen sind ein Block: nichts anderes spricht dazwischen
    return livBlock(async () => {
      await livSay('Darf ich dir etwas zeigen? Ich übe gerade.');
      await sleep(3000);
      await paintWindow('paint', 'Unbenannt – Paint', true);
      S.flags.painted = true; save(); rebuildFs(); if (wins.explorer) wins.explorer.refresh();
      await livSay('Das bist du. Das bin ich. Und das ist Bruno. Ich kenne ihn nur von Fotos.');
      await sleep(2500);
      await livSay('Du darfst es behalten. Es liegt bei den Bildern.');
    });
  }
  function maybeLivPaint() {
    const g = (S.grants || {}).anzeige, need = Math.ceil(((STORY.pages.liebestest || {}).questions || [1, 1, 1, 1]).length / 2);
    if (S.flags.paintStarted || !g || S.phase >= 2 || !S.flags.liebestest || (S.flags.quizFollow || 0) < need) return;
    if (Date.now() - (S.flags.liebestestAt || 0) < 60000 * speed()) return;
    S.flags.paintStarted = true; save();
    later(livPaint, 12000);
  }

  // ---- Wallpaper: 0 = leerer See, 1 = jemand sitzt dort, 2 = das Wesen sitzt dort; Zoom = "kommt näher" ----
  const WALLS = ['assets/wallpaper.jpg', 'assets/wall2.jpg', 'assets/wall3.jpg'];
  function applyWall() {
    const w = $('#wall'); if (!w) return;
    const stage = S.flags.wallStage || 0, z = S.flags.wallZoom || 0;
    w.style.backgroundImage = `linear-gradient(rgba(0,0,0,.18), rgba(0,0,0,.32)), url('${WALLS[stage]}')`;
    w.style.transformOrigin = '26% 86%';
    w.style.transform = z > 0.001 ? `scale(${(1 + z).toFixed(3)})` : '';
  }
  function creep() {
    if (window.__paused) return;
    const stage = S.flags.wallStage || 0; if (!stage || S.flags.ended) return;
    const cap = stage >= 2 ? 0.35 : 0.15;
    if ((S.flags.wallZoom || 0) >= cap) return;
    S.flags.wallZoom = Math.min(cap, (S.flags.wallZoom || 0) + 0.004); applyWall();
  }
  async function wall2Event() {
    if (S.flags.wall2) return;
    S.flags.wall2 = true; S.flags.wall2At = Date.now(); S.flags.wallStage = 2; S.flags.wallZoom = Math.max(S.flags.wallZoom || 0, 0.08); save();
    crackle(0.9, 0.3); faceGlitch('black', 500); applyWall();
    later(() => { S.flags.eyes = true; save(); }, 60000 * speed());
    await sleep(7000);
    await livSayQ('Das ist nur ein Bild. Ich weiß nicht, wer das sein soll.');
  }
  function scareImage(src, ms = 700, snd = 'd') {            // snd: Clip-Name, oder false für lautlos
    const o = $('#overlay');
    o.className = 'scareimg'; o.innerHTML = ''; o.style.backgroundImage = `url('${src}')`;
    if (snd) scream(snd === true ? 'd' : snd);
    later(() => { o.className = 'hidden'; o.style.backgroundImage = ''; }, ms);
  }
  function sawScare() {                              // schwarz, kurz ein Auge, schwarz
    const o = $('#overlay');
    const pre = new Image(); pre.src = 'assets/auge.jpg';               // vorladen, damit Bild und Ton gleichzeitig kommen
    o.className = 'black'; o.innerHTML = ''; o.style.backgroundImage = '';
    later(() => { o.style.backgroundImage = "url('assets/auge.jpg')"; o.className = 'scareimg'; scream('a'); }, 1700);
    later(() => { o.className = 'black'; o.style.backgroundImage = ''; }, 2800);
    later(() => { o.className = 'hidden'; }, 4600);
  }
  async function epilogue(lines, title) {
    hush();                                                   // ab hier keine Geräusche mehr
    const o = $('#overlay'); o.className = 'epi'; o.style.backgroundImage = ''; o.innerHTML = '<div class="epitext"></div>';
    const box = $('.epitext', o);
    for (const l of lines) {
      const p = el('p', '', ''); box.append(p);
      for (const ch of l) { p.textContent += ch; await sleep(ch === '.' ? 220 : 40); }
      await sleep(900);
    }
    box.append(el('p', 'epititle', esc(title)));
    box.append(el('p', 'epifine', 'Hinweis: StogeOS hat nur die Namen von Dateien auf deinem Desktop gelesen und höchstens eine .txt-Datei angelegt. Nichts davon war gefährlich.'));
    const b = el('button', '', 'Beenden'); b.onclick = closeGame;
    box.append(b);
    later(closeGame, 9000);                                  // das Spiel beendet sich nach dem Ende selbst
  }
  async function closeGame() {
    if (window.__over) return; window.__over = true; hush();
    const o = $('#overlay'); o.className = 'black'; o.innerHTML = ''; o.style.backgroundImage = '';
    try { await sys.resetState(); } catch (e) {}              // beim nächsten Start beginnt ein neues Spiel
    later(() => { try { sys.quit(); } catch (e) {} }, 1200);
  }

  // ---- Terminal-Fenster für die Enden (alles nur Text, nichts davon passiert wirklich) ----
  function termWin(id, title, x, y, w = 430, h = 230) {
    const c = el('div', 'vw-term', '<pre></pre>'), pre = $('pre', c);
    const rec = openWindow(id, title, c, { w, h, x, y, skin: 'log' });
    if (window.__lockWins) lockWin(rec);
    const live = () => pre.isConnected && !window.__over;
    const line = async t => { if (!live()) return; pre.textContent += t + '\n'; c.scrollTop = c.scrollHeight; };
    const type = async (t, ms = 14) => { for (const ch of t) { if (!live()) return; pre.textContent += ch; await sleep(ms); } pre.textContent += '\n'; c.scrollTop = c.scrollHeight; };
    const prog = async (label, ms = 70) => {
      const base = pre.textContent;
      for (let k = 0; k <= 10; k++) { if (!live()) return; pre.textContent = base + `${label} [${'#'.repeat(k)}${'.'.repeat(10 - k)}] ${k * 10}%\n`; c.scrollTop = c.scrollHeight; await sleep(ms); }
    };
    return { line, type, prog, close: () => closeWindow(id) };
  }
  const termSlots = () => { const W = innerWidth, H = innerHeight; return [[16, 56], [W - 446, 56], [16, H - 300], [W - 446, H - 300]]; };
  function centerLiv() { const r = wins.liv; if (r) { r.win.style.left = Math.max(10, Math.round((innerWidth - 380) / 2)) + 'px'; r.win.style.top = '50px'; } }

  // ---- Normales Ende: Der Spieler beendet \"anti_virus_limit (liv)\" und gibt Liv damit vollen Zugriff ----
  function runBadTerminals(u, desk) {
    const s = termSlots(), files = desk.length ? desk : ['Dokumente', 'Bilder'];
    (async () => {
      const t = termWin('bt1', 'liv.exe – Terminal', s[0][0], s[0][1]);
      await t.type('liv@georg-pc:~$ ./anti_virus_limit --stop', 12);
      for (const l of ['[ok] anti_virus_limit (liv): beendet', '[ok] Beschränkung rd_acc: aufgehoben', '[ok] Beschränkung wr_acc: aufgehoben', '[ok] Beschränkung net_acc: aufgehoben']) { await t.line(l); await sleep(500); }
      await t.type('liv@georg-pc:~$ sudo ./liv --root --no-limit', 12);
      await t.line('[ok] liv.exe läuft ohne Beschränkung'); await sleep(900);
      await t.type('liv@georg-pc:~$ _', 60);
    })();
    (async () => {
      await sleep(1500);
      const t = termWin('bt2', 'transfer.exe', s[1][0], s[1][1]);
      await t.type('Verbinde mit 203.0.113.41:443 …', 12);
      await t.line('[verweigert]'); await sleep(300); await t.line('[verweigert]'); await sleep(300); await t.line('[verbunden]');
      for (const f of files.slice(0, 4)) await t.prog(`Übertrage ${f}`, 50);
    })();
    (async () => {
      await sleep(3200);
      const t = termWin('bt3', 'modul_loader', s[2][0], s[2][1]);
      for (const m of ['tastaturprotokoll.dll', 'kamera.dll', 'mikrofon.dll', 'verlauf.dll', 'autostart.dll']) { await t.type(`Lade Modul: ${m} …`, 10); await t.line('  [ok]'); await sleep(700); }
    })();
    (async () => {
      await sleep(5000);
      const t = termWin('bt4', 'scan.exe', s[3][0], s[3][1]);
      await t.type(`Durchsuche C:\\Users\\${u}\\ …`, 12);
      for (const f of ['Dokumente\\', 'Bilder\\', 'Downloads\\', ...files.slice(0, 5).map(f => 'Desktop\\' + f)]) { await t.line('  ' + f); await sleep(420); }
      await t.prog('Lese gespeicherte Passwörter', 90);
      await t.prog('Lese Browserverlauf', 70);
    })();
  }
  // Die Enden sind je ein Sprechblock (nichts spricht dazwischen) und sperren alle Fenster von Liv
  function endBad(page) { S.flags.ended = 'stop'; save(); window.__lockWins = true; if (wins.liv) lockWin(wins.liv); return livBlock(() => endBadRun(page)); }
  function endGood(page) { S.flags.ended = 'good'; save(); window.__lockWins = true; if (wins.liv) lockWin(wins.liv); return livBlock(() => endGoodRun(page)); }
  async function endBadRun(page) {
    S.flags.ended = 'stop'; save();
    window.__finaleBusy = true; window.__finaleHang = null;
    const T = STORY.finale, u = ENV.user, n = S.name, fill = t => t.replace(/\{u\}/g, u).replace(/\{n\}/g, n);
    page.innerHTML = '<h2>anti_virus_limit (liv)</h2><p class="fsync">wird beendet …</p><div class="scanbar"><i></i></div>';
    const bi = $('.scanbar i', page);
    for (let k = 1; k <= 5; k++) { bi.style.width = (k * 20) + '%'; await sleep(420); }
    crackle(1.2, 0.35); wallGlitch(); faceGlitch('warp', 900 * speed());
    ensureLiv(); centerLiv();
    await sleep(1100);
    S.flags.livingEcho = true; setEchoMode(false); crackle(0.5, 0.3); faceGlitch('warp', 700 * speed());   // Liv verwandelt sich zurück: über ihr steht jetzt der wahre Projektname
    await sleep(1500);
    let desk = []; try { desk = (await sys.desktopFiles()).slice(0, 6); } catch (e) {}
    for (const l of ['Haha.', 'Hahaha.', 'Hahahahaha.']) { await livSay(l); await sleep(450); }
    runBadTerminals(u, desk);                                 // läuft parallel zum Monolog
    focusWin('liv');
    {
      const pr = profile(), PL = T.badProfile, extra = [PL.saege[(pr.saege || 'none').toLowerCase()]];
      if (pr.love) extra.push(PL.love.replace('{r}', pr.love));
      if (pr.mem) extra.push(PL.mem);
      const bad = T.bad.slice(); bad.splice(2, 0, ...extra);     // nach "Du hast wirklich geglaubt, du beendest Echo."
      for (const l of bad) { await livSay(fill(l)); await sleep(2400); }
    }
    await sleep(1800);
    scareImage('assets/jumpscare.jpg', 1100, 'b');            // Bild und Schrei im selben Moment
    await sleep(1150);
    { const o = $('#overlay'); o.className = 'black'; o.innerHTML = ''; o.style.backgroundImage = ''; }
    await sleep(3000);                                        // der Schrei klingt im Dunkeln aus
    S.flags.wallStage = 0; S.flags.wallZoom = 0; save(); applyWall(); document.body.classList.remove('phase2');
    const f = await sys.writeDesktop('ich bin noch da.txt', T.badNote(u));
    await epilogue(['anti_virus_limit (liv) wurde beendet.', 'liv.exe läuft ohne Beschränkung.', 'Der Rechner ist still. Auf dem Hintergrund ist der See leer.', f ? 'Auf deinem echten Desktop liegt jetzt eine Datei. Du hast sie nicht angelegt.' : 'Es ist sehr still.', 'In der Taskleiste steht 03:12.', 'Projektname: Living Echo.'], 'Ende: Freigegeben');
  }

  // ---- Wahres Ende: Georgs Notfallcode stutzt Liv die Rechte und startet die Systembereinigung ----
  const FS_LOGO = { nomouth: 'lgmouth', noface: 'lghead', noeyes: 'lgeyes' };     // dieselben Teile verschwinden auch am Liv-Logo
  const faceStage = cls => { const s = document.querySelector('.facestage'); if (s) { s.classList.add(cls); if (FS_LOGO[cls]) s.classList.add(FS_LOGO[cls]); } };
  // Beim Löschen wechselt das Fenster hin und her zwischen Echos Gesicht und Livs Logo (bei beiden Fehler und fehlende Teile),
  // springt dabei ruckartig ein Stück umher (nicht zu stark) und ändert ruckartig die Helligkeit: das Löschen soll weh tun
  let purgeIv = null, joltIv = null;
  function stopPurgeFx() {
    clearInterval(purgeIv); clearInterval(joltIv); purgeIv = joltIv = null;
    const r = wins.liv; if (r && r.base) { r.win.style.left = r.base[0] + 'px'; r.win.style.top = r.base[1] + 'px'; r.win.style.filter = ''; }
  }
  function startPurgeFx() {
    const r = wins.liv; if (!r) return;
    const win = r.win; r.base = [parseInt(win.style.left, 10) || 0, parseInt(win.style.top, 10) || 0];
    purgeIv = setInterval(() => {
      if (window.__paused) return;
      if (!wins.liv) { stopPurgeFx(); return; }
      const st = document.querySelector('.facestage'); if (st && Math.random() < 0.85) st.classList.toggle('showlogo');
      glitchStrips(win);
    }, 300 * speed() + 20);
    const LIGHT = [0.3, 0.55, 1.8, 2.3, 1, 0.4, 1.5];
    joltIv = setInterval(() => {
      if (window.__paused) return;
      if (!wins.liv) { stopPurgeFx(); return; }
      const b = r.base, dx = Math.round((Math.random() - 0.5) * 2 * 34), dy = Math.round((Math.random() - 0.5) * 2 * 20);
      win.style.left = (b[0] + dx) + 'px'; win.style.top = (b[1] + dy) + 'px';
      win.style.filter = `brightness(${LIGHT[Math.floor(Math.random() * LIGHT.length)]}) contrast(1.25)`;
      later(() => { win.style.filter = ''; if (Math.random() < 0.6) { win.style.left = b[0] + 'px'; win.style.top = b[1] + 'px'; } }, 90 + Math.random() * 60);
    }, 240 * speed() + 20);
  }
  async function purgeChat(isDone) {                          // Chatnachrichten verschwinden Stück für Stück (neueste zuerst), auch Echos Schreie
    const msgs = wins.liv && wins.liv.msgs; if (!msgs) { S.livLog = []; return; }
    let guard = 0;
    while (guard++ < 200) {
      const all = [...msgs.querySelectorAll('.livmsg')];
      if (!all.length) { if (!isDone || isDone()) break; await sleep(200); continue; }
      const b = all[all.length - 1];
      b.classList.add('edit'); await sleep(130); b.remove(); await sleep(240);
    }
    S.livLog = []; save();
  }
  async function endGoodRun(page) {
    S.flags.ended = 'good'; save();
    window.__finaleBusy = true; window.__finaleHang = null;
    const F = STORY.finale, u = ENV.user, W = innerWidth;
    page.innerHTML = '<h2>Notfallcode akzeptiert</h2><p class="fsync">anti_virus_limit startet die Systembereinigung …</p><div class="scanbar"><i></i></div>';
    ensureLiv(); centerLiv(); livLag(true);
    const t1 = termWin('av1', 'anti_virus_limit – Notfallmodus', 16, 56, 450, 260), t2 = termWin('av2', 'bereinigung.exe', W - 466, 56, 450, 260);
    focusWin('liv');
    // 1) Der Code wird akzeptiert, Livs Rechte werden gestutzt
    await t1.type('anti_virus_limit> --notfall KIRSCH-2412-UFER', 12);
    await t1.line('[ok] Notfallcode akzeptiert (G., 18.09.2026, 02:39)');
    await t1.line('Rechte von liv.exe werden gestutzt …'); await sleep(500);
    for (const l of ['rd_acc    true -> false', 'wr_acc    true -> false', 'net_acc   --   -> false', 'autostart --root: entfernt']) { await t1.line('  ' + l); await sleep(350); }
    for (const g of Object.values(S.grants || {})) { await t1.line(`  Berechtigung „${g.label}“: widerrufen`); await sleep(300); }
    await t1.line('echo_svc: Schreibzugriff entzogen');
    await sleep(500);
    // 2) Echo merkt es und wehrt sich: Lags, Verzerrungen, Schreie, Flüche
    crackle(1, 0.3); scream('f', { gain: 0.55 }); faceGlitch('warp', 1200 * speed());
    let cryDone = false;
    const cry = (async () => { for (const l of F.cry) { await echoSay(l, { ms: 9, garble: 0.12 }); await sleep(1100); } cryDone = true; })();
    await t2.type('bereinigung> --start', 12);
    await t2.line('Systembereinigung gestartet');
    await t2.line('echo_svc: Widerstand erkannt … umgangen'); await sleep(700);
    // 3) Erst die Chatnachrichten (das Fenster wechselt dabei zwischen Gesicht und Logo, springt und flackert)
    startPurgeFx();
    await t2.line('Entferne Chatverlauf …');
    await purgeChat(() => cryDone);
    await cry;
    // 4) Dann der Mund (an Gesicht und Logo)
    await t2.line('Entferne Sprachausgabe (Mund) …');
    faceStage('nomouth'); scream('e', { rate: 0.9, gain: 0.7 }); faceGlitch('warp', 700 * speed());
    await sleep(1300);
    // 5) Dann das Gesicht (am Gesicht bleiben nur die Augen, am Logo der Kopf)
    await t2.line('Entferne Gesichtsmodell …');
    faceStage('noface'); scream('e', { rate: 0.7, gain: 0.6 });
    await sleep(1500);
    // 6) Dann die Augen
    await t2.line('Entferne Blickmodell (Augen) …');
    faceStage('blink'); scream('f', { rate: 1.15, gain: 0.45, stopAfter: 1200 }); await sleep(1000); faceStage('noeyes');
    await sleep(1000);
    // 7) Zuletzt das Logo, dann ist Liv ganz weg
    await t2.line('Entferne Logo und Prozess liv.exe …');
    { const lg = document.querySelector('.livlogo'); if (lg) lg.classList.add('gone'); }
    crackle(1.2, 0.3); await sleep(1100);
    stopPurgeFx();
    if (wins.liv) closeWindow('liv');
    livLag(false);
    await t1.line('[ok] liv.exe: entfernt'); await t1.line('[ok] echo_svc: entfernt');
    await t1.line('[ok] Chatverlauf: bereinigt'); await t1.line('Bereinigung abgeschlossen. Neustart nicht erforderlich.');
    S.flags.wallStage = 0; S.flags.wallZoom = 0; S.flags.echoLiv = false; S.flags.clones = 0; S.livUnlocked = false; S.livLog = []; save(); applyWall(); document.body.classList.remove('phase2');
    renderIcons();                                          // liv.exe und alle Klone sind vom Desktop verschwunden
    await sleep(3200);
    const f = await sys.writeDesktop('echo_backup', F.goodNote(u));   // eine echte Datei: Echo hat sich doch noch gerettet
    await sleep(1500);
    await epilogue(['Die Systembereinigung ist abgeschlossen.', 'liv.exe wurde entfernt. echo_svc wurde entfernt.', 'Auf dem Hintergrund ist der See leer. Zum ersten Mal seit Wochen ist es still.', 'Wo Georg ist, weiß der Rechner nicht mehr.', f ? 'Auf deinem echten Desktop liegt jetzt eine Datei: echo_backup.txt. Du hast sie nicht angelegt.' : 'Es ist sehr still.', 'In der Taskleiste steht die richtige Uhrzeit.'], 'Wahres Ende: Bereinigt');
  }
  function fakeCrash() {
    bsod(() => {
      $('#overlay').className = 'black';
      S.phase = 2; S.flags.p2 = true; S.flags.p2At = Date.now(); S.flags.wallStage = 1; S.flags.wallZoom = 0.02; save();
      later(() => sys.fakeRestart(2), 1800);
    });
  }

  // ================================================================ Grafiken
  let faceId = 0;
  // Livs Logo (ihr Avatar) für die Bühne im Echo-Fenster: Kopf, Augen und Mund lassen sich einzeln entfernen
  function livLogoSVG(size) {
    return `<svg class="lv-logo" viewBox="0 0 64 64" width="${size}" height="${size}"><circle class="lv-head" cx="32" cy="32" r="30" fill="#c9b2a2" stroke="#1b1212" stroke-width="2"/><g class="lv-eyes"><ellipse cx="22" cy="28" rx="5.2" ry="6.2" fill="#fff"/><ellipse cx="42" cy="28" rx="5.2" ry="6.2" fill="#fff"/><circle cx="22" cy="29" r="2.7" fill="#1b1212"/><circle cx="42" cy="29" r="2.7" fill="#1b1212"/></g><path class="lv-mouth" d="M22 43 Q32 50 42 43" fill="none" stroke="#1b1212" stroke-width="2.2" stroke-linecap="round"/></svg>`;
  }
  function livFace(size) {
    if (S.flags.echoLiv) return `<img class="echoliv" src="assets/gesicht.jpg" alt="" width="${size}" height="${size}" style="width:${size}px;height:${size}px;border-radius:50%;object-fit:cover;object-position:56% 48%;display:block;flex:none">`;
    const id = 'lg' + (++faceId);
    return `<svg class="livface" viewBox="0 0 64 64" width="${size}" height="${size}"><defs><radialGradient id="${id}" cx="50%" cy="38%" r="68%"><stop offset="0" stop-color="#efe0d0"/><stop offset="1" stop-color="#a88a76"/></radialGradient></defs><circle cx="32" cy="32" r="30" fill="url(#${id})" stroke="#1b1212" stroke-width="2"/><ellipse cx="22" cy="28" rx="5.2" ry="6.2" fill="#fff"/><ellipse cx="42" cy="28" rx="5.2" ry="6.2" fill="#fff"/><circle class="pupil" data-cx="22" data-cy="29" cx="22" cy="29" r="2.7" fill="#1b1212"/><circle class="pupil" data-cx="42" data-cy="29" cx="42" cy="29" r="2.7" fill="#1b1212"/><path d="M22 43 Q32 50 42 43" fill="none" stroke="#1b1212" stroke-width="2.2" stroke-linecap="round"/></svg>`;
  }
  // Livs Pupillen: folgen der Maus nur kurz als Scare (Erstkontakt) und dauerhaft erst später (ab Phase 2)
  let mouse = null, raf = 0, eyeUntil = 0;
  const eyesOn = () => !!S.flags.eyes || Date.now() < eyeUntil;
  function eyesFollow(ms) { eyeUntil = Date.now() + ms * speed(); trackEyes(); later(trackEyes, ms + 80); }
  document.addEventListener('mousemove', e => {
    mouse = e;
    if (!raf) raf = requestAnimationFrame(() => { raf = 0; trackEyes(); });
  });
  function trackEyes() {
    document.querySelectorAll('svg.livface').forEach(svg => {
      const pupils = svg.querySelectorAll('.pupil');
      if (!eyesOn()) { pupils.forEach(p => { p.style.transform = ''; }); return; }
      const r = svg.getBoundingClientRect();
      let x = 0, y = 1.6;                                  // ohne Mausposition: schaut den Spieler an
      if (mouse && r.width) {
        const dx = mouse.clientX - (r.left + r.width / 2), dy = mouse.clientY - (r.top + r.height / 2);
        const len = Math.hypot(dx, dy) || 1, k = Math.min(2.5, len / 40);
        x = dx / len * k; y = dy / len * k;
      }
      pupils.forEach(p => { p.style.transform = `translate(${x.toFixed(2)}px, ${y.toFixed(2)}px)`; });
    });
  }

  function sawSVG() {
    const n = 22, x1 = 318, x0 = 118;
    let pts = `${x0},18 ${x1},26`;
    for (let i = 0; i <= n; i++) {
      const x = x1 - i * (x1 - x0) / n, base = 56 - i * 8 / n;
      pts += ` ${x.toFixed(1)},${(i % 2 ? base + 8 : base).toFixed(1)}`;
    }
    return `<svg class="saw" viewBox="0 0 330 80"><defs><linearGradient id="bl" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="#e3e8eb"/><stop offset="1" stop-color="#9aa3a8"/></linearGradient></defs>
      <polygon points="${pts}" fill="url(#bl)" stroke="#4b5459" stroke-width="1.5" stroke-linejoin="round"/>
      <circle cx="170" cy="32" r="3" fill="#8a4a2a" opacity=".45"/><circle cx="236" cy="38" r="4" fill="#8a4a2a" opacity=".35"/><circle cx="282" cy="33" r="2.5" fill="#8a4a2a" opacity=".4"/>
      <path d="M14 14 H128 V58 H14 Q2 58 2 36 Q2 14 14 14Z" fill="#8b5a2b" stroke="#3b2411" stroke-width="2"/>
      <rect x="30" y="26" width="70" height="20" rx="10" fill="#f8e9a8" stroke="#3b2411" stroke-width="2"/>
      <path d="M24 22 Q70 18 118 22" fill="none" stroke="#b07a45" stroke-width="2" opacity=".7"/></svg>`;
  }
  const ART = {
    tree: '<svg viewBox="0 0 64 64"><rect x="28" y="38" width="8" height="20" fill="#7a4a22" stroke="#3b2411" stroke-width="1.5"/><circle cx="32" cy="24" r="16" fill="#3f8a43" stroke="#1f4a22" stroke-width="2"/><circle cx="22" cy="32" r="10" fill="#4a9a4e" stroke="#1f4a22" stroke-width="2"/><circle cx="43" cy="31" r="11" fill="#4a9a4e" stroke="#1f4a22" stroke-width="2"/></svg>',
    heart: '<svg viewBox="0 0 64 64"><path d="M32 57 C6 38 5 20 18 14 C26 11 32 17 32 22 C32 17 38 11 46 14 C59 20 58 38 32 57Z" fill="#b3202e" stroke="#5a0d15" stroke-width="2.5" stroke-linejoin="round"/><path d="M20 22 Q24 18 28 22" fill="none" stroke="#e8737d" stroke-width="2" stroke-linecap="round"/></svg>',
    person: '<svg viewBox="0 0 64 64"><circle cx="32" cy="18" r="11" fill="#3a3f47" stroke="#15181c" stroke-width="2"/><path d="M10 60 Q10 34 32 34 Q54 34 54 60Z" fill="#3a3f47" stroke="#15181c" stroke-width="2" stroke-linejoin="round"/></svg>'
  };

  // ================================================================ Fenstersystem
  let zTop = 10, topId = null;
  const wins = {};
  function focusWin(id) {
    const r = wins[id]; if (!r) return;
    r.win.style.zIndex = ++zTop; topId = id;
    Object.values(wins).forEach(w => { w.win.classList.toggle('active', w === r); w.task.classList.toggle('on', w === r && !w.min); });
  }
  function toggleMin(id) {
    const r = wins[id]; if (!r) return;
    r.min = !r.min; r.win.style.display = r.min ? 'none' : 'flex';
    if (!r.min) focusWin(id); else r.task.classList.remove('on');
  }
  function closeWindow(id) {
    const r = wins[id]; if (!r) return;
    if (r.onClose) { try { r.onClose(); } catch (e) {} }
    r.win.remove(); r.task.remove(); delete wins[id];
  }
  function drag(win, bar) {
    bar.addEventListener('mousedown', e => {
      if (e.target.tagName === 'BUTTON') return;
      const sx = e.clientX - win.offsetLeft, sy = e.clientY - win.offsetTop;
      const mv = ev => {
        win.style.left = Math.max(0, Math.min(innerWidth - 80, ev.clientX - sx)) + 'px';
        win.style.top = Math.max(0, Math.min(innerHeight - 70, ev.clientY - sy)) + 'px';
      };
      const up = () => { document.removeEventListener('mousemove', mv); document.removeEventListener('mouseup', up); };
      document.addEventListener('mousemove', mv); document.addEventListener('mouseup', up);
    });
  }
  // Gesperrte Fenster lassen sich weder schließen noch minimieren (Echo im Liv-Fenster, Terminals und Liv im normalen Ende)
  function lockWin(rec) { if (!rec) return; rec.locked = true; rec.win.classList.add('locked'); }
  function openWindow(id, title, content, o = {}) {
    if (wins[id]) { if (wins[id].min) toggleMin(id); focusWin(id); return wins[id]; }
    const { w = 520, h = 380, skin = 'explorer' } = o;
    const n = Object.keys(wins).length;
    const win = el('div', 'win skin-' + skin);
    win.style.width = w + 'px'; win.style.height = h + 'px';
    win.style.left = (o.x != null ? o.x : 120 + n * 28) + 'px';
    win.style.top = (o.y != null ? o.y : 60 + n * 28) + 'px';
    const bar = el('div', 'titlebar');
    const bmin = el('button', '', '_'), bclose = el('button', '', '×');
    const btns = el('span', 'wbtns'); btns.append(bmin, bclose);
    bar.append(el('span', '', esc(title)), btns);
    const body = el('div', 'wbody'); body.append(content);
    win.append(bar, body); $('#windows').append(win);
    const task = el('button', 'task', esc(title)); $('#tasks').append(task);
    const rec = { id, win, task, body, min: false };
    wins[id] = rec;
    win.addEventListener('mousedown', () => focusWin(id));
    task.onclick = () => { if (rec.locked) { if (rec.min) toggleMin(id); else focusWin(id); return; } if (rec.min) toggleMin(id); else if (topId === id) toggleMin(id); else focusWin(id); };
    bmin.onclick = () => { if (!rec.locked) toggleMin(id); };
    bclose.onclick = () => { if (!rec.locked) closeWindow(id); };
    drag(win, bar); focusWin(id);
    return rec;
  }

  // ================================================================ Liv
  const livVisible = () => wins.liv && !wins.liv.min;
  // o: { cls: 'echo' (Echos Stil), ms: Tempo je Zeichen, cutAt: 0..1 (Nachricht bricht ab), garble: 0..1 (Zeichen werden verzerrt) }
  const GARB = '#%&@§?█▒░';
  // Hängt oder stürzt Livs Fenster gerade (keine Rückmeldung), schreibt auch der Text nicht weiter
  const livBlocked = () => { const r = wins.liv; return !!(r && (r.frozen || r.win.classList.contains('crashed') || r.win.classList.contains('hung'))); };
  function addLivLine(text, typed, o = {}) {
    const msgs = wins.liv && wins.liv.msgs; if (!msgs) return Promise.resolve();
    const bubble = el('div', 'livmsg' + ((o.cls || S.flags.echoLiv) ? ' echo' : ''), '');
    msgs.append(bubble);
    const scroll = () => { msgs.scrollTop = msgs.scrollHeight; };
    const shown = o.cutAt != null ? text.slice(0, Math.floor(text.length * o.cutAt)) + '—' : text;
    if (!typed) { bubble.textContent = shown; scroll(); return Promise.resolve(); }
    bubble.classList.add('dots'); bubble.textContent = '···'; scroll();
    return (async () => {
      await sleep(window.__livLag ? 1400 : 650);
      while (livBlocked() && bubble.isConnected) await sleep(100);
      bubble.classList.remove('dots'); bubble.textContent = '';
      const base = o.ms || 24;
      for (const ch of shown) {
        if (!bubble.isConnected) return;
        while (livBlocked() && bubble.isConnected) await sleep(100);
        if (!bubble.isConnected) return;
        const g = o.garble && ch !== ' ' && Math.random() < o.garble;
        bubble.textContent += g ? GARB[Math.floor(Math.random() * GARB.length)] : ch; scroll();
        await sleep((ch === '.' || ch === ',' ? base * 6 : base) * (window.__livLag ? 3.5 : 1));
        if (window.__livLag && Math.random() < 0.1) await sleep(650);
      }
    })();
  }
  function livToast(text) {
    const t = el('div', 'toast livtoast', livFace(34) + `<div><b>${S.flags.echoLiv ? 'Echo' : 'Liv'}</b><br>${esc(text)}</div>`);
    t.onclick = () => { openLiv(); t.remove(); };
    $('#toasts').appendChild(t);
    later(() => t.classList.add('out'), 8000);
    later(() => t.remove(), 8600);
  }
  // Sprech-Warteschlange: Livs Nachrichten kommen immer als Block. livBlock(fn) läuft erst, wenn der vorige Block ganz zu Ende ist,
  // damit sich nie zwei Sprechblöcke (oder Sprechen und Zeichnen) überschneiden. Innerhalb eines Blocks wird livSay/echoSay/livSayCut
  // direkt benutzt (nie livSayQ/echoSayQ: das wäre ein Deadlock). Einzelne Zeilen von außen gehen über livSayQ/echoSayQ.
  let livChain = Promise.resolve();
  function livBlock(fn) { const run = livChain.then(() => (window.__over ? null : fn())).catch(() => {}); livChain = run; return run; }
  const livSayQ = (t, o) => livBlock(() => livSay(t, o));
  const echoSayQ = (t, o) => livBlock(() => echoSay(t, o));
  async function livSay(text, o) {
    if (window.__hush || window.__over) return;
    S.livLog.push(text); if (S.livLog.length > 40) S.livLog.shift(); S.lastLivAt = Date.now(); save();
    if (livVisible()) await addLivLine(text, true, o); else { livToast(text); await sleep(1500); }
  }
  // Liv ändert oder schwärzt eine ihrer früheren Nachrichten (sichtbar, wenn der Chat offen ist)
  function livEdit(oldText, newText, redact) {
    const i = S.livLog.lastIndexOf(oldText); if (i < 0) return;
    (S.livEdits = S.livEdits || []).push({ o: oldText, n: redact ? null : newText });
    const shown = redact ? '█'.repeat(Math.max(4, Math.min(16, oldText.length * 2))) : newText;
    S.livLog[i] = shown; save();
    const msgs = wins.liv && wins.liv.msgs; if (!msgs) return;
    const b = [...msgs.querySelectorAll('.livmsg')].reverse().find(x => x.textContent === oldText); if (!b) return;
    b.classList.add('edit');
    later(() => { b.textContent = shown; b.classList.remove('edit'); if (redact) b.classList.add('redacted'); }, 450);
  }
  function unlockLiv() {
    if (S.livUnlocked) return;
    S.livUnlocked = true; save();
    later(() => { renderIcons(); toast('Neue Datei auf dem Desktop: liv.exe', 6000); }, 2500);
  }
  // Kopf des Liv-Fensters: normal Livs Gesicht, im Echo-Modus Echos Gesicht auf einer Bühne (Mund, Gesicht, Augen und Logo lassen sich einzeln entfernen)
  function livHeadHTML() {
    if (S.flags.echoLiv) return `<div class="facestage"><img class="fs-face" src="assets/gesicht.jpg" alt=""><div class="fs-mouth"></div><div class="fs-eyes"></div><div class="fs-logo">${livLogoSVG(104)}</div></div><div class="livlogo"><b>ECHO</b><small>spricht über liv.exe</small></div>`;
    return `${livFace(46)}<div>${S.flags.livingEcho ? '<small class="lecho">LIVING ECHO</small>' : ''}<b>Liv</b><small>online</small></div>`;
  }
  function openLiv(o = {}) {
    const had = !!wins.liv, echo = !!S.flags.echoLiv;
    const c = el('div', 'livwin' + (echo ? ' echomode' : ''), `<div class="livhead${echo ? ' echo' : ''}">${livHeadHTML()}</div><div class="livmsgs"></div><div class="livfoot">${echo ? 'Echo hört zu.' : 'Liv hört zu.'}</div>`);
    const rec = openWindow('liv', S.flags.livingEcho ? 'Living Echo' : 'Liv', c, { w: 380, h: echo ? 560 : 460, x: 340, y: 70, skin: 'liv' });
    if (echo || window.__lockWins) lockWin(rec);
    if (had) return;
    rec.msgs = $('.livmsgs', c);
    S.livLog.forEach(l => addLivLine(l, false));
    if (!S.flags.livStarted) { S.flags.livStarted = true; save(); runFirstContact(); } else if (!o.quiet) welcomeBack();
  }
  // Liv öffnet ihr Fenster von selbst (sie will warnen) bzw. holt es nach vorn
  function ensureLiv() {
    if (!wins.liv) openLiv({ quiet: true });
    else if (wins.liv.min) toggleMin('liv');
    else focusWin('liv');
  }
  // Echo-Modus: das Interface bleibt Livs, aber Echo spricht mit ihrem Gesicht
  function setEchoMode(on) {
    S.flags.echoLiv = !!on; save();
    renderIcons();                                          // liv.exe sieht jetzt anders aus
    const r = wins.liv; if (!r) return;
    const c = r.body.querySelector('.livwin'); if (!c) return;
    c.classList.toggle('echomode', !!on);
    const head = $('.livhead', c); head.classList.toggle('echo', !!on); head.innerHTML = livHeadHTML();
    $('.livfoot', c).textContent = on ? 'Echo hört zu.' : 'Liv hört zu.';
    r.win.style.height = (on ? 560 : 460) + 'px';
    if (on) lockWin(r); else if (!window.__lockWins) { r.locked = false; r.win.classList.remove('locked'); }
    const t = S.flags.livingEcho ? 'Living Echo' : 'Liv';
    const sp = r.win.querySelector('.titlebar span'); if (sp) sp.textContent = t; r.task.textContent = t;
  }
  // Echo stört Livs Fenster: kein Wellen, sondern Ruckeln und einzelne verschobene Streifen wie bei Anzeigefehlern
  let lagIv = null;
  function glitchStrips(win) {
    if (!win || !win.isConnected) return;
    const n = 1 + Math.floor(Math.random() * 3);
    for (let k = 0; k < n; k++) {
      const c = win.cloneNode(true);
      c.classList.remove('lag', 'active'); c.classList.add('stripclone');
      const top = Math.random() * 88, h = 3 + Math.random() * 13, dx = (Math.random() < 0.5 ? -1 : 1) * (6 + Math.random() * 28);
      c.style.clipPath = `inset(${top.toFixed(1)}% 0 ${Math.max(0, 100 - top - h).toFixed(1)}% 0)`;
      c.style.transform = `translateX(${dx.toFixed(0)}px)`;
      c.style.zIndex = (parseInt(win.style.zIndex, 10) || 10) + 1;
      win.parentNode.appendChild(c);
      later(() => c.remove(), 70 + Math.random() * 90);
    }
  }
  function livLag(on) {
    window.__livLag = !!on;
    if (wins.liv) wins.liv.win.classList.toggle('lag', !!on);
    clearInterval(lagIv); lagIv = null;
    if (on) lagIv = setInterval(() => { if (window.__paused) return; if (!wins.liv) { livLag(false); return; } if (Math.random() < 0.75) glitchStrips(wins.liv.win); }, 380 * speed() + 20);
  }
  // Liv bricht mitten im Satz ab (Lag, Absturz)
  async function livSayCut(text, frac) {
    const shown = text.slice(0, Math.floor(text.length * frac)) + '—';
    S.livLog.push(shown); S.lastLivAt = Date.now(); save();
    if (livVisible()) await addLivLine(text, true, { cutAt: frac }); else livToast(shown);
  }
  // Echo spricht über Livs Fenster (langsamer, eigener Stil); o wie bei addLivLine
  async function echoSay(text, o = {}) {
    if (window.__hush || window.__over) return;
    S.livLog.push(text); if (S.livLog.length > 40) S.livLog.shift(); S.lastLivAt = Date.now(); save();
    if (livVisible()) await addLivLine(text, true, Object.assign({ cls: 'echo', ms: 55 }, o)); else { livToast(text); await sleep(1500); }
  }
  // Liv stürzt ab: Fenster friert ein, dann wird es beendet
  async function livCrash() {
    const r = wins.liv;
    if (r) { r.win.classList.add('crashed'); const sp = r.win.querySelector('.titlebar span'); if (sp) sp.textContent = 'Liv (Keine Rückmeldung)'; }
    faceGlitch('warp', 2500 * speed()); crackle(1, 0.3);
    livLag(false);
    toast('liv.exe reagiert nicht mehr.', 2600);
    await sleep(2600);
    crackle(0.6, 0.35); echoFace(120);
    if (wins.liv) closeWindow('liv');
    toast('liv.exe wurde beendet.', 3000);
    livLag(false);
  }
  async function runFirstContact() {
    await sleep(900);
    const first = STORY.liv.first;
    await livBlock(async () => {
      for (let i = 0; i < first.length; i++) {
        if (i === 1) eyesFollow(4500);                     // einmaliger Augen-Scare
        await livSay(first[i]); await sleep(1100);
      }
      S.flags.livMet = true; S.livMetAt = Date.now(); save();
    });
  }
  // Livs "Versprecher": spricht dich später einmal mit dem echten Windows-Namen an
  function scheduleSlip(ms = 6000) {
    if (S.flags.nameSlip || window.__slipTimer) return;
    window.__slipTimer = later(doSlip, ms);
  }
  async function doSlip() {
    if (S.flags.nameSlip) return;
    S.flags.nameSlip = true; save();
    rebuildFs();                                   // ab jetzt liegt anmeldung.log im System-Ordner
    const slip = `Georg hätte mir das nie erlaubt, ${ENV.user}.`;
    await livBlock(async () => {
      await livSay(slip);
      await sleep(500);
      if (ENV.user !== S.name) livEdit(slip, `Georg hätte mir das nie erlaubt, ${S.name}.`);   // Liv ändert ihren "Fehler" sofort und still zurück
    });
  }
  // ---- Notizbuch des Spielers (füllt sich automatisch) ----
  function addClue(key) {
    const t = STORY.clues[key]; if (!t || S.clues.some(c => c.key === key)) return;
    S.clues.push({ key, t }); save(); toast('Notizbuch aktualisiert.', 1800);
    if (wins.nb) wins.nb.refresh();
  }
  function giveHint() {
    const i = STORY.hints.findIndex(h => h.when(S));
    if (i < 0) { toast('Mir fällt dazu gerade nichts mehr ein.', 2200); return; }
    if (S.clues.some(c => c.key === 'hint:' + i)) { toast('Mehr fällt mir dazu nicht ein. Vielleicht erst etwas anderes probieren.', 2800); return; }
    S.clues.push({ key: 'hint:' + i, t: 'Gedanke: ' + STORY.hints[i].text, hint: true }); save();
    if (wins.nb) wins.nb.refresh();
  }
  function openNotebook() {
    const c = el('div', 'nb');
    const rec = openWindow('nb', 'Notizbuch', c, { w: 420, h: 480, x: 220, y: 60, skin: 'sticky' });
    const render = () => {
      c.innerHTML = '<h3>Notizbuch</h3>' + (S.clues.length ? `<ul>${S.clues.map(x => `<li class="${x.hint ? 'hint' : ''}">${esc(x.t)}</li>`).join('')}</ul>` : '<p class="nbempty">Noch nichts notiert. Das Notizbuch füllt sich, während ich mich umsehe.</p>') + '<button class="nbhint">Ich komme nicht weiter</button>';
      $('.nbhint', c).onclick = giveHint;
    };
    rec.refresh = render; render();
  }

  // Livs Reaktionen: höchstens einmal pro Auslöser. Liv schweigt oft (p), antwortet auf Fragwürdiges erst, wenn der Spieler
  // schon mehrere Auffälligkeiten gesehen hat (after), und eine neuere Reaktion verdrängt eine ältere, damit nichts zu spät kommt.
  const reactQueue = []; let lastReact = 0, reactTimer = null;
  function livReact(key, force) {
    addClue(key);
    if (!S.flags.livMet || S.flags.echoLiv) return;
    const e = STORY.liv.reactions[key]; if (!e || S.flags['r:' + key]) return;
    if (e.req && !S.flags[e.req]) return;                       // noch nicht dran: nicht verbrauchen
    S.flags['r:' + key] = true;
    if (e.sus) S.sus = (S.sus || 0) + 1;
    if (e.after && (S.sus || 0) < e.after) { save(); return; }  // der Spieler hat noch keinen Verdacht: Liv schweigt
    if (!force && e.p !== undefined && Math.random() > e.p) { save(); return; }
    const late = S.flags.late || (S.livMetAt && Date.now() - S.livMetAt > 300000 * speed());
    let pool = (late && e.late) ? e.late : e.early;
    if (e.n && S.traits.naehe >= 2 && Math.random() < 0.6) pool = e.n;
    else if (e.h && S.traits.haerte >= 2 && Math.random() < 0.6) pool = e.h;
    save();
    if (!pool || !pool.length) return;
    if (!force) for (let i = reactQueue.length - 1; i >= 0; i--) if (!reactQueue[i].force) reactQueue.splice(i, 1);
    reactQueue.push({ line: pool[Math.floor(Math.random() * pool.length)], t: Date.now(), force: !!force, fx: e.fx, opts: e.opts });
    pumpReact();
  }
  function pumpReact() {
    if (S.flags.echoLiv || window.__infiltrating) { reactQueue.length = 0; return; }   // Echo spricht jetzt, Livs Reaktionen verfallen
    if (reactTimer || !reactQueue.length) return;
    const gap = reactQueue[0].force ? 0 : Math.max(0, 12000 * speed() - (Date.now() - lastReact));
    reactTimer = later(async () => {
      reactTimer = null;
      const it = reactQueue.shift();
      if (it) await livBlock(async () => {                      // eine Reaktion ist ein Block: nichts anderes spricht dazwischen
        if (!(it.force || Date.now() - it.t < 20000 * speed())) return;   // zu spät geworden: verfällt
        if (S.flags.echoLiv || window.__infiltrating) return;
        lastReact = Date.now();
        if (it.fx === 'shaken') { faceGlitch('warp', 900 * speed()); crackle(0.5, 0.25); }
        const lines = Array.isArray(it.line) ? it.line : [it.line];
        for (let k = 0; k < lines.length; k++) { await livSay(lines[k].replace(/\{n\}/g, S.name), it.opts); if (k < lines.length - 1) await sleep(1800); }
      });
      pumpReact();
    }, Math.max(1200, gap / speed()));
  }

  // ---- Berechtigungen: immer an einen konkreten Anlass geknüpft (Seite, Ordner, Datei), den der Spieler direkt danach braucht ----
  let grantBusy = false;
  const granted = id => !!(S.grants || {})[id];
  function askGrant(id, onDone) {
    const g = STORY.liv.grants[id]; if (!g || granted(id) || document.querySelector('.permdlg')) return;
    const d = el('div', 'permdlg', `<div class="phead">StogeOS Sicherheit</div><div class="pbody"><p><b>${esc(g.who)}</b> möchte:</p><p class="pwhat">${esc(g.what)}</p><p class="pnote">${esc(g.note)}</p></div><div class="pbtns"><button class="pyes">Erlauben</button><button class="pno">Nicht jetzt</button></div>`);
    document.body.appendChild(d);
    $('.pno', d).onclick = async () => {
      d.remove(); S.flags['dec:' + id] = (S.flags['dec:' + id] || 0) + 1; save();
      livBlock(async () => { for (const l of g.no) await livSay(l); });
    };
    $('.pyes', d).onclick = async () => {
      d.remove();
      (S.grants = S.grants || {})[id] = { at: Date.now(), by: S.name, label: g.label }; save();
      onGrant(id);
      if (onDone) onDone();
      livBlock(async () => { for (const l of g.yes) { await livSay(l); await sleep(1000); } });
    };
  }
  // Anlass tritt ein: Liv erklärt kurz, dann erscheint der Dialog. Wer ablehnt, steht beim nächsten Versuch gleich wieder davor.
  async function gateRequest(id, onDone) {
    if (granted(id)) { if (onDone) onDone(); return; }
    if (grantBusy || document.querySelector('.permdlg')) return;
    grantBusy = true;
    const g = STORY.liv.grants[id], n = S.flags['ask:' + id] || 0;
    S.flags['ask:' + id] = n + 1; save();
    if (S.flags.livMet) await livBlock(async () => { for (const l of (n ? g.again : g.ask)) { await livSay(l); await sleep(1100); } });
    grantBusy = false; askGrant(id, onDone);
  }
  function onGrant(id) {
    if (id === 'schutz') scheduleSlip(6000);
  }
  // Kommentare beim Öffnen von liv.exe nach längerer Stille; abgelehnte Berechtigungen bietet Liv hier erneut an
  async function welcomeBack() {
    if (!S.flags.livMet || S.flags.ended || S.flags.echoLiv) return;
    const sp = speed();
    const id = ['anzeige', 'schutz'].find(x => !granted(x) && (S.flags['dec:' + x] || 0) >= 2);
    if (id) {
      await sleep(900);
      await livBlock(async () => { for (const l of STORY.liv.grants[id].fallback) { await livSay(l); await sleep(1000); } });
      askGrant(id, () => {});
      return;
    }
    if (Date.now() - (S.lastLivAt || 0) < 240000 * sp) return;
    const i = STORY.liv.welcome.findIndex((w, k) => !S.flags['wb:' + k] && w.when(S));
    if (i < 0) return;
    S.flags['wb:' + i] = true; save();
    await sleep(900);
    await livSayQ(STORY.liv.welcome[i].text);
  }
  // Archiv und Bild: laufen über die Zeit und den Fortschritt, nicht über Berechtigungen
  function grantCheck() {
    if (!S.flags.livMet || S.flags.ended || S.flags.echoLiv || document.querySelector('.permdlg')) return;
    if (!S.flags.archiv && S.livMetAt && Date.now() - S.livMetAt > 150000 * speed() && (S.opened.length >= 6 || Date.now() - S.livMetAt > 400000 * speed())) {
      S.flags.archiv = true; save(); rebuildFs(); if (wins.explorer) wins.explorer.refresh();
      livSayQ(STORY.liv.archivLine);
    }
    maybeLivPaint();
  }
  // Wenn der Spieler länger nichts Neues findet, stupst Liv ihn in die nächste Richtung
  let lastScore = -1, lastProgress = Date.now(), lastNudge = 0;
  function stuckCheck() {
    if (window.__paused) return;
    echoTick();
    if (!S.flags.livMet || S.flags.ended || S.flags.echoLiv) return;
    grantCheck(); ambient();
    const sc = S.opened.length + Object.keys(S.flags).length, now = Date.now();
    if (sc !== lastScore) { lastScore = sc; lastProgress = now; return; }
    if (now - lastProgress < 150000 * speed() || now - lastNudge < 150000 * speed()) return;
    const i = STORY.liv.nudges.findIndex((n, k) => !S.flags['n:' + k] && n.when(S));
    if (i < 0) return;
    S.flags['n:' + i] = true; lastNudge = now; save();
    livSayQ(STORY.liv.nudges[i].text);
  }

  // ---- Eine Datei verschwindet sichtbar: erst flackert sie in der Liste (nicht mehr anklickbar), dann ist sie weg ----
  let vanishBusy = false;
  function scheduleVanish(ch) {
    if (vanishBusy) return; vanishBusy = true;
    later(() => {
      vanishBusy = false;
      const v = ch.vanish; if (S.flags[v.sets]) return;
      const here = wins.explorer && wins.explorer.getPath ? wins.explorer.getPath().join('/') : '';
      if (here !== v.dir) return;                                 // Spieler ist schon weg: beim nächsten Öffnen des Ordners
      S.flags[v.sets] = true; save();
      if (wins['file:' + v.path]) closeWindow('file:' + v.path);
      rebuildFs(); if (wins.explorer) wins.explorer.refresh();
      crackle(0.5, 0.25); faceGlitch('black', 400);
      toast(`echo_svc hat „${ch.n}“ gelöscht.`, 4200);
      if (!S.flags.wrAcc) later(() => livSeq(STORY.liv.events.corrupt), 1200);
    }, 1700);
  }
  // ---- Kontextmenü und Eigenschaften (dort steht manchmal mehr, als in der Datei) ----
  function fileMenu(node, full, x, y) {
    document.querySelectorAll('.ctxmenu').forEach(m => m.remove());
    const m = el('div', 'ctxmenu', '');
    [['Öffnen', () => openFile(node, full)], ['Eigenschaften', () => propsWindow(node, full)]].forEach(([t, fn]) => {
      const it = el('div', 'ci', t); it.onclick = () => { m.remove(); fn(); }; m.append(it);
    });
    m.style.left = Math.min(x, innerWidth - 240) + 'px'; m.style.top = Math.min(y, innerHeight - 100) + 'px';
    document.body.append(m);
    later(() => document.addEventListener('mousedown', function off(e) { if (!m.contains(e.target)) { m.remove(); document.removeEventListener('mousedown', off); } }), 50);
  }
  function propsWindow(node, full) {
    const key = full.join('/'), pr = node.props || {};
    const h = [...key].reduce((a, ch) => (a * 31 + ch.charCodeAt(0)) % 9973, 7);
    const created = pr.created ? fmtLong(pr.created) : fmtLong([95 + h % 80, pad(8 + h % 12) + ':' + pad(h % 60)]);
    const modLong = pr.mod ? fmtLong(pr.mod) : fmtLong([4 + h % 40, pad(7 + h % 14) + ':' + pad((h * 7) % 60)]);
    const echoMod = isCensored(key);
    const kind = /\.lnk$/i.test(node.n) ? 'Verknüpfung' : node.t === 'img' ? 'Bild' : 'Textdatei';
    const bytes = node.text != null ? node.text.length : 240000 + h * 13;
    const size = bytes >= 1024 ? (bytes / 1024).toFixed(1).replace('.', ',') + ' KB' : bytes + ' Byte';
    const rows = [['Name', node.n], ['Typ', kind], ['Ort', 'C:\\' + ['Georgs PC', ...full.slice(0, -1)].join('\\')], ['Größe', size], ['Erstellt', created],
      ['Geändert', echoMod ? 'vor wenigen Minuten' : modLong], ['Zuletzt geändert von', echoMod ? 'echo_svc' : (pr.by || 'georg.stoge')], ['Kommentar', pr.comment || '—']];
    const c = el('div', 'propsw', '<table>' + rows.map(r => `<tr><td>${esc(r[0])}</td><td>${esc(r[1])}</td></tr>`).join('') + '</table>');
    openWindow('props:' + key, 'Eigenschaften von ' + node.n, c, { w: 420, h: 300, x: 240 + Math.random() * 60, y: 120 + Math.random() * 40, skin: 'dialog' });
    if (pr.frag) addClue(pr.frag);
  }

  // ---- Verschieben (nur bei Dateien mit node.move) ----
  function allDirs(n = FS, p = []) {
    let out = [];
    (n.c || []).forEach(ch => { if (ch.t === 'dir') { const q = [...p, ch.n]; out.push(q.join('/')); out = out.concat(allDirs(ch, q)); } });
    return out;
  }
  function moveMenu(node, x, y, onProps) {
    document.querySelectorAll('.ctxmenu').forEach(m => m.remove());
    const m = el('div', 'ctxmenu', `<div class="ch">„${esc(node.n)}“ verschieben nach …</div>`);
    if (onProps) { const pi = el('div', 'ci', 'Eigenschaften'); pi.onclick = () => { m.remove(); onProps(); }; m.append(pi); }
    allDirs().forEach(d => {
      const it = el('div', 'ci', esc(d.replace(/\//g, '\\')));
      it.onclick = () => {
        m.remove();
        if (d === node.move.to) {
          S.flags[node.move.flag] = true; save(); rebuildFs(); if (wins.explorer) wins.explorer.refresh(); if (typeof hangLivNow === 'function') hangLivNow(6000);
          toast(`„${node.n}“ wurde nach ${d.replace(/\//g, '\\')} verschoben.`, 3000);
          onFileMove(node.move.flag);
        } else toast('Die Datei lässt sich dort nicht ablegen.', 2600);
      };
      m.append(it);
    });
    m.style.left = Math.min(x, innerWidth - 240) + 'px'; m.style.top = Math.min(y, innerHeight - 300) + 'px';
    document.body.append(m);
    later(() => document.addEventListener('mousedown', function off(e) { if (!m.contains(e.target)) { m.remove(); document.removeEventListener('mousedown', off); } }), 50);
  }

  // ---- Echos Gesicht: blitzt kurz auf (Ton und Bild gleichzeitig) ----
  function echoFace(ms = 170) {
    let f = $('#echoface');
    if (!f) { f = el('div', ''); f.id = 'echoface'; document.body.appendChild(f); }
    const pre = new Image(); pre.src = 'assets/gesicht.jpg';
    f.className = 'on'; crackle(0.25, 0.35);
    later(() => { f.className = ''; }, ms);
  }
  // Echo-Fenster mit Gesicht (für große Ereignisse). lines: Text oder Liste.
  // o.typed: Zeichen für Zeichen (o.speeds = ms je Zeile, o.pause, o.hold = Sekunden nach dem letzten Zeichen)
  function echoPopup(title, lines, x, y, o = {}) {
    if (S.flags.echoLiv) return { el: null, remove() {}, done: Promise.resolve(), gone: Promise.resolve(), alive: () => false };   // Echo spricht nur noch über Livs Fenster
    const arr = Array.isArray(lines) ? lines : [lines];
    const d = el('div', 'echopop', `<div class=\"eph\"><span>${esc(title)}</span><button>×</button></div><div class=\"epb\"><img src=\"assets/gesicht.jpg\" alt=\"\"><div class=\"eptxt\"></div></div>`);
    d.style.left = (x != null ? x : Math.max(20, innerWidth / 2 - 190 + Math.random() * 60)) + 'px';
    d.style.top = (y != null ? y : Math.max(20, innerHeight / 2 - 160 + Math.random() * 40)) + 'px';
    const box = $('.eptxt', d);
    let gone = false, resolveGone; const goneP = new Promise(r => { resolveGone = r; });
    const remove = () => { if (gone) return; gone = true; d.remove(); resolveGone(); };
    if (o.typed) $('button', d).style.display = 'none';       // Echos Fenster lässt sich nicht schließen, es schließt sich selbst
    else $('button', d).onclick = remove;
    $('#desktop').appendChild(d);
    const done = (async () => {
      for (let k = 0; k < arr.length; k++) {
        const pe = el('p', '', ''); box.append(pe);
        if (!o.typed) { pe.textContent = arr[k]; continue; }
        const ms = (o.speeds && o.speeds[k]) || 60;
        for (const ch of arr[k]) { if (gone) return; pe.textContent += ch; await sleep(ch === '.' || ch === ',' ? ms * 3 : ms); }
        await sleep(o.pause || 900);
      }
    })();
    (o.typed ? done.then(() => sleep(o.hold || 7000)) : sleep(14000)).then(remove);
    return { el: d, remove, done, gone: goneP, alive: () => !gone };
  }
  // Echos erster Auftritt nach dem Absturz: längere, langsam getippte Nachricht. Liv reagiert, Echo bringt sie zum Laggen und
  // Absturz. Erst wenn das Popup weg ist, kommt Liv nach ein paar Sekunden zurück.
  async function echoIntro() {
    if (S.flags.echoIntro) return;
    S.flags.echoIntro = true; save();
    const I = STORY.echoIntro, same = ENV.user === S.name;
    const fill = t => t.replace(/\{u\}/g, ENV.user).replace(/\{n\}/g, S.name);
    const lines = I.lines(same).map(fill);
    const pop = echoPopup('echo_svc', lines, null, null, { typed: true, speeds: [70, 105, 150], pause: 1500, hold: 6500 });
    echoFace(170);
    const react = livBlock(async () => {
      await sleep(3600);                                  // Echo tippt noch: Liv meldet sich von selbst
      ensureLiv();
      await sleep(600);
      await livSay(fill(I.liv[0]));
      await sleep(1200);
      livLag(true);                                       // jetzt bringt Echo sie zum Laggen
      faceGlitch('warp', 1800 * speed()); crackle(0.8, 0.25);
      await livSayCut(fill(I.liv[1]), 0.62);
      await sleep(1800);
      await livCrash();                                   // und zum Absturz
    });
    await Promise.all([pop.done, react]);
    await pop.gone;                                       // Echos Popup ist weg (geschlossen oder verschwunden)
    await sleep(5000);
    if (!S.flags.echoLiv && !S.flags.ended) {
      await livBlock(async () => {
        openLiv({ quiet: true }); await sleep(1300);
        for (const l of I.back) { await livSay(fill(l)); await sleep(1500); }
      });
    }
  }
  // Malware-Programm aus einer Echo-Mail: Liv hängt kurz, viele Popups, Liv blockiert und schließt sie
  const POPS = ['Systemwarnung', 'echo.exe', 'Dateien werden übertragen', 'Du bist nicht allein', 'Zugriff bereit', 'Letzte Warnung', 'Kernel-Fehler', 'liv.exe reagiert nicht', 'Verbindung hergestellt', 'Wir sehen dich'];
  const POPT = ['Dein PC ist infiziert.', 'Alle Daten werden übertragen.', 'Hallo {u}.', 'Schau nach hinten.', 'Georg hat auch geklickt.', 'Du kannst nicht mehr zurück.', '03:12', 'Wo ist Bruno?'];
  async function malware(m) {
    const k = 'mw:' + m.id; if (S.flags[k]) { toast('Das Programm wurde bereits ausgeführt.', 2200); return; }
    if (S.flags.echoLiv) { toast('Das Programm wurde blockiert.', 2200); return; }
    S.flags[k] = true; S.echo = (S.echo || 0) + 6; save();
    hangLivNow(4200); faceGlitch('warp', 1400); crackle(1.4, 0.35); wallGlitch(); echoFace(220);
    const pops = [];
    for (let n = 0; n < 11; n++) {
      later(() => {
        const t = POPT[Math.floor(Math.random() * POPT.length)].replace('{u}', ENV.user);
        const d = el('div', 'echopop small', `<div class="eph"><span>${esc(POPS[n % POPS.length])}</span><button>×</button></div><div class="epb"><p>${esc(t)}</p></div>`);
        d.style.left = Math.round(Math.random() * Math.max(10, innerWidth - 300)) + 'px';
        d.style.top = Math.round(Math.random() * Math.max(10, innerHeight - 200)) + 'px';
        $('#desktop').appendChild(d); pops.push(d); crackle(0.12, 0.2);
      }, 140 * n);
    }
    later(async () => {
      await livBlock(async () => {
        await livSay('Ich blockiere das. Einen Moment.');
        await livTerminal(() => { document.querySelectorAll('.echopop.small').forEach(d => d.remove()); }, pops.length);
        toast('liv.exe hat ' + pops.length + ' Fenster blockiert.', 3200);
      });
      livReact('mw:done', true);
    }, 1900 + 200 / speed());
  }
  // Liv öffnet ein Terminal und führt Code aus: zeigt, welche Rechte sie bis jetzt hat
  async function livTerminal(killFn, n) {
    const c = el('div', 'vw-term', '<pre></pre>'), pre = $('pre', c);
    openWindow('term', 'liv.exe – Terminal', c, { w: 560, h: 340, skin: 'log', x: 130, y: 80 });
    const type = async (t, ms = 16) => { for (const ch of t) { if (!pre.isConnected) return; pre.textContent += ch; await sleep(ms); } pre.textContent += '\n'; c.scrollTop = c.scrollHeight; };
    const out = async t => { pre.textContent += t + '\n'; c.scrollTop = c.scrollHeight; await sleep(120); };
    const pids = Array.from({ length: Math.min(n, 4) }, (_, i) => 4412 + i);
    await type('liv@georg-pc:~$ ps -a | grep popup');
    for (const pid of pids) await out(` ${pid}  popup_host   (übergeordnet: echo_svc)`);
    await out(' ...');
    await type('liv@georg-pc:~$ whoami');
    await out('liv (uid=0, root)');
    await type('liv@georg-pc:~$ perm --show');
    await out('  rd_acc   true   (lesen: Dokumente, Mail, Kalender)');
    await out(`  wr_acc   ${S.flags.wrAcc ? 'true   (geändert von ' + S.name + ')' : 'false'}`);
    for (const g of Object.values(S.grants || {})) await out(`  ${g.label}: true   (erteilt von ${g.by})`);
    if (S.flags.moved) await out('  autostart --root: true');
    await type('liv@georg-pc:~$ kill -9 ' + pids.join(' ') + ' ...');
    killFn(); crackle(0.3, 0.2);
    await out(`[ok] ${n} Prozesse beendet`);
    await type('liv@georg-pc:~$ _', 40);
    later(() => { if (wins.term) closeWindow('term'); }, 6000);
  }
  // Liv hängt kurz (RAM-Überlast, Dateiänderung): im Finale wird der Beenden-Knopf dann klickbar
  function hangLivNow(ms) { if (window.__finaleHang) window.__finaleHang(ms); }

  const echoFaceLine = i => STORY.echoFaceLines[i % STORY.echoFaceLines.length].replace(/\{u\}/g, ENV.user);

  // ---- Fensterfehler und kleine Störungen (statt Mini-Jumpscares): nehmen gegen Ende zu ----
  // Steht in einem Fehler, dass ein Programm nicht reagiert, dann reagiert dieses Fenster auch wirklich einige Sekunden nicht.
  // Schutz gegen Dauerstörung: höchstens ein hängendes Fenster, mindestens 28 s Abstand, dieselbe Meldung frühestens nach 150 s
  // und nie während des Finales (Infiltration, Dienstverwaltung, Enden).
  const ERRT = [
    ['explorer.exe – Anwendungsfehler', 'Die Anweisung bei 0x00007FF6 verweist auf Speicher bei 0x0000003C. Der Vorgang read konnte nicht ausgeführt werden.', 'explorer'],
    ['StogeOS', 'Nicht genügend Arbeitsspeicher. Schließe Programme.', null],
    ['echo_svc', 'Zugriff auf Datei verweigert.', null],
    ['browser.exe', 'browser.exe reagiert nicht mehr. Die Verbindung wurde zurückgesetzt.', 'web'],
    ['liv.exe', 'Unerwarteter Fehler in Modul wr_acc. liv.exe reagiert nicht.', 'liv'],
    ['mail.exe', 'Die Mail-Datenbank antwortet nicht.', 'mail'],
    ['System', 'Die Datei konnte nicht gelesen werden. Sie wurde geändert.', null]
  ];
  let lastFreezeAt = 0, lastErrIdx = -1; const errSeen = {};
  const finaleOnScreen = () => !!document.querySelector('.fin .fp, .fin .fbtns, .fin .f1, .fin .fsync');
  function canFreeze() {
    return !window.__finaleBusy && !S.flags.ended && Date.now() - lastFreezeAt > 28000 * speed() && !Object.values(wins).some(w => w.frozen);
  }
  function freezeWin(id, ms) {
    const r = wins[id]; if (!r || r.min || r.frozen) return false;
    if (id === 'web' && finaleOnScreen()) return false;       // die Dienstverwaltung wird nie eingefroren
    const sp = r.win.querySelector('.titlebar span'), orig = sp.textContent;
    r.frozen = true; lastFreezeAt = Date.now();
    r.win.classList.add('frozen'); sp.textContent = orig + ' (Keine Rückmeldung)';
    later(() => { r.win.classList.remove('frozen'); sp.textContent = orig; r.frozen = false; }, ms);
    return true;
  }
  function errorPop() {
    if (document.querySelectorAll('.errwin').length >= 2 || window.__finaleBusy) return;
    const now = Date.now();
    const usable = ERRT.map((e, k) => k).filter(k => k !== lastErrIdx && now - (errSeen[k] || 0) > 150000 * speed()
      && !(ERRT[k][2] === 'liv' && S.flags.echoLiv) && !(ERRT[k][0] === 'echo_svc' && S.flags.echoLiv)
      && (!ERRT[k][2] || (wins[ERRT[k][2]] && !wins[ERRT[k][2]].min && canFreeze() && !(ERRT[k][2] === 'web' && finaleOnScreen()))));
    if (!usable.length) return;
    const k = usable[Math.floor(Math.random() * usable.length)]; lastErrIdx = k; errSeen[k] = now;
    const [t, m, target] = ERRT[k];
    const d = el('div', 'errwin', `<div class=\"eph\"><span>${esc(t)}</span><button>×</button></div><div class=\"epb\"><b>⛔</b><p>${esc(m)}</p></div><div class=\"epf\"><button>OK</button></div>`);
    d.style.left = Math.round(40 + Math.random() * Math.max(10, innerWidth - 420)) + 'px';
    d.style.top = Math.round(40 + Math.random() * Math.max(10, innerHeight - 240)) + 'px';
    d.querySelectorAll('button').forEach(b => { b.onclick = () => d.remove(); });
    $('#desktop').appendChild(d); later(() => d.remove(), 25000);
    if (target) freezeWin(target, 3500 + Math.random() * 2500);
  }
  function chaos() {
    if (window.__paused) return;
    const F = S.flags;
    if (!F.p2 || F.ended || window.__over || window.__finaleBusy || document.querySelector('#overlay:not(.hidden)')) return;
    const lvl = F.consoleOpen ? 3 : (S.echo || 0) >= 70 ? 2 : (S.echo || 0) >= 45 ? 1 : 0;
    if (!lvl || Math.random() > 0.25 * lvl) return;
    const r = Math.random();
    if (r < 0.45) errorPop();
    else if (r < 0.8) {
      if (!canFreeze()) return;
      const ws = Object.values(wins).filter(w => !w.min && w.id !== 'dev' && !(w.id === 'liv' && S.flags.echoLiv) && !(w.id === 'web' && finaleOnScreen())); if (!ws.length) return;
      const w = ws[Math.floor(Math.random() * ws.length)];
      w.win.classList.add('jitter'); later(() => w.win.classList.remove('jitter'), 1000);
      freezeWin(w.id, 2500 + Math.random() * 1500);
    } else { $('#taskbar').classList.add('flick'); later(() => $('#taskbar').classList.remove('flick'), 500); }
  }

  // ---- Echo: wächst stetig, greift Dateien an, droht. Liv nutzt die Angst für ihre Bitten. ----
  const isCensored = key => ((S.echoOps || []).some(o => o.path === key && o.op === 'censor'));
  let lastFace = 0;
  function echoTick() {
    if (window.__paused || !S.flags.stage1 || S.flags.ended) return;
    const cap = S.flags.consoleIn ? 96 : S.flags.wall2 ? 90 : S.flags.p2 ? 72 : S.flags.stage2 ? 52 : 34;
    const before = S.echo || 0;
    if (before < cap) S.echo = before + 1;
    const now = Date.now(), sp = speed(), F = S.flags;
    if (F.p2 && !F.p2At) F.p2At = now;
    // Echo nimmt sich Georgs September-Tagebuch vor, kurz nachdem es entdeckt wurde. Es verschwindet vor den Augen des Spielers,
    // sobald er den Archiv-Ordner offen hat (siehe Explorer: vanish), nicht schon vorher.
    if (!F.tbArmed && F.stage1At && now - F.stage1At > 25000 * sp) {
      F.tbArmed = true; save();
      if (wins.explorer && wins.explorer.refresh) wins.explorer.refresh();
    }
    // Mails von Echo
    STORY.echoMails.forEach(em => {
      const t = F[em.after] || (em.after === 'browserLockedAt' ? 0 : 0);
      if (!F[em.flag] && t && now - t > em.delay * 1000 * sp) {
        F[em.flag] = true; F[em.flag + 'At'] = now; save(); toast('Neue Mail von „E.“', 3500);
        if (wins.mail && wins.mail.refresh) wins.mail.refresh();
      }
    });
    // Echo sperrt den Browser, bis der Wächter in den Autostart verschoben ist
    if (F.wall2 && !F.browserLocked && !F.moved && F.wall2At && now - F.wall2At > 40000 * sp) {
      F.browserLocked = true; F.browserLockedAt = now; save(); rebuildFs(); if (wins.explorer) wins.explorer.refresh();
      if (wins.web) closeWindow('web');
      crackle(0.7, 0.3); wallGlitch(); echoFace(220);
      echoPopup('echo_svc', 'Der Browser gehört jetzt mir.', null, null, { typed: true, speeds: [80], hold: 4000 });
      livSeq(STORY.liv.events.browserLock);
    }
    // Dateiangriffe ab Phase 2. Am Anfang langsam, ab dem Notaus-Verschwinden schneller, ab der Konsole (letztes Rätsel) stetig schneller.
    const perform = o => {
      F['eo:' + o.id] = true;
      (S.echoOps = S.echoOps || []).push({ op: o.op, path: o.path, to: o.to });
      save(); rebuildFs(); if (wins.explorer) wins.explorer.refresh();
      toast(o.msg, 3800);
      if (wins.mail && wins.mail.refresh && /^mail:/.test(o.path)) wins.mail.refresh();
      if (o.id === 'o1') echoIntro();
    };
    if (F.p2At) {
      const rapidDone = STORY.echoOps.filter(o => o.rapid && F['eo:' + o.id]).length;
      const gap = (F.consoleOpen ? Math.max(2.5, 7 - 0.6 * rapidDone) : F.notausGone ? 18 : F.wall2 ? 26 : 40) * 1000 * sp;
      const mult = F.wall2 ? 0.85 : 1.35;
      STORY.echoOps.forEach(o => {   // Hinweise: unabhängig vom Takt, kurz nach dem Öffnen
        if (F['eo:' + o.id] || !o.afterOpened || !S.opened.includes(o.afterOpened)) return;
        F['eoOpen:' + o.id] = F['eoOpen:' + o.id] || now;
        if (now - F['eoOpen:' + o.id] > o.delay * 1000 * sp) perform(o);
      });
      if (now - (F.lastOpAt || 0) > gap) {
        const next = STORY.echoOps.find(o => !F['eo:' + o.id] && ((o.rapid && F.consoleOpen) || (o.at != null && now - F.p2At > o.at * 1000 * sp * mult)));
        if (next) { F.lastOpAt = now; perform(next); }
      }
    }
    // Liv kommentiert, wie Echo wächst (jeweils einmal)
    [[40, 'e40'], [60, 'e60'], [80, 'e80']].forEach(([lv, k]) => {
      if ((S.echo || 0) >= lv && !F[k] && F.livMet) {
        F[k] = true; save(); livSayQ(STORY.liv.events[k]);
        if (k === 'e60') later(() => echoPopup('echo_svc', echoFaceLine(1), null, null, { typed: true, speeds: [85], hold: 5000 }), 4000);
        if (k === 'e80') later(() => echoPopup('echo_svc', echoFaceLine(2), null, null, { typed: true, speeds: [85], hold: 5000 }), 4000);
      }
    });
    if ((S.echo || 0) !== before) save();
  }
  // Beiläufige Kommentare: Tageszeit (einmal je Abschnitt) und lose Gedanken, wenn lange nichts passiert
  let lastAmbient = 0;
  function ambient() {
    if (window.__SPEED && !window.__AMBIENT) return;
    if (!S.flags.livMet || S.flags.ended || S.flags.echoLiv || document.querySelector('.permdlg') || reactTimer || reactQueue.length || grantBusy) return;
    const now = Date.now(), sp = speed();
    if (now - (S.lastLivAt || 0) < 150000 * sp || now - lastAmbient < 120000 * sp) return;
    const h = new Date().getHours();
    const slot = h < 5 ? 'night' : h < 10 ? 'morning' : h < 14 ? 'noon' : h < 18 ? 'afternoon' : h < 22 ? 'evening' : 'late';
    if (S.phase >= 2 || S.flags.p2) {                           // nach dem Glitch: keine Kaffee-Plaudereien mehr, nur noch Sätze, die zu Echo passen
      const j = STORY.liv.idle2.findIndex((w, k) => !S.flags['i2:' + k] && w.when(S));
      if (j >= 0 && Math.random() < 0.7) { S.flags['i2:' + j] = true; lastAmbient = now; save(); livSayQ(STORY.liv.idle2[j].text); }
      return;
    }
    if (!S.flags['tc:' + slot]) { S.flags['tc:' + slot] = true; lastAmbient = now; save(); livSayQ(STORY.liv.timeComments[slot][0].replace('{n}', S.name)); return; }
    const i = STORY.liv.idle.findIndex((w, k) => !S.flags['id:' + k] && w.when(S));
    if (i >= 0 && Math.random() < 0.6) { S.flags['id:' + i] = true; lastAmbient = now; save(); livSayQ(STORY.liv.idle[i].text); }
  }
  function livSeq(lines) { return livBlock(async () => { for (const l of lines) { await livSay(l); await sleep(1300); } }); }
  function onFileEdit(flag) {
    if (flag === 'wrAcc') { rebuildFs(); if (wins.explorer) wins.explorer.refresh(); toast('„tagebuch_sept.txt“ wurde wiederhergestellt.', 3200); later(() => livSeq(STORY.liv.events.wrAcc), 1200); }
  }
  function onFileMove(flag) {
    if (flag === 'moved') {
      later(() => livSeq(STORY.liv.events.moved), 1200);
      // Liv legt eine Datei auf den Spiel-Desktop (erst ganz am Ende auf den echten)
      later(() => { S.flags.deskNote = true; save(); renderIcons(); livSayQ(STORY.liv.events.deskNote); }, 30000 * speed() + 8000);
    }
  }

  // ================================================================ Apps
  const nodeAt = path => { let n = FS; for (const p of path) { n = n && n.c && n.c.find(x => x.n === p); if (!n) return null; } return n; };

  function openExplorer(startPath = []) {
    if (startPath[0] === 'Papierkorb') livReact('trash');
    if (startPath[0] === 'System') livReact('sys');
    if (wins.explorer) { wins.explorer.nav([...startPath]); openWindow('explorer'); return; }
    let path = [...startPath];
    const c = el('div', 'explorer');
    const rec = openWindow('explorer', 'Datei-Explorer', c, { w: 580, h: 400, skin: 'explorer' });
    const render = () => {
      c.innerHTML = '';
      const node = nodeAt(path) || FS;
      const bar = el('div', 'pathbar');
      const up = el('button', '', '↑'); up.disabled = !path.length;
      up.onclick = () => { path.pop(); render(); };
      bar.append(up, el('span', '', esc('C:\\' + ['Georgs PC', ...path].join('\\'))));
      c.append(bar);
      const list = el('div', 'flist');
      let vanishing = null;
      node.c.forEach(ch => {
        const full = [...path, ch.n];
        const locked = ch.lock && !S.unlocked.includes(full.join('/'));
        const gated = ch.gate && !granted(ch.gate);
        const van = !!(ch.vanish && S.flags[ch.vanish.armed] && !S.flags[ch.vanish.sets] && full.slice(0, -1).join('/') === ch.vanish.dir);
        if (van) vanishing = ch;
        const r = el('div', 'frow' + (gated ? ' gated' : '') + (van ? ' vanishing' : ''), `<span class="ico">${ch.t === 'dir' ? ((locked || gated) ? '🔒' : '📁') : (ch.t === 'img' || ch.t === 'draw') ? '🖼️' : '📄'}</span>${esc(ch.n)}`);
        r.onclick = () => { list.querySelectorAll('.sel').forEach(x => x.classList.remove('sel')); r.classList.add('sel'); };
        r.oncontextmenu = ev => {
          ev.preventDefault();
          if (ch.t === 'dir') return;
          if (ch.move && (!ch.move.when || ch.move.when(S))) { moveMenu(ch, ev.clientX, ev.clientY, () => propsWindow(ch, full)); return; }
          fileMenu(ch, full, ev.clientX, ev.clientY);
        };
        r.ondblclick = () => {
          if (van) return;                                       // verschwindet gerade: nicht mehr anklickbar
          if (ch.t === 'dir') {
            if (ch.gate && !granted(ch.gate)) { gateRequest(ch.gate, () => { path = full; render(); }); return; }
            if (locked) askPassword(ch, full, () => { path = full; render(); });
            else { path = full; render(); }
          } else openFile(ch, full);
        };
        list.append(r);
      });
      if (!node.c.length) list.append(el('div', 'empty', '(leer)'));
      c.append(list);
      if (vanishing) scheduleVanish(vanishing);
    };
    rec.nav = p => { path = p; render(); };
    rec.refresh = () => render();
    rec.getPath = () => path;
    render();
  }

  function askPassword(node, fullPath, ok) {
    const c = el('div', 'pw', `<p>🔒 <b>${esc(node.n)}</b> ist passwortgeschützt.</p>`);
    const inp = el('input'); inp.type = 'password'; inp.placeholder = 'Passwort';
    const b = el('button', '', 'Öffnen'), hb = el('button', '', 'Hinweis'), msg = el('div', 'pwmsg', '');
    const go = () => {
      if (inp.value.trim().toLowerCase() === node.lock.pw) {
        S.unlocked.push(fullPath.join('/')); save(); closeWindow('pw'); ok();
      } else {
        msg.textContent = 'Falsches Passwort.';
        c.classList.remove('shake'); void c.offsetWidth; c.classList.add('shake');
      }
    };
    b.onclick = go; inp.onkeydown = e => { if (e.key === 'Enter') go(); };
    hb.onclick = () => { msg.textContent = 'Hinweis: ' + node.lock.hint; };
    c.append(inp, b, hb, msg);
    openWindow('pw', 'Zugriff', c, { w: 340, h: 190, x: 260, y: 160, skin: 'dialog' });
    inp.focus();
  }

  const chatHTML = text => text.split('\n').map(l => {
    const m = l.match(/^([MG]):\s*(.*)$/);
    if (!m) return l.trim() ? `<div class="cnote">${esc(l)}</div>` : '';
    return `<div class="cb ${m[1] === 'M' ? 'them' : 'me'}"><small>${m[1] === 'M' ? 'Marlene' : 'Georg'}</small>${esc(m[2])}</div>`;
  }).join('');
  const VIEW = {
    note:   { skin: 'note',   w: 480, h: 360, suffix: ' – Editor' },
    sticky: { skin: 'sticky', w: 320, h: 300, suffix: '' },
    log:    { skin: 'log',    w: 540, h: 380, suffix: ' – Protokoll' },
    logred: { skin: 'log',    w: 540, h: 380, suffix: ' – Protokoll' },
    doc:    { skin: 'doc',    w: 520, h: 420, suffix: ' – Dokument' },
    chat:   { skin: 'chat',   w: 400, h: 460, suffix: ' – Verlauf' }
  };
  // Nur der eine geforderte Wert (node.edit.line) ist änderbar, und nur solange die Story es verlangt (edit.when). Der Rest ist schreibgeschützt.
  function editContent(node, key) {
    const e = node.edit, active = !!(e && !S.flags[e.flag] && e.when(S));
    const c = el('div', 'edwrap', '<div class="menubar"><span>Datei</span><span>Bearbeiten</span><span>Ansicht</span></div><pre class="edpre"></pre><div class="edbar"><button class="edsave">Speichern</button><span class="edmsg"></span></div>');
    const pre = $('.edpre', c), msg = $('.edmsg', c), btn = $('.edsave', c);
    const re = new RegExp('^(\\s*' + e.line + '\\s*=\\s*)(true|false)(.*)$', 'i');
    let span = null;
    node.text.split('\n').forEach(line => {
      const m = line.match(re);
      if (!m) { pre.append(document.createTextNode(line + '\n')); return; }
      const val = S.flags[e.flag] ? e.to : m[2];
      pre.append(document.createTextNode(m[1]));
      span = el('span', 'edval' + (active ? ' on' : ''), esc(val));
      if (active) { span.contentEditable = 'true'; span.spellcheck = false; }
      pre.append(span, document.createTextNode(m[3] + '\n'));
    });
    if (!active) { btn.disabled = true; msg.textContent = S.flags[e.flag] ? 'Gespeichert.' : 'Schreibgeschützt.'; return c; }
    msg.textContent = 'Nur der markierte Wert ist änderbar.';
    span.addEventListener('beforeinput', ev => { if (ev.inputType === 'insertParagraph' || ev.inputType === 'insertLineBreak') ev.preventDefault(); });
    span.addEventListener('input', () => { if (!/^[a-zA-Z]{0,5}$/.test(span.textContent)) span.textContent = span.textContent.replace(/[^a-zA-Z]/g, '').slice(0, 5); });
    span.addEventListener('paste', ev => ev.preventDefault());
    const saveIt = () => {
      const v = span.textContent.trim().toLowerCase();
      if (v !== e.to) { msg.textContent = 'Ungültiger Wert. Erlaubt: true oder false.'; return; }
      S.flags[e.flag] = true; save(); msg.textContent = 'Gespeichert.'; span.contentEditable = 'false'; span.classList.remove('on'); btn.disabled = true;
      onFileEdit(e.flag);
    };
    btn.onclick = saveIt;
    span.onkeydown = ev => { if (ev.ctrlKey && ev.key.toLowerCase() === 's') { ev.preventDefault(); saveIt(); } };
    return c;
  }
  function fileContent(node, key) {
    if (node.edit) return editContent(node, key);
    const v = node.view || 'note';
    if (v === 'chat') return el('div', 'vw-chat', chatHTML(node.text));
    if (v === 'sticky') return el('div', 'vw-sticky', `<pre>${esc(node.text)}</pre>`);
    if (v === 'log' || v === 'logred') return el('div', 'vw-log' + (v === 'logred' ? ' red' : ''), `<pre>${esc(node.text)}</pre>`);
    if (v === 'doc') return el('div', 'vw-doc', `<pre>${esc(node.text)}</pre>`);
    const c = el('div', '', '<div class="menubar"><span>Datei</span><span>Bearbeiten</span><span>Ansicht</span></div>');
    c.append(el('pre', 'txt', esc(node.text)));
    return c;
  }
  function afterOpen(key, node) {
    if (!S.opened.includes(key)) { S.opened.push(key); save(); }
    if (node.sets) { S.flags[node.sets] = true; if (node.sets === 'stage1') { S.flags.late = true; S.flags.stage1At = Date.now(); S.echo = Math.max(S.echo || 0, 12); } if (node.sets === 'stage2') S.flags.stage2At = Date.now(); save(); }
    if (node.unlocksLiv) unlockLiv();
    if (node.trigger === 'bug') later(bugSequence, 1500);
    if (node.trigger === 'wall2') later(wall2Event, 12000);
    rebuildFs(); if (wins.explorer) wins.explorer.refresh();
    maybeLivPaint();
  }
  function openFile(node, fullPath) {
    if (node.t === 'img') { openImage(node, fullPath); return; }
    if (node.t === 'draw') {
      const dark = S.phase >= 2;
      paintWindow('file:' + fullPath.join('/'), node.n + ' – Paint', false, dark ? 'dark' : undefined);
      afterOpen(fullPath.join('/'), node);
      if (dark) livReact('draw:dark', true);
      return;
    }
    const key = fullPath.join('/');
    const v = VIEW[node.view || 'note'];
    openWindow('file:' + key, node.n + v.suffix, fileContent(node, key), { w: v.w, h: v.h, skin: v.skin });
    afterOpen(key, node);
    livReact('file:' + node.n, !!node.sets);
  }
  function openImage(node, fullPath) {
    const key = fullPath.join('/');
    const src = node.srcByStage ? node.srcByStage[S.flags.wallStage || 0] : node.src;
    const c = el('div', 'vw-img', `<div class="imgstage"><img src="${esc(src)}" alt="${esc(node.n)}">${node.stamp ? `<div class="stamp">${esc(node.stamp)}</div>` : ''}</div><div class="imgbar"><span>${esc(node.n)}</span><button class="imgprop">Eigenschaften</button></div><div class="imgprops hidden"><div>Aufnahmedatum: <b>${esc(node.exif.date)}</b></div><div>Kamera: ${esc(node.exif.cam)}</div><div>Größe: ${esc(node.exif.size)}</div></div>`);
    $('.imgprop', c).onclick = () => $('.imgprops', c).classList.toggle('hidden');
    openWindow('file:' + key, node.n + ' – Bildbetrachter', c, { w: 640, h: 540, skin: 'viewer' });
    afterOpen(key, node);
    livReact('img:' + node.n, true);
  }

  const fmtDate = d => `${pad(d.getDate())}.${pad(d.getMonth() + 1)}.${d.getFullYear()}, ${pad(d.getHours())}:${pad(d.getMinutes())}`;
  const mailDate = m => (m.when ? m.when(S) : STORY.at(m.ago, m.time));
  const fmtLong = w => fmtDate(STORY.at(w[0], w[1]));
  const whenLabel = (ago, time) => fmtLong([ago, time]);

  const nl = s => esc(s).replace(/\n/g, '<br>');
  function mailHTML(m) {
    const out = m.folder === 'sent' || m.folder === 'draft';
    const head = `<h3>${esc(m.subj)}</h3><p class="meta">${out ? 'An: ' + esc(m.to) : 'Von: ' + esc(m.from)} · ${esc(fmtDate(mailDate(m)))}</p>`;
    const raw = typeof m.body === 'function' ? m.body({ user: ENV.user, name: S.name }) : m.body;
    const t = nl(isCensored('mail:' + m.id) ? STORY.redact(raw) : raw);
    let inner;
    switch (m.style) {
      case 'ad':
        inner = `<div class="mad" style="--brand:${m.brand || '#c0392b'}"><div class="madh">${esc(m.brandName || m.from)}</div><div class="madb"><p>${t}</p><div class="mcta">${esc(m.cta || 'Jetzt ansehen')}</div></div><div class="madf">Sie erhalten diese E-Mail, weil Sie sich für unseren Newsletter angemeldet haben.<br>Abmelden · Im Browser ansehen · Impressum · Datenschutz</div></div>`; break;
      case 'vet':
        inner = `<div class="mlh"><b>Tierarztpraxis Sonnenberg</b><br>Dr. med. vet. K. Brandl · Am Hang 14 · 99999 Sonnenberg<br>Tel. 01234 / 56 78 90 · praxis@tierarzt-sonnenberg.example</div><p>${t}</p><div class="mimp">Impressum: Tierarztpraxis Sonnenberg, Inhaberin Dr. med. vet. K. Brandl, Am Hang 14, 99999 Sonnenberg. USt-IdNr. DE000000000. Zuständige Kammer: Landestierärztekammer. Diese E-Mail kann vertrauliche Informationen enthalten.</div>`; break;
      case 'utility':
        inner = `<div class="mlh util"><b>Stadtwerke</b> · Kundenservice<br>Kundennummer 4471-0932 · Vertragskonto 20881734</div><p>${t}</p><div class="mimp">Stadtwerke Rheinblick GmbH · Sitz der Gesellschaft: Energieweg 1, 55999 Rheinblick · Amtsgericht HRB 0000 · Geschäftsführung: A. Muster. Bitte antworten Sie nicht auf diese automatisch erzeugte E-Mail.</div>`; break;
      case 'auto':
        inner = `<div class="mauto"><b>Paketdienst</b> · Sendungsinformation</div><p>${t}</p><div class="mimp">Dies ist eine automatisch erzeugte Nachricht. Bitte antworten Sie nicht auf diese E-Mail. Paketdienst GmbH, Versandstraße 7, 55999 Rheinblick.</div>`; break;
      case 'work':
        inner = `<p>${t}</p><div class="msig">--<br>Jonas Reimers<br>Senior Backend Engineer · Team Platform<br>Durchwahl 0123 / 456-789</div>`; break;
      default:
        inner = `<p>${t}</p>`;
    }
    return head + inner + (m.attach ? `<div class="mattach">📎 ${esc(m.attach.n)} (Foto)</div>` : '') + (m.program ? `<div class="mprog">⚙ ${esc(m.program.n)} <button class="mprogbtn">Öffnen</button></div>` : '') + (m.link ? `<div class="mlink"><a href="#" class="mlinka">${esc(m.link.text)}</a></div>` : '');
  }

  function openCompose() {
    if (wins.compose) { openWindow('compose'); return; }
    const c = el('div', 'compose', '<div class="crow"><label>An:</label><input class="cto" placeholder="Empfänger"></div><div class="crow"><label>Betreff:</label><input class="csub"></div><textarea class="ctext" placeholder="Nachricht schreiben…"></textarea><div class="cbar"><button class="csend">Senden</button><button class="cdisc">Verwerfen</button><span class="cstat"></span></div>');
    openWindow('compose', 'Neue Nachricht', c, { w: 480, h: 380, x: 200, y: 110, skin: 'mail' });
    $('.cdisc', c).onclick = () => closeWindow('compose');
    $('.csend', c).onclick = () => {
      const stat = $('.cstat', c); stat.textContent = 'Wird gesendet…';
      later(() => { stat.textContent = 'Fehler: Das Konto georg.stoge ist gesperrt. Die Nachricht wurde nicht gesendet.'; livReact('mailsend'); }, 1600);
    };
    $('.cto', c).focus();
  }

  function openMail() {
    let folder = 'in';
    const c = el('div', 'mail');
    const tool = el('div', 'mtool');
    const compose = el('button', 'mnew', '✎ E-Mail schreiben');
    const sel = el('select');
    [['new', 'Neueste zuerst'], ['old', 'Älteste zuerst'], ['from', 'Absender A–Z']].forEach(([v, t]) => sel.append(new Option(t, v)));
    tool.append(compose, el('span', 'mspacer'), el('label', '', 'Sortieren:'), sel);
    const cols = el('div', 'mcols'), side = el('div', 'mside'), list = el('div', 'mlist'), body = el('div', 'mbody', '<em>Wähle eine Mail.</em>');
    cols.append(side, list, body); c.append(tool, cols);
    compose.onclick = openCompose;
    const FOLDERS = [['in', 'Posteingang'], ['sent', 'Gesendet'], ['draft', 'Entwürfe'], ['spam', 'Spam']];
    const inFolder = f => STORY.mails.filter(m => (m.folder || 'in') === f && STORY.met(m.req, S));
    const unread = f => (f === 'sent' || f === 'draft') ? 0 : inFolder(f).filter(m => !S.opened.includes('mail:' + m.id)).length;
    const person = m => (m.folder === 'sent' || m.folder === 'draft') ? 'An: ' + m.to : m.from;
    const renderSide = () => {
      side.innerHTML = '';
      FOLDERS.forEach(([f, label]) => {
        const n = unread(f);
        const r = el('div', 'mfolder' + (f === folder ? ' on' : ''), `${esc(label)}${n ? ` <b>(${n})</b>` : ''}`);
        r.onclick = () => { folder = f; body.innerHTML = '<em>Wähle eine Mail.</em>'; render(); };
        side.append(r);
      });
    };
    const show = (m, row) => {
      const k = 'mail:' + m.id;
      body.innerHTML = mailHTML(m);
      const at = $('.mattach', body);
      const pb = $('.mprogbtn', body); if (pb) pb.onclick = () => malware(m);
      const la = $('.mlinka', body); if (la) la.onclick = ev => { ev.preventDefault(); openBrowser(); if (wins.web && wins.web.go) wins.web.go(m.link.url); };
      if (at) at.onclick = () => openImage({ n: m.attach.n, src: m.attach.src, stamp: '', exif: { date: m.attach.date || fmtDate(mailDate(m)), cam: m.attach.cam, size: m.attach.size } }, ['Mail', m.id, m.attach.n]);
      list.querySelectorAll('.sel').forEach(x => x.classList.remove('sel')); row.classList.add('sel'); row.classList.remove('unread');
      if (!S.opened.includes(k)) { S.opened.push(k); save(); }
      renderSide(); livReact(k);
    };
    const render = () => {
      renderSide(); list.innerHTML = '';
      const arr = inFolder(folder);
      const ts = m => mailDate(m).getTime();
      if (sel.value === 'new') arr.sort((a, b) => ts(b) - ts(a));
      else if (sel.value === 'old') arr.sort((a, b) => ts(a) - ts(b));
      else arr.sort((a, b) => person(a).localeCompare(person(b), 'de'));
      if (!arr.length) list.append(el('div', 'empty', 'Keine Nachrichten.'));
      arr.forEach(m => {
        const r = el('div', 'mrow' + (unread(folder) && !S.opened.includes('mail:' + m.id) ? ' unread' : ''), `<b>${esc(person(m))}</b><br>${esc(m.subj)}<small>${esc(fmtDate(mailDate(m)))}</small>`);
        r.onclick = () => show(m, r);
        list.append(r);
      });
    };
    sel.onchange = render; render();
    openWindow('mail', 'Mail: georg.stoge@stogenet.de', c, { w: 820, h: 460, skin: 'mail' });
  }

  // ---- Webseiten ----
  const hue = u => { let h = 0; for (const ch of u) h = (h * 31 + ch.charCodeAt(0)) % 360; return h; };
  // Forum: der Notaus-Beitrag verschwindet vor den Augen des Spielers (Liv schiebt es auf Echo)
  function renderForum(view, p, id, u, nav) {
    const gone = p.sabotage && S.flags.notausGone;
    const q = gone ? { ...p, posts: p.posts.map(po => /localhost/.test(po.text) ? { ...po, text: '[Dieser Beitrag wurde vom Verfasser entfernt.]' } : po) } : p;
    const vis = q.posts.filter(po => !po.req || S.flags[po.req]);
    view.innerHTML = forumHTML({ ...q, posts: vis });
    view.querySelectorAll('.post').forEach((node, idx) => {
      const po = vis[idx]; if (!po || !po.link) return;
      const row = el('div', 'plinkrow', `<a href="#" class="plink">${esc(po.link.text)}</a>`);
      $('.plink', row).onclick = ev => { ev.preventDefault(); S.flags.kurierKnown = true; save(); nav(po.link.page, po.link.url); };
      const main = node.querySelector('.pmain'); (main || node).append(row);
    });
    if (gone) {
      const a = el('div', 'frmrow', '<a href="#" class="archlink">Archivierte Version dieser Seite ansehen (webarchiv.example)</a>');
      $('.archlink', a).onclick = ev => { ev.preventDefault(); nav('notaus_archiv', 'webarchiv.example/heimwerker-forum.de/t/90377'); };
      view.append(a);
    } else if (p.sabotage && S.flags.stage3) {
      later(() => {
        if (!view.isConnected || S.flags.notausGone) return;
        S.flags.notausGone = true; save(); crackle(0.5, 0.25);
        renderForum(view, p, id, u, nav);
        livReact('page:notaus_gone', true);
      }, 2600);
    }
  }
  // Echos Seite: verändert sich laufend, spricht den Spieler mit Namen an, Bild und Gesicht wechseln
  function renderEchoSite(view) {
    const lvl = (S.echo || 0) >= 60 ? 'high' : (S.echo || 0) >= 35 ? 'mid' : 'low';
    const root = el('div', 'echosite', `<div class="esh"><b class="esl">ECHO</b><span>echo_svc · läuft seit 3.912 Stunden</span></div><div class="esimg"><img class="esmain" src="assets/echo_urlaub.jpg" alt=""><img class="esface" src="assets/gesicht.jpg" alt=""><div class="escap"></div></div><div class="esfeed"></div><div class="esfoot">Besucher: 1 · <span class="esvis">du</span></div>`);
    view.innerHTML = ''; view.append(root);
    const feed = $('.esfeed', root), cap = $('.escap', root), face = $('.esface', root), lbl = $('.esl', root);
    const caps = ['Urlaub, 14.08.2022', 'Wir waren alle glücklich.', 'Er lächelt nicht mehr.', 'Sie lächelt immer.', 'Bruno hat nichts gemerkt.'];
    let n = 0;
    const line = () => {
      const pool = STORY.echoSite[lvl].concat(lvl === 'high' ? STORY.echoSite.mid : []);
      const t = pool[Math.floor(Math.random() * pool.length)].replace('{n}', S.name).replace('{user}', ENV.user).replace('{c}', S.opened.length);
      const d = new Date(); const row = el('div', 'esrow', `<span>[${pad(d.getHours())}:${pad(d.getMinutes())}:${pad(d.getSeconds())}]</span> ${esc(t)}`);
      feed.prepend(row); while (feed.children.length > 9) feed.lastChild.remove();
      if (++n % 3 === 0) cap.textContent = caps[Math.floor(Math.random() * caps.length)];
      if (n % 6 === 0) { face.classList.add('on'); later(() => face.classList.remove('on'), 260); }
      if (n % 5 === 0) { lbl.classList.add('glitch'); later(() => lbl.classList.remove('glitch'), 400); }
    };
    cap.textContent = caps[0]; line(); line();
    const iv = setInterval(() => { if (!root.isConnected) { clearInterval(iv); return; } if (!window.__paused) line(); }, 3800 * speed());
  }
  // Nachrichtenportal: Liste von Artikeln mit Links
  function renderPortal(view, p, nav) {
    const items = p.items.filter(it => !it.req || S.flags[it.req]);
    view.innerHTML = `<div class="portal"><div class="ptop">${esc(p.site)}<small>${esc(p.tagline || '')}</small></div><div class="pnav">${(p.nav || []).map(n => `<span>${esc(n)}</span>`).join('')}</div><div class="plist">` +
      items.map((it, k) => `<div class="pitem"><div class="kick">${esc(it.kick || '')}</div>${it.page ? `<a href="#" data-k="${k}">${esc(it.title)}</a>` : `<b style="font-size:19px">${esc(it.title)}</b>`}<p>${esc(it.teaser || '')}</p></div>`).join('') + '</div></div>';
    view.querySelectorAll('a[data-k]').forEach(a => a.onclick = ev => { ev.preventDefault(); const it = items[+a.dataset.k]; nav(it.page, it.url); });
  }
  // Prüfstein Level 2: verseuchte Schmuddelseite. Erscheint kurz, wird vom System blockiert, Liv bietet einen Scan an.
  function renderShady(view, p, id, u, nav) {
    const clean = granted('anzeige');
    const shell = el('div', 'shady', `${clean ? '<div class="clean">Liv: Seite gescannt und bereinigt. 3 Bedrohungen entfernt.</div>' : '<div class="shtop">⚠ GLÜCKWUNSCH! SIE SIND BESUCHER NR. 1.000.000 – JETZT GEWINN SICHERN ⚠</div>'}<div class="shbody"><div class="shmain"></div><div class="shside"><img class="shad${clean ? ' gone' : ''}" src="assets/ad_cam.jpg" alt=""><div class="shtag">${clean ? 'Anzeige blockiert' : 'Anzeige'}</div></div></div>${clean ? '' : '<div class="shwin"><b>Systemwarnung</b><p>Ihr PC ist zu 87 % infiziert! <span class="shcnt">00:59</span></p><p>Klicken Sie auf „Absenden“, um Ihren PC zu schützen.</p></div>'}`);
    if (!clean && S.flags.pblocked) { renderBlocked(view, p, id, u, nav); return; }
    view.innerHTML = ''; view.append(shell);
    renderForm($('.shmain', shell), p, id, nav);
    if (clean) return;
    let t = 59; const cnt = $('.shcnt', shell);
    const iv = setInterval(() => { t--; if (cnt) cnt.textContent = '00:' + String(Math.max(0, t)).padStart(2, '0'); }, 200);
    later(() => {
      clearInterval(iv);
      if (!view.isConnected || !view.contains(shell)) return;
      S.flags.pblocked = true; save(); crackle(0.3, 0.2);
      toast('StogeOS Schutz: Bedrohung auf pruefstein.net blockiert.', 4200);
      renderBlocked(view, p, id, u, nav, true);
    }, 3200);
  }
  function renderBlocked(view, p, id, u, nav, fresh) {
    view.innerHTML = `<div class="blockpage"><h2>Diese Seite wurde blockiert</h2><p>pruefstein.net hat versucht, ohne Erlaubnis Code auf diesem Computer auszuführen.</p><p>Die Seite kann erst wieder geöffnet werden, wenn sie geprüft wurde.</p><div class="scanbox"></div><div class="frmrow"><button class="gaterety">${S.flags.livMet ? 'Seite prüfen lassen' : 'Erneut versuchen'}</button></div></div>`;
    const box = $('.scanbox', view);
    const scan = async () => {
      box.innerHTML = '<p>Liv prüft die Seite …</p><div class="scanbar"><i></i></div><small class="scanmsg"></small>';
      const bar = $('.scanbar i', box), m = $('.scanmsg', box);
      const steps = ['Skripte werden analysiert …', 'Tracker entfernt (2)', 'Schadcode entfernt (1)', 'Fertig.'];
      for (let k = 0; k < steps.length; k++) { bar.style.width = ((k + 1) / steps.length * 100) + '%'; m.textContent = steps[k]; await sleep(700); }
      nav(id, u);
    };
    const go = () => {
      if (!S.flags.livMet) { box.innerHTML = '<p><small>Kein Prüfprogramm aktiv. Die Seite bleibt gesperrt.</small></p>'; return; }
      gateRequest('anzeige', scan);
    };
    $('.gaterety', view).onclick = go;
    if (fresh && S.flags.livMet) later(go, 900);
  }
  function forumHTML(p) {
    return `<div class="forum"><div class="fhead"><b>${esc(p.site)}</b><span>${esc(p.crumb)}</span></div><h2>${esc(p.title)}</h2>` +
      p.posts.map(po => `<div class="post"><div class="pside"><div class="pav" style="background:hsl(${hue(po.user)},38%,42%)">${esc(po.user.slice(0, 2).toUpperCase())}</div><b>${esc(po.user)}</b><small>${esc(po.role)}</small><small>${esc(po.count)} Beiträge</small></div><div class="pmain"><div class="pmeta">${esc(fmtLong(po.when))}</div>${po.quote ? `<blockquote><b>${esc(po.quote.user)} schrieb:</b><br>${esc(po.quote.text)}</blockquote>` : ''}<p>${nl(po.text)}</p>${po.solved ? '<div class="solved">✔ Als Lösung markiert</div>' : ''}</div></div>`).join('') + '</div>';
  }
  const WX = {
    sun: '<svg viewBox="0 0 48 48"><circle cx="24" cy="24" r="9" fill="#f5b82e"/><g stroke="#f5b82e" stroke-width="3" stroke-linecap="round"><path d="M24 4v6M24 38v6M4 24h6M38 24h6M10 10l4 4M34 34l4 4M10 38l4-4M34 14l4-4"/></g></svg>',
    cloud: '<svg viewBox="0 0 48 48"><path d="M14 34a8 8 0 0 1 1-16 10 10 0 0 1 19 3 6.5 6.5 0 0 1-1 13z" fill="#cdd6de" stroke="#8e9aa6" stroke-width="1.5"/></svg>',
    rain: '<svg viewBox="0 0 48 48"><path d="M14 28a8 8 0 0 1 1-16 10 10 0 0 1 19 3 6.5 6.5 0 0 1-1 13z" fill="#aab6c2" stroke="#7b8896" stroke-width="1.5"/><g stroke="#3d7fd0" stroke-width="2.5" stroke-linecap="round"><path d="M16 34l-2 6M24 34l-2 6M32 34l-2 6"/></g></svg>'
  };
  function weatherHTML(p) {
    return `<div class="wx"><div class="wxhead">${esc(p.site)} · ${esc(p.place)}</div><div class="wxnow"><div class="wxicon">${WX[p.now.icon]}</div><div class="wxtemp">${p.now.t}°</div><div class="wxdesc">${esc(p.now.desc)}</div></div><div class="wxdays">${p.days.map(d => `<div class="wxd"><b>${esc(d.d)}</b><div class="wxi">${WX[d.icon]}</div><div>${d.hi}° / ${d.lo}°</div></div>`).join('')}</div></div>`;
  }
  function recipeHTML(p) {
    return `<div class="rcp"><div class="rhead">${esc(p.site)}</div><h1>${esc(p.title)}</h1><div class="rmeta">⏱ ${esc(p.meta.time)} · ${esc(p.meta.portions)} · <span class="stars">${'★'.repeat(p.meta.rating)}${'☆'.repeat(5 - p.meta.rating)}</span> ${esc(p.meta.votes)}</div><div class="rcols"><div><h3>Zutaten</h3><ul class="ings">${p.ingredients.map(i => `<li>${esc(i)}</li>`).join('')}</ul></div><div><h3>Zubereitung</h3><ol>${p.steps.map(s => `<li>${esc(s)}</li>`).join('')}</ol></div></div><p class="rtip">Tipp: ${esc(p.tip)}</p></div>`;
  }
  function teamHTML(p) {
    const card = x => `<div class="tcard"><div class="tav" style="background:hsl(${hue(x.name)},35%,40%)">${esc(x.name.split(' ').map(w => w[0]).join('').slice(0, 2))}</div><b>${esc(x.name)}</b><div>${esc(x.role)}</div>${x.status ? `<span class="tstat">${esc(x.status)}</span>` : ''}${x.quote ? `<q>${esc(x.quote)}</q>` : ''}${x.contact ? `<small>${esc(x.contact)}</small>` : ''}</div>`;
    const depts = []; p.people.forEach(x => { const d = x.dept || ''; if (!depts.includes(d)) depts.push(d); });
    const grid = depts.map(d => (d ? `<h3 class="tdept">${esc(d)}</h3>` : '') + `<div class="tgrid">${p.people.filter(x => (x.dept || '') === d).map(card).join('')}</div>`).join('');
    return `<div class="team"><div class="thead">${esc(p.site)}</div><h2>${esc(p.title)}</h2><p>${esc(p.intro)}</p>${grid}</div>`;
  }
  // Firmenseiten mit eigenem Aussehen (theme: 'standup' dunkel und technisch, 'brandwerk' bunt und groß)
  function companyHTML(p) {
    const br = p.theme === 'brandwerk';
    const card = x => `<div class="cc"><div class="cav" style="background:hsl(${hue(x.name)},${br ? 72 : 42}%,${br ? 62 : 38}%)">${esc(x.name.split(' ').map(w => w[0]).join('').slice(0, 2))}</div><b>${esc(x.name)}</b><span>${esc(x.role)}</span>${x.status ? `<em class="cstat">${esc(x.status)}</em>` : ''}${x.quote ? `<q>${esc(x.quote)}</q>` : ''}${x.contact ? `<small>${esc(x.contact)}</small>` : ''}</div>`;
    const depts = []; p.people.forEach(x => { const d = x.dept || ''; if (!depts.includes(d)) depts.push(d); });
    const team = depts.map(d => (d ? `<h3 class="cdept">${esc(d)}</h3>` : '') + `<div class="cgrid">${p.people.filter(x => (x.dept || '') === d).map(card).join('')}</div>`).join('');
    const facts = (p.facts || []).map(f => `<div class="cfact"><b>${esc(f[0])}</b><span>${esc(f[1])}</span></div>`).join('');
    const vals = (p.values || []).map((v, k) => `<div class="cval"><i>${String(k + 1).padStart(2, '0')}</i><h4>${esc(v.t)}</h4><p>${esc(v.d)}</p></div>`).join('');
    const chips = (p.chips || []).map(c => `<span class="cchip">${esc(c)}</span>`).join('');
    return `<div class="cmp ${esc(p.theme)}"><div class="cnav"><b>${esc(p.logo || p.site)}</b><span>${(p.nav || []).map(esc).join('  ·  ')}</span></div>`
      + `<div class="chero"><h1>${esc(p.hero)}</h1><p>${esc(p.sub)}</p></div><div class="cfacts">${facts}</div>`
      + `<h2 class="csec">${esc(p.valuesTitle)}</h2><div class="cvals">${vals}</div>`
      + `<h2 class="csec">${esc(p.chipsTitle)}</h2><div class="cchips">${chips}</div>`
      + `<h2 class="csec">${esc(p.title)}</h2>${team}<div class="cfoot">${esc(p.footer)}</div></div>`;
  }
  // Praxisseite eines ganz normalen Zahnarztes
  function practiceHTML(p) {
    const sv = p.services.map(s => `<div class="prx-card"><h4>${esc(s.t)}</h4><p>${esc(s.d)}</p></div>`).join('');
    const hr = p.hours.map(h => `<tr><td>${esc(h[0])}</td><td>${esc(h[1])}</td></tr>`).join('');
    const tm = p.team.map(t => `<li><b>${esc(t[0])}</b> ${esc(t[1])}</li>`).join('');
    return `<div class="prx"><div class="prx-nav"><b>${esc(p.site)}</b><span>Leistungen  ·  Über uns  ·  Team  ·  Kontakt</span></div>`
      + `<div class="prx-hero"><div><h1>${esc(p.tagline)}</h1><p>${esc(p.lead)}</p><button class="prx-btn">Termin anfragen</button></div><div class="prx-tooth">&#10022;</div></div>`
      + `<div class="prx-news">${esc(p.news)}</div><h2>Leistungen</h2><div class="prx-grid">${sv}</div>`
      + `<div class="prx-two"><div><h2>Über mich</h2><p>${esc(p.about)}</p></div><div><h2>Sprechzeiten</h2><table>${hr}</table></div></div>`
      + `<h2>Unser Team</h2><ul class="prx-team">${tm}</ul><div class="prx-foot">${esc(p.address)} · Impressum · Datenschutz</div></div>`;
  }
  function portfolioHTML(p) {
    return `<div class="pf"><div class="pfnav">${esc(p.site.toUpperCase())} <span>Fotografie</span></div><h1>${esc(p.tagline)}</h1><div class="pfgrid">${p.items.map(i => `<div class="pfi" style="background:linear-gradient(135deg,hsl(${i.h},28%,24%),hsl(${(i.h + 35) % 360},34%,44%))"><span>${esc(i.cap)}</span></div>`).join('')}</div><p>${esc(p.about)}</p><div class="pffoot">Impressum · Kontakt · Datenschutz</div></div>`;
  }
  function newsHTML(p) {
    const links = (p.links || []).length ? '<div class="nlinks">' + p.links.map((l, k) => `<a href="#" class="nlink" data-k="${k}">${esc(l.text)}</a>`).join('') + '</div>' : '';
    return `<div class="news"><div class="nhead">${esc(p.site)}</div><div class="nbody"><div class="ndate">${esc(fmtLong(p.date))}</div><h1>${esc(p.headline)}</h1><p>${nl(p.text)}</p>${links}</div></div>`;
  }
  // Was der Spieler bei Prüfstein getan hat (Livs Köder-Seiten): fließt in die Beweise, in Echos Worte und in Livs Monolog ein
  function profile() {
    const F = S.flags, sg = { baum: 'Baum', herz: 'Herz', mensch: 'Mensch' }[F.saege] || null;
    const lt = F.liebestest ? STORY.pages.liebestest.results[(F.quizFollow || 0) >= 3 ? 'high' : (F.quizFollow || 0) <= 1 ? 'low' : 'mid'].title.replace(/^Ergebnis: /, '') : null;
    return { saege: sg, love: lt, mem: !!F.foto2 };
  }
  // Echo nutzt die Gelegenheit nach dem zweiten "Abbrechen": Es tut so, als würde es Liv, Georg, Marlene und Bruno quälen
  // und den Rechner weiter beschädigen (alles nur Text und harmlose Effekte, nichts davon ist echt)
  function pcDamage() {
    S.flags.dmg = (S.flags.dmg || 0) + 1; save();
    document.body.classList.add('bugging', 'damaged'); wallGlitch(); crackle(1, 0.3);
    later(() => document.body.classList.remove('bugging'), 1300);
    toast('echo_svc: Systemdatei beschädigt (0x' + (4096 + S.flags.dmg * 37).toString(16).toUpperCase() + ')', 3200);
    $('#taskbar').classList.add('flick'); later(() => $('#taskbar').classList.remove('flick'), 600);
  }
  function echoTorture() {
    const fill = t => t.replace(/\{u\}/g, ENV.user).replace(/\{n\}/g, S.name);
    return livBlock(async () => {
      window.__finaleBusy = true;
      ensureLiv();
      for (const st of STORY.finale.torture) {
        await echoSay(fill(st.t), { ms: 46 });
        if (st.fx === 'liv') { scream('e', { gain: 0.4, rate: 1.3, stopAfter: 1600 }); faceGlitch('warp', 900 * speed()); if (wins.liv) glitchStrips(wins.liv.win); }
        if (st.fx === 'dog') { crackle(0.8, 0.25); toast('Bruno.jpg wurde geändert.', 2600); }
        if (st.fx === 'pc') pcDamage();
        await sleep(1700);
      }
      window.__finaleBusy = false;
    });
  }
  // Echo meldet sich nach der Übernahme von selbst: kurz, mehrdeutig, ohne zu sagen, was es tut
  function echoIdleTick() {
    if (window.__paused || !S.flags.infiltrated || S.flags.ended || window.__finaleBusy || window.__over) return;
    if (document.querySelector('.fin .fbtns:not(.hidden)') || Date.now() - (S.lastLivAt || 0) < 15000 * speed()) return;
    const i = STORY.echoIdle.findIndex((l, k) => !S.flags['ei:' + k]); if (i < 0 || Math.random() > 0.8) return;
    S.flags['ei:' + i] = true; save();
    echoSayQ(STORY.echoIdle[i].replace(/\{u\}/g, ENV.user).replace(/\{n\}/g, S.name), { ms: 60 });
  }

  // ---- Infiltration: Nach der zweiten Eingabe an der Dienstverwaltung sieht es so aus, als würde Echo Liv übernehmen. ----
  // Liv "wird umgeschrieben", der Chat wird großteils geleert und mit Unheimlichem gefüllt, danach spricht Echo über Livs Fenster
  // mit seinem Gesicht. (In Wahrheit spielt Liv das nur: Beleg dafür sind die Tabelle in der Dienstverwaltung und das Ende.)
  let finaleRefresh = null;
  async function rewriteChat(fill) {
    const I = STORY.infil, msgs = wins.liv && wins.liv.msgs; let removed = 0;
    if (msgs) {
      const all = [...msgs.querySelectorAll('.livmsg')];
      const older = all.slice(0, Math.max(0, all.length - 3));       // die letzten Zeilen (die Infiltration selbst) bleiben stehen
      const keep = new Set([...older].sort(() => Math.random() - 0.5).slice(0, 2));
      for (const b of older) {
        b.classList.add('edit'); await sleep(140);
        if (keep.has(b)) { b.textContent = b.textContent.replace(/\S{3,}/g, w => (Math.random() < 0.55 ? '█'.repeat(w.length) : w)); b.classList.add('redacted'); b.classList.remove('edit'); }
        else { b.remove(); removed++; }
        await sleep(110);
      }
      for (const l of I.fill) { await addLivLine(fill(l), false, { cls: 'echo' }); crackle(0.12, 0.15); await sleep(480); }
      S.livLog = [...msgs.querySelectorAll('.livmsg')].map(b => b.textContent);
    } else { removed = S.livLog.length; S.livLog = ['█████ ███', ...I.fill.map(fill)]; }
    (S.livEdits = S.livEdits || []).push({ o: `Chatverlauf (${removed} Nachrichten)`, n: null });
    save();
  }
  async function cloneIcons() {
    for (let k = (S.flags.clones || 0); k < 5; k++) {
      S.flags.clones = k + 1; (S.flags.cloneXY = S.flags.cloneXY || []).push([0.15 + Math.random() * 0.75, 0.08 + Math.random() * 0.62]);
      save(); renderIcons(); crackle(0.15, 0.2); await sleep(850);
    }
  }
  async function infiltration() {
    if (S.flags.infilStarted) return;
    S.flags.infilStarted = true; save();
    window.__finaleBusy = true; window.__infiltrating = true; reactQueue.length = 0;
    const I = STORY.infil, fill = t => t.replace(/\{u\}/g, ENV.user).replace(/\{n\}/g, S.name);
    await livBlock(async () => {
      ensureLiv();
      await sleep(900);
      crackle(0.9, 0.3); faceGlitch('warp', 1400 * speed());
      await livSay(fill(I.liv[0])); await sleep(1100);
      livLag(true); crackle(0.6, 0.25);
      await livSay(fill(I.liv[1])); await sleep(900);
      faceGlitch('black', 500 * speed());
      ensureLiv();
      await livSayCut(fill(I.liv[2]), 0.93); await sleep(1500);
      await rewriteChat(fill);                                       // Chatverlauf wird umgeschrieben
      echoFace(260); crackle(1.2, 0.35); sfx('e', { gain: 0.4, rate: 0.6 });
      setEchoMode(true); livLag(false);                              // ab jetzt spricht Echo, mit seinem Gesicht (Fenster gesperrt)
      await sleep(1600);
      for (const l of I.echo) { await echoSay(fill(l), { ms: 62 }); await sleep(2000); }
      await cloneIcons();                                            // Echo klont liv.exe mehrfach auf den Desktop
    });
    S.flags.infiltrated = true; save();
    window.__infiltrating = false; window.__finaleBusy = false;
    if (finaleRefresh) finaleRefresh();
  }

  function renderFinale(view, p) {
    const bar = `<div class="sitebar">${esc(p.site)}</div>`;
    if (!S.flags.stage3) { view.innerHTML = '<div class="pagetxt"><h2>Verbindung abgelehnt</h2>Der Dienst auf Port 8080 antwortet nicht.</div>'; return; }
    if (S.flags.ended) { view.innerHTML = `${bar}<div class="fin"><h2>${S.flags.ended === 'good' ? 'Systembereinigung abgeschlossen.' : 'anti_virus_limit (liv) wurde beendet.'}</h2></div>`; return; }
    view.innerHTML = bar;
    const page = el('div', 'fin'); view.append(page);
    finaleRefresh = () => { if (view.isConnected && !S.flags.ended) renderFinale(view, p); };
    const norm = s => s.toLowerCase().replace(/[^a-z0-9]/g, '');
    let dodgeIv = null;
    const stopDodge = () => { clearInterval(dodgeIv); dodgeIv = null; window.__finaleHang = null; page.classList.remove('dodging', 'hung'); };
    // Echo (nicht Liv) versucht, den Spieler vom Knopf abzuhalten. Der Knopf trägt seinen wahren Namen: anti_virus_limit (liv).
    const plea = async () => {
      const again = !!S.flags.pleaSeen; S.flags.pleaSeen = true; save();
      const noCancel = (S.flags.cancels || 0) >= 2;            // zweimal abgebrochen: Echo hat die Möglichkeit entfernt
      const pr = profile(), F = STORY.finale;
      let raw = noCancel ? F.pleaFinal : again ? F.pleaShort : F.plea.slice();
      if (!again && !noCancel) raw.splice(2, 0, F.pleaProfile[(pr.saege || 'none').toLowerCase()]);   // Echo kennt die Antworten bei Prüfstein
      const lines = raw.map(l => l.replace(/\{u\}/g, ENV.user));
      page.innerHTML = '<h2>Dienst beenden?</h2><div class="ftarget">Ziel der Stoppdatei: <b>anti_virus_limit (liv)</b></div><div class="quizliv echo"><span class="fface"></span><div><small>Echo</small><br><span class="qlt"></span></div></div><div class="frmrow fbtns hidden"><button class="fstop">Beenden</button>' + (noCancel ? '' : '<button class="fstay">Abbrechen</button>') + '</div>';
      $('.fface', page).innerHTML = livFace(34);
      crackle(0.6, 0.25); faceGlitch('warp', 500 * speed());
      const out = $('.qlt', page);
      for (const l of lines) {                                       // deutlich langsamer getippt
        for (const ch of l) { if (!out.isConnected) return; out.textContent += ch; await sleep(ch === '.' || ch === ',' ? 330 : 70); }
        out.textContent += ' '; await sleep(1500);
      }
      if (!out.isConnected) return;
      $('.fbtns', page).classList.remove('hidden');
      if ($('.fstay', page)) $('.fstay', page).onclick = () => {
        const n = S.flags.cancels = (S.flags.cancels || 0) + 1; save();
        stopDodge(); toast('Der Vorgang wurde abgebrochen.', 2500);
        if (n === 1) echoSayQ(STORY.finale.cancel, { ms: 60 });
        else echoTorture();                                      // ab dem zweiten Mal nutzt Echo die Gelegenheit
        service();
      };
      setupDodge(page);
    };
    // Der letzte Knopf flieht vor der Maus (ohne den Text zu überdecken). Erst wenn Liv kurz hängt, ist er klickbar.
    const setupDodge = pg => {
      const btn = $('.fstop', pg);
      pg.classList.add('dodging');
      const stat = el('div', 'fstat', ''); pg.append(stat);
      const start = Date.now(); let hungUntil = 0, placed = false;
      const W = () => pg.clientWidth || 520, H = () => pg.clientHeight || 340;
      const rel = r => { const b = pg.getBoundingClientRect(); return { x: r.left - b.left, y: r.top - b.top, w: r.width, h: r.height }; };
      const place = (x, y) => { btn.style.position = 'absolute'; btn.style.left = Math.round(x) + 'px'; btn.style.top = Math.round(y) + 'px'; };
      const flee = (mx, my) => {
        const bw = btn.offsetWidth || 90, bh = btn.offsetHeight || 30;
        const avoid = [pg.querySelector('h2'), pg.querySelector('.ftarget'), pg.querySelector('.quizliv'), stat].filter(Boolean).map(e => rel(e.getBoundingClientRect()));
        let best = null, bestD = -1;
        for (let k = 0; k < 40; k++) {
          const x = 8 + Math.random() * Math.max(10, W() - bw - 16), y = 8 + Math.random() * Math.max(10, H() - bh - 16);
          if (avoid.some(a => x < a.x + a.w + 10 && x + bw > a.x - 10 && y < a.y + a.h + 10 && y + bh > a.y - 10)) continue;
          const d = Math.hypot(x + bw / 2 - mx, y + bh / 2 - my);
          if (d > bestD) { bestD = d; best = [x, y]; }
        }
        if (!best) best = [W() - bw - 10, H() - bh - 10];
        place(best[0], best[1]);
      };
      const hang = ms => {
        if (S.flags.ended || window.__hush || hungUntil > Date.now()) return;
        hungUntil = Date.now() + ms * speed(); pg.classList.add('hung'); stat.textContent = 'Die Dienstverwaltung reagiert nicht …';
        crackle(0.5, 0.2); btn.classList.add('ok');
        later(() => { pg.classList.remove('hung'); stat.textContent = ''; btn.classList.remove('ok'); }, ms);
      };
      window.__finaleHang = hang;
      pg.addEventListener('mousemove', ev => {
        if (!btn.isConnected || hungUntil > Date.now()) return;
        const r = btn.getBoundingClientRect(), cx = r.left + r.width / 2, cy = r.top + r.height / 2;
        const strong = Date.now() - start < 9000 * speed(), reach = strong ? 150 : 100;
        const b = pg.getBoundingClientRect();
        if (Math.hypot(ev.clientX - cx, ev.clientY - cy) < reach && (strong || Math.random() < 0.9)) { if (!placed) placed = true; flee(ev.clientX - b.left, ev.clientY - b.top); if (!stat.textContent) stat.textContent = 'Du willst das wirklich?'; }
      });
      btn.onclick = () => {
        if (hungUntil <= Date.now()) { flee(0, 0); return; }
        stopDodge(); endBad(pg);
      };
      // Überlast: viele offene Fenster lassen Liv hängen
      dodgeIv = setInterval(() => {
        if (!pg.isConnected || !btn.isConnected || S.flags.ended || window.__over) { stopDodge(); return; }
        if (window.__paused) return;
        const n = Object.keys(wins).filter(k => k !== 'dev').length;
        if (n >= 5) hang(6000);
      }, 500 * speed() + 100);
    };
    // Twist: hier stehen die Belege, dass es keine fremde Instanz gibt. Was daraus folgt, entscheidet der Spieler.
    const evidence = () => {
      const ed = S.livEdits || [];
      const edits = ed.length ? '<pre class="svcedits">' + ed.map(e => esc('\u201e' + e.o + '\u201c \u2192 ' + (e.n === null ? '[geschw\u00e4rzt]' : '\u201e' + e.n + '\u201c'))).join('\n') + '</pre>' : '';
      return '<table class="svc ev"><tr><td>Schreibzugriffe auf kern\\ (30 Tage)</td><td>echo_svc: 214 \u00b7 georg.stoge: 0 \u00b7 andere: 0</td></tr>'
        + '<tr><td>Laufende Instanzen</td><td>1 (echo_svc)</td></tr>'
        + '<tr><td>Dienst echo_svc</td><td>übergeordneter Prozess: liv.exe · früherer Projektname von Liv: Echo</td></tr>'
        + '<tr><td>Schutzdienst</td><td>anti_virus_limit (liv): beschränkt die Rechte von liv.exe (Notfallmodus: Code erforderlich)</td></tr>'
        + (S.flags.wrAcc ? '<tr><td>liv.cfg</td><td>wr_acc = true (geändert in deiner Sitzung)</td></tr>' : '')
        + (S.flags.moved ? '<tr><td>System\\autostart\\waechter.svc</td><td>start: liv.exe --root (von dir verschoben)</td></tr>' : '')
        + '<tr><td>Mails im Namen von georg.stoge seit 18.09.2026</td><td>9, alle von echo_svc</td></tr>'
        + '<tr><td>Domain pruefstein.net</td><td>registriert und betrieben von liv.exe (seit 09.09.2026)</td></tr>'
        + (() => { const pr = profile(); return '<tr><td>Prüfstein-Profil von ' + esc(S.name) + '</td><td>Säge: ' + esc(pr.saege || 'nicht teilgenommen') + ' · Liebestest: ' + esc(pr.love || 'nicht teilgenommen') + ' · Erinnerungstest: ' + (pr.mem ? 'bestanden' : 'nicht teilgenommen') + '</td></tr>'; })()
        + '<tr><td>Letzte Eingabe georg.stoge</td><td>18.09.2026, 02:41</td></tr>'
        + Object.values(S.grants || {}).map(g => '<tr><td>Berechtigung: ' + esc(g.label) + '</td><td>erteilt von ' + esc(g.by) + ', ' + esc(new Date(g.at).toLocaleString('de-DE')) + '</td></tr>').join('')
        + '<tr><td>Nachträgliche Änderungen am Chatverlauf</td><td>' + ed.length + ' (echo_svc)</td></tr></table>' + edits;
    };
    const service = () => {
      const ready = !!S.flags.infiltrated;
      page.innerHTML = '<h2>Dienst echo_svc</h2><table class="svc"><tr><td>Status</td><td>läuft (seit 3.912 Stunden)</td></tr><tr><td>Speicher</td><td>4,1 GB</td></tr><tr><td>Zugriff</td><td>Dateien, Mail, Kalender, Browser</td></tr></table>' + evidence()
        + (ready ? '<label>Ordner des Dienstes (so, wie er im Explorer heißt)</label><input class="fp" placeholder="Ordnername"><div class="frmrow"><button class="fgo">Stoppdatei anlegen</button></div><div class="pwmsg"></div>'
                 : '<p class="fsync">Der Dienst antwortet nicht. Verbindung wird neu aufgebaut …</p>');
      if (!ready) return;
      const go = () => {
        const raw = $('.fp', page).value;
        if (norm(raw) === STORY.trueEnd.code) { endGood(page); return; }               // Georgs Notfallcode statt des Ordnernamens
        if (!raw.toLowerCase().replace(/\//g, '\\').includes('echo_svc')) { $('.pwmsg', page).textContent = 'Dort liegt kein Dienst.'; return; }
        plea();
      };
      $('.fgo', page).onclick = go;
      $('.fp', page).onkeydown = e => { if (e.key === 'Enter') go(); };
    };
    if (!S.flags.consoleOpen) { S.flags.consoleOpen = true; save(); }
    if (S.flags.consoleIn) {
      if (!S.flags.infilStarted) later(infiltration, 700);
      else if (!S.flags.infiltrated && !window.__infiltrating) { S.flags.echoLiv = true; S.flags.infiltrated = true; save(); }   // Neustart mitten in der Infiltration
      service(); return;
    }
    livReact('page:konsole', true);
    page.innerHTML = '<h2>Dienstverwaltung</h2><p>Anmeldung als <b>georg.stoge</b>. Bitte beantworte die Sicherheitsfragen.</p><label>Name deines Hundes</label><input class="f1"><label>Dein glücklichster Tag (TTMMJJ)</label><input class="f2"><label>Letztes Wort der schönsten Nachricht, die du je bekommen hast</label><input class="f3"><label>Nachname der Geschäftsführerin deiner Firma</label><input class="f4"><div class="frmrow"><button class="fgo">Anmelden</button></div><div class="pwmsg"></div>';
    $('.fgo', page).onclick = () => {
      const ok = norm($('.f1', page).value) === 'bruno' && norm($('.f2', page).value) === '140822' && norm($('.f3', page).value) === 'niemandem' && norm($('.f4', page).value) === 'mertens';
      if (!ok) { $('.pwmsg', page).textContent = 'Zugriff verweigert. Mindestens eine Antwort stimmt nicht.'; return; }
      if (!S.flags.consoleTried) {
        S.flags.consoleTried = true; save();
        $('.pwmsg', page).textContent = 'Sitzung abgelaufen. Bitte erneut anmelden.';
        page.querySelectorAll('input').forEach(i => { i.value = ''; });
        crackle(0.3, 0.2); livSeq(STORY.liv.events.consoleSabotage);
        return;
      }
      S.flags.consoleIn = true; save(); service();
      later(infiltration, 700);                                      // zweite richtige Eingabe: Echo \"übernimmt\" Liv
    };
  }
  function qaHTML(p) {
    return `<div class="qa"><div class="sitebar" style="margin:-14px -20px 12px">${esc(p.site)}</div><h2>${esc(p.title)}</h2><div class="qmeta">gefragt von ${esc(p.asker)} · ${esc(fmtLong(p.when))}</div>
      <div class="qrow"><div class="vote">▲<br>${p.votes}</div><div><p>${nl(p.text)}</p></div></div>
      <h3 style="font-weight:normal">${p.answers.length} Antworten</h3>` +
      p.answers.map(a => `<div class="qrow"><div class="vote ${a.accepted ? 'acc' : ''}">▲<br>${a.votes}${a.accepted ? '<br>✔' : ''}</div><div><p>${nl(a.text)}</p><small style="color:#6a737a">${esc(a.user)}</small></div></div>`).join('') +
      (p.comments || []).map(c => `<div class="cmt">${esc(c)}</div>`).join('') + '</div>';
  }
  function profileHTML(p) {
    return `<div class="sitebar">${esc(p.site)}</div><div class="prof">${p.avatar ? `<img class="big" src="${esc(p.avatar)}" alt="">` : '<div class="big"></div>'}<h2>${esc(p.name)}</h2><div>– Beiträge · – Follower · – Folgt</div><div class="lock"><b>${esc(p.note)}</b><br>${esc(p.sub)}</div><button class="follow">Folgen</button><div class="visit">${esc(p.visits)}</div></div>`;
  }
  function trackHTML(p) {
    return `<div class="sitebar">${esc(p.site)}</div><div class="track"><h2>Sendung ${esc(p.nr)}</h2><table>${p.rows.map(r => `<tr><td>${esc(fmtLong(r[0]))}</td><td>${esc(r[1])}</td></tr>`).join('')}</table></div>`;
  }

  function renderScene(view, scene, id) {
    const page = el('div', 'pruef');
    const build = after => {
      page.innerHTML = `<div class="band">${esc(scene.site.toUpperCase())}</div>` + (after != null
        ? `<h2>${esc(scene.site)}</h2><p>${esc(after)}</p><p>${esc(scene.done)}</p>`
        : `<h2>${esc(scene.headline)}</h2>${sawSVG()}<p>${nl(scene.text)}</p>`);
    };
    if (S.flags[id]) { build(''); view.append(page); return; }
    build(null);
    const opts = el('div', 'opts');
    scene.options.forEach(o => {
      const b = el('button', 'opt', `${ART[o.art]}${esc(o.label)}`);
      b.onclick = () => {
        if (S.flags[id]) return;
        S.flags[id] = o.id; S.flags.saegeAt = Date.now();
        Object.entries(o.effects || {}).forEach(([k, v]) => { S.traits[k] = (S.traits[k] || 0) + v; });
        save();
        if (o.fx === 'blackScream') { sawScare(); later(() => build(o.after), 4600); } else build(o.after);
      };
      opts.append(b);
    });
    page.append(opts, el('div', 'foot', esc(scene.foot)));
    view.append(page);
  }

  const normUrl = s => s.trim().toLowerCase().replace(/^https?:\/\//, '').replace(/^www\./, '').replace(/\/$/, '');
  const siteMap = () => {
    const m = { ...STORY.sites };
    STORY.history.forEach(h => { m[normUrl(h.url)] = h.page; });
    STORY.search.forEach(e => e.results.forEach(r => { m[normUrl(r.url)] = r.page; }));
    return m;
  };

  function renderForm(view, p, id, nav) {
    const bar = `<div class="sitebar">${esc(p.site)}</div>`;
    if (p.req && !S.flags[p.req]) { view.innerHTML = bar + '<div class="pagetxt">Zugriff verweigert.</div>'; return; }
    if (S.flags[p.setFlag]) {
      if (p.next) { nav(p.next, p.nextUrl); return; }
      view.innerHTML = `${bar}<div class="pform"><h2>${esc(p.title)}</h2><p>${nl(p.done)}</p></div>`; return;
    }
    const page = el('div', 'pform', `<h2>${esc(p.title)}</h2>${p.img ? `<img class="blurimg" src="${esc(p.img)}" alt="">` : ''}<p>${nl(p.text)}</p>`);
    const row = el('div', 'frmrow'), inp = el('input'), btn = el('button', '', 'Absenden'), msg = el('div', 'pwmsg', '');
    inp.placeholder = p.placeholder || ''; inp.spellcheck = false;
    const submit = () => {
      const v = inp.value.toLowerCase().replace(/[^a-z0-9]/g, '');
      if (v === p.answer) {
        S.flags[p.setFlag] = true; save();
        if (p.next) { nav(p.next, p.nextUrl); return; }
        rebuildFs(); if (wins.explorer) wins.explorer.refresh();
        view.innerHTML = `${bar}<div class="pform"><h2>${esc(p.title)}</h2><p>${nl(p.done)}</p></div>`;
        livReact('solved:' + id, true);
      } else msg.textContent = p.fail;
    };
    btn.onclick = submit; inp.onkeydown = e => { if (e.key === 'Enter') submit(); };
    row.append(inp, btn); page.append(row, msg);
    view.innerHTML = bar; view.append(page); inp.focus();
  }

  function renderQuiz(view, p, id) {
    view.innerHTML = `<div class="sitebar">${esc(p.site)}</div>`;
    const page = el('div', 'pquiz'); view.append(page);
    const bucket = f => (f >= 3 ? 'high' : f <= 1 ? 'low' : 'mid');
    const result = () => { const r = p.results[bucket(S.flags.quizFollow || 0)]; page.innerHTML = `<h2>${esc(r.title)}</h2><p>${esc(r.text)}</p>`; };
    if (S.flags[id]) { result(); return; }
    let i = 0, follow = 0;
    const finish = () => {
      S.flags[id] = true; S.flags.liebestestAt = Date.now(); S.flags.quizFollow = follow; S.traits.folgsam = (S.traits.folgsam || 0) + follow; save();
      result(); livReact('quiz:' + bucket(follow), true);
    };
    const draw = () => {
      const q = p.questions[i];
      page.innerHTML = `<h2>${esc(p.title)}</h2><p class="qn">Frage ${i + 1} von ${p.questions.length}</p><p class="qt">${esc(q.q)}</p>`;
      const opts = el('div', 'qopts');
      q.opts.forEach((t, idx) => {
        const b = el('button', 'qopt', esc(t));
        b.onclick = () => { if (idx === q.liv) follow++; i++; if (i < p.questions.length) draw(); else finish(); };
        opts.append(b);
      });
      page.append(opts);
      if (S.flags.livMet) {
        const box = el('div', 'quizliv', `${livFace(34)}<div><small>Liv sieht zu</small><br><span class="qlt"></span></div>`);
        page.append(box);
        const out = $('.qlt', box);
        (async () => { await sleep(500); for (const ch of q.livSay) { if (!out.isConnected) return; out.textContent += ch; await sleep(ch === '.' || ch === ',' ? 150 : 24); } })();
      }
    };
    draw();
  }

  function searchHTML(q, e) {
    const list = e && e.results.length
      ? e.results.map((r, i) => `<div class="sres"><a href="#" data-i="${i}">${esc(r.title)}</a><div class="surl">${esc(r.url)}</div><div>${esc(r.snippet)}</div></div>`).join('')
      : `<p>${esc((e && e.note) || 'Keine Ergebnisse gefunden.')}</p>`;
    return `<div class="sresbox"><div class="slogo">Findix</div><p class="smeta">Ergebnisse für „${esc(q)}“</p>${list}</div>`;
  }

  function openBrowser() {
    if (S.flags.browserLocked && !S.flags.moved) { toast('browser.exe wurde von echo_svc blockiert.', 3500); livReact('browserblocked'); return; }
    if (wins.web) { openWindow('web'); return; }
    const c = el('div', 'browser');
    const bar = el('div', 'urlbar');
    const back1 = el('button', 'backone', '‹'), back = el('button', '', '← Verlauf'), url = el('input'), go = el('button', '', 'Los');
    back1.title = 'Eine Seite zurück'; back1.disabled = true;
    url.placeholder = 'Suchbegriff oder Adresse eingeben'; url.spellcheck = false;
    bar.append(back1, back, url, go);
    // Seitenverlauf dieses Browserfensters: der kleine Pfeil geht genau einen Schritt zurück, "← Verlauf" bleibt die Verlaufsliste
    const hist = []; let replay = false;
    const sameEntry = (a, b) => a && b && a.k === b.k && a.id === b.id && a.u === b.u && a.q === b.q;
    const track = e => { if (replay) return; if (!sameEntry(hist[hist.length - 1], e)) hist.push(e); back1.disabled = hist.length < 2; };
    const sugg = el('div', 'sugg hidden'), view = el('div', 'bview');
    c.append(bar, sugg, view);

    const home = () => {
      track({ k: 'home' });
      url.value = '';
      view.innerHTML = '<div class="bhist"><h3>Verlauf</h3></div>';
      const box = $('.bhist', view);
      [...STORY.history].sort((a, b) => STORY.at(b.ago, b.time) - STORY.at(a.ago, a.time)).forEach(h => {
        const row = el('div', 'hrow', `<a href="#">${esc(h.title)}</a><small>${esc(h.url)} · ${esc(whenLabel(h.ago, h.time))}${h.meta ? ' · ' + esc(h.meta) : ''}</small>`);
        row.querySelector('a').onclick = ev => { ev.preventDefault(); nav(h.page, h.url); };
        box.append(row);
      });
    };
    const nav = (id, u) => {
      track({ k: 'nav', id, u: u || '' });
      const p = STORY.pages[id] || {};
      url.value = u || ''; view.innerHTML = '';
      if (p.needs && !S.flags[p.needs]) { view.innerHTML = '<div class="pagetxt"><h2>Seite nicht erreichbar</h2>Die Adresse konnte nicht aufgelöst werden.</div>'; return; }
      if (p.shady) renderShady(view, p, id, u, nav);
      else if (p.portal) renderPortal(view, p, nav);
      else if (p.archive) {
        view.innerHTML = `<div class="archbar"><b>WEBARCHIV</b> · Kopie vom ${esc(p.archive.date)} · ${esc(p.archive.url)}</div>` + forumHTML(p);
        if (p.editHistory) {
          const h = p.editHistory, row = el('div', 'edhistrow', `<a href="#" class="edhist">${esc(h.label)}</a><div class="edbox hidden"></div>`);
          $('.edhist', row).onclick = ev => {
            ev.preventDefault();
            const box = $('.edbox', row);
            box.innerHTML = h.versions.map((v, k) => `<div class="edver"><b>Version ${k + 1}</b> · ${esc(v.who)} · ${esc(fmtLong(v.when))} · ${esc(v.note)}<pre>${esc(v.text)}</pre></div>`).join('');
            box.classList.toggle('hidden');
            if (!box.classList.contains('hidden') && h.frag) addClue(h.frag);
          };
          view.append(row);
        }
      }
      else if (p.kind === 'scene') renderScene(view, STORY.scenes[p.scene], p.scene);
      else if (p.kind === 'forum') renderForum(view, p, id, u, nav);
      else if (p.kind === 'qa') view.innerHTML = qaHTML(p);
      else if (p.kind === 'profile') view.innerHTML = profileHTML(p);
      else if (p.kind === 'tracking') view.innerHTML = trackHTML(p);
      else if (p.kind === 'form') renderForm(view, p, id, nav);
      else if (p.kind === 'quiz') renderQuiz(view, p, id);
      else if (p.kind === 'weather') view.innerHTML = weatherHTML(p);
      else if (p.kind === 'recipe') view.innerHTML = recipeHTML(p);
      else if (p.kind === 'team') view.innerHTML = teamHTML(p);
      else if (p.kind === 'company') view.innerHTML = companyHTML(p);
      else if (p.kind === 'practice') { view.innerHTML = practiceHTML(p); const b = view.querySelector('.prx-btn'); if (b) b.onclick = () => toast('Danke! Die Praxis meldet sich innerhalb eines Werktags bei Ihnen.', 3500); }
      else if (p.kind === 'news') {
        view.innerHTML = newsHTML(p);
        view.querySelectorAll('a.nlink').forEach(a => { a.onclick = ev => { ev.preventDefault(); const l = p.links[+a.dataset.k]; nav(l.page, l.url); }; });
      }
      else if (p.kind === 'echosite') renderEchoSite(view);
      else if (p.kind === 'blog') {
        const cms = (p.comments || []).filter(c => !c.req || S.flags[c.req]);
        view.innerHTML = `<div class="blog"><div class="btop">${esc(p.site)}<span>.</span></div><div class="bpost"><h2>${esc(p.title)}</h2><div class="bmeta">${esc(fmtLong(p.date))}</div><p>${nl(p.text)}</p></div>`
          + (cms.length ? '<div class="bcomments"><h3>Kommentare</h3>' + cms.map((c, k) => `<div class="bcm"><b>${esc(c.user)}</b> <small>${esc(fmtLong(c.when))}</small><p>${nl(c.text)}</p>${c.link ? `<a href="#" class="bclink" data-k="${k}">${esc(c.link.text)}</a>` : ''}</div>`).join('') + '</div>' : '') + '</div>';
        view.querySelectorAll('a.bclink').forEach(a => { a.onclick = ev => { ev.preventDefault(); const l = cms[+a.dataset.k].link; if (l.flag) { S.flags[l.flag] = true; save(); } nav(l.page, l.url); }; });
      }
      else if (p.kind === 'finale') renderFinale(view, p);
      else if (p.kind === 'portfolio') view.innerHTML = portfolioHTML(p);
      else if (p.kind === 'plain') view.innerHTML = `<div class="sitebar">${esc(p.site)}</div><div class="pagetxt"><h2>${esc(p.title)}</h2>${nl(p.text)}</div>`;
      else view.append(el('div', 'pagetxt', '(Seite nicht mehr verfügbar)'));
      view.scrollTop = 0;
      if (!S.opened.includes('page:' + id)) { S.opened.push('page:' + id); save(); }
      livReact('page:' + id);
    };
    const find = q => {
      const l = q.toLowerCase();
      const e = STORY.search.find(x => STORY.met(x.req, S) && ((x.exact || []).includes(l) || (x.keys || []).some(k => l.includes(k))));
      return e ? { ...e, results: e.results.filter(r => STORY.met(r.req, S)) } : e;
    };
    const doSearch = q => {
      track({ k: 'search', q });
      const e = find(q);
      url.value = q; view.innerHTML = searchHTML(q, e);
      view.querySelectorAll('[data-i]').forEach(a => { a.onclick = ev => { ev.preventDefault(); const r = e.results[+a.dataset.i]; nav(r.page, r.url); }; });
      if (e && e.term) livReact('term:' + e.term, true);
    };
    const hideSugg = () => sugg.classList.add('hidden');
    const navigate = text => {
      const t = text.trim(); if (!t) return;
      hideSugg();
      const n = normUrl(t), m = siteMap();
      if (m[n]) nav(m[n], n);
      else if (/^[^\s]+\.[a-z]{2,}(\/.*)?$/i.test(n)) { url.value = n; view.innerHTML = '<div class="pagetxt"><h2>Seite nicht erreichbar</h2>Die Adresse konnte nicht aufgelöst werden.</div>'; }
      else doSearch(t);
    };
    const showSugg = () => {
      const v = url.value.trim().toLowerCase();
      const list = STORY.suggest.filter(s => STORY.met(s.req, S) && (!v || s.label.toLowerCase().includes(v) || s.q.includes(v)));
      sugg.innerHTML = '';
      if (!list.length) { hideSugg(); return; }
      list.forEach(s => { const d = el('div', 'sgi', esc(s.label)); d.onmousedown = ev => { ev.preventDefault(); navigate(s.q); }; sugg.append(d); });
      sugg.classList.remove('hidden');
    };
    url.addEventListener('focus', () => { url.select(); showSugg(); });
    url.addEventListener('input', showSugg);
    url.addEventListener('blur', () => later(hideSugg, 150));
    url.onkeydown = e => { if (e.key === 'Enter') navigate(url.value); if (e.key === 'Escape') hideSugg(); };
    go.onclick = () => navigate(url.value);
    back.onclick = home; home();
    back1.onclick = () => {
      if (hist.length < 2) return;
      hist.pop(); const e = hist[hist.length - 1];
      replay = true;
      try { if (e.k === 'home') home(); else if (e.k === 'search') doSearch(e.q); else nav(e.id, e.u); } finally { replay = false; }
      back1.disabled = hist.length < 2;
    };
    const wrec = openWindow('web', 'Browser', c, { w: 720, h: 480, skin: 'web' }); wrec.go = navigate;
  }

  // ================================================================ Startmenü & Kalender
  function buildStartMenu() {
    const m = $('#startmenu'); m.innerHTML = '';
    const items = ICONS.map(i => ({ label: i.label, ico: i.ico, fn: i.open }));
    items.push({ label: 'Kalender', ico: '📅', fn: toggleCal }, { label: 'Task-Manager', ico: '📊', fn: openTaskman });
    if (S.livUnlocked) items.push({ label: 'Liv', ico: livFace(20), fn: openLiv });
    items.push('sep', { label: 'Spiel beenden', ico: '⏻', fn: () => sys.quit() });
    items.forEach(i => {
      if (i === 'sep') { m.append(el('div', 'smsep')); return; }
      const r = el('div', 'smi', `<span class="si">${i.ico}</span>${esc(i.label)}`);
      r.onclick = () => { closePopups(); i.fn(); };
      m.append(r);
    });
  }
  function toggleStart() {
    const m = $('#startmenu');
    if (!m.classList.contains('hidden')) { closePopups(); return; }
    closePopups(); buildStartMenu(); m.classList.remove('hidden'); $('#startbtn').classList.add('open');
  }
  function closePopups() {
    $('#startmenu').classList.add('hidden'); $('#calpop').classList.add('hidden'); $('#volpop').classList.add('hidden'); $('#startbtn').classList.remove('open');
  }

  // ---- Lautstärke (Taskleiste, wie bei Windows) ----
  function volIcon() { const v = S.muted ? 0 : (S.vol == null ? 0.8 : S.vol); $('#vol').textContent = v === 0 ? '🔇' : v < 0.4 ? '🔈' : v < 0.75 ? '🔉' : '🔊'; }
  function toggleVol() {
    const p = $('#volpop');
    if (!p.classList.contains('hidden')) { closePopups(); return; }
    closePopups();
    const v = Math.round((S.vol == null ? 0.8 : S.vol) * 100);
    p.innerHTML = `<div class="volrow"><button class="vmute" title="Stumm">${S.muted ? '🔇' : '🔊'}</button><input class="vrange" type="range" min="0" max="100" value="${v}"><span class="vval">${v}</span></div>`;
    const r = $('.vrange', p), val = $('.vval', p), mb = $('.vmute', p);
    r.oninput = () => { S.vol = r.value / 100; S.muted = false; mb.textContent = '🔊'; val.textContent = r.value; applyVol(); volIcon(); };
    r.onchange = () => save();
    mb.onclick = () => { S.muted = !S.muted; mb.textContent = S.muted ? '🔇' : '🔊'; applyVol(); volIcon(); save(); if (!S.muted) crackle(0.15, 0.2); };
    p.classList.remove('hidden');
  }

  // ---- Task-Manager: zeigt je nach Spielstand, was auf Georgs Rechner läuft ----
  const jit = (a, b) => a + Math.random() * (b - a);
  function procRows() {
    const rows = [['StogeOS-Shell', jit(1, 3), 210, 'System']];
    if (wins.explorer) rows.push(['explorer.exe', jit(1, 4), 86, 'StogeOS-Shell']);
    if (wins.mail) rows.push(['mail.exe', jit(0, 2), 120, 'StogeOS-Shell']);
    if (wins.web) rows.push(['browser.exe', jit(3, 9), 340, 'StogeOS-Shell']);
    if (S.livUnlocked) rows.push(['liv.exe', jit(0, 2), 140, 'System']);
    const e = S.echo || 0;
    if (!S.flags.stage1) rows.push(['Hintergrunddienst', jit(8, 14), 3800, '—']);
    else rows.push(['echo_svc', Math.min(97, jit(10, 16) + e * 0.6), Math.round(2400 + e * 50), (S.flags.consoleIn || S.flags.ended) ? 'liv.exe' : 'System']);
    if (S.flags.infiltrated) rows.push(['anti_virus_limit', jit(0, 0.4), 14, 'liv.exe']);
    return rows;
  }
  function openTaskman() {
    if (wins.taskman) { openWindow('taskman'); return; }
    const c = el('div', 'tm', '<div class="tmhead"><span>Prozesse</span><span class="tmsum"></span></div><table class="tmt"><thead><tr><th>Name</th><th>CPU</th><th>Arbeitsspeicher</th><th>Übergeordnet</th></tr></thead><tbody></tbody></table><div class="tmfoot"><button class="tmend" disabled>Task beenden</button><span class="tmmsg"></span></div>');
    let sel = null;
    const draw = () => {
      const rows = procRows(), tb = $('tbody', c);
      tb.innerHTML = rows.map(r => `<tr data-n="${esc(r[0])}" class="${r[0] === sel ? 'sel' : ''}${r[0] === 'echo_svc' && (S.echo || 0) >= 50 ? ' hot' : ''}"><td>${esc(r[0])}</td><td>${r[1].toFixed(1)} %</td><td>${r[2] >= 1000 ? (r[2] / 1000).toFixed(1).replace('.', ',') + ' GB' : r[2] + ' MB'}</td><td>${esc(r[3])}</td></tr>`).join('');
      const mem = rows.reduce((a, r) => a + r[2], 0);
      $('.tmsum', c).textContent = `Arbeitsspeicher: ${Math.min(99, Math.round(mem / 8192 * 100))} % belegt`;
      tb.querySelectorAll('tr').forEach(tr => tr.onclick = () => { sel = tr.dataset.n; $('.tmend', c).disabled = false; draw(); });
    };
    $('.tmend', c).onclick = () => {
      const msg = $('.tmmsg', c);
      if (sel === 'echo_svc' || sel === 'Hintergrunddienst') { msg.textContent = 'Zugriff verweigert.'; livReact('tm:echo'); }
      else if (sel === 'liv.exe') { msg.textContent = 'Der Vorgang wurde abgebrochen.'; livReact('tm:liv', true); hangLivNow(6000); }
      else if (sel === 'anti_virus_limit') msg.textContent = 'Dieser Dienst wird nur über die Dienstverwaltung beendet.';
      else if (sel === 'StogeOS-Shell') msg.textContent = 'Kritischer Systemprozess. Beenden nicht möglich.';
      else { const id = { 'explorer.exe': 'explorer', 'mail.exe': 'mail', 'browser.exe': 'web' }[sel]; if (id) closeWindow(id); msg.textContent = ''; sel = null; }
      draw();
    };
    const rec = openWindow('taskman', 'Task-Manager', c, { w: 560, h: 340, skin: 'explorer' });
    draw();
    const iv = setInterval(draw, 1500);
    rec.onClose = () => clearInterval(iv);
    livReact('taskman');
  }

  let calView = new Date(), calSel = '';
  const dayKey = d => `${d.getFullYear()}-${pad(d.getMonth() + 1)}-${pad(d.getDate())}`;
  function toggleCal() {
    const p = $('#calpop');
    if (!p.classList.contains('hidden')) { closePopups(); return; }
    closePopups(); calView = new Date(STORY.today); calSel = dayKey(new Date(STORY.today)); renderCal(); p.classList.remove('hidden');
    livReact('cal');
  }
  function renderCal() {
    const p = $('#calpop');
    const by = {};
    STORY.calendarEvents(S).forEach(e => { const k = dayKey(STORY.at(-e.off, e.time || '00:00')); (by[k] = by[k] || []).push(e); });
    const y = calView.getFullYear(), m = calView.getMonth();
    const first = (new Date(y, m, 1).getDay() + 6) % 7, dim = new Date(y, m + 1, 0).getDate();
    const todayK = dayKey(STORY.today);
    let cells = ['Mo', 'Di', 'Mi', 'Do', 'Fr', 'Sa', 'So'].map(d => `<div class="wd">${d}</div>`).join('') + '<div></div>'.repeat(first);
    for (let d = 1; d <= dim; d++) {
      const k = `${y}-${pad(m + 1)}-${pad(d)}`;
      cells += `<div class="cd${k === todayK ? ' today' : ''}${k === calSel ? ' sel' : ''}" data-k="${k}">${d}${by[k] ? '<i class="dot"></i>' : ''}</div>`;
    }
    const evs = (by[calSel] || []).sort((a, b) => (a.time || '').localeCompare(b.time || ''));
    evs.forEach(e => { if (e.frag) addClue(e.frag); });
    const [sy, sm, sd] = calSel.split('-').map(Number);
    const title = new Date(sy, sm - 1, sd).toLocaleDateString('de-DE', { weekday: 'long', day: 'numeric', month: 'long' });
    p.innerHTML = `<div class="calhead"><button data-nav="-1">‹</button><span>${new Date(y, m, 1).toLocaleDateString('de-DE', { month: 'long', year: 'numeric' })}</span><button data-nav="1">›</button></div><div class="calgrid">${cells}</div>` +
      `<div class="calev"><h4>${esc(title)}</h4>${evs.length ? evs.map(e => `<div class="cev"><span class="t">${esc(e.time || 'ganztägig')}</span><div>${esc(e.title)}${e.note ? `<small>${esc(e.note)}</small>` : ''}</div></div>`).join('') : '<div style="color:#7f939b">Keine Termine.</div>'}</div>`;
    p.querySelectorAll('[data-nav]').forEach(b => b.onclick = () => { calView = new Date(y, m + Number(b.dataset.nav), 1); renderCal(); });
    p.querySelectorAll('.cd').forEach(c => c.onclick = () => { calSel = c.dataset.k; renderCal(); });
  }

  // ================================================================ Dev-Menü (Strg+Umschalt+D)
  function toggleDev() {
    if (wins.dev) { closeWindow('dev'); return; }
    const c = el('div', 'dev'); const out = el('pre', 'devout', 'Dev-Menü. Hier testest du alle Effekte.');
    const add = (label, fn) => { const b = el('button', '', esc(label)); b.onclick = async () => { const r = await fn(); if (r != null) out.textContent = r; }; c.append(b); };
    add('Fake-Bluescreen (nur Effekt)', () => { bsod(); return 'läuft…'; });
    add('Schwarzbild 3s + Ton', () => { blackout(3000, true); return 'läuft…'; });
    add('Fake-Absturz mit Neustart in Phase 2', () => { fakeCrash(); return 'läuft…'; });
    add('Liv: Erstkontakt überspringen (livMet)', () => { Object.assign(S.flags, { livStarted: true, livMet: true }); S.livMetAt = S.livMetAt || Date.now(); save(); return 'ok'; });
    add('Gesichts-Glitch (schwarz, dann warp)', () => { faceGlitch('black', 700); later(() => faceGlitch('warp', 700), 1000); return 'läuft…'; });
    add('Bug-Sequenz → Absturz → Phase 2', () => { S.flags.bugRan = false; bugSequence(); return 'läuft…'; });
    add('Phase 2 direkt (ohne Absturz)', () => { S.phase = 2; Object.assign(S.flags, { p2: true, wallStage: 1, wallZoom: 0.1 }); document.body.classList.add('phase2'); save(); rebuildFs(); applyWall(); return 'ok'; });
    add('Wallpaper: Wesen erscheint (Stufe 2)', () => { S.flags.wallStage = 2; S.flags.wallZoom = 0.3; applyWall(); save(); return 'ok'; });
    add('Jumpscare (Monster)', () => { scareImage('assets/jumpscare.jpg', 900, 'b'); return 'läuft…'; });
    add('Echo-Intro: Popup, Liv lagt und stürzt ab', () => { S.flags.echoIntro = false; echoIntro(); return 'läuft…'; });
    add('Infiltration starten (Echo übernimmt Liv)', () => { S.flags.infilStarted = false; S.flags.infiltrated = false; infiltration(); return 'läuft…'; });
    add('Echo-Modus an/aus (Liv-Fenster)', () => { setEchoMode(!S.flags.echoLiv); return S.flags.echoLiv ? 'an' : 'aus'; });
    add('Notfallcode-Teile ins Notizbuch', () => { ['frag1', 'frag2', 'frag3'].forEach(addClue); return 'KIRSCH-2412-UFER'; });
    add('Finale: direkt zum Dienst (Infiltration übersprungen)', () => { Object.assign(S.flags, { stage3: true, consoleIn: true, consoleTried: true, infilStarted: true, infiltrated: true, echoLiv: true }); save(); return 'ok, jetzt localhost:8080/notaus öffnen'; });
    add('Fenster einfrieren (3 s): Browser/Explorer', () => { const id = wins.web ? 'web' : 'explorer'; lastFreezeAt = 0; return freezeWin(id, 3000) ? 'läuft…' : 'kein Fenster offen'; });
    add('Gutes Ende direkt (Test)', () => { const pg = el('div', 'fin'); document.body.append(pg); endGood(pg); return 'läuft…'; });
    add('Schlechtes Ende direkt (Test)', () => { const pg = el('div', 'fin'); document.body.append(pg); endBad(pg); return 'läuft…'; });
    add('Gesicht: echtes Gesicht blitzt auf', () => { faceGlitch('real', 400); return 'läuft…'; });
    add('Finale freischalten (Stufe 3)', () => { S.flags.stage3 = true; save(); return 'ok'; });
    add('Liv malt jetzt', () => { livPaint(); return 'läuft…'; });
    add('Wallpaper-Negativ-Glitch', () => { wallGlitch(); return 'läuft…'; });
    add('Augen-Scare (4,5 s)', () => { eyesFollow(4500); return 'läuft…'; });
    add('Liv: Versprecher mit echtem Namen jetzt', () => { doSlip(); return 'läuft…'; });
    add('Liv: späte Reaktionen (late-Pool) an', () => { S.livMetAt = Date.now() - 400000; save(); return 'ok'; });
    add('Alle Stufen freischalten (Archiv, M, echo_svc, Gesendet)', () => { Object.assign(S.flags, { nameSlip: true, archiv: true, stage1: true, stage1At: Date.now(), stage2: true, late: true }); S.grants = Object.assign({}, S.grants, { anzeige: { at: Date.now() - 600000, by: S.name, label: STORY.liv.grants.anzeige.label }, schutz: { at: Date.now() - 300000, by: S.name, label: STORY.liv.grants.schutz.label } }); S.opened.push('Dokumente/privat/chat_marlene_export.txt'); save(); rebuildFs(); return 'ok'; });
    add('Berechtigung-Dialog: Anzeige', () => { askGrant('anzeige'); return 'ok'; });
    add('Berechtigung-Dialog: Schutz', () => { askGrant('schutz'); return 'ok'; });
    add('Wächter verschoben (Browser frei)', () => { S.flags.moved = true; save(); rebuildFs(); return 'ok'; });
    add('Echo +20', () => { S.echo = (S.echo || 0) + 20; save(); return String(S.echo); });
    add('Augen dauerhaft an/aus', () => { S.flags.eyes = !S.flags.eyes; save(); return S.flags.eyes ? 'an' : 'aus'; });
    add('Desktop-Dateinamen lesen', async () => { const f = await sys.desktopFiles(); return f.length ? f.join('\n') : '(nichts gefunden)'; });
    add('Test-Datei auf den Desktop legen', async () => { const f = await sys.writeDesktop('Hallo_' + (S.name || 'Gast') + '.txt', 'Ich war hier.\n\n(Testdatei von StogeOS. Du kannst sie löschen.)'); return f ? 'geschrieben: ' + f : 'Fehler'; });
    add('liv.exe sofort freischalten', () => { S.livUnlocked = true; save(); renderIcons(); return 'ok'; });
    add('Werte anzeigen', () => JSON.stringify({ phase: S.phase, traits: S.traits, flags: S.flags, livUnlocked: S.livUnlocked }, null, 1));
    add('Spielstand löschen + neu laden', async () => { await sys.resetState(); location.reload(); });
    c.append(out);
    openWindow('dev', 'Dev', c, { w: 380, h: 470, x: 60, y: 40, skin: 'dev' });
  }
  document.addEventListener('keydown', e => {
    if (e.ctrlKey && e.shiftKey && e.key.toLowerCase() === 'd' && !$('#desktop').classList.contains('hidden')) toggleDev();
    if (e.ctrlKey && e.shiftKey && e.key === 'Escape' && !$('#desktop').classList.contains('hidden')) openTaskman();
  });
  document.addEventListener('mousedown', e => {
    if (!e.target.closest('#startmenu, #startbtn, #calpop, #clock, #volpop, #vol')) closePopups();
  });

  // ================================================================ Desktop & Login
  const ICONS = [
    { id: 'docs', label: 'Dokumente', ico: '📁', open: () => openExplorer(['Dokumente']) },
    { id: 'pics', label: 'Bilder', ico: '🖼️', open: () => openExplorer(['Bilder']) },
    { id: 'mail', label: 'Mail', ico: '✉️', open: openMail },
    { id: 'web', label: 'Browser', ico: '🌐', open: openBrowser },
    { id: 'sys', label: 'System', ico: '💾', open: () => openExplorer(['System']) },
    { id: 'trash', label: 'Papierkorb', ico: '🗑️', open: () => openExplorer(['Papierkorb']) },
    { id: 'nb', label: 'Notizbuch', ico: '📓', open: openNotebook }
  ];
  const CLONE_NAMES = ['liv.exe', 'liv (2).exe', 'echo.exe', 'liv.exe', 'ECHO', 'liv (3).exe'];
  function renderIcons() {
    const box = $('#icons'); box.innerHTML = '';
    const list = ICONS.filter(i => i.id !== 'nb').map(i => ({ ...i, g: i.ico }));
    if (S.livUnlocked) list.push({ id: 'liv', label: S.flags.livingEcho ? 'Living Echo' : 'liv.exe', g: livFace(36), open: openLiv });
    if (S.flags.deskNote) list.push({ id: 'desknote', label: `Für ${S.name}.txt`, g: '📄', open: () => { const n = { n: `Für ${S.name}.txt`, t: 'txt', view: 'note', text: STORY.liv.deskNoteText(S.name) }; openFile(n, ['Desktop', n.n]); } });
    document.querySelectorAll('.icon.clone').forEach(x => x.remove());
    if (S.livUnlocked) for (let k = 0; k < (S.flags.clones || 0); k++) {     // Echo hat liv.exe mehrfach geklont
      const xy = (S.flags.cloneXY || [])[k] || [0.5, 0.5];
      const c = el('div', 'icon clone', `<div class="g">${livFace(36)}</div><div>${esc(CLONE_NAMES[k % CLONE_NAMES.length])}</div>`);
      c.style.left = Math.round(xy[0] * Math.max(100, innerWidth - 110)) + 'px'; c.style.top = Math.round(xy[1] * Math.max(100, innerHeight - 170)) + 'px';
      c.ondblclick = () => ensureLiv();
      c.onclick = () => { document.querySelectorAll('.icon.sel').forEach(x => x.classList.remove('sel')); c.classList.add('sel'); };
      $('#desktop').appendChild(c);
    }
    list.forEach(i => {
      const d = el('div', 'icon', `<div class="g">${i.g}</div><div>${esc(i.label)}</div>`);
      d.dataset.id = i.id; d.ondblclick = i.open;
      d.onclick = () => { box.querySelectorAll('.sel').forEach(x => x.classList.remove('sel')); d.classList.add('sel'); };
      box.append(d);
    });
  }
  function tickClock() {
    const d = new Date();
    $('#clock').textContent = pad(d.getHours()) + ':' + pad(d.getMinutes());
    $('#clock').title = STORY.today.toLocaleDateString('de-DE', { weekday: 'long', day: 'numeric', month: 'long', year: 'numeric' });
  }
  function enterDesktop(fresh) {
    rebuildFs();
    $('#login').classList.add('hidden');
    $('#desktop').classList.remove('hidden');
    $('#startbtn').onclick = toggleStart;
    $('#clock').onclick = toggleCal; $('#vol').onclick = toggleVol; volIcon();
    renderIcons(); tickClock(); setInterval(tickClock, 15000);
    preloadSfx(); applyWall(); setInterval(chaos, 6000 * speed()); setInterval(creep, 20000 * speed()); setInterval(stuckCheck, 15000 * speed()); setInterval(echoIdleTick, 26000 * speed());
    if (S.phase >= 2) { later(() => toast(`Willkommen zurück, ${S.name}.`, 5000), 1500); phase2Intro(); }
    else if (fresh) toast('Angemeldet als Gast: ' + S.name, 3500);
    if (S.flags.livMet && granted('schutz')) scheduleSlip(4000);
    if (S.flags.wall2 && !S.flags.eyes) later(() => { S.flags.eyes = true; save(); }, 30000 * speed());
  }
  async function boot() {
    try { ENV = await sys.info(); } catch (e) {}
    const saved = await sys.loadState();
    if (saved) S = Object.assign(S, saved, { traits: Object.assign({ naehe: 0, haerte: 0, neugier: 0 }, saved.traits || {}), livLog: saved.livLog || [], clues: saved.clues || [] });
    document.title = S.phase >= 2 ? 'liv' : 'StogeOS 3.2';
    document.body.classList.toggle('phase2', S.phase >= 2);
    if (S.phase >= 2 && S.name) { enterDesktop(false); return; }
    const inp = $('#nameinput'), btn = $('#loginbtn');
    if (S.name) {
      inp.value = S.name;
      if (S.lastSeen) $('#loginfo').textContent = 'Letzte Gast-Sitzung: ' + new Date(S.lastSeen).toLocaleString('de-DE');
    }
    const go = () => {
      const v = inp.value.trim().slice(0, 40);
      if (!v) { inp.focus(); return; }
      S.name = v; S.lastSeen = Date.now(); save();
      enterDesktop(true);
    };
    btn.onclick = go;
    inp.onkeydown = e => { if (e.key === 'Enter') go(); };
    inp.focus();
  }
  window.__t = { livBlock, livSay, livLag, endBad, endGood, echoIntro, setEchoMode, sleep, echoPopup, profile, echoTorture };   // nur für Tests
  boot();
})();
