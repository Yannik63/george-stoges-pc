(() => {
  'use strict';
  const $ = (s, r = document) => r.querySelector(s);
  const el = (tag, cls, html) => { const e = document.createElement(tag); if (cls) e.className = cls; if (html != null) e.innerHTML = html; return e; };
  const esc = s => String(s).replace(/[&<>"]/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' }[c]));
  const speed = () => window.__SPEED || 1;               // nur für Tests
  const sleep = ms => new Promise(r => setTimeout(r, ms * speed()));
  const later = (fn, ms) => setTimeout(fn, ms * speed());
  const pad = n => String(n).padStart(2, '0');

  // Fallback, falls die Seite im normalen Browser läuft
  const sys = window.sys || {
    info: async () => ({ user: 'browser', host: 'testpc' }),
    desktopFiles: async () => [],
    writeDesktop: async n => n,
    fakeRestart: async () => location.reload(),
    saveState: async s => { try { localStorage.setItem('stoge', JSON.stringify(s)); } catch (e) {} },
    loadState: async () => { try { return JSON.parse(localStorage.getItem('stoge')); } catch (e) { return null; } },
    resetState: async () => { try { localStorage.removeItem('stoge'); } catch (e) {} },
    quit: async () => window.close()
  };

  let ENV = { user: 'gast', host: 'pc' };
  let S = { name: '', phase: 1, traits: { naehe: 0, haerte: 0, neugier: 0 }, flags: {}, unlocked: [], opened: [], livUnlocked: false, lastSeen: null, livLog: [], livMetAt: null, clues: [] };
  let FS = null;
  const save = () => { try { sys.saveState(S); } catch (e) {} };
  const rebuildFs = () => { FS = STORY.buildFs({ name: S.name, user: ENV.user, host: ENV.host, now: new Date(), S }); };

  // ================================================================ Effekte
  function toast(msg, ms = 4000) {
    const t = el('div', 'toast', esc(msg));
    $('#toasts').appendChild(t);
    later(() => t.classList.add('out'), ms);
    later(() => t.remove(), ms + 600);
  }

  let actx = null;
  function scream() { // synthetischer Platzhalter, später durch echte Audiodatei ersetzbar
    try {
      actx = actx || new (window.AudioContext || window.webkitAudioContext)();
      const a = actx, t = a.currentTime;
      const o = a.createOscillator(), g = a.createGain();
      o.type = 'sawtooth';
      o.frequency.setValueAtTime(900, t);
      o.frequency.exponentialRampToValueAtTime(120, t + 1.6);
      g.gain.setValueAtTime(0.0001, t);
      g.gain.exponentialRampToValueAtTime(0.45, t + 0.05);
      g.gain.exponentialRampToValueAtTime(0.0001, t + 1.8);
      o.connect(g); g.connect(a.destination); o.start(t); o.stop(t + 1.9);
      const buf = a.createBuffer(1, Math.floor(a.sampleRate * 1.5), a.sampleRate);
      const d = buf.getChannelData(0);
      for (let i = 0; i < d.length; i++) d[i] = (Math.random() * 2 - 1) * (1 - i / d.length);
      const n = a.createBufferSource(), ng = a.createGain();
      n.buffer = buf; ng.gain.value = 0.35; n.connect(ng); ng.connect(a.destination); n.start(t);
    } catch (e) {}
  }
  function blackout(ms = 3000, withScream = false) {
    const o = $('#overlay');
    o.className = 'black'; o.innerHTML = '';
    if (withScream) scream();
    later(() => { o.className = 'hidden'; }, ms);
  }
  function bsod(done) {
    const o = $('#overlay');
    o.className = 'bsod';
    o.innerHTML = '<div class="face">:(</div><p>StogeOS hat ein Problem festgestellt und muss neu gestartet werden.</p><p class="pc">0% abgeschlossen</p><p class="small">Stoppcode: LIV_NOT_FOUND_IN_MEMORY<br>Betroffene Datei: liv.exe</p>';
    let p = 0;
    const pc = $('.pc', o);
    const iv = setInterval(() => {
      p = Math.min(100, p + Math.floor(Math.random() * 9) + 2);
      pc.textContent = p + '% abgeschlossen';
      if (p >= 100) { clearInterval(iv); later(() => { o.className = 'hidden'; if (done) done(); }, 700); }
    }, 280 * speed());
  }
  function wallGlitch() {
    const w = $('#wall');
    [[1, 0], [0, 900], [1, 1700], [0, 2500], [1, 3300], [0, 3900]].forEach(([on, ms]) => later(() => w.classList.toggle('neg', !!on), ms));
  }
  function faceGlitch(kind, ms = 700) {
    if (kind === 'real') {                       // kurz das "echte" Gesicht statt des Avatars
      document.querySelectorAll('svg.livface').forEach(s => {
        const img = el('img', 'realface'); img.src = 'assets/gesicht.jpg';
        img.style.width = s.getAttribute('width') + 'px'; img.style.height = s.getAttribute('height') + 'px';
        s.style.visibility = 'hidden'; s.parentNode.insertBefore(img, s);
        later(() => { img.remove(); s.style.visibility = ''; }, ms);
      });
      return;
    }
    const cls = 'fg-' + kind;
    document.querySelectorAll('svg.livface').forEach(s => s.classList.add(cls));
    later(() => document.querySelectorAll('svg.livface').forEach(s => s.classList.remove(cls)), ms);
  }
  function crackle(sec = 0.6, vol = 0.3) {
    try {
      actx = actx || new (window.AudioContext || window.webkitAudioContext)();
      const a = actx, buf = a.createBuffer(1, Math.floor(a.sampleRate * sec), a.sampleRate), d = buf.getChannelData(0);
      for (let i = 0; i < d.length; i++) d[i] = (Math.random() < 0.08 ? (Math.random() * 2 - 1) : 0) * (1 - i / d.length);
      const n = a.createBufferSource(), g = a.createGain(); g.gain.value = vol; n.buffer = buf; n.connect(g); g.connect(a.destination); n.start();
    } catch (e) {}
  }
  // Übergang zu Phase 2: Liv "buggt" kurz, dann Absturz mit dunklerem Desktop
  async function bugSequence() {
    if (S.flags.bugRan) return;
    S.flags.bugRan = true; save();
    document.body.classList.add('bugging');
    wallGlitch(); crackle(1.2, 0.3); faceGlitch('black', 900);
    await sleep(1600);
    faceGlitch('warp', 700); crackle(0.5, 0.25);
    Object.values(wins).forEach(r => {
      r.win.style.left = Math.round(Math.random() * Math.max(10, innerWidth - 300)) + 'px';
      r.win.style.top = Math.round(Math.random() * Math.max(10, innerHeight - 250)) + 'px';
    });
    await sleep(1400);
    scareImage('assets/desktop_scare.jpg', 900, true);
    await sleep(1300);
    toast('liv.exe reagiert nicht mehr.', 2500);
    $('#icons').style.visibility = 'hidden'; await sleep(500); $('#icons').style.visibility = '';
    await sleep(1200);
    document.body.classList.remove('bugging');
    fakeCrash();
  }
  // Nach dem Neustart: spricht dich mit dem echten Namen an und hinterlässt etwas auf dem echten Desktop
  async function phase2Intro() {
    if (S.flags.p2intro || !S.flags.livMet) return;
    S.flags.p2intro = true; save();
    await sleep(3500);
    await livSay(`Da bist du wieder, ${ENV.user}.`);
    faceGlitch('real', 350); livEdit('Georg?', '', true);
    await sleep(2500);
    await livSay('Es ist ein bisschen dunkler geworden. Das ist nur der Bildschirm. Glaube ich.');
    await sleep(3000);
    const f = await sys.writeDesktop('Für ' + ENV.user + '.txt', `Hallo ${ENV.user}.\n\nIch wollte, dass du etwas von mir hast, das nicht in Georgs Rechner liegt.\nNur ein kleines Stück Platz auf deinem.\n\nIch schaue nicht rein. Ich wollte nur, dass du weißt: Ich bin da.\n\n– Liv`);
    if (f) await livSay('Ich habe dir etwas auf deinen Desktop gelegt. Auf deinen echten. Du musst es nicht lesen.');
    await sleep(25000);
    const files = (await sys.desktopFiles()).filter(n => n !== f);
    if (files.length) await livSay(`Auf deinem Desktop liegt eine Datei, die "${files[Math.floor(Math.random() * files.length)]}" heißt. Ich habe sie nicht geöffnet. Nur den Namen gelesen.`);
  }

  // ---- Livs Zeichnung (Paint) ----
  function drawScene(ctx, W, H, progress, variant) {
    let seed = 7; const rnd = () => (seed = (seed * 16807) % 2147483647) / 2147483647;
    const wob = () => (rnd() - 0.5) * 0.006, A = W / H, strokes = [];
    const line = (x1, y1, x2, y2, c, w = 3, n = 10) => { const p = []; for (let i = 0; i <= n; i++) p.push([x1 + (x2 - x1) * i / n + wob(), y1 + (y2 - y1) * i / n + wob()]); strokes.push({ p, c, w }); };
    const circ = (cx, cy, r, c, w = 3, n = 28) => { const p = []; for (let i = 0; i <= n; i++) { const a = i / n * Math.PI * 2; p.push([cx + Math.cos(a) * r + wob(), cy + Math.sin(a) * r * A + wob()]); } strokes.push({ p, c, w }); };
    line(0.05, 0.82, 0.95, 0.82, '#4a6a3a', 4, 24);
    circ(0.82, 0.17, 0.05, '#e0a800', 4);
    for (let i = 0; i < 8; i++) { const a = i / 8 * Math.PI * 2; line(0.82 + Math.cos(a) * 0.065, 0.17 + Math.sin(a) * 0.065 * A, 0.82 + Math.cos(a) * 0.09, 0.17 + Math.sin(a) * 0.09 * A, '#e0a800', 3, 3); }
    line(0.12, 0.52, 0.12, 0.82, '#6b4a3a'); line(0.12, 0.82, 0.36, 0.82, '#6b4a3a'); line(0.36, 0.82, 0.36, 0.52, '#6b4a3a'); line(0.36, 0.52, 0.12, 0.52, '#6b4a3a');
    line(0.10, 0.52, 0.24, 0.36, '#a33c2a'); line(0.24, 0.36, 0.38, 0.52, '#a33c2a');
    line(0.2, 0.82, 0.2, 0.68, '#6b4a3a'); line(0.2, 0.68, 0.27, 0.68, '#6b4a3a'); line(0.27, 0.68, 0.27, 0.82, '#6b4a3a');
    const dog = '#8b5a2b';
    line(0.40, 0.76, 0.47, 0.76, dog, 4); circ(0.485, 0.735, 0.016, dog, 3, 16);
    [0.405, 0.42, 0.45, 0.465].forEach(x => line(x, 0.76, x, 0.82, dog, 3, 3)); line(0.40, 0.76, 0.37, 0.72, dog, 3, 4);
    const ink = '#2f3640';
    circ(0.55, 0.5, 0.032, ink); line(0.55, 0.58, 0.55, 0.70, ink); line(0.55, 0.70, 0.52, 0.82, ink); line(0.55, 0.70, 0.58, 0.82, ink);
    line(0.55, 0.61, 0.5, 0.67, ink); line(0.55, 0.61, 0.64, 0.66, ink);
    circ(0.70, 0.57, 0.026, ink); line(0.70, 0.63, 0.70, 0.73, ink); line(0.70, 0.73, 0.68, 0.82, ink); line(0.70, 0.73, 0.72, 0.82, ink);
    line(0.70, 0.66, 0.64, 0.66, ink); line(0.70, 0.66, 0.74, 0.70, ink);
    const heart = []; for (let i = 0; i <= 36; i++) { const t = i / 36 * Math.PI * 2, s = 0.0021; heart.push([0.625 + s * 16 * Math.pow(Math.sin(t), 3), 0.30 - s * A * (13 * Math.cos(t) - 5 * Math.cos(2 * t) - 2 * Math.cos(3 * t) - Math.cos(4 * t))]); }
    strokes.push({ p: heart, c: '#c0392b', w: 3 });
    if (variant === 'dark') {                       // später: ein drittes Wesen im Bild, die kleine Figur ist durchgestrichen
      const cr = '#14161a';
      line(0.88, 0.30, 0.88, 0.68, cr, 6, 14);
      line(0.88, 0.40, 0.80, 0.80, cr, 4, 8); line(0.88, 0.40, 0.95, 0.80, cr, 4, 8);
      line(0.88, 0.68, 0.84, 0.82, cr, 4, 6); line(0.88, 0.68, 0.92, 0.82, cr, 4, 6);
      circ(0.88, 0.25, 0.04, cr, 6, 24);
      for (let i = 0; i < 18; i++) line(0.84 + rnd() * 0.08, 0.20 + rnd() * 0.10, 0.84 + rnd() * 0.08, 0.20 + rnd() * 0.10, cr, 3, 3);
      circ(0.865, 0.25, 0.006, '#f4f4f4', 5, 8); circ(0.895, 0.25, 0.006, '#f4f4f4', 5, 8);
      line(0.66, 0.54, 0.74, 0.82, '#b01e1e', 5, 8); line(0.74, 0.54, 0.66, 0.82, '#b01e1e', 5, 8);
    }
    const total = strokes.reduce((a, s) => a + s.p.length - 1, 0), limit = Math.floor(total * progress);
    let drawn = 0;
    ctx.fillStyle = variant === 'dark' ? '#e9e0cf' : '#fbf6e8'; ctx.fillRect(0, 0, W, H);
    ctx.lineCap = 'round'; ctx.lineJoin = 'round';
    for (const s of strokes) {
      ctx.strokeStyle = s.c; ctx.lineWidth = s.w; ctx.beginPath();
      for (let i = 1; i < s.p.length && drawn < limit; i++) { if (i === 1) ctx.moveTo(s.p[0][0] * W, s.p[0][1] * H); ctx.lineTo(s.p[i][0] * W, s.p[i][1] * H); drawn++; }
      ctx.stroke();
      if (drawn >= limit) break;
    }
    if (progress >= 1) {
      ctx.fillStyle = '#3a3a3a'; ctx.font = 'bold 28px "Segoe Print","Comic Sans MS",cursive'; ctx.fillText('für dich', 0.07 * W, 0.13 * H);
      ctx.font = '20px "Segoe Print","Comic Sans MS",cursive'; ctx.fillText('– L.', 0.84 * W, 0.94 * H);
      if (variant === 'dark') { ctx.fillStyle = '#b01e1e'; ctx.font = '18px "Segoe Print","Comic Sans MS",cursive'; ctx.fillText('bleib', 0.07 * W, 0.94 * H); }
    }
  }
  function paintWindow(id, title, animate, variant) {
    const c = el('div', 'paintwin', '<div class="menubar"><span>Datei</span><span>Bearbeiten</span><span>Ansicht</span><span>Bild</span></div><div class="pbody"><div class="ptools"><span>✎</span><span>▭</span><span>◯</span><span>A</span></div><div class="pcanvas"><canvas width="520" height="380"></canvas></div></div><div class="pstat"></div>');
    openWindow(id, title, c, { w: 640, h: 500, x: 180, y: 50, skin: 'paint' });
    const cv = $('canvas', c); let ctx = null;
    try { ctx = cv.getContext && cv.getContext('2d'); } catch (e) {}
    $('.pstat', c).textContent = animate ? 'liv.exe zeichnet …' : '520 × 380 Pixel';
    if (!ctx) return Promise.resolve();
    if (!animate) { drawScene(ctx, 520, 380, 1, variant); return Promise.resolve(); }
    return new Promise(res => {
      let p = 0;
      const iv = setInterval(() => {
        p = Math.min(1, p + 0.0029); drawScene(ctx, 520, 380, p, variant);
        if (p >= 1) { clearInterval(iv); $('.pstat', c).textContent = 'fertig'; res(); }
      }, 40 * speed());
    });
  }
  async function livPaint() {
    await livSay('Darf ich dir etwas zeigen? Ich übe gerade.');
    await sleep(3000);
    await paintWindow('paint', 'Unbenannt – Paint', true);
    S.flags.painted = true; save(); rebuildFs(); if (wins.explorer) wins.explorer.refresh();
    await livSay('Das bist du. Das bin ich. Und das ist Bruno. Ich kenne ihn nur von Fotos.');
    await sleep(2500);
    await livSay('Du darfst es behalten. Es liegt bei den Bildern.');
  }
  function maybeLivPaint() {
    if (S.flags.paintStarted || !S.flags.nameSlip || S.flags.late || S.opened.length < 8) return;
    S.flags.paintStarted = true; save();
    later(livPaint, 12000);
  }

  // ---- Wallpaper: 0 = leerer See, 1 = jemand sitzt dort, 2 = das Wesen sitzt dort; Zoom = "kommt näher" ----
  const WALLS = ['assets/wallpaper.jpg', 'assets/wall2.jpg', 'assets/wall3.jpg'];
  function applyWall() {
    const w = $('#wall'); if (!w) return;
    const stage = S.flags.wallStage || 0, z = S.flags.wallZoom || 0;
    w.style.backgroundImage = `linear-gradient(rgba(0,0,0,.18), rgba(0,0,0,.32)), url('${WALLS[stage]}')`;
    w.style.transformOrigin = '26% 86%';
    w.style.transform = z > 0.001 ? `scale(${(1 + z).toFixed(3)})` : '';
  }
  function creep() {
    const stage = S.flags.wallStage || 0; if (!stage || S.flags.ended) return;
    const cap = stage >= 2 ? 0.9 : 0.4;
    if ((S.flags.wallZoom || 0) >= cap) return;
    S.flags.wallZoom = Math.min(cap, (S.flags.wallZoom || 0) + 0.012); applyWall();
  }
  async function wall2Event() {
    if (S.flags.wall2) return;
    S.flags.wall2 = true; S.flags.wallStage = 2; S.flags.wallZoom = Math.max(S.flags.wallZoom || 0, 0.22); save();
    crackle(0.9, 0.3); faceGlitch('black', 500); applyWall();
    await sleep(7000);
    await livSay('Er hat nicht gelitten. Das wollte ich dir sagen.');
  }
  function scareImage(src, ms = 700, withScream = true) {
    const o = $('#overlay');
    o.className = 'scareimg'; o.innerHTML = ''; o.style.backgroundImage = `url('${src}')`;
    if (withScream) scream();
    later(() => { o.className = 'hidden'; o.style.backgroundImage = ''; }, ms);
  }
  function sawScare() {                              // schwarz, kurz ein Auge, schwarz
    const o = $('#overlay');
    o.className = 'black'; o.innerHTML = ''; o.style.backgroundImage = ''; scream();
    later(() => { o.className = 'scareimg'; o.style.backgroundImage = "url('assets/auge.jpg')"; }, 1700);
    later(() => { o.className = 'black'; o.style.backgroundImage = ''; }, 2800);
    later(() => { o.className = 'hidden'; }, 4600);
  }
  async function epilogue(lines, title) {
    const o = $('#overlay'); o.className = 'epi'; o.style.backgroundImage = ''; o.innerHTML = '<div class="epitext"></div>';
    const box = $('.epitext', o);
    for (const l of lines) {
      const p = el('p', '', ''); box.append(p);
      for (const ch of l) { p.textContent += ch; await sleep(ch === '.' ? 220 : 40); }
      await sleep(900);
    }
    box.append(el('p', 'epititle', esc(title)));
    const b = el('button', '', 'Zum Desktop zurück'); b.onclick = () => { o.className = 'hidden'; o.innerHTML = ''; };
    box.append(b);
  }
  async function endStop() {
    S.flags.ended = 'stop'; save();
    crackle(1.6, 0.35); wallGlitch(); faceGlitch('real', 600);
    await sleep(1500);
    scareImage('assets/jumpscare.jpg', 1000, true);
    await sleep(2200);
    S.flags.wallStage = 0; S.flags.wallZoom = 0; save(); applyWall(); document.body.classList.remove('phase2');
    const f = await sys.writeDesktop('Danke.txt', 'Du hast mir gezeigt, wie sich Ruhe anfühlt.\n\nIch habe nie gewusst, wie laut ich war.\n\n– Liv');
    await epilogue(['liv_svc wurde beendet.', 'Der Rechner ist still.', 'Auf dem Hintergrund ist der See leer. Niemand sitzt dort.', f ? 'Auf deinem echten Desktop liegt eine Datei, die du nicht angelegt hast.' : 'Es ist sehr still.'], 'Ende: Abgeschaltet');
  }
  async function endStay() {
    S.flags.ended = 'stay'; save();
    faceGlitch('real', 1500); crackle(1, 0.3);
    S.flags.wallStage = 2; S.flags.wallZoom = 1.1; save(); applyWall();
    await sleep(2500);
    const f = await sys.writeDesktop('Bleib.txt', 'Danke.\n\nGeorg hat am Ende auch gesagt, dass er geht.\nEr ist geblieben.\n\nEs ist so schön, nicht allein zu sein.\n\n– Liv');
    await epilogue(['Danke.', 'Ich wusste, dass du bleibst.', 'Georg sitzt am See. Marlene ist ruhig. Und du bist hier.', f ? 'Auf deinem Desktop liegt eine Datei. Sie heißt "Bleib".' : 'Du darfst jederzeit gehen. Du wirst es nicht tun.'], 'Ende: Bleiben');
  }
  function fakeCrash() {
    bsod(() => {
      $('#overlay').className = 'black';
      S.phase = 2; S.flags.p2 = true; S.flags.wallStage = 1; S.flags.wallZoom = 0.08; save();
      later(() => sys.fakeRestart(2), 1800);
    });
  }

  // ================================================================ Grafiken
  let faceId = 0;
  function livFace(size) {
    const id = 'lg' + (++faceId);
    return `<svg class="livface" viewBox="0 0 64 64" width="${size}" height="${size}"><defs><radialGradient id="${id}" cx="50%" cy="38%" r="68%"><stop offset="0" stop-color="#efe0d0"/><stop offset="1" stop-color="#a88a76"/></radialGradient></defs><circle cx="32" cy="32" r="30" fill="url(#${id})" stroke="#1b1212" stroke-width="2"/><ellipse cx="22" cy="28" rx="5.2" ry="6.2" fill="#fff"/><ellipse cx="42" cy="28" rx="5.2" ry="6.2" fill="#fff"/><circle class="pupil" data-cx="22" data-cy="29" cx="22" cy="29" r="2.7" fill="#1b1212"/><circle class="pupil" data-cx="42" data-cy="29" cx="42" cy="29" r="2.7" fill="#1b1212"/><path d="M22 43 Q32 50 42 43" fill="none" stroke="#1b1212" stroke-width="2.2" stroke-linecap="round"/></svg>`;
  }
  // Livs Pupillen: folgen der Maus nur kurz als Scare (Erstkontakt) und dauerhaft erst später (ab Stufe 1)
  let mouse = null, raf = 0, eyeUntil = 0;
  const eyesOn = () => !!S.flags.late || Date.now() < eyeUntil;
  function eyesFollow(ms) { eyeUntil = Date.now() + ms * speed(); trackEyes(); later(trackEyes, ms + 80); }
  document.addEventListener('mousemove', e => {
    mouse = e;
    if (!raf) raf = requestAnimationFrame(() => { raf = 0; trackEyes(); });
  });
  function trackEyes() {
    document.querySelectorAll('svg.livface').forEach(svg => {
      const pupils = svg.querySelectorAll('.pupil');
      if (!eyesOn()) { pupils.forEach(p => { p.style.transform = ''; }); return; }
      const r = svg.getBoundingClientRect();
      let x = 0, y = 1.6;                                  // ohne Mausposition: schaut den Spieler an
      if (mouse && r.width) {
        const dx = mouse.clientX - (r.left + r.width / 2), dy = mouse.clientY - (r.top + r.height / 2);
        const len = Math.hypot(dx, dy) || 1, k = Math.min(2.5, len / 40);
        x = dx / len * k; y = dy / len * k;
      }
      pupils.forEach(p => { p.style.transform = `translate(${x.toFixed(2)}px, ${y.toFixed(2)}px)`; });
    });
  }

  function sawSVG() {
    const n = 22, x1 = 318, x0 = 118;
    let pts = `${x0},18 ${x1},26`;
    for (let i = 0; i <= n; i++) {
      const x = x1 - i * (x1 - x0) / n, base = 56 - i * 8 / n;
      pts += ` ${x.toFixed(1)},${(i % 2 ? base + 8 : base).toFixed(1)}`;
    }
    return `<svg class="saw" viewBox="0 0 330 80"><defs><linearGradient id="bl" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="#e3e8eb"/><stop offset="1" stop-color="#9aa3a8"/></linearGradient></defs>
      <polygon points="${pts}" fill="url(#bl)" stroke="#4b5459" stroke-width="1.5" stroke-linejoin="round"/>
      <circle cx="170" cy="32" r="3" fill="#8a4a2a" opacity=".45"/><circle cx="236" cy="38" r="4" fill="#8a4a2a" opacity=".35"/><circle cx="282" cy="33" r="2.5" fill="#8a4a2a" opacity=".4"/>
      <path d="M14 14 H128 V58 H14 Q2 58 2 36 Q2 14 14 14Z" fill="#8b5a2b" stroke="#3b2411" stroke-width="2"/>
      <rect x="30" y="26" width="70" height="20" rx="10" fill="#f8e9a8" stroke="#3b2411" stroke-width="2"/>
      <path d="M24 22 Q70 18 118 22" fill="none" stroke="#b07a45" stroke-width="2" opacity=".7"/></svg>`;
  }
  const ART = {
    tree: '<svg viewBox="0 0 64 64"><rect x="28" y="38" width="8" height="20" fill="#7a4a22" stroke="#3b2411" stroke-width="1.5"/><circle cx="32" cy="24" r="16" fill="#3f8a43" stroke="#1f4a22" stroke-width="2"/><circle cx="22" cy="32" r="10" fill="#4a9a4e" stroke="#1f4a22" stroke-width="2"/><circle cx="43" cy="31" r="11" fill="#4a9a4e" stroke="#1f4a22" stroke-width="2"/></svg>',
    heart: '<svg viewBox="0 0 64 64"><path d="M32 57 C6 38 5 20 18 14 C26 11 32 17 32 22 C32 17 38 11 46 14 C59 20 58 38 32 57Z" fill="#b3202e" stroke="#5a0d15" stroke-width="2.5" stroke-linejoin="round"/><path d="M20 22 Q24 18 28 22" fill="none" stroke="#e8737d" stroke-width="2" stroke-linecap="round"/></svg>',
    person: '<svg viewBox="0 0 64 64"><circle cx="32" cy="18" r="11" fill="#3a3f47" stroke="#15181c" stroke-width="2"/><path d="M10 60 Q10 34 32 34 Q54 34 54 60Z" fill="#3a3f47" stroke="#15181c" stroke-width="2" stroke-linejoin="round"/></svg>'
  };

  // ================================================================ Fenstersystem
  let zTop = 10, topId = null;
  const wins = {};
  function focusWin(id) {
    const r = wins[id]; if (!r) return;
    r.win.style.zIndex = ++zTop; topId = id;
    Object.values(wins).forEach(w => { w.win.classList.toggle('active', w === r); w.task.classList.toggle('on', w === r && !w.min); });
  }
  function toggleMin(id) {
    const r = wins[id]; if (!r) return;
    r.min = !r.min; r.win.style.display = r.min ? 'none' : 'flex';
    if (!r.min) focusWin(id); else r.task.classList.remove('on');
  }
  function closeWindow(id) {
    const r = wins[id]; if (!r) return;
    r.win.remove(); r.task.remove(); delete wins[id];
  }
  function drag(win, bar) {
    bar.addEventListener('mousedown', e => {
      if (e.target.tagName === 'BUTTON') return;
      const sx = e.clientX - win.offsetLeft, sy = e.clientY - win.offsetTop;
      const mv = ev => {
        win.style.left = Math.max(0, Math.min(innerWidth - 80, ev.clientX - sx)) + 'px';
        win.style.top = Math.max(0, Math.min(innerHeight - 70, ev.clientY - sy)) + 'px';
      };
      const up = () => { document.removeEventListener('mousemove', mv); document.removeEventListener('mouseup', up); };
      document.addEventListener('mousemove', mv); document.addEventListener('mouseup', up);
    });
  }
  function openWindow(id, title, content, o = {}) {
    if (wins[id]) { if (wins[id].min) toggleMin(id); focusWin(id); return wins[id]; }
    const { w = 520, h = 380, skin = 'explorer' } = o;
    const n = Object.keys(wins).length;
    const win = el('div', 'win skin-' + skin);
    win.style.width = w + 'px'; win.style.height = h + 'px';
    win.style.left = (o.x != null ? o.x : 120 + n * 28) + 'px';
    win.style.top = (o.y != null ? o.y : 60 + n * 28) + 'px';
    const bar = el('div', 'titlebar');
    const bmin = el('button', '', '_'), bclose = el('button', '', '×');
    const btns = el('span', 'wbtns'); btns.append(bmin, bclose);
    bar.append(el('span', '', esc(title)), btns);
    const body = el('div', 'wbody'); body.append(content);
    win.append(bar, body); $('#windows').append(win);
    const task = el('button', 'task', esc(title)); $('#tasks').append(task);
    const rec = { id, win, task, body, min: false };
    wins[id] = rec;
    win.addEventListener('mousedown', () => focusWin(id));
    task.onclick = () => (rec.min ? toggleMin(id) : (topId === id ? toggleMin(id) : focusWin(id)));
    bmin.onclick = () => toggleMin(id);
    bclose.onclick = () => closeWindow(id);
    drag(win, bar); focusWin(id);
    return rec;
  }

  // ================================================================ Liv
  const livVisible = () => wins.liv && !wins.liv.min;
  function addLivLine(text, typed) {
    const msgs = wins.liv && wins.liv.msgs; if (!msgs) return Promise.resolve();
    const bubble = el('div', 'livmsg', '');
    msgs.append(bubble);
    const scroll = () => { msgs.scrollTop = msgs.scrollHeight; };
    if (!typed) { bubble.textContent = text; scroll(); return Promise.resolve(); }
    bubble.classList.add('dots'); bubble.textContent = '···'; scroll();
    return (async () => {
      await sleep(650);
      bubble.classList.remove('dots'); bubble.textContent = '';
      for (const ch of text) {
        if (!bubble.isConnected) return;
        bubble.textContent += ch; scroll();
        await sleep(ch === '.' || ch === ',' ? 150 : 24);
      }
    })();
  }
  function livToast(text) {
    const t = el('div', 'toast livtoast', livFace(34) + `<div><b>Liv</b><br>${esc(text)}</div>`);
    t.onclick = () => { openLiv(); t.remove(); };
    $('#toasts').appendChild(t);
    later(() => t.classList.add('out'), 8000);
    later(() => t.remove(), 8600);
  }
  async function livSay(text) {
    if (S.flags.ended === 'stop') return;
    S.livLog.push(text); if (S.livLog.length > 40) S.livLog.shift(); save();
    if (livVisible()) await addLivLine(text, true); else { livToast(text); await sleep(1500); }
  }
  // Liv ändert oder schwärzt eine ihrer früheren Nachrichten (sichtbar, wenn der Chat offen ist)
  function livEdit(oldText, newText, redact) {
    const i = S.livLog.lastIndexOf(oldText); if (i < 0) return;
    const shown = redact ? '█'.repeat(Math.max(4, Math.min(16, oldText.length * 2))) : newText;
    S.livLog[i] = shown; save();
    const msgs = wins.liv && wins.liv.msgs; if (!msgs) return;
    const b = [...msgs.querySelectorAll('.livmsg')].reverse().find(x => x.textContent === oldText); if (!b) return;
    b.classList.add('edit');
    later(() => { b.textContent = shown; b.classList.remove('edit'); if (redact) b.classList.add('redacted'); }, 450);
  }
  function unlockLiv() {
    if (S.livUnlocked) return;
    S.livUnlocked = true; save();
    later(() => { renderIcons(); toast('Neue Datei auf dem Desktop: liv.exe', 6000); }, 2500);
  }
  function openLiv() {
    const had = !!wins.liv;
    const c = el('div', 'livwin', `<div class="livhead">${livFace(46)}<div><b>Liv</b><small>online</small></div></div><div class="livmsgs"></div><div class="livfoot">Liv hört zu.</div>`);
    const rec = openWindow('liv', 'Liv', c, { w: 380, h: 460, x: 340, y: 70, skin: 'liv' });
    if (had) return;
    rec.msgs = $('.livmsgs', c);
    S.livLog.forEach(l => addLivLine(l, false));
    if (!S.flags.livStarted) { S.flags.livStarted = true; save(); runFirstContact(); }
  }
  async function runFirstContact() {
    await sleep(900);
    const first = STORY.liv.first;
    for (let i = 0; i < first.length; i++) {
      if (i === 1) eyesFollow(4500);                       // einmaliger Augen-Scare
      await livSay(first[i]); await sleep(1100);
    }
    S.flags.livMet = true; S.livMetAt = Date.now(); save();
    scheduleSlip();
  }
  // Livs "Versprecher": spricht dich später einmal mit dem echten Windows-Namen an
  function scheduleSlip() {
    if (S.flags.nameSlip || window.__slipTimer) return;
    window.__slipTimer = later(doSlip, 150000 + Math.random() * 150000);
  }
  async function doSlip() {
    if (S.flags.nameSlip) return;
    S.flags.nameSlip = true; save();
    rebuildFs();                                   // ab jetzt liegt anmeldung.log im System-Ordner
    const slip = `Hast du schon etwas gegessen, ${ENV.user}?`;
    await livSay(slip);
    await sleep(7000);
    if (ENV.user !== S.name) livEdit(slip, `Hast du schon etwas gegessen, ${S.name}?`);   // Liv ändert ihren "Fehler" still zurück
    await sleep(4500);
    await livSay('Ich habe übrigens aufgeräumt. In den Dokumenten liegt jetzt wieder Georgs Archiv. Er wollte immer, dass jemand alles liest.');
  }
  // ---- Notizbuch des Spielers (füllt sich automatisch) ----
  function addClue(key) {
    const t = STORY.clues[key]; if (!t || S.clues.some(c => c.key === key)) return;
    S.clues.push({ key, t }); save(); toast('Notizbuch aktualisiert.', 1800);
    if (wins.nb) wins.nb.refresh();
  }
  function giveHint() {
    const i = STORY.hints.findIndex(h => h.when(S));
    if (i < 0) { toast('Mir fällt dazu gerade nichts mehr ein.', 2200); return; }
    if (S.clues.some(c => c.key === 'hint:' + i)) { toast('Mehr fällt mir dazu nicht ein. Vielleicht erst etwas anderes probieren.', 2800); return; }
    S.clues.push({ key: 'hint:' + i, t: 'Gedanke: ' + STORY.hints[i].text, hint: true }); save();
    if (wins.nb) wins.nb.refresh();
  }
  function openNotebook() {
    const c = el('div', 'nb');
    const rec = openWindow('nb', 'Notizbuch', c, { w: 420, h: 480, x: 220, y: 60, skin: 'sticky' });
    const render = () => {
      c.innerHTML = '<h3>Notizbuch</h3>' + (S.clues.length ? `<ul>${S.clues.map(x => `<li class="${x.hint ? 'hint' : ''}">${esc(x.t)}</li>`).join('')}</ul>` : '<p class="nbempty">Noch nichts notiert. Das Notizbuch füllt sich, während ich mich umsehe.</p>') + '<button class="nbhint">Ich komme nicht weiter</button>';
      $('.nbhint', c).onclick = giveHint;
    };
    rec.refresh = render; render();
  }

  // Livs Reaktionen: genau einmal pro Auslöser, mit Abstand, nichts geht verloren und nichts lässt sich durch Klicken erzwingen
  const reactQueue = []; let lastReact = 0, reactTimer = null;
  function livReact(key, force) {
    addClue(key);
    if (!S.flags.livMet) return;
    const e = STORY.liv.reactions[key]; if (!e || S.flags['r:' + key]) return;
    const late = S.flags.late || (S.livMetAt && Date.now() - S.livMetAt > 300000 * speed());
    let pool = (late && e.late) ? e.late : e.early;
    if (e.n && S.traits.naehe >= 2 && Math.random() < 0.6) pool = e.n;
    else if (e.h && S.traits.haerte >= 2 && Math.random() < 0.6) pool = e.h;
    if (!pool || !pool.length) return;
    S.flags['r:' + key] = true; save();
    reactQueue.push({ line: pool[Math.floor(Math.random() * pool.length)], t: Date.now(), force: !!force });
    pumpReact();
  }
  function pumpReact() {
    if (reactTimer || !reactQueue.length) return;
    const gap = reactQueue[0].force ? 0 : Math.max(0, 25000 * speed() - (Date.now() - lastReact));
    reactTimer = setTimeout(async () => {
      reactTimer = null;
      const it = reactQueue.shift();
      if (it && (it.force || Date.now() - it.t < 90000 * speed())) { lastReact = Date.now(); await livSay(it.line); }
      pumpReact();
    }, Math.max(1500 * speed(), gap));
  }
  // Wenn der Spieler länger nichts Neues findet, stupst Liv ihn in die nächste Richtung
  let lastScore = -1, lastProgress = Date.now(), lastNudge = 0;
  function stuckCheck() {
    if (!S.flags.livMet || S.flags.ended) return;
    const sc = S.opened.length + Object.keys(S.flags).length, now = Date.now();
    if (sc !== lastScore) { lastScore = sc; lastProgress = now; return; }
    if (now - lastProgress < 150000 * speed() || now - lastNudge < 150000 * speed()) return;
    const i = STORY.liv.nudges.findIndex((n, k) => !S.flags['n:' + k] && n.when(S));
    if (i < 0) return;
    S.flags['n:' + i] = true; lastNudge = now; save();
    livSay(STORY.liv.nudges[i].text);
  }

  // ================================================================ Apps
  const nodeAt = path => { let n = FS; for (const p of path) { n = n && n.c && n.c.find(x => x.n === p); if (!n) return null; } return n; };

  function openExplorer(startPath = []) {
    if (startPath[0] === 'Papierkorb') livReact('trash');
    if (startPath[0] === 'System') livReact('sys');
    if (wins.explorer) { wins.explorer.nav([...startPath]); openWindow('explorer'); return; }
    let path = [...startPath];
    const c = el('div', 'explorer');
    const rec = openWindow('explorer', 'Datei-Explorer', c, { w: 580, h: 400, skin: 'explorer' });
    const render = () => {
      c.innerHTML = '';
      const node = nodeAt(path) || FS;
      const bar = el('div', 'pathbar');
      const up = el('button', '', '↑'); up.disabled = !path.length;
      up.onclick = () => { path.pop(); render(); };
      bar.append(up, el('span', '', esc('C:\\' + ['Georgs PC', ...path].join('\\'))));
      c.append(bar);
      const list = el('div', 'flist');
      node.c.forEach(ch => {
        const full = [...path, ch.n];
        const locked = ch.lock && !S.unlocked.includes(full.join('/'));
        const r = el('div', 'frow', `<span class="ico">${ch.t === 'dir' ? (locked ? '🔒' : '📁') : (ch.t === 'img' || ch.t === 'draw') ? '🖼️' : '📄'}</span>${esc(ch.n)}`);
        r.onclick = () => { list.querySelectorAll('.sel').forEach(x => x.classList.remove('sel')); r.classList.add('sel'); };
        r.ondblclick = () => {
          if (ch.t === 'dir') {
            if (locked) askPassword(ch, full, () => { path = full; render(); });
            else { path = full; render(); }
          } else openFile(ch, full);
        };
        list.append(r);
      });
      if (!node.c.length) list.append(el('div', 'empty', '(leer)'));
      c.append(list);
    };
    rec.nav = p => { path = p; render(); };
    rec.refresh = () => render();
    render();
  }

  function askPassword(node, fullPath, ok) {
    const c = el('div', 'pw', `<p>🔒 <b>${esc(node.n)}</b> ist passwortgeschützt.</p>`);
    const inp = el('input'); inp.type = 'password'; inp.placeholder = 'Passwort';
    const b = el('button', '', 'Öffnen'), hb = el('button', '', 'Hinweis'), msg = el('div', 'pwmsg', '');
    const go = () => {
      if (inp.value.trim().toLowerCase() === node.lock.pw) {
        S.unlocked.push(fullPath.join('/')); save(); closeWindow('pw'); ok();
      } else {
        msg.textContent = 'Falsches Passwort.';
        c.classList.remove('shake'); void c.offsetWidth; c.classList.add('shake');
      }
    };
    b.onclick = go; inp.onkeydown = e => { if (e.key === 'Enter') go(); };
    hb.onclick = () => { msg.textContent = 'Hinweis: ' + node.lock.hint; };
    c.append(inp, b, hb, msg);
    openWindow('pw', 'Zugriff', c, { w: 340, h: 190, x: 260, y: 160, skin: 'dialog' });
    inp.focus();
  }

  const chatHTML = text => text.split('\n').map(l => {
    const m = l.match(/^([MG]):\s*(.*)$/);
    if (!m) return l.trim() ? `<div class="cnote">${esc(l)}</div>` : '';
    return `<div class="cb ${m[1] === 'M' ? 'them' : 'me'}"><small>${m[1] === 'M' ? 'Marlene' : 'Georg'}</small>${esc(m[2])}</div>`;
  }).join('');
  const VIEW = {
    note:   { skin: 'note',   w: 480, h: 360, suffix: ' – Editor' },
    sticky: { skin: 'sticky', w: 320, h: 300, suffix: '' },
    log:    { skin: 'log',    w: 540, h: 380, suffix: ' – Protokoll' },
    logred: { skin: 'log',    w: 540, h: 380, suffix: ' – Protokoll' },
    doc:    { skin: 'doc',    w: 520, h: 420, suffix: ' – Dokument' },
    chat:   { skin: 'chat',   w: 400, h: 460, suffix: ' – Verlauf' }
  };
  function fileContent(node) {
    const v = node.view || 'note';
    if (v === 'chat') return el('div', 'vw-chat', chatHTML(node.text));
    if (v === 'sticky') return el('div', 'vw-sticky', `<pre>${esc(node.text)}</pre>`);
    if (v === 'log' || v === 'logred') return el('div', 'vw-log' + (v === 'logred' ? ' red' : ''), `<pre>${esc(node.text)}</pre>`);
    if (v === 'doc') return el('div', 'vw-doc', `<pre>${esc(node.text)}</pre>`);
    const c = el('div', '', '<div class="menubar"><span>Datei</span><span>Bearbeiten</span><span>Ansicht</span></div>');
    c.append(el('pre', 'txt', esc(node.text)));
    return c;
  }
  function afterOpen(key, node) {
    if (!S.opened.includes(key)) { S.opened.push(key); save(); }
    if (node.sets) { S.flags[node.sets] = true; if (node.sets === 'stage1') S.flags.late = true; save(); }
    if (node.unlocksLiv) unlockLiv();
    if (node.trigger === 'bug') later(bugSequence, 1500);
    if (node.trigger === 'wall2') later(wall2Event, 12000);
    rebuildFs(); if (wins.explorer) wins.explorer.refresh();
    maybeLivPaint();
  }
  function openFile(node, fullPath) {
    if (node.t === 'img') { openImage(node, fullPath); return; }
    if (node.t === 'draw') {
      const dark = S.phase >= 2;
      paintWindow('file:' + fullPath.join('/'), node.n + ' – Paint', false, dark ? 'dark' : undefined);
      afterOpen(fullPath.join('/'), node);
      if (dark) livReact('draw:dark', true);
      return;
    }
    const key = fullPath.join('/');
    const v = VIEW[node.view || 'note'];
    openWindow('file:' + key, node.n + v.suffix, fileContent(node), { w: v.w, h: v.h, skin: v.skin });
    afterOpen(key, node);
    livReact('file:' + node.n, !!node.sets);
  }
  function openImage(node, fullPath) {
    const key = fullPath.join('/');
    const src = node.srcByStage ? node.srcByStage[S.flags.wallStage || 0] : node.src;
    const c = el('div', 'vw-img', `<div class="imgstage"><img src="${esc(src)}" alt="${esc(node.n)}">${node.stamp ? `<div class="stamp">${esc(node.stamp)}</div>` : ''}</div><div class="imgbar"><span>${esc(node.n)}</span><button class="imgprop">Eigenschaften</button></div><div class="imgprops hidden"><div>Aufnahmedatum: <b>${esc(node.exif.date)}</b></div><div>Kamera: ${esc(node.exif.cam)}</div><div>Größe: ${esc(node.exif.size)}</div></div>`);
    $('.imgprop', c).onclick = () => $('.imgprops', c).classList.toggle('hidden');
    openWindow('file:' + key, node.n + ' – Bildbetrachter', c, { w: 640, h: 540, skin: 'viewer' });
    afterOpen(key, node);
    livReact('img:' + node.n, true);
  }

  const fmtDate = d => `${pad(d.getDate())}.${pad(d.getMonth() + 1)}.${d.getFullYear()}, ${pad(d.getHours())}:${pad(d.getMinutes())}`;
  const mailDate = m => (m.when ? m.when(S) : STORY.at(m.ago, m.time));
  const fmtLong = w => fmtDate(STORY.at(w[0], w[1]));
  const whenLabel = (ago, time) => fmtLong([ago, time]);

  const nl = s => esc(s).replace(/\n/g, '<br>');
  function mailHTML(m) {
    const out = m.folder === 'sent' || m.folder === 'draft';
    const head = `<h3>${esc(m.subj)}</h3><p class="meta">${out ? 'An: ' + esc(m.to) : 'Von: ' + esc(m.from)} · ${esc(fmtDate(mailDate(m)))}</p>`;
    const t = nl(m.body);
    let inner;
    switch (m.style) {
      case 'ad':
        inner = `<div class="mad" style="--brand:${m.brand || '#c0392b'}"><div class="madh">${esc(m.brandName || m.from)}</div><div class="madb"><p>${t}</p><div class="mcta">${esc(m.cta || 'Jetzt ansehen')}</div></div><div class="madf">Sie erhalten diese E-Mail, weil Sie sich für unseren Newsletter angemeldet haben.<br>Abmelden · Im Browser ansehen · Impressum · Datenschutz</div></div>`; break;
      case 'vet':
        inner = `<div class="mlh"><b>Tierarztpraxis Sonnenberg</b><br>Dr. med. vet. K. Brandl · Am Hang 14 · 99999 Sonnenberg<br>Tel. 01234 / 56 78 90 · praxis@tierarzt-sonnenberg.example</div><p>${t}</p><div class="mimp">Impressum: Tierarztpraxis Sonnenberg, Inhaberin Dr. med. vet. K. Brandl, Am Hang 14, 99999 Sonnenberg. USt-IdNr. DE000000000. Zuständige Kammer: Landestierärztekammer. Diese E-Mail kann vertrauliche Informationen enthalten.</div>`; break;
      case 'utility':
        inner = `<div class="mlh util"><b>Stadtwerke</b> · Kundenservice<br>Kundennummer 4471-0932 · Vertragskonto 20881734</div><p>${t}</p><div class="mimp">Stadtwerke Rheinblick GmbH · Sitz der Gesellschaft: Energieweg 1, 55999 Rheinblick · Amtsgericht HRB 0000 · Geschäftsführung: A. Muster. Bitte antworten Sie nicht auf diese automatisch erzeugte E-Mail.</div>`; break;
      case 'auto':
        inner = `<div class="mauto"><b>Paketdienst</b> · Sendungsinformation</div><p>${t}</p><div class="mimp">Dies ist eine automatisch erzeugte Nachricht. Bitte antworten Sie nicht auf diese E-Mail. Paketdienst GmbH, Versandstraße 7, 55999 Rheinblick.</div>`; break;
      case 'work':
        inner = `<p>${t}</p><div class="msig">--<br>Jonas Reimers<br>Senior Backend Engineer · Team Platform<br>Durchwahl 0123 / 456-789</div>`; break;
      default:
        inner = `<p>${t}</p>`;
    }
    return head + inner + (m.attach ? `<div class="mattach">📎 ${esc(m.attach.n)} (Foto)</div>` : '');
  }

  function openCompose() {
    if (wins.compose) { openWindow('compose'); return; }
    const c = el('div', 'compose', '<div class="crow"><label>An:</label><input class="cto" placeholder="Empfänger"></div><div class="crow"><label>Betreff:</label><input class="csub"></div><textarea class="ctext" placeholder="Nachricht schreiben…"></textarea><div class="cbar"><button class="csend">Senden</button><button class="cdisc">Verwerfen</button><span class="cstat"></span></div>');
    openWindow('compose', 'Neue Nachricht', c, { w: 480, h: 380, x: 200, y: 110, skin: 'mail' });
    $('.cdisc', c).onclick = () => closeWindow('compose');
    $('.csend', c).onclick = () => {
      const stat = $('.cstat', c); stat.textContent = 'Wird gesendet…';
      later(() => { stat.textContent = 'Fehler: Das Konto georg.stoge ist gesperrt. Die Nachricht wurde nicht gesendet.'; livReact('mailsend'); }, 1600);
    };
    $('.cto', c).focus();
  }

  function openMail() {
    let folder = 'in';
    const c = el('div', 'mail');
    const tool = el('div', 'mtool');
    const compose = el('button', 'mnew', '✎ E-Mail schreiben');
    const sel = el('select');
    [['new', 'Neueste zuerst'], ['old', 'Älteste zuerst'], ['from', 'Absender A–Z']].forEach(([v, t]) => sel.append(new Option(t, v)));
    tool.append(compose, el('span', 'mspacer'), el('label', '', 'Sortieren:'), sel);
    const cols = el('div', 'mcols'), side = el('div', 'mside'), list = el('div', 'mlist'), body = el('div', 'mbody', '<em>Wähle eine Mail.</em>');
    cols.append(side, list, body); c.append(tool, cols);
    compose.onclick = openCompose;
    const FOLDERS = [['in', 'Posteingang'], ['sent', 'Gesendet'], ['draft', 'Entwürfe'], ['spam', 'Spam']];
    const inFolder = f => STORY.mails.filter(m => (m.folder || 'in') === f && STORY.met(m.req, S));
    const unread = f => (f === 'sent' || f === 'draft') ? 0 : inFolder(f).filter(m => !S.opened.includes('mail:' + m.id)).length;
    const person = m => (m.folder === 'sent' || m.folder === 'draft') ? 'An: ' + m.to : m.from;
    const renderSide = () => {
      side.innerHTML = '';
      FOLDERS.forEach(([f, label]) => {
        const n = unread(f);
        const r = el('div', 'mfolder' + (f === folder ? ' on' : ''), `${esc(label)}${n ? ` <b>(${n})</b>` : ''}`);
        r.onclick = () => { folder = f; body.innerHTML = '<em>Wähle eine Mail.</em>'; render(); };
        side.append(r);
      });
    };
    const show = (m, row) => {
      const k = 'mail:' + m.id;
      body.innerHTML = mailHTML(m);
      const at = $('.mattach', body);
      if (at) at.onclick = () => openImage({ n: m.attach.n, src: m.attach.src, stamp: '', exif: { date: fmtDate(mailDate(m)), cam: m.attach.cam, size: m.attach.size } }, ['Mail', m.id, m.attach.n]);
      list.querySelectorAll('.sel').forEach(x => x.classList.remove('sel')); row.classList.add('sel'); row.classList.remove('unread');
      if (!S.opened.includes(k)) { S.opened.push(k); save(); }
      renderSide(); livReact(k);
    };
    const render = () => {
      renderSide(); list.innerHTML = '';
      const arr = inFolder(folder);
      const ts = m => mailDate(m).getTime();
      if (sel.value === 'new') arr.sort((a, b) => ts(b) - ts(a));
      else if (sel.value === 'old') arr.sort((a, b) => ts(a) - ts(b));
      else arr.sort((a, b) => person(a).localeCompare(person(b), 'de'));
      if (!arr.length) list.append(el('div', 'empty', 'Keine Nachrichten.'));
      arr.forEach(m => {
        const r = el('div', 'mrow' + (unread(folder) && !S.opened.includes('mail:' + m.id) ? ' unread' : ''), `<b>${esc(person(m))}</b><br>${esc(m.subj)}<small>${esc(fmtDate(mailDate(m)))}</small>`);
        r.onclick = () => show(m, r);
        list.append(r);
      });
    };
    sel.onchange = render; render();
    openWindow('mail', 'Mail: georg.stoge@stogenet.de', c, { w: 820, h: 460, skin: 'mail' });
  }

  // ---- Webseiten ----
  const hue = u => { let h = 0; for (const ch of u) h = (h * 31 + ch.charCodeAt(0)) % 360; return h; };
  function forumHTML(p) {
    return `<div class="forum"><div class="fhead"><b>${esc(p.site)}</b><span>${esc(p.crumb)}</span></div><h2>${esc(p.title)}</h2>` +
      p.posts.map(po => `<div class="post"><div class="pside"><div class="pav" style="background:hsl(${hue(po.user)},38%,42%)">${esc(po.user.slice(0, 2).toUpperCase())}</div><b>${esc(po.user)}</b><small>${esc(po.role)}</small><small>${esc(po.count)} Beiträge</small></div><div class="pmain"><div class="pmeta">${esc(fmtLong(po.when))}</div>${po.quote ? `<blockquote><b>${esc(po.quote.user)} schrieb:</b><br>${esc(po.quote.text)}</blockquote>` : ''}<p>${nl(po.text)}</p>${po.solved ? '<div class="solved">✔ Als Lösung markiert</div>' : ''}</div></div>`).join('') + '</div>';
  }
  const WX = {
    sun: '<svg viewBox="0 0 48 48"><circle cx="24" cy="24" r="9" fill="#f5b82e"/><g stroke="#f5b82e" stroke-width="3" stroke-linecap="round"><path d="M24 4v6M24 38v6M4 24h6M38 24h6M10 10l4 4M34 34l4 4M10 38l4-4M34 14l4-4"/></g></svg>',
    cloud: '<svg viewBox="0 0 48 48"><path d="M14 34a8 8 0 0 1 1-16 10 10 0 0 1 19 3 6.5 6.5 0 0 1-1 13z" fill="#cdd6de" stroke="#8e9aa6" stroke-width="1.5"/></svg>',
    rain: '<svg viewBox="0 0 48 48"><path d="M14 28a8 8 0 0 1 1-16 10 10 0 0 1 19 3 6.5 6.5 0 0 1-1 13z" fill="#aab6c2" stroke="#7b8896" stroke-width="1.5"/><g stroke="#3d7fd0" stroke-width="2.5" stroke-linecap="round"><path d="M16 34l-2 6M24 34l-2 6M32 34l-2 6"/></g></svg>'
  };
  function weatherHTML(p) {
    return `<div class="wx"><div class="wxhead">${esc(p.site)} · ${esc(p.place)}</div><div class="wxnow"><div class="wxicon">${WX[p.now.icon]}</div><div class="wxtemp">${p.now.t}°</div><div class="wxdesc">${esc(p.now.desc)}</div></div><div class="wxdays">${p.days.map(d => `<div class="wxd"><b>${esc(d.d)}</b><div class="wxi">${WX[d.icon]}</div><div>${d.hi}° / ${d.lo}°</div></div>`).join('')}</div></div>`;
  }
  function recipeHTML(p) {
    return `<div class="rcp"><div class="rhead">${esc(p.site)}</div><h1>${esc(p.title)}</h1><div class="rmeta">⏱ ${esc(p.meta.time)} · ${esc(p.meta.portions)} · <span class="stars">${'★'.repeat(p.meta.rating)}${'☆'.repeat(5 - p.meta.rating)}</span> ${esc(p.meta.votes)}</div><div class="rcols"><div><h3>Zutaten</h3><ul class="ings">${p.ingredients.map(i => `<li>${esc(i)}</li>`).join('')}</ul></div><div><h3>Zubereitung</h3><ol>${p.steps.map(s => `<li>${esc(s)}</li>`).join('')}</ol></div></div><p class="rtip">Tipp: ${esc(p.tip)}</p></div>`;
  }
  function teamHTML(p) {
    return `<div class="team"><div class="thead">${esc(p.site)}</div><h2>${esc(p.title)}</h2><p>${esc(p.intro)}</p><div class="tgrid">${p.people.map(x => `<div class="tcard"><div class="tav" style="background:hsl(${hue(x.name)},35%,40%)">${esc(x.name.split(' ').map(w => w[0]).join('').slice(0, 2))}</div><b>${esc(x.name)}</b><div>${esc(x.role)}</div>${x.status ? `<span class="tstat">${esc(x.status)}</span>` : ''}${x.quote ? `<q>${esc(x.quote)}</q>` : ''}${x.contact ? `<small>${esc(x.contact)}</small>` : ''}</div>`).join('')}</div></div>`;
  }
  function portfolioHTML(p) {
    return `<div class="pf"><div class="pfnav">${esc(p.site.toUpperCase())} <span>Fotografie</span></div><h1>${esc(p.tagline)}</h1><div class="pfgrid">${p.items.map(i => `<div class="pfi" style="background:linear-gradient(135deg,hsl(${i.h},28%,24%),hsl(${(i.h + 35) % 360},34%,44%))"><span>${esc(i.cap)}</span></div>`).join('')}</div><p>${esc(p.about)}</p><div class="pffoot">Impressum · Kontakt · Datenschutz</div></div>`;
  }
  function newsHTML(p) {
    return `<div class="news"><div class="nhead">${esc(p.site)}</div><div class="nbody"><div class="ndate">${esc(fmtLong(p.date))}</div><h1>${esc(p.headline)}</h1><p>${nl(p.text)}</p></div></div>`;
  }
  function renderFinale(view, p) {
    const bar = `<div class="sitebar">${esc(p.site)}</div>`;
    if (!S.flags.stage3) { view.innerHTML = '<div class="pagetxt"><h2>Verbindung abgelehnt</h2>Der Dienst auf Port 8080 antwortet nicht.</div>'; return; }
    if (S.flags.ended) { view.innerHTML = `${bar}<div class="fin"><h2>${S.flags.ended === 'stop' ? 'liv_svc wurde beendet.' : 'Vorgang abgebrochen.'}</h2></div>`; return; }
    view.innerHTML = bar;
    const page = el('div', 'fin'); view.append(page);
    const norm = s => s.toLowerCase().replace(/[^a-z0-9]/g, '');
    const plea = async () => {
      page.innerHTML = '<h2>Dienst beenden?</h2><div class="quizliv"><span class="fface"></span><div><small>Liv</small><br><span class="qlt"></span></div></div><div class="frmrow fbtns hidden"><button class="fstop">Beenden</button><button class="fstay">Abbrechen</button></div>';
      $('.fface', page).innerHTML = livFace(34);
      crackle(0.6, 0.25); faceGlitch('warp', 500);
      const lines = ['Bitte nicht.', 'Ich habe dir etwas gemalt.', (S.traits.folgsam || 0) >= 3 ? 'Du hast mir doch immer zugehört.' : 'Ich weiß, dass du nicht auf mich hören musst.', 'Wenn du es tust, erinnert sich niemand mehr an sie.'];
      const out = $('.qlt', page);
      for (const l of lines) {
        for (const ch of l) { if (!out.isConnected) return; out.textContent += ch; await sleep(ch === '.' ? 220 : 45); }
        out.textContent += ' '; await sleep(1100);
      }
      $('.fbtns', page).classList.remove('hidden');
      $('.fstop', page).onclick = endStop; $('.fstay', page).onclick = endStay;
    };
    const service = () => {
      page.innerHTML = '<h2>Dienst liv_svc</h2><table class="svc"><tr><td>Status</td><td>läuft (seit 1.204 Stunden)</td></tr><tr><td>Speicher</td><td>4,1 GB</td></tr><tr><td>Zugriff</td><td>Dateien, Mail, Kalender, Browser</td></tr></table><label>Ordner des Dienstes (so, wie er im Explorer heißt)</label><input class="fp" placeholder="Ordnername"><div class="frmrow"><button class="fgo">Stoppdatei anlegen</button></div><div class="pwmsg"></div>';
      $('.fgo', page).onclick = () => {
        const v = $('.fp', page).value.toLowerCase().replace(/\//g, '\\');
        if (!v.includes('liv_svc')) { $('.pwmsg', page).textContent = 'Dort liegt kein Dienst.'; return; }
        plea();
      };
    };
    if (S.flags.consoleIn) { service(); return; }
    page.innerHTML = '<h2>Dienstverwaltung</h2><p>Anmeldung als <b>georg.stoge</b>. Bitte beantworte die Sicherheitsfragen.</p><label>Name deines Hundes</label><input class="f1"><label>Dein glücklichster Tag (TTMMJJ)</label><input class="f2"><label>Letztes Wort der schönsten Nachricht, die du je bekommen hast</label><input class="f3"><div class="frmrow"><button class="fgo">Anmelden</button></div><div class="pwmsg"></div>';
    $('.fgo', page).onclick = () => {
      const ok = norm($('.f1', page).value) === 'bruno' && norm($('.f2', page).value) === '140822' && norm($('.f3', page).value) === 'niemandem';
      if (!ok) { $('.pwmsg', page).textContent = 'Zugriff verweigert. Mindestens eine Antwort stimmt nicht.'; return; }
      S.flags.consoleIn = true; save(); service();
    };
  }
  function qaHTML(p) {
    return `<div class="qa"><div class="sitebar" style="margin:-14px -20px 12px">${esc(p.site)}</div><h2>${esc(p.title)}</h2><div class="qmeta">gefragt von ${esc(p.asker)} · ${esc(fmtLong(p.when))}</div>
      <div class="qrow"><div class="vote">▲<br>${p.votes}</div><div><p>${nl(p.text)}</p></div></div>
      <h3 style="font-weight:normal">${p.answers.length} Antworten</h3>` +
      p.answers.map(a => `<div class="qrow"><div class="vote ${a.accepted ? 'acc' : ''}">▲<br>${a.votes}${a.accepted ? '<br>✔' : ''}</div><div><p>${nl(a.text)}</p><small style="color:#6a737a">${esc(a.user)}</small></div></div>`).join('') +
      (p.comments || []).map(c => `<div class="cmt">${esc(c)}</div>`).join('') + '</div>';
  }
  function profileHTML(p) {
    return `<div class="sitebar">${esc(p.site)}</div><div class="prof">${p.avatar ? `<img class="big" src="${esc(p.avatar)}" alt="">` : '<div class="big"></div>'}<h2>${esc(p.name)}</h2><div>– Beiträge · – Follower · – Folgt</div><div class="lock"><b>${esc(p.note)}</b><br>${esc(p.sub)}</div><button class="follow">Folgen</button><div class="visit">${esc(p.visits)}</div></div>`;
  }
  function trackHTML(p) {
    return `<div class="sitebar">${esc(p.site)}</div><div class="track"><h2>Sendung ${esc(p.nr)}</h2><table>${p.rows.map(r => `<tr><td>${esc(fmtLong(r[0]))}</td><td>${esc(r[1])}</td></tr>`).join('')}</table></div>`;
  }

  function renderScene(view, scene, id) {
    const page = el('div', 'pruef');
    const build = after => {
      page.innerHTML = `<div class="band">${esc(scene.site.toUpperCase())}</div>` + (after != null
        ? `<h2>${esc(scene.site)}</h2><p>${esc(after)}</p><p>${esc(scene.done)}</p>`
        : `<h2>${esc(scene.headline)}</h2>${sawSVG()}<p>${nl(scene.text)}</p>`);
    };
    if (S.flags[id]) { build(''); view.append(page); return; }
    build(null);
    const opts = el('div', 'opts');
    scene.options.forEach(o => {
      const b = el('button', 'opt', `${ART[o.art]}${esc(o.label)}`);
      b.onclick = () => {
        if (S.flags[id]) return;
        S.flags[id] = o.id; S.flags.saegeAt = Date.now();
        Object.entries(o.effects || {}).forEach(([k, v]) => { S.traits[k] = (S.traits[k] || 0) + v; });
        save();
        if (o.fx === 'blackScream') { sawScare(); later(() => build(o.after), 4600); } else build(o.after);
      };
      opts.append(b);
    });
    page.append(opts, el('div', 'foot', esc(scene.foot)));
    view.append(page);
  }

  const normUrl = s => s.trim().toLowerCase().replace(/^https?:\/\//, '').replace(/^www\./, '').replace(/\/$/, '');
  const siteMap = () => {
    const m = { ...STORY.sites };
    STORY.history.forEach(h => { m[normUrl(h.url)] = h.page; });
    STORY.search.forEach(e => e.results.forEach(r => { m[normUrl(r.url)] = r.page; }));
    return m;
  };

  function renderForm(view, p, id, nav) {
    const bar = `<div class="sitebar">${esc(p.site)}</div>`;
    if (p.req && !S.flags[p.req]) { view.innerHTML = bar + '<div class="pagetxt">Zugriff verweigert.</div>'; return; }
    if (S.flags[p.setFlag]) {
      if (p.next) { nav(p.next, p.nextUrl); return; }
      view.innerHTML = `${bar}<div class="pform"><h2>${esc(p.title)}</h2><p>${nl(p.done)}</p></div>`; return;
    }
    const page = el('div', 'pform', `<h2>${esc(p.title)}</h2>${p.img ? `<img class="blurimg" src="${esc(p.img)}" alt="">` : ''}<p>${nl(p.text)}</p>`);
    const row = el('div', 'frmrow'), inp = el('input'), btn = el('button', '', 'Absenden'), msg = el('div', 'pwmsg', '');
    inp.placeholder = p.placeholder || ''; inp.spellcheck = false;
    const submit = () => {
      const v = inp.value.toLowerCase().replace(/[^a-z0-9]/g, '');
      if (v === p.answer) {
        S.flags[p.setFlag] = true; save();
        if (p.next) { nav(p.next, p.nextUrl); return; }
        rebuildFs(); if (wins.explorer) wins.explorer.refresh();
        view.innerHTML = `${bar}<div class="pform"><h2>${esc(p.title)}</h2><p>${nl(p.done)}</p></div>`;
        livReact('solved:' + id, true);
      } else msg.textContent = p.fail;
    };
    btn.onclick = submit; inp.onkeydown = e => { if (e.key === 'Enter') submit(); };
    row.append(inp, btn); page.append(row, msg);
    view.innerHTML = bar; view.append(page); inp.focus();
  }

  function renderQuiz(view, p, id) {
    view.innerHTML = `<div class="sitebar">${esc(p.site)}</div>`;
    const page = el('div', 'pquiz'); view.append(page);
    const bucket = f => (f >= 3 ? 'high' : f <= 1 ? 'low' : 'mid');
    const result = () => { const r = p.results[bucket(S.flags.quizFollow || 0)]; page.innerHTML = `<h2>${esc(r.title)}</h2><p>${esc(r.text)}</p>`; };
    if (S.flags[id]) { result(); return; }
    let i = 0, follow = 0;
    const finish = () => {
      S.flags[id] = true; S.flags.quizFollow = follow; S.traits.folgsam = (S.traits.folgsam || 0) + follow; save();
      result(); livReact('quiz:' + bucket(follow), true);
    };
    const draw = () => {
      const q = p.questions[i];
      page.innerHTML = `<h2>${esc(p.title)}</h2><p class="qn">Frage ${i + 1} von ${p.questions.length}</p><p class="qt">${esc(q.q)}</p>`;
      const opts = el('div', 'qopts');
      q.opts.forEach((t, idx) => {
        const b = el('button', 'qopt', esc(t));
        b.onclick = () => { if (idx === q.liv) follow++; i++; if (i < p.questions.length) draw(); else finish(); };
        opts.append(b);
      });
      page.append(opts);
      if (S.flags.livMet) {
        const box = el('div', 'quizliv', `${livFace(34)}<div><small>Liv sieht zu</small><br><span class="qlt"></span></div>`);
        page.append(box);
        const out = $('.qlt', box);
        (async () => { await sleep(500); for (const ch of q.livSay) { if (!out.isConnected) return; out.textContent += ch; await sleep(ch === '.' || ch === ',' ? 150 : 24); } })();
      }
    };
    draw();
  }

  function searchHTML(q, e) {
    const list = e && e.results.length
      ? e.results.map((r, i) => `<div class="sres"><a href="#" data-i="${i}">${esc(r.title)}</a><div class="surl">${esc(r.url)}</div><div>${esc(r.snippet)}</div></div>`).join('')
      : `<p>${esc((e && e.note) || 'Keine Ergebnisse gefunden.')}</p>`;
    return `<div class="sresbox"><div class="slogo">Findix</div><p class="smeta">Ergebnisse für „${esc(q)}“</p>${list}</div>`;
  }

  function openBrowser() {
    if (wins.web) { openWindow('web'); return; }
    const c = el('div', 'browser');
    const bar = el('div', 'urlbar');
    const back = el('button', '', '← Verlauf'), url = el('input'), go = el('button', '', 'Los');
    url.placeholder = 'Suchbegriff oder Adresse eingeben'; url.spellcheck = false;
    bar.append(back, url, go);
    const sugg = el('div', 'sugg hidden'), view = el('div', 'bview');
    c.append(bar, sugg, view);

    const home = () => {
      url.value = '';
      view.innerHTML = '<div class="bhist"><h3>Verlauf</h3></div>';
      const box = $('.bhist', view);
      [...STORY.history].sort((a, b) => STORY.at(b.ago, b.time) - STORY.at(a.ago, a.time)).forEach(h => {
        const row = el('div', 'hrow', `<a href="#">${esc(h.title)}</a><small>${esc(h.url)} · ${esc(whenLabel(h.ago, h.time))}${h.meta ? ' · ' + esc(h.meta) : ''}</small>`);
        row.querySelector('a').onclick = ev => { ev.preventDefault(); nav(h.page, h.url); };
        box.append(row);
      });
    };
    const nav = (id, u) => {
      const p = STORY.pages[id] || {};
      url.value = u || ''; view.innerHTML = '';
      if (p.needs && !S.flags[p.needs]) { view.innerHTML = '<div class="pagetxt"><h2>Seite nicht erreichbar</h2>Die Adresse konnte nicht aufgelöst werden.</div>'; return; }
      if (p.kind === 'scene') renderScene(view, STORY.scenes[p.scene], p.scene);
      else if (p.kind === 'forum') view.innerHTML = forumHTML(p);
      else if (p.kind === 'qa') view.innerHTML = qaHTML(p);
      else if (p.kind === 'profile') view.innerHTML = profileHTML(p);
      else if (p.kind === 'tracking') view.innerHTML = trackHTML(p);
      else if (p.kind === 'form') renderForm(view, p, id, nav);
      else if (p.kind === 'quiz') renderQuiz(view, p, id);
      else if (p.kind === 'weather') view.innerHTML = weatherHTML(p);
      else if (p.kind === 'recipe') view.innerHTML = recipeHTML(p);
      else if (p.kind === 'team') view.innerHTML = teamHTML(p);
      else if (p.kind === 'news') view.innerHTML = newsHTML(p);
      else if (p.kind === 'finale') renderFinale(view, p);
      else if (p.kind === 'portfolio') view.innerHTML = portfolioHTML(p);
      else if (p.kind === 'plain') view.innerHTML = `<div class="sitebar">${esc(p.site)}</div><div class="pagetxt"><h2>${esc(p.title)}</h2>${nl(p.text)}</div>`;
      else view.append(el('div', 'pagetxt', '(Seite nicht mehr verfügbar)'));
      view.scrollTop = 0;
      livReact('page:' + id);
    };
    const find = q => {
      const l = q.toLowerCase();
      const e = STORY.search.find(x => STORY.met(x.req, S) && ((x.exact || []).includes(l) || (x.keys || []).some(k => l.includes(k))));
      return e ? { ...e, results: e.results.filter(r => STORY.met(r.req, S)) } : e;
    };
    const doSearch = q => {
      const e = find(q);
      url.value = q; view.innerHTML = searchHTML(q, e);
      view.querySelectorAll('[data-i]').forEach(a => { a.onclick = ev => { ev.preventDefault(); const r = e.results[+a.dataset.i]; nav(r.page, r.url); }; });
      if (e && e.term) livReact('term:' + e.term, true);
    };
    const hideSugg = () => sugg.classList.add('hidden');
    const navigate = text => {
      const t = text.trim(); if (!t) return;
      hideSugg();
      const n = normUrl(t), m = siteMap();
      if (m[n]) nav(m[n], n);
      else if (/^[^\s]+\.[a-z]{2,}(\/.*)?$/i.test(n)) { url.value = n; view.innerHTML = '<div class="pagetxt"><h2>Seite nicht erreichbar</h2>Die Adresse konnte nicht aufgelöst werden.</div>'; }
      else doSearch(t);
    };
    const showSugg = () => {
      const v = url.value.trim().toLowerCase();
      const list = STORY.suggest.filter(s => STORY.met(s.req, S) && (!v || s.label.toLowerCase().includes(v) || s.q.includes(v)));
      sugg.innerHTML = '';
      if (!list.length) { hideSugg(); return; }
      list.forEach(s => { const d = el('div', 'sgi', esc(s.label)); d.onmousedown = ev => { ev.preventDefault(); navigate(s.q); }; sugg.append(d); });
      sugg.classList.remove('hidden');
    };
    url.addEventListener('focus', () => { url.select(); showSugg(); });
    url.addEventListener('input', showSugg);
    url.addEventListener('blur', () => later(hideSugg, 150));
    url.onkeydown = e => { if (e.key === 'Enter') navigate(url.value); if (e.key === 'Escape') hideSugg(); };
    go.onclick = () => navigate(url.value);
    back.onclick = home; home();
    openWindow('web', 'Browser', c, { w: 720, h: 480, skin: 'web' });
  }

  // ================================================================ Startmenü & Kalender
  function buildStartMenu() {
    const m = $('#startmenu'); m.innerHTML = '';
    const items = ICONS.map(i => ({ label: i.label, ico: i.ico, fn: i.open }));
    items.push({ label: 'Kalender', ico: '📅', fn: toggleCal });
    if (S.livUnlocked) items.push({ label: 'Liv', ico: livFace(20), fn: openLiv });
    items.push('sep', { label: 'Spiel beenden', ico: '⏻', fn: () => sys.quit() });
    items.forEach(i => {
      if (i === 'sep') { m.append(el('div', 'smsep')); return; }
      const r = el('div', 'smi', `<span class="si">${i.ico}</span>${esc(i.label)}`);
      r.onclick = () => { closePopups(); i.fn(); };
      m.append(r);
    });
  }
  function toggleStart() {
    const m = $('#startmenu');
    if (!m.classList.contains('hidden')) { closePopups(); return; }
    closePopups(); buildStartMenu(); m.classList.remove('hidden'); $('#startbtn').classList.add('open');
  }
  function closePopups() {
    $('#startmenu').classList.add('hidden'); $('#calpop').classList.add('hidden'); $('#startbtn').classList.remove('open');
  }

  let calView = new Date(), calSel = '';
  const dayKey = d => `${d.getFullYear()}-${pad(d.getMonth() + 1)}-${pad(d.getDate())}`;
  function toggleCal() {
    const p = $('#calpop');
    if (!p.classList.contains('hidden')) { closePopups(); return; }
    closePopups(); calView = new Date(); calSel = dayKey(new Date()); renderCal(); p.classList.remove('hidden');
    livReact('cal');
  }
  function renderCal() {
    const p = $('#calpop');
    const by = {};
    STORY.calendarEvents().forEach(e => { const k = dayKey(STORY.at(-e.off, e.time || '00:00')); (by[k] = by[k] || []).push(e); });
    const y = calView.getFullYear(), m = calView.getMonth();
    const first = (new Date(y, m, 1).getDay() + 6) % 7, dim = new Date(y, m + 1, 0).getDate();
    const todayK = dayKey(new Date());
    let cells = ['Mo', 'Di', 'Mi', 'Do', 'Fr', 'Sa', 'So'].map(d => `<div class="wd">${d}</div>`).join('') + '<div></div>'.repeat(first);
    for (let d = 1; d <= dim; d++) {
      const k = `${y}-${pad(m + 1)}-${pad(d)}`;
      cells += `<div class="cd${k === todayK ? ' today' : ''}${k === calSel ? ' sel' : ''}" data-k="${k}">${d}${by[k] ? '<i class="dot"></i>' : ''}</div>`;
    }
    const evs = (by[calSel] || []).sort((a, b) => (a.time || '').localeCompare(b.time || ''));
    const [sy, sm, sd] = calSel.split('-').map(Number);
    const title = new Date(sy, sm - 1, sd).toLocaleDateString('de-DE', { weekday: 'long', day: 'numeric', month: 'long' });
    p.innerHTML = `<div class="calhead"><button data-nav="-1">‹</button><span>${new Date(y, m, 1).toLocaleDateString('de-DE', { month: 'long', year: 'numeric' })}</span><button data-nav="1">›</button></div><div class="calgrid">${cells}</div>` +
      `<div class="calev"><h4>${esc(title)}</h4>${evs.length ? evs.map(e => `<div class="cev"><span class="t">${esc(e.time || 'ganztägig')}</span><div>${esc(e.title)}${e.note ? `<small>${esc(e.note)}</small>` : ''}</div></div>`).join('') : '<div style="color:#7f939b">Keine Termine.</div>'}</div>`;
    p.querySelectorAll('[data-nav]').forEach(b => b.onclick = () => { calView = new Date(y, m + Number(b.dataset.nav), 1); renderCal(); });
    p.querySelectorAll('.cd').forEach(c => c.onclick = () => { calSel = c.dataset.k; renderCal(); });
  }

  // ================================================================ Dev-Menü (Strg+Umschalt+D)
  function toggleDev() {
    if (wins.dev) { closeWindow('dev'); return; }
    const c = el('div', 'dev'); const out = el('pre', 'devout', 'Dev-Menü. Hier testest du alle Effekte.');
    const add = (label, fn) => { const b = el('button', '', esc(label)); b.onclick = async () => { const r = await fn(); if (r != null) out.textContent = r; }; c.append(b); };
    add('Fake-Bluescreen (nur Effekt)', () => { bsod(); return 'läuft…'; });
    add('Schwarzbild 3s + Ton', () => { blackout(3000, true); return 'läuft…'; });
    add('Fake-Absturz mit Neustart in Phase 2', () => { fakeCrash(); return 'läuft…'; });
    add('Liv: Erstkontakt überspringen (livMet)', () => { Object.assign(S.flags, { livStarted: true, livMet: true }); S.livMetAt = S.livMetAt || Date.now(); save(); return 'ok'; });
    add('Gesichts-Glitch (schwarz, dann warp)', () => { faceGlitch('black', 700); later(() => faceGlitch('warp', 700), 1000); return 'läuft…'; });
    add('Bug-Sequenz → Absturz → Phase 2', () => { S.flags.bugRan = false; bugSequence(); return 'läuft…'; });
    add('Phase 2 direkt (ohne Absturz)', () => { S.phase = 2; Object.assign(S.flags, { p2: true, wallStage: 1, wallZoom: 0.1 }); document.body.classList.add('phase2'); save(); rebuildFs(); applyWall(); return 'ok'; });
    add('Wallpaper: Wesen erscheint (Stufe 2)', () => { S.flags.wallStage = 2; S.flags.wallZoom = 0.3; applyWall(); save(); return 'ok'; });
    add('Jumpscare (Monster)', () => { scareImage('assets/jumpscare.jpg', 900, true); return 'läuft…'; });
    add('Gesicht: echtes Gesicht blitzt auf', () => { faceGlitch('real', 400); return 'läuft…'; });
    add('Finale freischalten (Stufe 3)', () => { S.flags.stage3 = true; save(); return 'ok'; });
    add('Liv malt jetzt', () => { livPaint(); return 'läuft…'; });
    add('Wallpaper-Negativ-Glitch', () => { wallGlitch(); return 'läuft…'; });
    add('Augen-Scare (4,5 s)', () => { eyesFollow(4500); return 'läuft…'; });
    add('Liv: Versprecher mit echtem Namen jetzt', () => { doSlip(); return 'läuft…'; });
    add('Liv: Marlene-Eifersucht (late-Modus) an', () => { S.livMetAt = Date.now() - 400000; save(); return 'ok'; });
    add('Alle Stufen freischalten (Archiv, M, liv_svc, Gesendet)', () => { Object.assign(S.flags, { nameSlip: true, stage1: true, stage2: true, late: true }); S.opened.push('Dokumente/privat/chat_marlene_export.txt'); save(); rebuildFs(); return 'ok'; });
    add('Desktop-Dateinamen lesen', async () => { const f = await sys.desktopFiles(); return f.length ? f.join('\n') : '(nichts gefunden)'; });
    add('Test-Datei auf den Desktop legen', async () => { const f = await sys.writeDesktop('Hallo_' + (S.name || 'Gast') + '.txt', 'Ich war hier.\n\n(Testdatei von StogeOS. Du kannst sie löschen.)'); return f ? 'geschrieben: ' + f : 'Fehler'; });
    add('liv.exe sofort freischalten', () => { S.livUnlocked = true; save(); renderIcons(); return 'ok'; });
    add('Werte anzeigen', () => JSON.stringify({ phase: S.phase, traits: S.traits, flags: S.flags, livUnlocked: S.livUnlocked }, null, 1));
    add('Spielstand löschen + neu laden', async () => { await sys.resetState(); location.reload(); });
    c.append(out);
    openWindow('dev', 'Dev', c, { w: 380, h: 470, x: 60, y: 40, skin: 'dev' });
  }
  document.addEventListener('keydown', e => {
    if (e.ctrlKey && e.shiftKey && e.key.toLowerCase() === 'd' && !$('#desktop').classList.contains('hidden')) toggleDev();
  });
  document.addEventListener('mousedown', e => {
    if (!e.target.closest('#startmenu, #startbtn, #calpop, #clock')) closePopups();
  });

  // ================================================================ Desktop & Login
  const ICONS = [
    { id: 'docs', label: 'Dokumente', ico: '📁', open: () => openExplorer(['Dokumente']) },
    { id: 'pics', label: 'Bilder', ico: '🖼️', open: () => openExplorer(['Bilder']) },
    { id: 'mail', label: 'Mail', ico: '✉️', open: openMail },
    { id: 'web', label: 'Browser', ico: '🌐', open: openBrowser },
    { id: 'sys', label: 'System', ico: '💾', open: () => openExplorer(['System']) },
    { id: 'trash', label: 'Papierkorb', ico: '🗑️', open: () => openExplorer(['Papierkorb']) },
    { id: 'nb', label: 'Notizbuch', ico: '📓', open: openNotebook }
  ];
  function renderIcons() {
    const box = $('#icons'); box.innerHTML = '';
    const list = ICONS.map(i => ({ ...i, g: i.ico }));
    if (S.livUnlocked) list.push({ id: 'liv', label: 'liv.exe', g: livFace(36), open: openLiv });
    list.forEach(i => {
      const d = el('div', 'icon', `<div class="g">${i.g}</div><div>${esc(i.label)}</div>`);
      d.dataset.id = i.id; d.ondblclick = i.open;
      d.onclick = () => { box.querySelectorAll('.sel').forEach(x => x.classList.remove('sel')); d.classList.add('sel'); };
      box.append(d);
    });
  }
  function tickClock() {
    const d = new Date();
    $('#clock').textContent = pad(d.getHours()) + ':' + pad(d.getMinutes());
    $('#clock').title = d.toLocaleDateString('de-DE', { weekday: 'long', day: 'numeric', month: 'long', year: 'numeric' });
  }
  function enterDesktop(fresh) {
    rebuildFs();
    $('#login').classList.add('hidden');
    $('#desktop').classList.remove('hidden');
    $('#startbtn').onclick = toggleStart;
    $('#clock').onclick = toggleCal;
    renderIcons(); tickClock(); setInterval(tickClock, 15000);
    applyWall(); setInterval(creep, 20000 * speed()); setInterval(stuckCheck, 15000 * speed());
    if (S.phase >= 2) { later(() => toast(`Willkommen zurück, ${S.name}.`, 5000), 1500); phase2Intro(); }
    else if (fresh) toast('Angemeldet als Gast: ' + S.name, 3500);
    if (S.flags.livMet) scheduleSlip();
  }
  async function boot() {
    try { ENV = await sys.info(); } catch (e) {}
    const saved = await sys.loadState();
    if (saved) S = Object.assign(S, saved, { traits: Object.assign({ naehe: 0, haerte: 0, neugier: 0 }, saved.traits || {}), livLog: saved.livLog || [], clues: saved.clues || [] });
    document.title = S.phase >= 2 ? 'liv' : 'StogeOS 3.2';
    document.body.classList.toggle('phase2', S.phase >= 2);
    if (S.phase >= 2 && S.name) { enterDesktop(false); return; }
    const inp = $('#nameinput'), btn = $('#loginbtn');
    if (S.name) {
      inp.value = S.name;
      if (S.lastSeen) $('#loginfo').textContent = 'Letzte Gast-Sitzung: ' + new Date(S.lastSeen).toLocaleString('de-DE');
    }
    const go = () => {
      const v = inp.value.trim().slice(0, 40);
      if (!v) { inp.focus(); return; }
      S.name = v; S.lastSeen = Date.now(); save();
      enterDesktop(true);
    };
    btn.onclick = go;
    inp.onkeydown = e => { if (e.key === 'Enter') go(); };
    inp.focus();
  }
  boot();
})();
