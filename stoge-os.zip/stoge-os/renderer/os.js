(() => {
  'use strict';
  const $ = (s, r = document) => r.querySelector(s);
  const el = (tag, cls, html) => { const e = document.createElement(tag); if (cls) e.className = cls; if (html != null) e.innerHTML = html; return e; };
  const esc = s => String(s).replace(/[&<>"]/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' }[c]));
  const speed = () => window.__SPEED || 1;               // nur für Tests
  const sleep = ms => new Promise(r => setTimeout(r, ms * speed()));
  const later = (fn, ms) => setTimeout(fn, ms * speed());
  const pad = n => String(n).padStart(2, '0');

  // Fallback, falls die Seite im normalen Browser läuft
  const sys = window.sys || {
    info: async () => ({ user: 'browser', host: 'testpc' }),
    desktopFiles: async () => [],
    writeDesktop: async n => n,
    fakeRestart: async () => location.reload(),
    saveState: async s => { try { localStorage.setItem('stoge', JSON.stringify(s)); } catch (e) {} },
    loadState: async () => { try { return JSON.parse(localStorage.getItem('stoge')); } catch (e) { return null; } },
    resetState: async () => { try { localStorage.removeItem('stoge'); } catch (e) {} },
    quit: async () => window.close()
  };

  let ENV = { user: 'gast', host: 'pc' };
  let S = { name: '', phase: 1, traits: { naehe: 0, haerte: 0, neugier: 0 }, flags: {}, unlocked: [], opened: [], livUnlocked: false, lastSeen: null, livLog: [], livMetAt: null };
  let FS = null;
  const save = () => { try { sys.saveState(S); } catch (e) {} };
  const rebuildFs = () => { FS = STORY.buildFs({ name: S.name, user: ENV.user, host: ENV.host, now: new Date(), S }); };

  // ================================================================ Effekte
  function toast(msg, ms = 4000) {
    const t = el('div', 'toast', esc(msg));
    $('#toasts').appendChild(t);
    later(() => t.classList.add('out'), ms);
    later(() => t.remove(), ms + 600);
  }

  let actx = null;
  function scream() { // synthetischer Platzhalter, später durch echte Audiodatei ersetzbar
    try {
      actx = actx || new (window.AudioContext || window.webkitAudioContext)();
      const a = actx, t = a.currentTime;
      const o = a.createOscillator(), g = a.createGain();
      o.type = 'sawtooth';
      o.frequency.setValueAtTime(900, t);
      o.frequency.exponentialRampToValueAtTime(120, t + 1.6);
      g.gain.setValueAtTime(0.0001, t);
      g.gain.exponentialRampToValueAtTime(0.45, t + 0.05);
      g.gain.exponentialRampToValueAtTime(0.0001, t + 1.8);
      o.connect(g); g.connect(a.destination); o.start(t); o.stop(t + 1.9);
      const buf = a.createBuffer(1, Math.floor(a.sampleRate * 1.5), a.sampleRate);
      const d = buf.getChannelData(0);
      for (let i = 0; i < d.length; i++) d[i] = (Math.random() * 2 - 1) * (1 - i / d.length);
      const n = a.createBufferSource(), ng = a.createGain();
      n.buffer = buf; ng.gain.value = 0.35; n.connect(ng); ng.connect(a.destination); n.start(t);
    } catch (e) {}
  }
  function blackout(ms = 3000, withScream = false) {
    const o = $('#overlay');
    o.className = 'black'; o.innerHTML = '';
    if (withScream) scream();
    later(() => { o.className = 'hidden'; }, ms);
  }
  function bsod(done) {
    const o = $('#overlay');
    o.className = 'bsod';
    o.innerHTML = '<div class="face">:(</div><p>StogeOS hat ein Problem festgestellt und muss neu gestartet werden.</p><p class="pc">0% abgeschlossen</p><p class="small">Stoppcode: LIV_NOT_FOUND_IN_MEMORY<br>Betroffene Datei: liv.exe</p>';
    let p = 0;
    const pc = $('.pc', o);
    const iv = setInterval(() => {
      p = Math.min(100, p + Math.floor(Math.random() * 9) + 2);
      pc.textContent = p + '% abgeschlossen';
      if (p >= 100) { clearInterval(iv); later(() => { o.className = 'hidden'; if (done) done(); }, 700); }
    }, 280 * speed());
  }
  function fakeCrash() {
    bsod(() => {
      $('#overlay').className = 'black';
      S.phase = 2; save();
      later(() => sys.fakeRestart(2), 1800);
    });
  }

  // ================================================================ Grafiken
  let faceId = 0;
  function livFace(size) {
    const id = 'lg' + (++faceId);
    return `<svg class="livface" viewBox="0 0 64 64" width="${size}" height="${size}"><defs><radialGradient id="${id}" cx="50%" cy="38%" r="68%"><stop offset="0" stop-color="#efe0d0"/><stop offset="1" stop-color="#a88a76"/></radialGradient></defs><circle cx="32" cy="32" r="30" fill="url(#${id})" stroke="#1b1212" stroke-width="2"/><ellipse cx="22" cy="28" rx="5.2" ry="6.2" fill="#fff"/><ellipse cx="42" cy="28" rx="5.2" ry="6.2" fill="#fff"/><circle class="pupil" data-cx="22" data-cy="29" cx="22" cy="29" r="2.7" fill="#1b1212"/><circle class="pupil" data-cx="42" data-cy="29" cx="42" cy="29" r="2.7" fill="#1b1212"/><path d="M22 43 Q32 50 42 43" fill="none" stroke="#1b1212" stroke-width="2.2" stroke-linecap="round"/></svg>`;
  }
  // Livs Pupillen folgen der Maus (billig und unheimlich)
  let mouse = null, raf = 0;
  document.addEventListener('mousemove', e => {
    mouse = e;
    if (!raf) raf = requestAnimationFrame(() => { raf = 0; trackEyes(); });
  });
  function trackEyes() {
    if (!mouse) return;
    document.querySelectorAll('svg.livface').forEach(svg => {
      const r = svg.getBoundingClientRect(); if (!r.width) return;
      const dx = mouse.clientX - (r.left + r.width / 2), dy = mouse.clientY - (r.top + r.height / 2);
      const len = Math.hypot(dx, dy) || 1, k = Math.min(2.5, len / 40);
      svg.querySelectorAll('.pupil').forEach(p => {
        p.setAttribute('cx', +p.dataset.cx + dx / len * k);
        p.setAttribute('cy', +p.dataset.cy + dy / len * k);
      });
    });
  }

  function sawSVG() {
    const n = 22, x1 = 318, x0 = 118;
    let pts = `${x0},18 ${x1},26`;
    for (let i = 0; i <= n; i++) {
      const x = x1 - i * (x1 - x0) / n, base = 56 - i * 8 / n;
      pts += ` ${x.toFixed(1)},${(i % 2 ? base + 8 : base).toFixed(1)}`;
    }
    return `<svg class="saw" viewBox="0 0 330 80"><defs><linearGradient id="bl" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="#e3e8eb"/><stop offset="1" stop-color="#9aa3a8"/></linearGradient></defs>
      <polygon points="${pts}" fill="url(#bl)" stroke="#4b5459" stroke-width="1.5" stroke-linejoin="round"/>
      <circle cx="170" cy="32" r="3" fill="#8a4a2a" opacity=".45"/><circle cx="236" cy="38" r="4" fill="#8a4a2a" opacity=".35"/><circle cx="282" cy="33" r="2.5" fill="#8a4a2a" opacity=".4"/>
      <path d="M14 14 H128 V58 H14 Q2 58 2 36 Q2 14 14 14Z" fill="#8b5a2b" stroke="#3b2411" stroke-width="2"/>
      <rect x="30" y="26" width="70" height="20" rx="10" fill="#f8e9a8" stroke="#3b2411" stroke-width="2"/>
      <path d="M24 22 Q70 18 118 22" fill="none" stroke="#b07a45" stroke-width="2" opacity=".7"/></svg>`;
  }
  const ART = {
    tree: '<svg viewBox="0 0 64 64"><rect x="28" y="38" width="8" height="20" fill="#7a4a22" stroke="#3b2411" stroke-width="1.5"/><circle cx="32" cy="24" r="16" fill="#3f8a43" stroke="#1f4a22" stroke-width="2"/><circle cx="22" cy="32" r="10" fill="#4a9a4e" stroke="#1f4a22" stroke-width="2"/><circle cx="43" cy="31" r="11" fill="#4a9a4e" stroke="#1f4a22" stroke-width="2"/></svg>',
    heart: '<svg viewBox="0 0 64 64"><path d="M32 57 C6 38 5 20 18 14 C26 11 32 17 32 22 C32 17 38 11 46 14 C59 20 58 38 32 57Z" fill="#b3202e" stroke="#5a0d15" stroke-width="2.5" stroke-linejoin="round"/><path d="M20 22 Q24 18 28 22" fill="none" stroke="#e8737d" stroke-width="2" stroke-linecap="round"/></svg>',
    person: '<svg viewBox="0 0 64 64"><circle cx="32" cy="18" r="11" fill="#3a3f47" stroke="#15181c" stroke-width="2"/><path d="M10 60 Q10 34 32 34 Q54 34 54 60Z" fill="#3a3f47" stroke="#15181c" stroke-width="2" stroke-linejoin="round"/></svg>'
  };

  // ================================================================ Fenstersystem
  let zTop = 10, topId = null;
  const wins = {};
  function focusWin(id) {
    const r = wins[id]; if (!r) return;
    r.win.style.zIndex = ++zTop; topId = id;
    Object.values(wins).forEach(w => { w.win.classList.toggle('active', w === r); w.task.classList.toggle('on', w === r && !w.min); });
  }
  function toggleMin(id) {
    const r = wins[id]; if (!r) return;
    r.min = !r.min; r.win.style.display = r.min ? 'none' : 'flex';
    if (!r.min) focusWin(id); else r.task.classList.remove('on');
  }
  function closeWindow(id) {
    const r = wins[id]; if (!r) return;
    r.win.remove(); r.task.remove(); delete wins[id];
  }
  function drag(win, bar) {
    bar.addEventListener('mousedown', e => {
      if (e.target.tagName === 'BUTTON') return;
      const sx = e.clientX - win.offsetLeft, sy = e.clientY - win.offsetTop;
      const mv = ev => {
        win.style.left = Math.max(0, Math.min(innerWidth - 80, ev.clientX - sx)) + 'px';
        win.style.top = Math.max(0, Math.min(innerHeight - 70, ev.clientY - sy)) + 'px';
      };
      const up = () => { document.removeEventListener('mousemove', mv); document.removeEventListener('mouseup', up); };
      document.addEventListener('mousemove', mv); document.addEventListener('mouseup', up);
    });
  }
  function openWindow(id, title, content, o = {}) {
    if (wins[id]) { if (wins[id].min) toggleMin(id); focusWin(id); return wins[id]; }
    const { w = 520, h = 380, skin = 'explorer' } = o;
    const n = Object.keys(wins).length;
    const win = el('div', 'win skin-' + skin);
    win.style.width = w + 'px'; win.style.height = h + 'px';
    win.style.left = (o.x != null ? o.x : 120 + n * 28) + 'px';
    win.style.top = (o.y != null ? o.y : 60 + n * 28) + 'px';
    const bar = el('div', 'titlebar');
    const bmin = el('button', '', '_'), bclose = el('button', '', '×');
    const btns = el('span', 'wbtns'); btns.append(bmin, bclose);
    bar.append(el('span', '', esc(title)), btns);
    const body = el('div', 'wbody'); body.append(content);
    win.append(bar, body); $('#windows').append(win);
    const task = el('button', 'task', esc(title)); $('#tasks').append(task);
    const rec = { id, win, task, body, min: false };
    wins[id] = rec;
    win.addEventListener('mousedown', () => focusWin(id));
    task.onclick = () => (rec.min ? toggleMin(id) : (topId === id ? toggleMin(id) : focusWin(id)));
    bmin.onclick = () => toggleMin(id);
    bclose.onclick = () => closeWindow(id);
    drag(win, bar); focusWin(id);
    return rec;
  }

  // ================================================================ Liv
  const livVisible = () => wins.liv && !wins.liv.min;
  function addLivLine(text, typed) {
    const msgs = wins.liv && wins.liv.msgs; if (!msgs) return Promise.resolve();
    const bubble = el('div', 'livmsg', '');
    msgs.append(bubble);
    const scroll = () => { msgs.scrollTop = msgs.scrollHeight; };
    if (!typed) { bubble.textContent = text; scroll(); return Promise.resolve(); }
    bubble.classList.add('dots'); bubble.textContent = '···'; scroll();
    return (async () => {
      await sleep(650);
      bubble.classList.remove('dots'); bubble.textContent = '';
      for (const ch of text) {
        if (!bubble.isConnected) return;
        bubble.textContent += ch; scroll();
        await sleep(ch === '.' || ch === ',' ? 150 : 24);
      }
    })();
  }
  function livToast(text) {
    const t = el('div', 'toast livtoast', livFace(34) + `<div><b>Liv</b><br>${esc(text)}</div>`);
    t.onclick = () => { openLiv(); t.remove(); };
    $('#toasts').appendChild(t);
    later(() => t.classList.add('out'), 8000);
    later(() => t.remove(), 8600);
  }
  async function livSay(text) {
    S.livLog.push(text); if (S.livLog.length > 40) S.livLog.shift(); save();
    if (livVisible()) await addLivLine(text, true); else { livToast(text); await sleep(1500); }
  }
  function unlockLiv() {
    if (S.livUnlocked) return;
    S.livUnlocked = true; save();
    later(() => { renderIcons(); toast('Neue Datei auf dem Desktop: liv.exe', 6000); }, 2500);
  }
  function openLiv() {
    const had = !!wins.liv;
    const c = el('div', 'livwin', `<div class="livhead">${livFace(46)}<div><b>Liv</b><small>online</small></div></div><div class="livmsgs"></div><div class="livfoot">Liv hört zu.</div>`);
    const rec = openWindow('liv', 'Liv', c, { w: 380, h: 460, x: 340, y: 70, skin: 'liv' });
    if (had) return;
    rec.msgs = $('.livmsgs', c);
    S.livLog.forEach(l => addLivLine(l, false));
    if (!S.flags.livStarted) { S.flags.livStarted = true; save(); runFirstContact(); }
  }
  async function runFirstContact() {
    await sleep(900);
    for (const line of STORY.liv.first) { await livSay(line); await sleep(1100); }
    S.flags.livMet = true; S.livMetAt = Date.now(); save();
    scheduleSlip();
  }
  // Livs "Versprecher": spricht dich später einmal mit dem echten Windows-Namen an
  function scheduleSlip() {
    if (S.flags.nameSlip || window.__slipTimer) return;
    window.__slipTimer = later(doSlip, 150000 + Math.random() * 150000);
  }
  async function doSlip() {
    if (S.flags.nameSlip) return;
    S.flags.nameSlip = true; save();
    rebuildFs();                                   // ab jetzt liegt anmeldung.log im System-Ordner
    await livSay(`Hast du schon etwas gegessen, ${ENV.user}?`);
    await sleep(6000);
    await livSay('Oh. So heißt du hier ja gar nicht. Vergiss das.');
    await sleep(5000);
    await livSay('Ich habe übrigens aufgeräumt. In den Dokumenten liegt jetzt wieder Georgs Archiv. Er wollte immer, dass jemand alles liest.');
  }
  // Livs gelegentliche, nicht immer gleiche Reaktionen
  let lastReact = 0;
  function livReact(key, force) {
    if (!S.flags.livMet) return;
    const e = STORY.liv.reactions[key]; if (!e) return;
    if (S.flags['r:' + key]) return;
    if (!force && (Date.now() - lastReact < 50000 * speed() || Math.random() > 0.6)) return;
    const late = S.flags.late || (S.livMetAt && Date.now() - S.livMetAt > 300000 * speed());
    let pool = (late && e.late) ? e.late : e.early;
    if (e.n && S.traits.naehe >= 2 && Math.random() < 0.6) pool = e.n;
    else if (e.h && S.traits.haerte >= 2 && Math.random() < 0.6) pool = e.h;
    if (!pool || !pool.length) return;
    S.flags['r:' + key] = true; lastReact = Date.now(); save();
    const line = pool[Math.floor(Math.random() * pool.length)];
    later(() => livSay(line), 1500 + Math.random() * 2000);
  }

  // ================================================================ Apps
  const nodeAt = path => { let n = FS; for (const p of path) { n = n && n.c && n.c.find(x => x.n === p); if (!n) return null; } return n; };

  function openExplorer(startPath = []) {
    if (startPath[0] === 'Papierkorb') livReact('trash');
    if (startPath[0] === 'System') livReact('sys');
    if (wins.explorer) { wins.explorer.nav([...startPath]); openWindow('explorer'); return; }
    let path = [...startPath];
    const c = el('div', 'explorer');
    const rec = openWindow('explorer', 'Datei-Explorer', c, { w: 580, h: 400, skin: 'explorer' });
    const render = () => {
      c.innerHTML = '';
      const node = nodeAt(path) || FS;
      const bar = el('div', 'pathbar');
      const up = el('button', '', '↑'); up.disabled = !path.length;
      up.onclick = () => { path.pop(); render(); };
      bar.append(up, el('span', '', esc('C:\\' + ['Georgs PC', ...path].join('\\'))));
      c.append(bar);
      const list = el('div', 'flist');
      node.c.forEach(ch => {
        const full = [...path, ch.n];
        const locked = ch.lock && !S.unlocked.includes(full.join('/'));
        const r = el('div', 'frow', `<span class="ico">${ch.t === 'dir' ? (locked ? '🔒' : '📁') : '📄'}</span>${esc(ch.n)}`);
        r.onclick = () => { list.querySelectorAll('.sel').forEach(x => x.classList.remove('sel')); r.classList.add('sel'); };
        r.ondblclick = () => {
          if (ch.t === 'dir') {
            if (locked) askPassword(ch, full, () => { path = full; render(); });
            else { path = full; render(); }
          } else openFile(ch, full);
        };
        list.append(r);
      });
      if (!node.c.length) list.append(el('div', 'empty', '(leer)'));
      c.append(list);
    };
    rec.nav = p => { path = p; render(); };
    rec.refresh = () => render();
    render();
  }

  function askPassword(node, fullPath, ok) {
    const c = el('div', 'pw', `<p>🔒 <b>${esc(node.n)}</b> ist passwortgeschützt.</p>`);
    const inp = el('input'); inp.type = 'password'; inp.placeholder = 'Passwort';
    const b = el('button', '', 'Öffnen'), hb = el('button', '', 'Hinweis'), msg = el('div', 'pwmsg', '');
    const go = () => {
      if (inp.value.trim().toLowerCase() === node.lock.pw) {
        S.unlocked.push(fullPath.join('/')); save(); closeWindow('pw'); ok();
      } else {
        msg.textContent = 'Falsches Passwort.';
        c.classList.remove('shake'); void c.offsetWidth; c.classList.add('shake');
      }
    };
    b.onclick = go; inp.onkeydown = e => { if (e.key === 'Enter') go(); };
    hb.onclick = () => { msg.textContent = 'Hinweis: ' + node.lock.hint; };
    c.append(inp, b, hb, msg);
    openWindow('pw', 'Zugriff', c, { w: 340, h: 190, x: 260, y: 160, skin: 'dialog' });
    inp.focus();
  }

  function openFile(node, fullPath) {
    const key = fullPath.join('/');
    const c = el('div', '', `<div class="menubar"><span>Datei</span><span>Bearbeiten</span><span>Ansicht</span></div>`);
    c.append(el('pre', 'txt', esc(node.text)));
    openWindow('file:' + key, node.n + ' – Editor', c, { w: 480, h: 360, skin: 'note' });
    if (!S.opened.includes(key)) { S.opened.push(key); save(); }
    if (node.sets) { S.flags[node.sets] = true; if (node.sets === 'stage1') S.flags.late = true; save(); }
    if (node.unlocksLiv) unlockLiv();
    rebuildFs(); if (wins.explorer) wins.explorer.refresh();
    livReact('file:' + node.n, !!node.sets);
  }

  const fmtDate = d => `${pad(d.getDate())}.${pad(d.getMonth() + 1)}.${d.getFullYear()}, ${pad(d.getHours())}:${pad(d.getMinutes())}`;
  const fmtLong = w => fmtDate(STORY.at(w[0], w[1]));
  const whenLabel = (ago, time) => fmtLong([ago, time]);

  const nl = s => esc(s).replace(/\n/g, '<br>');
  function mailHTML(m) {
    const out = m.folder === 'sent' || m.folder === 'draft';
    const head = `<h3>${esc(m.subj)}</h3><p class="meta">${out ? 'An: ' + esc(m.to) : 'Von: ' + esc(m.from)} · ${esc(fmtDate(STORY.at(m.ago, m.time)))}</p>`;
    const t = nl(m.body);
    let inner;
    switch (m.style) {
      case 'ad':
        inner = `<div class="mad" style="--brand:${m.brand || '#c0392b'}"><div class="madh">${esc(m.brandName || m.from)}</div><div class="madb"><p>${t}</p><div class="mcta">${esc(m.cta || 'Jetzt ansehen')}</div></div><div class="madf">Sie erhalten diese E-Mail, weil Sie sich für unseren Newsletter angemeldet haben.<br>Abmelden · Im Browser ansehen · Impressum · Datenschutz</div></div>`; break;
      case 'vet':
        inner = `<div class="mlh"><b>Tierarztpraxis Sonnenberg</b><br>Dr. med. vet. K. Brandl · Am Hang 14 · 99999 Sonnenberg<br>Tel. 01234 / 56 78 90 · praxis@tierarzt-sonnenberg.example</div><p>${t}</p><div class="mimp">Impressum: Tierarztpraxis Sonnenberg, Inhaberin Dr. med. vet. K. Brandl, Am Hang 14, 99999 Sonnenberg. USt-IdNr. DE000000000. Zuständige Kammer: Landestierärztekammer. Diese E-Mail kann vertrauliche Informationen enthalten.</div>`; break;
      case 'utility':
        inner = `<div class="mlh util"><b>Stadtwerke</b> · Kundenservice<br>Kundennummer 4471-0932 · Vertragskonto 20881734</div><p>${t}</p><div class="mimp">Stadtwerke Beispielstadt GmbH · Sitz der Gesellschaft: Energieweg 1, 99999 Beispielstadt · Amtsgericht HRB 0000 · Geschäftsführung: A. Muster. Bitte antworten Sie nicht auf diese automatisch erzeugte E-Mail.</div>`; break;
      case 'auto':
        inner = `<div class="mauto"><b>Paketdienst</b> · Sendungsinformation</div><p>${t}</p><div class="mimp">Dies ist eine automatisch erzeugte Nachricht. Bitte antworten Sie nicht auf diese E-Mail. Paketdienst GmbH, Versandstraße 7, 99999 Beispielstadt.</div>`; break;
      case 'work':
        inner = `<p>${t}</p><div class="msig">--<br>Jonas Reimers<br>Senior Backend Engineer · Team Platform<br>Durchwahl 0123 / 456-789</div>`; break;
      default:
        inner = `<p>${t}</p>`;
    }
    return head + inner;
  }

  function openCompose() {
    if (wins.compose) { openWindow('compose'); return; }
    const c = el('div', 'compose', '<div class="crow"><label>An:</label><input class="cto" placeholder="Empfänger"></div><div class="crow"><label>Betreff:</label><input class="csub"></div><textarea class="ctext" placeholder="Nachricht schreiben…"></textarea><div class="cbar"><button class="csend">Senden</button><button class="cdisc">Verwerfen</button><span class="cstat"></span></div>');
    openWindow('compose', 'Neue Nachricht', c, { w: 480, h: 380, x: 200, y: 110, skin: 'mail' });
    $('.cdisc', c).onclick = () => closeWindow('compose');
    $('.csend', c).onclick = () => {
      const stat = $('.cstat', c); stat.textContent = 'Wird gesendet…';
      later(() => { stat.textContent = 'Fehler: Das Konto georg.stoge ist gesperrt. Die Nachricht wurde nicht gesendet.'; livReact('mailsend'); }, 1600);
    };
    $('.cto', c).focus();
  }

  function openMail() {
    let folder = 'in';
    const c = el('div', 'mail');
    const tool = el('div', 'mtool');
    const compose = el('button', 'mnew', '✎ E-Mail schreiben');
    const sel = el('select');
    [['new', 'Neueste zuerst'], ['old', 'Älteste zuerst'], ['from', 'Absender A–Z']].forEach(([v, t]) => sel.append(new Option(t, v)));
    tool.append(compose, el('span', 'mspacer'), el('label', '', 'Sortieren:'), sel);
    const cols = el('div', 'mcols'), side = el('div', 'mside'), list = el('div', 'mlist'), body = el('div', 'mbody', '<em>Wähle eine Mail.</em>');
    cols.append(side, list, body); c.append(tool, cols);
    compose.onclick = openCompose;
    const FOLDERS = [['in', 'Posteingang'], ['sent', 'Gesendet'], ['draft', 'Entwürfe'], ['spam', 'Spam']];
    const inFolder = f => STORY.mails.filter(m => (m.folder || 'in') === f && STORY.met(m.req, S));
    const unread = f => (f === 'sent' || f === 'draft') ? 0 : inFolder(f).filter(m => !S.opened.includes('mail:' + m.id)).length;
    const person = m => (m.folder === 'sent' || m.folder === 'draft') ? 'An: ' + m.to : m.from;
    const renderSide = () => {
      side.innerHTML = '';
      FOLDERS.forEach(([f, label]) => {
        const n = unread(f);
        const r = el('div', 'mfolder' + (f === folder ? ' on' : ''), `${esc(label)}${n ? ` <b>(${n})</b>` : ''}`);
        r.onclick = () => { folder = f; body.innerHTML = '<em>Wähle eine Mail.</em>'; render(); };
        side.append(r);
      });
    };
    const show = (m, row) => {
      const k = 'mail:' + m.id;
      body.innerHTML = mailHTML(m);
      list.querySelectorAll('.sel').forEach(x => x.classList.remove('sel')); row.classList.add('sel'); row.classList.remove('unread');
      if (!S.opened.includes(k)) { S.opened.push(k); save(); }
      renderSide(); livReact(k);
    };
    const render = () => {
      renderSide(); list.innerHTML = '';
      const arr = inFolder(folder);
      const ts = m => STORY.at(m.ago, m.time).getTime();
      if (sel.value === 'new') arr.sort((a, b) => ts(b) - ts(a));
      else if (sel.value === 'old') arr.sort((a, b) => ts(a) - ts(b));
      else arr.sort((a, b) => person(a).localeCompare(person(b), 'de'));
      if (!arr.length) list.append(el('div', 'empty', 'Keine Nachrichten.'));
      arr.forEach(m => {
        const r = el('div', 'mrow' + (unread(folder) && !S.opened.includes('mail:' + m.id) ? ' unread' : ''), `<b>${esc(person(m))}</b><br>${esc(m.subj)}<small>${esc(fmtDate(STORY.at(m.ago, m.time)))}</small>`);
        r.onclick = () => show(m, r);
        list.append(r);
      });
    };
    sel.onchange = render; render();
    openWindow('mail', 'Mail: georg.stoge@stogenet.de', c, { w: 820, h: 460, skin: 'mail' });
  }

  // ---- Webseiten ----
  const hue = u => { let h = 0; for (const ch of u) h = (h * 31 + ch.charCodeAt(0)) % 360; return h; };
  function forumHTML(p) {
    return `<div class="forum"><div class="fhead"><b>${esc(p.site)}</b><span>${esc(p.crumb)}</span></div><h2>${esc(p.title)}</h2>` +
      p.posts.map(po => `<div class="post"><div class="pside"><div class="pav" style="background:hsl(${hue(po.user)},38%,42%)">${esc(po.user.slice(0, 2).toUpperCase())}</div><b>${esc(po.user)}</b><small>${esc(po.role)}</small><small>${esc(po.count)} Beiträge</small></div><div class="pmain"><div class="pmeta">${esc(fmtLong(po.when))}</div>${po.quote ? `<blockquote><b>${esc(po.quote.user)} schrieb:</b><br>${esc(po.quote.text)}</blockquote>` : ''}<p>${nl(po.text)}</p>${po.solved ? '<div class="solved">✔ Als Lösung markiert</div>' : ''}</div></div>`).join('') + '</div>';
  }
  function qaHTML(p) {
    return `<div class="qa"><div class="sitebar" style="margin:-14px -20px 12px">${esc(p.site)}</div><h2>${esc(p.title)}</h2><div class="qmeta">gefragt von ${esc(p.asker)} · ${esc(fmtLong(p.when))}</div>
      <div class="qrow"><div class="vote">▲<br>${p.votes}</div><div><p>${nl(p.text)}</p></div></div>
      <h3 style="font-weight:normal">${p.answers.length} Antworten</h3>` +
      p.answers.map(a => `<div class="qrow"><div class="vote ${a.accepted ? 'acc' : ''}">▲<br>${a.votes}${a.accepted ? '<br>✔' : ''}</div><div><p>${nl(a.text)}</p><small style="color:#6a737a">${esc(a.user)}</small></div></div>`).join('') +
      (p.comments || []).map(c => `<div class="cmt">${esc(c)}</div>`).join('') + '</div>';
  }
  function profileHTML(p) {
    return `<div class="sitebar">${esc(p.site)}</div><div class="prof"><div class="big"></div><h2>${esc(p.name)}</h2><div>– Beiträge · – Follower · – Folgt</div><div class="lock"><b>${esc(p.note)}</b><br>${esc(p.sub)}</div><button class="follow">Folgen</button><div class="visit">${esc(p.visits)}</div></div>`;
  }
  function trackHTML(p) {
    return `<div class="sitebar">${esc(p.site)}</div><div class="track"><h2>Sendung ${esc(p.nr)}</h2><table>${p.rows.map(r => `<tr><td>${esc(fmtLong(r[0]))}</td><td>${esc(r[1])}</td></tr>`).join('')}</table></div>`;
  }

  function renderScene(view, scene, id) {
    const page = el('div', 'pruef');
    const build = after => {
      page.innerHTML = `<div class="band">${esc(scene.site.toUpperCase())}</div>` + (after != null
        ? `<h2>${esc(scene.site)}</h2><p>${esc(after)}</p><p>${esc(scene.done)}</p>`
        : `<h2>${esc(scene.headline)}</h2>${sawSVG()}<p>${nl(scene.text)}</p>`);
    };
    if (S.flags[id]) { build(''); view.append(page); return; }
    build(null);
    const opts = el('div', 'opts');
    scene.options.forEach(o => {
      const b = el('button', 'opt', `${ART[o.art]}${esc(o.label)}`);
      b.onclick = () => {
        if (S.flags[id]) return;
        S.flags[id] = o.id;
        Object.entries(o.effects || {}).forEach(([k, v]) => { S.traits[k] = (S.traits[k] || 0) + v; });
        save();
        if (o.fx === 'blackScream') { blackout(4500, true); later(() => build(o.after), 4500); } else build(o.after);
      };
      opts.append(b);
    });
    page.append(opts, el('div', 'foot', esc(scene.foot)));
    view.append(page);
  }

  function openBrowser() {
    const c = el('div', 'browser');
    const bar = el('div', 'urlbar');
    const back = el('button', '', '← Verlauf'), url = el('input'); url.readOnly = true;
    bar.append(back, url);
    const view = el('div', 'bview');
    c.append(bar, view);
    const home = () => {
      url.value = 'verlauf://';
      view.innerHTML = '<div class="bhist"><h3>Verlauf</h3></div>';
      const box = $('.bhist', view);
      [...STORY.history].sort((a, b) => STORY.at(b.ago, b.time) - STORY.at(a.ago, a.time)).forEach(h => {
        const row = el('div', 'hrow', `<a href="#">${esc(h.title)}</a><small>${esc(h.url)} · ${esc(whenLabel(h.ago, h.time))}${h.meta ? ' · ' + esc(h.meta) : ''}</small>`);
        row.querySelector('a').onclick = ev => { ev.preventDefault(); visit(h); };
        box.append(row);
      });
    };
    const visit = h => {
      url.value = h.url; view.innerHTML = '';
      const p = STORY.pages[h.page] || {};
      if (p.kind === 'scene') renderScene(view, STORY.scenes[p.scene], p.scene);
      else if (p.kind === 'forum') view.innerHTML = forumHTML(p);
      else if (p.kind === 'qa') view.innerHTML = qaHTML(p);
      else if (p.kind === 'profile') view.innerHTML = profileHTML(p);
      else if (p.kind === 'tracking') view.innerHTML = trackHTML(p);
      else if (p.kind === 'plain') view.innerHTML = `<div class="sitebar">${esc(p.site)}</div><div class="pagetxt"><h2>${esc(p.title)}</h2>${nl(p.text)}</div>`;
      else view.append(el('div', 'pagetxt', '(Seite nicht mehr verfügbar)'));
      livReact('page:' + h.page);
    };
    back.onclick = home; home();
    openWindow('web', 'Browser', c, { w: 700, h: 460, skin: 'web' });
  }

  // ================================================================ Startmenü & Kalender
  function buildStartMenu() {
    const m = $('#startmenu'); m.innerHTML = '';
    const items = ICONS.map(i => ({ label: i.label, ico: i.ico, fn: i.open }));
    items.push({ label: 'Kalender', ico: '📅', fn: toggleCal });
    if (S.livUnlocked) items.push({ label: 'Liv', ico: livFace(20), fn: openLiv });
    items.push('sep', { label: 'Spiel beenden', ico: '⏻', fn: () => sys.quit() });
    items.forEach(i => {
      if (i === 'sep') { m.append(el('div', 'smsep')); return; }
      const r = el('div', 'smi', `<span class="si">${i.ico}</span>${esc(i.label)}`);
      r.onclick = () => { closePopups(); i.fn(); };
      m.append(r);
    });
  }
  function toggleStart() {
    const m = $('#startmenu');
    if (!m.classList.contains('hidden')) { closePopups(); return; }
    closePopups(); buildStartMenu(); m.classList.remove('hidden'); $('#startbtn').classList.add('open');
  }
  function closePopups() {
    $('#startmenu').classList.add('hidden'); $('#calpop').classList.add('hidden'); $('#startbtn').classList.remove('open');
  }

  let calView = new Date(), calSel = '';
  const dayKey = d => `${d.getFullYear()}-${pad(d.getMonth() + 1)}-${pad(d.getDate())}`;
  function toggleCal() {
    const p = $('#calpop');
    if (!p.classList.contains('hidden')) { closePopups(); return; }
    closePopups(); calView = new Date(); calSel = dayKey(new Date()); renderCal(); p.classList.remove('hidden');
    livReact('cal');
  }
  function renderCal() {
    const p = $('#calpop');
    const by = {};
    STORY.calendarEvents().forEach(e => { const k = dayKey(STORY.at(-e.off, e.time || '00:00')); (by[k] = by[k] || []).push(e); });
    const y = calView.getFullYear(), m = calView.getMonth();
    const first = (new Date(y, m, 1).getDay() + 6) % 7, dim = new Date(y, m + 1, 0).getDate();
    const todayK = dayKey(new Date());
    let cells = ['Mo', 'Di', 'Mi', 'Do', 'Fr', 'Sa', 'So'].map(d => `<div class="wd">${d}</div>`).join('') + '<div></div>'.repeat(first);
    for (let d = 1; d <= dim; d++) {
      const k = `${y}-${pad(m + 1)}-${pad(d)}`;
      cells += `<div class="cd${k === todayK ? ' today' : ''}${k === calSel ? ' sel' : ''}" data-k="${k}">${d}${by[k] ? '<i class="dot"></i>' : ''}</div>`;
    }
    const evs = (by[calSel] || []).sort((a, b) => (a.time || '').localeCompare(b.time || ''));
    const [sy, sm, sd] = calSel.split('-').map(Number);
    const title = new Date(sy, sm - 1, sd).toLocaleDateString('de-DE', { weekday: 'long', day: 'numeric', month: 'long' });
    p.innerHTML = `<div class="calhead"><button data-nav="-1">‹</button><span>${new Date(y, m, 1).toLocaleDateString('de-DE', { month: 'long', year: 'numeric' })}</span><button data-nav="1">›</button></div><div class="calgrid">${cells}</div>` +
      `<div class="calev"><h4>${esc(title)}</h4>${evs.length ? evs.map(e => `<div class="cev"><span class="t">${esc(e.time || 'ganztägig')}</span><div>${esc(e.title)}${e.note ? `<small>${esc(e.note)}</small>` : ''}</div></div>`).join('') : '<div style="color:#7f939b">Keine Termine.</div>'}</div>`;
    p.querySelectorAll('[data-nav]').forEach(b => b.onclick = () => { calView = new Date(y, m + Number(b.dataset.nav), 1); renderCal(); });
    p.querySelectorAll('.cd').forEach(c => c.onclick = () => { calSel = c.dataset.k; renderCal(); });
  }

  // ================================================================ Dev-Menü (Strg+Umschalt+D)
  function toggleDev() {
    if (wins.dev) { closeWindow('dev'); return; }
    const c = el('div', 'dev'); const out = el('pre', 'devout', 'Dev-Menü. Hier testest du alle Effekte.');
    const add = (label, fn) => { const b = el('button', '', esc(label)); b.onclick = async () => { const r = await fn(); if (r != null) out.textContent = r; }; c.append(b); };
    add('Fake-Bluescreen (nur Effekt)', () => { bsod(); return 'läuft…'; });
    add('Schwarzbild 3s + Ton', () => { blackout(3000, true); return 'läuft…'; });
    add('Fake-Absturz mit Neustart in Phase 2', () => { fakeCrash(); return 'läuft…'; });
    add('Liv: Versprecher mit echtem Namen jetzt', () => { doSlip(); return 'läuft…'; });
    add('Liv: Marlene-Eifersucht (late-Modus) an', () => { S.livMetAt = Date.now() - 400000; save(); return 'ok'; });
    add('Alle Stufen freischalten (Archiv, M, liv_svc, Gesendet)', () => { Object.assign(S.flags, { nameSlip: true, stage1: true, stage2: true, late: true }); S.opened.push('Dokumente/privat/chat_marlene_export.txt'); save(); rebuildFs(); return 'ok'; });
    add('Desktop-Dateinamen lesen', async () => { const f = await sys.desktopFiles(); return f.length ? f.join('\n') : '(nichts gefunden)'; });
    add('Test-Datei auf den Desktop legen', async () => { const f = await sys.writeDesktop('Hallo_' + (S.name || 'Gast') + '.txt', 'Ich war hier.\n\n(Testdatei von StogeOS. Du kannst sie löschen.)'); return f ? 'geschrieben: ' + f : 'Fehler'; });
    add('liv.exe sofort freischalten', () => { S.livUnlocked = true; save(); renderIcons(); return 'ok'; });
    add('Werte anzeigen', () => JSON.stringify({ phase: S.phase, traits: S.traits, flags: S.flags, livUnlocked: S.livUnlocked }, null, 1));
    add('Spielstand löschen + neu laden', async () => { await sys.resetState(); location.reload(); });
    c.append(out);
    openWindow('dev', 'Dev', c, { w: 380, h: 470, x: 60, y: 40, skin: 'dev' });
  }
  document.addEventListener('keydown', e => {
    if (e.ctrlKey && e.shiftKey && e.key.toLowerCase() === 'd' && !$('#desktop').classList.contains('hidden')) toggleDev();
  });
  document.addEventListener('mousedown', e => {
    if (!e.target.closest('#startmenu, #startbtn, #calpop, #clock')) closePopups();
  });

  // ================================================================ Desktop & Login
  const ICONS = [
    { id: 'docs', label: 'Dokumente', ico: '📁', open: () => openExplorer(['Dokumente']) },
    { id: 'mail', label: 'Mail', ico: '✉️', open: openMail },
    { id: 'web', label: 'Browser', ico: '🌐', open: openBrowser },
    { id: 'sys', label: 'System', ico: '💾', open: () => openExplorer(['System']) },
    { id: 'trash', label: 'Papierkorb', ico: '🗑️', open: () => openExplorer(['Papierkorb']) }
  ];
  function renderIcons() {
    const box = $('#icons'); box.innerHTML = '';
    const list = ICONS.map(i => ({ ...i, g: i.ico }));
    if (S.livUnlocked) list.push({ id: 'liv', label: 'liv.exe', g: livFace(36), open: openLiv });
    list.forEach(i => {
      const d = el('div', 'icon', `<div class="g">${i.g}</div><div>${esc(i.label)}</div>`);
      d.dataset.id = i.id; d.ondblclick = i.open;
      d.onclick = () => { box.querySelectorAll('.sel').forEach(x => x.classList.remove('sel')); d.classList.add('sel'); };
      box.append(d);
    });
  }
  function tickClock() {
    const d = new Date();
    $('#clock').textContent = pad(d.getHours()) + ':' + pad(d.getMinutes());
    $('#clock').title = d.toLocaleDateString('de-DE', { weekday: 'long', day: 'numeric', month: 'long', year: 'numeric' });
  }
  function enterDesktop(fresh) {
    rebuildFs();
    $('#login').classList.add('hidden');
    $('#desktop').classList.remove('hidden');
    $('#startbtn').onclick = toggleStart;
    $('#clock').onclick = toggleCal;
    renderIcons(); tickClock(); setInterval(tickClock, 15000);
    if (S.phase >= 2) later(() => toast(`Willkommen zurück, ${S.name}.`, 5000), 1500);
    else if (fresh) toast('Angemeldet als Gast: ' + S.name, 3500);
    if (S.flags.livMet) scheduleSlip();
  }
  async function boot() {
    try { ENV = await sys.info(); } catch (e) {}
    const saved = await sys.loadState();
    if (saved) S = Object.assign(S, saved, { traits: Object.assign({ naehe: 0, haerte: 0, neugier: 0 }, saved.traits || {}), livLog: saved.livLog || [] });
    document.title = S.phase >= 2 ? 'liv' : 'StogeOS 3.2';
    document.body.classList.toggle('phase2', S.phase >= 2);
    if (S.phase >= 2 && S.name) { enterDesktop(false); return; }
    const inp = $('#nameinput'), btn = $('#loginbtn');
    if (S.name) {
      inp.value = S.name;
      if (S.lastSeen) $('#loginfo').textContent = 'Letzte Gast-Sitzung: ' + new Date(S.lastSeen).toLocaleString('de-DE');
    }
    const go = () => {
      const v = inp.value.trim().slice(0, 40);
      if (!v) { inp.focus(); return; }
      S.name = v; S.lastSeen = Date.now(); save();
      enterDesktop(true);
    };
    btn.onclick = go;
    inp.onkeydown = e => { if (e.key === 'Enter') go(); };
    inp.focus();
  }
  boot();
})();
