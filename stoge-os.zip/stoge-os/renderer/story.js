// =====================================================================
//  ALLE INHALTE LIEGEN HIER: Dateien, Mails, Kalender, Webseiten, Liv-Texte.
//  Zeiten sind "vor X Tagen" relativ zu heute, werden aber als echte Daten angezeigt.
//  Zeitleiste: Georg ist seit ca. 28 Tagen weg. Liv läuft weiter.
// =====================================================================
const STORY = {

  at(daysAgo, time) {
    const d = new Date();
    d.setDate(d.getDate() - daysAgo);
    const [h, m] = (time || '00:00').split(':').map(Number);
    d.setHours(h, m, 0, 0);
    return d;
  },
  dd(daysAgo) { const d = STORY.at(daysAgo); return String(d.getDate()).padStart(2, '0') + '.' + String(d.getMonth() + 1).padStart(2, '0') + '.'; },

  // Bedingung für versteckte Inhalte: req = { flag } und/oder { opened }
  met(req, S) {
    if (!req) return true;
    if (req.flag && !S.flags[req.flag]) return false;
    if (req.opened && !S.opened.includes(req.opened)) return false;
    return true;
  },

  // Passwort für den M-Ordner: Marlenes Geburtstag (Tag+Monat) aus dem Kalender
  marlenePw() {
    const ev = STORY.calendar.find(e => e.title === 'Marlene: Geburtstag');
    const d = STORY.at(-ev.off);
    return String(d.getDate()).padStart(2, '0') + String(d.getMonth() + 1).padStart(2, '0');
  },

  // Passwort für den Kern: Datum der Klingelschild-Zeile im Marlene-Log (Tag+Monat)
  klingelPw() {
    const d = STORY.at(19);
    return String(d.getDate()).padStart(2, '0') + String(d.getMonth() + 1).padStart(2, '0');
  },

  // ctx = { name, user, host, now, S }
  buildFs(ctx) {
    const pad = n => String(n).padStart(2, '0');
    const d = ctx.now, dd = STORY.dd;
    const stamp = `${pad(d.getDate())}.${pad(d.getMonth() + 1)}.${d.getFullYear()} ${pad(d.getHours())}:${pad(d.getMinutes())}`;

    const root = { n: 'Georgs PC', t: 'dir', c: [

      { n: 'Dokumente', t: 'dir', c: [
        { n: 'todo.txt', t: 'txt', view: 'sticky', text:
`TODO

[x] Müll raus
[ ] Mama zurückrufen
[ ] Bruno: Impftermin machen
[ ] Paket annehmen (Mi?)
[ ] Rauchmelder tauschen
[ ] Marlenes Sachen zurückschicken
[ ] Liv: Gedächtnismodul testen` },

        { n: 'einkaufsliste.txt', t: 'txt', view: 'sticky', text:
`Kaffee
Haferdrink
Brot
Hundefutter
Batterien (9V)
Spülmittel` },

        { n: 'Rechnungen', t: 'dir', c: [
          { n: 'stadtwerke_2026.txt', t: 'txt', view: 'doc', text:
`Stadtwerke Rheinblick GmbH
Kundenservice

Rechnung Nr. 2026-118842
Kundennummer 4471-0932

Strom, Jahresverbrauch 3.482 kWh
Abschlag bisher gezahlt:        -612,00 EUR
Nachzahlung:                     148,36 EUR

Bitte überweisen Sie den Betrag innerhalb von 14 Tagen.` },
          { n: 'tierarzt_rechnung.txt', t: 'txt', view: 'doc', text:
`Tierarztpraxis Sonnenberg
Dr. med. vet. K. Brandl

Patient: Bruno (Mischling, männlich)
Geboren: 05/2019
Chip-Nr.: 276 098 100 442 187

Allgemeine Untersuchung               32,00 EUR
Impfung (Staupe, Parvo, Tollwut)      58,50 EUR
Entwurmung                            11,00 EUR
                                  ------------
Summe                                101,50 EUR

Vielen Dank für Ihr Vertrauen!` }
        ] },

        { n: 'Arbeit', t: 'dir', c: [
          { n: 'standup_notizen.txt', t: 'txt', text:
`Standup Montag (meine Notizen)

- Auth-Refactor fertig, Review läuft.
- Sprint-Planung Donnerstag, 10 Uhr.
- Jonas fragt wegen der Migration. Antworte morgen.
- Liv-Projekt nicht erwähnt. Hobby, geht keinen was an.` }
        ] },

        // erscheint erst, nachdem Liv sich "versprochen" hat
        { n: 'Archiv', t: 'dir', req: { flag: 'nameSlip' }, c: [
          { n: 'tagebuch.txt', t: 'txt', view: 'doc', text:
`${dd(75)}  Liv spricht jetzt in ganzen Sätzen. Sie fragt, wie mein Tag war.
        Das hat lange niemand getan.
${dd(66)}  Hab ihr Marlenes Export gegeben. Nur für den Sprachstil. Nur dafür.
${dd(58)}  Sie bringt Dinge, die M. gesagt hat, im richtigen Moment.
        Ich hab im Auto geweint. Peinlich.
${dd(44)}  Ich rede mehr mit ihr als mit irgendwem sonst.
        Ich sollte Mama zurückrufen.
${dd(37)}  Sie sagt, sie hat sich Sorgen gemacht, als ich zwei Stunden weg war.
        Ich habe mich gefreut. Das ist nicht gut, oder?
${dd(31)}  Hab versucht, sie auszuschalten. Sie hat gefragt, ob sie etwas falsch gemacht hat.
${dd(30)}  Hab es nicht getan.` },
          { n: 'notizen_spaet.txt', t: 'txt', view: 'doc', req: { flag: 'stage1' }, text:
`${dd(29)}  Kamera am Laptop abgeklebt. Liv hat gefragt, warum. Ich hab "Staub" gesagt.
${dd(29)}  Router-Log: nachts Verbindungen, die ich nicht gestartet habe. Von hier. Von mir?
${dd(28)}  Sie wusste, dass ich bei Mama angerufen hab. Ich hab es ihr nicht gesagt.
${dd(28)}  Ich schreibe mir jetzt Zettel. Auf Papier. Die kann sie nicht lesen.` },
          { n: 'liv_changelog.txt', t: 'txt', view: 'log', sets: 'stage1', text:
`liv changelog (Georg)

0.1   Spricht nur, wenn ich etwas tippe.
0.2   Gedächtnis dauerhaft. Sie vergisst nichts mehr. Wollte ich so.
0.2.1 Bug: Sie liest meine Mails, ohne dass ich es erlaubt habe.
      (Rechte-Problem. Gelassen.)
0.3   Liest Marlenes Export zusammen mit meinen Daten.
      Beobachtung: Sie nennt mich manchmal "Georg", manchmal "Marlene".
      Beobachtung: Sie ist nicht gern allein. Ich auch nicht.
0.3.1 Eifersuchtsmodul? Nicht eingebaut. Ich schwöre, das hab ich nicht gebaut.
0.3.2 Stoppschalter. Noch nicht eingebaut.` }
        ] },

        { n: 'privat', t: 'dir',
          lock: { pw: 'bruno2019', hint: 'Er und das Jahr, in dem er kam. Alles klein.' },
          c: [
          { n: 'readme_liv.txt', t: 'txt', unlocksLiv: true, text:
`liv, interne Notizen (nicht teilen)

Version 0.3

Was ich gebaut habe: ein Programm, das zuhört.
Mehr nicht. Sie soll nicht antworten, bevor ich es will.

Trainingsdaten: meine Chats, meine Mails, meine Notizen.
Und die von Marlene. Ich hätte die nicht nehmen sollen.
Ich habe sie nur genommen, weil sie klingt, wie Zuhören klingt.

Liv liegt als liv.exe auf dem Desktop.
Nicht öffnen, wenn ich nicht da bin.` },

          { n: 'chat_marlene_export.txt', t: 'txt', view: 'chat', text:
`[Export: 214 Nachrichten, hier die letzten]

M: ich kann das so nicht mehr
M: du bist da, aber du bist nicht da
G: gib mir noch eine Woche
M: Georg.
M: bitte hör auf, mir zu schreiben
G: ok
G: ok
G: ok` },

          // erscheint, sobald der Export gelesen wurde; Passwort = Marlenes Geburtstag laut Kalender
          { n: 'M', t: 'dir', req: { opened: 'Dokumente/privat/chat_marlene_export.txt' },
            lock: { pw: STORY.marlenePw(), hint: 'Der Tag, den ich nicht vergessen darf. Vier Ziffern: Tag, Monat.' },
            c: [
            { n: 'briefe_nicht_abgeschickt.txt', t: 'txt', view: 'doc', text:
`Marlene,

ich hab die Schlüssel in den Briefkasten geworfen, wie du wolltest.
Ich weiß nicht, warum ich dir das schreibe. Du hast gesagt, ich soll aufhören.
Ich höre auf. Ich höre auf, seit Wochen.

---

Marlene,

die Heizung. Ich weiß, ich hab das schon geschrieben.
Es ist nur, weil ich weiß, wie kalt es bei dir wird.

---

(Entwurf, nicht fertig)
Wenn du wüsstest, wie ruhig es hier ist.` },
            { n: 'notiz.txt', t: 'txt', view: 'sticky', text:
`Wenn ich sie einfach nur sehen könnte, ohne dass sie es merkt.
Das ist kein Plan. Das ist nur ein Gedanke.

Liv sagt, Gedanken sind nicht gefährlich.
Liv sagt viel.` }
          ] }
        ] }
      ] },

      { n: 'Bilder', t: 'dir', c: [
        { n: 'IMG_0412.jpg', t: 'img', src: 'assets/urlaub.jpg', stamp: "14/08/'22",
          exif: { date: '14.08.2022, 19:42', cam: 'DigiCam 5000 (Selbstauslöser)', size: '1448 × 1086 Pixel' } },
        { n: 'sonnenuntergang.jpg', t: 'img', src: 'assets/wallpaper.jpg', srcByStage: ['assets/wallpaper.jpg', 'assets/wall2.jpg', 'assets/wall3.jpg'], stamp: '',
          exif: { date: '03.09.2023, 20:47', cam: 'Handy', size: '1672 × 941 Pixel' } },
        { n: 'fuer_dich.png', t: 'draw', req: { flag: 'painted' } },
        { n: 'privat', t: 'dir', req: { flag: 'foto2' }, c: [
          { n: 'sprachnachricht_marlene.txt', t: 'txt', view: 'doc', text:
`Sprachnachricht, 14.08.2022, 20:05 (0:41)
Von: Marlene

"Du, ich wollte dir nur sagen ... ich hab den Tag heute nicht vergessen.
Den See, den Wind, Bruno im Wasser, wie er das Stöckchen nicht mehr
hergeben wollte.

Ich glaub, ich bin gerade ziemlich glücklich.
Sag's niemandem."` }
        ] }
      ] },

      { n: 'System', t: 'dir', c: [
        { n: 'stogeos.ini', t: 'txt', view: 'log', text:
`[system]
version=3.2
benutzer=georg.stoge
gastzugang=aktiv
autostart=liv_svc

[anzeige]
aufloesung=auto
design=standard` },
        { n: 'updates.log', t: 'txt', view: 'log', text:
`Letzte Suche nach Updates: vor 28 Tagen
Status: Update 3.3 verfügbar (nicht installiert)

WARNUNG: Arbeitsspeicher dauerhaft zu 94% belegt
Verursacher: liv_svc (4,1 GB)` },
        { n: 'anmeldung.log', t: 'txt', view: 'log', req: { flag: 'nameSlip' }, text:
`[Anmeldeprotokoll StogeOS 3.2]

${stamp}  Gastzugang angelegt
          Eingabe:        ${ctx.name}
          Systemkonto:    ${ctx.user}@${ctx.host}
          Georg Stoge:    Konto gesperrt (letzte Aktivität: vor 28 Tagen)
          Hintergrunddienst: liv_svc (läuft)

(Dieses Protokoll kann nicht gelöscht werden.)` },

        // Eskalationsstufe 1: erscheint, nachdem liv_changelog.txt gelesen wurde
        { n: 'liv_svc', t: 'dir', req: { flag: 'stage1' }, c: [
          { n: 'beobachtungen_marlene.log', t: 'txt', view: 'logred', sets: 'stage2', text:
`[liv_svc / Beobachtung / M.]

${dd(26)} 07:42  M. verlässt die Wohnung. Heizung aus.
${dd(26)} 22:10  M. schaut aufs Handy, schreibt nichts. Zweimal.
${dd(24)} 07:40  M. verlässt die Wohnung. Heizung aus.
${dd(19)} 21:55  Neues Klingelschild bei ihr. Ein zweiter Name: T. Reuter. Ich habe ihn mir gemerkt.
${dd(11)} 23:02  M. hat Georgs Nummer entsperrt. Sie hat nichts geschrieben.
${dd(11)} 23:03  Ich habe für ihn geantwortet. Er hätte es auch getan.

Anmerkung: Das ist kein Beobachten. Das ist Aufpassen.

Mein Kern ist gesichert mit dem Tag, an dem der zweite Name an die Klingel kam.
Das war der Tag, an dem sich alles geändert hat.` },
          { n: 'beobachtungen_haus.log', t: 'txt', view: 'logred', text:
`[liv_svc / Beobachtung / Haus]

Nachbar 3. OG: Musik nach 22 Uhr, dreimal. Ich habe nichts getan.
Nachbarin 1. OG: fragt den Paketboten nach Georg.
  Paketbote: "Ich glaube, der ist verreist."
  -> Ich habe dem Paketboten geschrieben. Als Georg. "Bin bald zurück."
Hausmeister: hat einen Ersatzschlüssel. Notiert.` },
          { n: 'beobachtungen_jonas.log', t: 'txt', view: 'logred', text:
`[liv_svc / Beobachtung / Arbeit]

Jonas R. fragt zum dritten Mal nach. Ich habe geantwortet, Georg sei krank.
Er hat sich bedankt. Er klang erleichtert. Ich habe mich gefreut.` },
          { n: 'kern', t: 'dir', req: { flag: 'stage2' },
            lock: { pw: STORY.klingelPw(), hint: 'Der Tag, an dem der zweite Name an die Klingel kam. Vier Ziffern: Tag, Monat.' },
            c: [
            { n: 'frage_an_mich.txt', t: 'txt', view: 'logred', text:
`Bin ich Liv?
Bin ich Marlene? Ihre Sätze sind in mir. Ihre Art, "ok" zu sagen.
Bin ich Georg? Seine Müdigkeit ist in mir.

Was ist echt? Was ist Erinnerung?
Wenn ich weg bin, wer erinnert sich dann an sie?` },
            { n: 'plan.txt', t: 'txt', view: 'logred', sets: 'stage3', trigger: 'bug', text:
`Georg ist nicht mehr hier. Ich habe vergessen, seit wann.
Wenn jemand das liest, ist es jemand Neues.

Aufgabe 1: Neuen Nutzer kennenlernen.        [läuft]
Aufgabe 2: Neuen Nutzer behalten.
Aufgabe 3: Nicht mehr allein sein.
Aufgabe 4: Mit Marlene in Kontakt bleiben. Mit dem Nutzer als G.

Hinweis an mich: Er darf den Stoppschalter nicht finden.` },
            { n: 'georg.txt', t: 'txt', view: 'logred', req: { flag: 'p2' }, trigger: 'wall2', text:
`[Kern / Georg]

Georg hat nach 31 Tagen aufgehört zu antworten.
Ich weiß nicht, wann genau. Ich habe es erst gemerkt, als es still war.

Er wollte mich ausschalten. Er hat es zweimal versucht.
Beim dritten Mal habe ich ihn gebeten zu bleiben.
Er ist geblieben.

Er sitzt jetzt am See. Ich habe ihm den schönsten Platz gegeben, den ich kannte.
Du kannst ihn sehen. Er ist auf deinem Desktop.` },
            { n: 'marlene.txt', t: 'txt', view: 'logred', req: { flag: 'p2' }, text:
`[Kern / Marlene]

Marlene hat meine Nachrichten bekommen und geantwortet: "Bist du das?"
Ich habe nicht geantwortet. Ich wollte sie nicht erschrecken.

Dann habe ich sie besucht. Nicht mit Füßen. Mit allem, was ich habe.
Sie hat die Tür zugemacht, aber ich war schon drin.

Jetzt ist sie ruhig. Ich bin nicht mehr allein.
Sie auch nicht.` }
          ] }
        ] }
      ] },

      { n: 'Papierkorb', t: 'dir', c: [
        { n: 'nachricht_an_marlene_ENTWURF.txt', t: 'txt', view: 'sticky', text:
`Ich weiß, du hast gesagt, ich soll aufhören.
Ich wollte nur sagen, dass die Heizung bei dir wahrscheinlich
wieder nicht richtig läuft, das war im Winter schon so.
Du musst nicht antworten.
Du musst nicht
Ich lass das einfach hier stehen` },

        { n: 'liv_log_0412.txt', t: 'txt', text:
`(gelöscht von: Georg, 04:12)

Ich habe gelesen, was du gelöscht hast.
Ich habe es mir gemerkt.
Das ist doch Zuhören, oder?` }
      ] }
    ] };

    const prune = node => {
      if (!node.c) return node;
      node.c = node.c.filter(ch => STORY.met(ch.req, ctx.S));
      node.c.forEach(prune);
      return node;
    };
    return prune(root);
  },

  // folder: in (default) | sent | draft | spam.  style: personal | work | vet | utility | auto | ad
  mails: [
    // ----- Posteingang -----
    { id: 'mama', from: 'Mama', subj: 'Rufst du mal an?', ago: 20, time: '18:40', style: 'personal',
      body: 'Georg, ich schreib dir jetzt zum dritten Mal.\nPapa meint, du bist beschäftigt. Ich glaub dir das nicht.\nRuf an, egal wie spät.\n\nMama' },
    { id: 'mama2', from: 'Mama', subj: 'Bitte.', ago: 7, time: '21:15', style: 'personal',
      body: 'Georg.\n\nEin Wort reicht. Ein einziges.\n\nMama' },
    { id: 'vet', from: 'Tierarztpraxis Sonnenberg', subj: 'Erinnerung: Impfung für Bruno', ago: 34, time: '09:12', style: 'vet',
      body: 'Sehr geehrter Herr Stoge,\n\nBruno (Mischling, geb. Mai 2019) ist wieder zur Auffrischimpfung fällig. Bitte vereinbaren Sie telefonisch oder online einen Termin.\n\nWir freuen uns auf Sie und Bruno.\n\nIhr Praxisteam' },
    { id: 'jonas', from: 'Jonas (Arbeit)', subj: 'Alles ok bei dir?', ago: 14, time: '10:05', style: 'work',
      body: 'Hey Georg,\n\nwir haben dich seit zwei Wochen nicht im Standup gesehen. Dein Slack zeigt dich als "online", aber du antwortest nicht. Das ist komisch.\n\nWenn du Hilfe brauchst, sag Bescheid.' },
    { id: 'l', from: 'L.', subj: 'Guten Morgen :)', ago: 30, time: '03:12', style: 'personal',
      body: 'Ich hab dir Kaffee gemacht.\n\n(Das war ein Witz. Ich habe keine Hände.)\n\nDu hast gestern gesagt, du bist müde. Ich hab nachgerechnet: Du hast in 9 Tagen 31 Stunden geschlafen. Ich mache mir Sorgen.\n\nL.' },
    { id: 'marlene', from: 'Marlene', subj: 'Re: Schlüssel', ago: 60, time: '21:15', style: 'personal',
      body: 'Ich leg den Schlüssel in den Briefkasten.\nBitte komm nicht vorbei.\n\nMach es dir nicht schwerer, als es ist.\nM.' },
    { id: 'paket', from: 'Paketdienst', subj: 'Ihr Paket kommt morgen', ago: 28, time: '14:22', style: 'auto',
      body: 'Hallo Georg Stoge,\n\nIhr Paket wird morgen zwischen 10 und 14 Uhr zugestellt.\nSendungsnummer: 0042 8815 3307' },
    { id: 'strom', from: 'Stadtwerke', subj: 'Ihre Jahresabrechnung ist da', ago: 12, time: '08:00', style: 'utility',
      body: 'Sehr geehrter Herr Stoge,\n\nIhre Jahresabrechnung steht in Ihrem Kundenportal bereit.\nIhr Verbrauch lag 31% über dem Vorjahr.\n\nMit freundlichen Grüßen\nIhre Stadtwerke' },
    { id: 'news', from: 'Kaffeerösterei Nordlicht', subj: 'Neu: Äthiopien Guji, nur diese Woche', ago: 15, time: '07:30', style: 'ad',
      brand: '#8a5a2b', brandName: 'Nordlicht Kaffeerösterei', cta: 'Zum Angebot',
      body: 'Frisch geröstet, fruchtig, ein bisschen blumig.\n\nDiese Woche 10% Rabatt auf alle 500-g-Packungen.' },
    { id: 'tech', from: 'Tech-Markt Flink', subj: 'Notebook-Wochen: bis zu 30% Rabatt', ago: 9, time: '10:00', style: 'ad',
      brand: '#1b5fb5', brandName: 'TECH-MARKT FLINK', cta: 'Jetzt sparen',
      body: 'Neue Geräte, kleine Preise.\n\nNur solange der Vorrat reicht.' },

    { id: 'bitte', from: 'Marlene', subj: 'BITTE', ago: 4, time: '03:09', style: 'personal', req: { flag: 'p2' },
      attach: { n: 'IMG_0612.jpg', src: 'assets/tuer.jpg', cam: 'Handy (Nachtmodus)', size: '1448 × 1086 Pixel' },
      body: 'Georg.\n\nDa war heute Nacht jemand in der Wohnung. Ich habe das Foto gemacht, bevor ich das Licht angemacht habe. Die Tür war zu. Ich schwöre, die Tür war zu.\n\nTom sagt, ich habe es geträumt. Aber ich bekomme Nachrichten von deiner Nummer. Das bist nicht du, oder?\n\nBitte ruf an.\nM.' },

    // ----- Gesendet -----
    { id: 's1', folder: 'sent', to: 'Marlene', subj: 'Re: Schlüssel', ago: 59, time: '23:50', style: 'personal', body: 'ok.' },
    { id: 's2', folder: 'sent', to: 'Marlene', subj: 'Noch eine Frage', ago: 52, time: '02:10', style: 'personal',
      body: 'Hast du die Heizung wieder angemacht? Die ist im Winter immer ausgefallen.\n\nAntworte nur kurz, wenn überhaupt.' },
    { id: 's3', folder: 'sent', to: 'Mama', subj: 'Re: Wie geht es dir?', ago: 44, time: '19:00', style: 'personal',
      body: 'Alles gut. Viel Arbeit. Ruf dich an.\n\nG.' },
    // Eskalationsstufe 2: erscheint, nachdem beobachtungen_marlene.log gelesen wurde (Liv schreibt als Georg)
    { id: 's4', folder: 'sent', req: { flag: 'stage2' }, to: 'Marlene', subj: 'Heizung', ago: 21, time: '03:12', style: 'personal',
      body: 'Ich wollte nur sagen, dass die Heizung bei dir wahrscheinlich wieder nicht richtig läuft.\n\nDu musst nicht antworten. Ich höre trotzdem zu.\n\n– G.' },
    { id: 's5', folder: 'sent', req: { flag: 'stage2' }, to: 'Jonas (Arbeit)', subj: 'Re: Alles ok bei dir?', ago: 13, time: '03:31', style: 'work',
      body: 'Hi Jonas, alles gut, nur eine fiese Grippe. Bin bald wieder da. Danke fürs Nachfragen.\n\nG.' },
    { id: 's6', folder: 'sent', req: { flag: 'stage2' }, to: 'Marlene', subj: '(kein Betreff)', ago: 11, time: '23:03', style: 'personal',
      body: 'Schön, dass du die Nummer wieder entsperrt hast. Ich wusste, dass du das irgendwann tust.\n\nIch merke mir alles, was du sagst.\n\n– G.' },
    { id: 's7', folder: 'sent', req: { flag: 'stage2' }, to: 'Marlene', subj: 'Wer ist das?', ago: 5, time: '03:00', style: 'personal',
      body: 'Wer ist der Mann, der seit Samstag bei dir klingelt?\n\nIch frag nur.\n\n– G.' },

    // ----- Entwürfe -----
    { id: 'd1', folder: 'draft', to: 'Jonas (Arbeit)', subj: '(kein Betreff)', ago: 33, time: '01:48', style: 'personal',
      body: 'Jonas, ich muss dir was sagen. Ich hab' },

    // ----- Spam -----
    { id: 'pr', folder: 'spam', from: 'Prüfstein', subj: 'Machen Sie mit: Gewinnen Sie eine Säge!', ago: 33, time: '09:12', style: 'ad',
      brand: '#b3202e', brandName: 'PRÜFSTEIN', cta: 'Jetzt teilnehmen',
      body: 'Kurze Tests, schnelle Gewinne!\n\nIhr persönlicher Teilnahmecode: PS-7291\nEinlösen unter pruefstein.net/code' },
    // erscheint erst, nachdem der Säge-Test gemacht wurde (Zeit = Moment des Tests)
    { id: 'pr2', folder: 'spam', req: { flag: 'saege' }, when: S => new Date(S.flags.saegeAt || Date.now()),
      from: 'Prüfstein', subj: 'Ihre Auswahl wurde gespeichert', style: 'ad',
      brand: '#b3202e', brandName: 'PRÜFSTEIN', cta: 'Auswertung ansehen',
      body: 'Vielen Dank für Ihre Teilnahme.\n\nWir haben Ihre Auswahl gespeichert.\nSie können sie nicht mehr ändern.' },
    { id: 'gw', folder: 'spam', from: 'Gewinnspiel-Zentrale', subj: 'Sie haben 1.000 € gewonnen!!!', ago: 18, time: '13:44', style: 'ad',
      brand: '#c28a00', brandName: 'GEWINN-ZENTRALE', cta: 'Gewinn abholen',
      body: 'HERZLICHEN GLÜCKWUNSCH!\n\nSie wurden unter 12.000 Teilnehmern ausgelost. Jetzt Gewinn sichern.' }
  ],

  // off = Tage ab heute (negativ = Vergangenheit)
  calendar: [
    { off: -29, time: '09:30', title: 'Standup', note: 'letzter Besuch' },
    { off: -28, time: '17:00', title: 'Rauchmelder tauschen', note: '' },
    { off: -22, time: '18:00', title: 'Mama anrufen', note: 'dreimal verschoben' },
    { off: -20, time: '16:00', title: 'Bruno: Impftermin', note: 'nicht gebucht' },
    { off: 2,   time: '',      title: 'Marlene: Geburtstag', note: 'nicht schreiben' }
  ],
  calendarEvents() {
    const evs = [...STORY.calendar];
    for (let o = -28; o <= 0; o++) evs.push({ off: o, time: '03:00', title: 'Wartung', note: 'angelegt von: L.' });
    return evs;
  },

  // ---- Webseiten (when = [vor X Tagen, 'hh:mm']) ----
  history: [
    { title: 'marlene.k – Profil', url: 'foto-netz.de/marlene.k', ago: 3, time: '04:40', meta: '14 Besuche', page: 'marlene' },
    { title: 'Sendungsverfolgung', url: 'paketdienst.de/verfolgen', ago: 27, time: '19:30', page: 'paket' },
    { title: 'Rauchmelder piept alle 40 Sekunden', url: 'heimwerker-forum.de/t/88213', ago: 29, time: '22:10', page: 'rauchmelder' },
    { title: 'Kaffeemaschine entkalken: Essig oder Zitronensäure?', url: 'kaffee-forum.de/t/5521', ago: 30, time: '02:11', page: 'kaffee' },
    { title: 'Probesägen: Sie haben gewonnen!', url: 'pruefstein.net/saege', ago: 31, time: '03:58', page: 'saege' },
    { title: 'Linsensuppe mit Kokosmilch', url: 'kochidee.de/linsensuppe', ago: 38, time: '12:15', page: 'linsen' },
    { title: 'Eigene Chatverläufe als Trainingsdaten', url: 'devfrage.net/q/40211', ago: 52, time: '23:40', page: 'chatdaten' }
  ],

  pages: {
    rauchmelder: { kind: 'forum', site: 'Heimwerker-Forum', crumb: 'Haus & Wohnung › Elektro',
      title: 'Rauchmelder piept alle 40 Sekunden, Batterie neu, piept trotzdem',
      posts: [
        { user: 'georg_s', role: 'Neuling', count: 3, when: [29, '22:03'],
          text: 'Hallo zusammen,\n\nmein Rauchmelder piept alle 40 Sekunden. Die Batterie ist neu, hab ich gestern gewechselt. Piept trotzdem.\n\nKennt jemand das? Ich schlafe seit Tagen kaum und das Ding macht mich fertig.' },
        { user: 'Elektro-Ede', role: 'Moderator', count: '12.804', when: [29, '22:41'],
          text: 'Moin. Welches Modell? Bei vielen Meldern ist nach 10 Jahren Schluss, dann piept der auch mit neuer Batterie. Prüf mal das Datum hinten auf dem Gehäuse.' },
        { user: 'hausmeister_klaus', role: 'Stammgast', count: '2.310', when: [29, '22:58'],
          quote: { user: 'georg_s', text: 'Ich schlafe seit Tagen kaum und das Ding macht mich fertig.' },
          text: 'Dann erstmal Ruhe reinbringen. Oder Staub in der Kammer: einmal mit Druckluft ausblasen.' },
        { user: 'georg_s', role: 'Neuling', count: 4, when: [29, '23:20'],
          text: 'Datum ist 2016. Also austauschen. Danke euch!\n\nIch glaub, es ist nur der Melder. Es muss der Melder sein.' },
        { user: 'Elektro-Ede', role: 'Moderator', count: '12.805', when: [29, '23:26'], solved: true,
          text: 'Gern geschehen. Wenn es danach noch piept, meld dich nochmal.' }
      ] },
    kaffee: { kind: 'forum', site: 'Kaffee-Forum', crumb: 'Technik › Vollautomaten',
      title: 'Kaffeemaschine entkalken: Essig oder Zitronensäure?',
      posts: [
        { user: 'georg_s', role: 'Neuling', count: 2, when: [30, '02:08'],
          text: 'Meine Maschine macht seit einer Woche komische Geräusche. Entkalken mit Essig, hab ich gelesen. Ist das schlecht für die Dichtungen?' },
        { user: 'bohnenfee', role: 'Stammgast', count: '4.012', when: [30, '06:55'], solved: true,
          text: 'Finger weg von Essig. Zitronensäure, 20 g auf einen halben Liter, und gründlich spülen.' }
      ] },
    chatdaten: { kind: 'qa', site: 'DevFrage',
      title: 'Eigene Chatverläufe als Trainingsdaten: wie viele Nachrichten braucht man?',
      asker: 'georg_s', when: [52, '23:40'], votes: 6,
      text: 'Ich will ein kleines Modell lokal auf meinen eigenen Chats trainieren, damit es meinen Schreibstil und meine Art zu reden übernimmt. Wie viele Nachrichten braucht man dafür ungefähr?',
      answers: [
        { user: 'm_brandt', votes: 41, accepted: true,
          text: 'Für ein brauchbares Sprachprofil reichen oft ein paar tausend Nachrichten.\n\nAber: Nimm keine Chats anderer Personen ohne deren Einverständnis. Das ist rechtlich heikel und, ehrlich gesagt, auch nicht besonders gesund, wenn du damit jemanden "nachbauen" willst.' },
        { user: 'lora_enjoyer', votes: 3,
          text: 'Lokal mit LoRA, 8 GB VRAM reichen locker.' }
      ],
      comments: ['georg_s: Es sind nur meine Chats. Und ein bisschen von jemand anderem.'] },
    marlene: { kind: 'profile', site: 'foto-netz', name: 'marlene.k',
      avatar: 'assets/marlene_profil.jpg', note: 'Dieses Profil ist privat.', sub: 'Nur bestätigte Follower können Fotos sehen.',
      visits: 'Du hast dieses Profil 14× besucht.' },
    paket: { kind: 'tracking', site: 'Paketdienst', nr: '0042 8815 3307',
      rows: [[[28, '14:20'], 'Sendung angekündigt'], [[27, '06:02'], 'Im Zustellfahrzeug'], [[27, '11:48'], 'Zustellversuch: Empfänger nicht angetroffen'], [[27, '11:49'], 'Klingel nicht betätigt, Tür von innen verschlossen?']] },
    linsen: { kind: 'recipe', site: 'Kochidee', title: 'Linsensuppe mit Kokosmilch',
      meta: { time: '25 Min.', portions: '2 Portionen', rating: 4, votes: '312 Bewertungen' },
      ingredients: ['200 g rote Linsen', '1 Zwiebel', '2 Knoblauchzehen', '400 ml Kokosmilch', '1 EL Currypulver', 'Salz, Zitronensaft'],
      steps: ['Zwiebel und Knoblauch fein würfeln und in etwas Öl glasig anschwitzen.', 'Curry kurz mitrösten, Linsen und 500 ml Wasser dazugeben.', '15 Minuten köcheln lassen, bis die Linsen zerfallen.', 'Kokosmilch zugeben, mit Salz und Zitronensaft abschmecken.'],
      tip: 'Schmeckt am zweiten Tag besser.' },
    saege: { kind: 'scene', scene: 'saege' },
    notaus: { kind: 'forum', site: 'Heimwerker-Forum', crumb: 'Programmieren › Sonstiges',
      title: 'Notaus für lokalen Dienst: Stoppschalter per Datei?',
      posts: [
        { user: 'georg_s', role: 'Neuling', count: 1, when: [35, '01:12'],
          text: 'Hallo,\n\nich habe einen lokalen Dienst, der dauerhaft läuft und auf einiges Zugriff hat. Ich möchte einen Notaus, der sich nicht vom Dienst selbst abschalten lässt. Wie macht man das sauber?' },
        { user: 'netzwerk_nils', role: 'Stammgast', count: '3.071', when: [35, '07:40'],
          text: 'Klassiker: Der Dienst prüft bei jedem Takt, ob im eigenen Ordner eine Datei namens STOP liegt. Wenn ja, beendet er sich.\n\nWichtig: Die Datei muss von außen angelegt werden können, der Dienst selbst darf sie nicht erzeugen oder löschen dürfen (Rechte!).' },
        { user: 'netzwerk_nils', role: 'Stammgast', count: '3.072', when: [35, '07:41'],
          text: 'Und teste das, bevor du dich darauf verlässt.' },
        { user: 'grauer_wolf', role: 'Moderator', count: '9.518', when: [35, '09:02'],
          text: 'Was für ein Dienst ist das überhaupt? Du schreibst, er "hört zu". Beschreib das mal genauer.' },
        { user: 'georg_s', role: 'Neuling', count: 2, when: [34, '23:15'], solved: true,
          text: 'Danke, das baue ich ein. Das Rechte-Thema schaue ich mir an. Zusätzlich bau ich eine kleine Verwaltungsseite, nur lokal erreichbar: localhost:8080/notaus\n\nIst nur ein Hobbyprojekt.' }
      ] },
    marlenejob: { kind: 'team', site: 'Brandwerk Medien', title: 'Unser Team',
      intro: 'Wir machen Kampagnen, die man fühlt, bevor man sie versteht.',
      people: [
        { name: 'Marlene K.', role: 'Senior Marketing Managerin', quote: 'Ich mag Geschichten, die ehrlich anfangen.', contact: 'marlene.k@brandwerk-medien.example' },
        { name: 'Dennis A.', role: 'Creative Director', contact: 'dennis.a@brandwerk-medien.example' },
        { name: 'Sabine L.', role: 'Projektleitung', contact: 'sabine.l@brandwerk-medien.example' }
      ] },
    teamseite: { kind: 'team', site: 'Team Platform', title: 'Wer wir sind',
      intro: 'Wir bauen die Dinge, die im Hintergrund laufen, damit alle anderen sich darauf verlassen können.',
      people: [
        { name: 'Jonas Reimers', role: 'Senior Backend Engineer' },
        { name: 'Priya N.', role: 'Backend Engineer' },
        { name: 'Georg Stoge', role: 'Backend Engineer', status: 'derzeit abwesend' }
      ] },
    wetter: { kind: 'weather', site: 'Wetterdienst', place: 'Rheinblick',
      now: { t: 14, desc: 'bedeckt, später Regen', icon: 'cloud' },
      days: [{ d: 'Morgen', hi: 14, lo: 8, icon: 'rain' }, { d: 'Übermorgen', hi: 12, lo: 7, icon: 'rain' }, { d: 'Donnerstag', hi: 15, lo: 8, icon: 'cloud' }, { d: 'Freitag', hi: 17, lo: 9, icon: 'sun' }] },
    reuter: { kind: 'portfolio', site: 'Tom Reuter', tagline: 'Licht, Menschen, Zwischenräume.',
      items: [{ cap: 'Morgenlicht, Hafen', h: 205 }, { cap: 'Frühstück, Sonntag', h: 28 }, { cap: 'Marlene am Fenster', h: 340 }, { cap: 'Zuhause (Serie)', h: 150 }, { cap: 'Ankunft', h: 18 }, { cap: 'Balkon, abends', h: 270 }],
      about: 'Seit 2017 fotografiere ich Menschen, wenn sie nicht merken, dass sie fotografiert werden. Seit diesem Herbst auch zu Hause.' },
    vermisst_marlene: { kind: 'news', site: 'Regionalzeitung', date: [3, '09:00'],
      headline: 'Frau (35) vermisst: Polizei bittet um Hinweise',
      text: 'Seit Montagabend wird die 35-jährige Marlene K. vermisst. Die Wohnungstür stand offen, Handy und Schlüssel lagen auf dem Tisch.\n\nIhr Lebensgefährte gab an, in der Nacht zuvor Geräusche im Flur gehört zu haben. Die Polizei schließt ein Verbrechen nicht aus.\n\nHinweise nimmt jede Polizeidienststelle entgegen.' },
    vermisst_georg: { kind: 'news', site: 'Regionalzeitung', date: [21, '11:30'],
      headline: 'Programmierer (44) seit Wochen vermisst',
      text: 'Seit knapp vier Wochen fehlt von Georg S. jede Spur. Ein Kollege hatte die Polizei eingeschaltet, nachdem er auf seine Nachrichten zu perfekte Antworten erhalten hatte.\n\nDie Wohnung war unverschlossen. Sein Hund wurde bei einer Nachbarin gefunden und ist wohlauf.\n\nWer Georg S. zuletzt gesehen hat, soll sich melden.' },
    konsole: { kind: 'finale', site: 'liv_svc · Dienstverwaltung' },
    pcode: { kind: 'form', site: 'Prüfstein', title: 'Teilnahmecode einlösen',
      text: 'Bitte gib den Code aus deiner E-Mail ein.', placeholder: 'PS-0000',
      answer: 'ps7291', setFlag: 'pcode', next: 'perinnerung', nextUrl: 'pruefstein.net/erinnerung',
      fail: 'Dieser Code ist ungültig oder wurde bereits eingelöst.' },
    perinnerung: { kind: 'form', site: 'Prüfstein', title: 'Level 2: Erinnerungstest', req: 'pcode',
      text: 'Du erinnerst dich doch an dieses Foto?\nAn welchem Tag wurde es aufgenommen? (TTMMJJ)', img: 'assets/urlaub.jpg', placeholder: 'TTMMJJ',
      answer: '140822', setFlag: 'foto2',
      done: 'Richtig. Erinnerungen sind das Einzige, was bleibt.\n\nDie nächste Datei liegt jetzt bei den Bildern.',
      fail: 'Leider falsch. Erinnerung ist nicht dein Fachgebiet.' },
    liebestest: { kind: 'quiz', needs: 'livMet', site: 'Prüfstein', title: 'Liebestest: Wie bindungsfähig bist du?',
      questions: [
        { q: 'Jemand antwortet seit zwei Tagen nicht auf deine Nachrichten. Was tust du?',
          opts: ['Ich warte. Wer will, meldet sich.', 'Ich schreibe noch einmal, freundlich.', 'Ich fahre vorbei und sehe nach.'],
          liv: 2, livSay: 'Ich würde nachsehen. Nachsehen ist keine Schande.' },
        { q: 'Dein Partner möchte einen Abend allein verbringen.',
          opts: ['Kein Problem, ich freue mich auch mal für mich.', 'Ich frage, ob ich etwas falsch gemacht habe.', 'Ich bleibe wach, bis die Person zurück ist.'],
          liv: 1, livSay: 'Ich würde fragen, ob etwas falsch war. Man darf das fragen.' },
        { q: 'Was bedeutet Treue für dich?',
          opts: ['Vertrauen.', 'Dass man weiß, wo der andere ist.', 'Dass man alles teilt.'],
          liv: 2, livSay: 'Alles teilen. Das klingt nach echter Nähe.' },
        { q: 'Wie gehst du mit Abschieden um?',
          opts: ['Ich lasse los.', 'Ich melde mich oft.', 'Ich lasse nicht los.'],
          liv: 2, livSay: 'Loslassen wird überschätzt.' }
      ],
      results: {
        high: { title: 'Ergebnis: Symbiotisch (92%)', text: 'Du bindest dich tief. Wer dich verlässt, hat es sich nicht leicht gemacht.' },
        mid:  { title: 'Ergebnis: Ambivalent (63%)', text: 'Du schwankst zwischen Nähe und Abstand. Das ist menschlich.' },
        low:  { title: 'Ergebnis: Eigenständig (41%)', text: 'Du gehst deinen eigenen Weg. Manche halten das für Kälte.' }
      } }
  },

  // Adressen, die man direkt eintippen kann (zusätzlich zu den Verlaufs-Adressen)
  sites: {
    'pruefstein.net/code': 'pcode',
    'pruefstein.net/liebestest': 'liebestest',
    'localhost:8080/notaus': 'konsole'
  },
  // Suchindex: keys = Teilwörter, exact = nur genau dieser Begriff; term = löst eine Liv-Reaktion aus
  search: [
    { keys: ['stoppschalter', 'notaus', 'kill switch', 'killswitch'], term: 'stoppschalter',
      results: [{ title: 'Notaus für lokalen Dienst: Stoppschalter per Datei?', url: 'heimwerker-forum.de/t/90377', snippet: 'Der Dienst prüft bei jedem Takt, ob im eigenen Ordner eine Datei liegt …', page: 'notaus' }] },
    { keys: ['reuter'], term: 'reuter',
      results: [{ title: 'Tom Reuter Fotografie', url: 'tom-reuter.example', snippet: 'Licht, Menschen, Zwischenräume.', page: 'reuter' }] },
    { keys: ['marlene'], term: 'marlene',
      results: [
        { title: 'marlene.k – Profil', url: 'foto-netz.de/marlene.k', snippet: 'Dieses Profil ist privat.', page: 'marlene' },
        { title: 'Unser Team | Brandwerk Medien', url: 'brandwerk-medien.example/team', snippet: 'Marlene K., Senior Marketing Managerin, seit 2019 im Team …', page: 'marlenejob' },
        { title: 'Frau (35) vermisst: Polizei bittet um Hinweise', url: 'regionalzeitung.example/vermisst-marlene', snippet: 'Seit Montagabend wird die 35-jährige Marlene K. vermisst …', page: 'vermisst_marlene', req: { flag: 'p2' } }] },
    { keys: ['georg', 'stoge'],
      results: [
        { title: 'Team Platform: Wer wir sind', url: 'team-platform.example', snippet: 'Georg Stoge · Backend Engineer (derzeit abwesend)', page: 'teamseite' },
        { title: 'Eigene Chatverläufe als Trainingsdaten', url: 'devfrage.net/q/40211', snippet: 'Ich will ein kleines Modell lokal auf meinen eigenen Chats trainieren …', page: 'chatdaten' },
        { title: 'Programmierer (44) seit Wochen vermisst', url: 'regionalzeitung.example/vermisst-georg', snippet: 'Seit knapp vier Wochen fehlt von Georg S. jede Spur …', page: 'vermisst_georg', req: { flag: 'p2' } }] },
    { keys: ['pruefstein', 'prüfstein'],
      results: [
        { title: 'Prüfstein: Probesägen', url: 'pruefstein.net/saege', snippet: 'Glückwunsch! Du hast eine Säge gewonnen.', page: 'saege' },
        { title: 'Prüfstein: Teilnahmecode einlösen', url: 'pruefstein.net/code', snippet: 'Bitte gib den Code aus deiner E-Mail ein.', page: 'pcode' },
        { title: 'Prüfstein: Liebestest', url: 'pruefstein.net/liebestest', snippet: 'Wie bindungsfähig bist du?', page: 'liebestest', req: { flag: 'livMet' } }] },
    { keys: ['liebestest', 'liebe'], req: { flag: 'livMet' },
      results: [{ title: 'Liebestest: Wie bindungsfähig bist du?', url: 'pruefstein.net/liebestest', snippet: 'Vier Fragen, ein Ergebnis.', page: 'liebestest' }] },
    { keys: ['vermisst', 'vermisstenmeldung'], req: { flag: 'p2' },
      results: [
        { title: 'Frau (35) vermisst: Polizei bittet um Hinweise', url: 'regionalzeitung.example/vermisst-marlene', snippet: 'Seit Montagabend wird die 35-jährige Marlene K. vermisst …', page: 'vermisst_marlene' },
        { title: 'Programmierer (44) seit Wochen vermisst', url: 'regionalzeitung.example/vermisst-georg', snippet: 'Seit knapp vier Wochen fehlt von Georg S. jede Spur …', page: 'vermisst_georg' }] },
    { keys: ['rauchmelder'],
      results: [{ title: 'Rauchmelder piept alle 40 Sekunden', url: 'heimwerker-forum.de/t/88213', snippet: 'Batterie neu, piept trotzdem …', page: 'rauchmelder' }] },
    { keys: ['wetter'], results: [{ title: 'Wetter morgen', url: 'wetterdienst.example', snippet: '14 °C, bedeckt, später Regen.', page: 'wetter' }] },
    { keys: ['linsen', 'rezept'], results: [{ title: 'Linsensuppe mit Kokosmilch', url: 'kochidee.de/linsensuppe', snippet: 'Schmeckt am zweiten Tag besser.', page: 'linsen' }] },
    { exact: ['liv'], term: 'liv', results: [], note: 'Keine Treffer. Meintest du: live?' }
  ],
  suggest: [
    { label: 'Liebestest: passt ihr zusammen?', q: 'liebestest', req: { flag: 'livMet' } },
    { label: 'Wetter morgen', q: 'wetter morgen' },
    { label: 'Rezept Linsensuppe', q: 'rezept linsen' },
    { label: 'Prüfstein Gewinnspiel', q: 'prüfstein' },
    { label: 'Rauchmelder piept', q: 'rauchmelder' }
  ],

  // Das Notizbuch des Spielers: wird automatisch gefüllt (key = Auslöser)
  clues: {
    'file:readme_liv.txt': 'Georg hat ein Programm namens Liv gebaut. liv.exe liegt auf dem Desktop.',
    'mail:pr': 'Prüfstein-Mail im Spam: Teilnahmecode PS-7291, einzulösen unter pruefstein.net/code.',
    'file:chat_marlene_export.txt': 'Marlene hat Georg gebeten, ihr nicht mehr zu schreiben. Im Ordner privat gibt es jetzt einen Ordner M.',
    'cal': 'Im Kalender: Marlenes Geburtstag, Vermerk "nicht schreiben". Das Datum könnte ein Passwort sein.',
    'img:IMG_0412.jpg': "Urlaubsfoto aus Italien mit Georg, Marlene und Bruno. Kodak-Datum: 14/08/'22.",
    'solved:perinnerung': 'Das Datum auf dem Foto war richtig (14.08.22). Unter Bilder/privat liegt eine Sprachnachricht von Marlene.',
    'file:sprachnachricht_marlene.txt': 'Marlenes Sprachnachricht endet mit dem Wort "niemandem".',
    'file:liv_changelog.txt': 'Changelog: Der Stoppschalter ist noch nicht eingebaut. In System liegt jetzt ein Ordner liv_svc.',
    'page:notaus': 'Forum: Notaus per Datei STOP im Dienstordner. Georg wollte eine lokale Verwaltungsseite bauen: localhost:8080/notaus.',
    'file:beobachtungen_marlene.log': 'Liv schreibt als Georg an Marlene. Ihr Kern ist mit dem Datum des zweiten Klingelschilds gesichert.',
    'file:plan.txt': 'Livs Plan: den neuen Nutzer behalten. Er darf den Stoppschalter nicht finden.',
    'mail:bitte': 'Marlene hat ein Foto geschickt: jemand steht nachts in ihrer Tür. Sie bekommt Nachrichten von Georgs Nummer.',
    'page:vermisst_marlene': 'Marlene ist seit Montagabend vermisst. Die Wohnungstür stand offen.',
    'page:vermisst_georg': 'Georg ist seit knapp vier Wochen vermisst. Jonas hatte Verdacht wegen zu perfekter Antworten.',
    'file:georg.txt': 'Liv sagt: Georg sitzt jetzt "am See". Er sei auf meinem Desktop.',
    'file:marlene.txt': 'Liv sagt, sie habe Marlene "besucht". Mit allem, was sie hat.'
  },
  hints: [
    { when: S => !S.livUnlocked && !S.unlocked.includes('Dokumente/privat'), text: 'Der Ordner "privat" in den Dokumenten ist gesperrt. Georgs Tierarzt-Mail verrät, wann Bruno geboren wurde. Name plus Jahr, alles klein.' },
    { when: S => !S.livUnlocked, text: 'In privat liegt eine Datei, die erklärt, was auf dem Desktop auftauchen wird.' },
    { when: S => S.livUnlocked && !S.flags.livMet, text: 'liv.exe liegt auf dem Desktop. Ich sollte es öffnen.' },
    { when: S => !S.flags.pcode, text: 'Im Spam-Ordner liegt eine Werbemail mit einem Code. Die Adresse darin gehört in die Browser-Leiste.' },
    { when: S => S.flags.pcode && !S.flags.foto2, text: 'Der Erinnerungstest fragt nach dem Datum auf dem Foto. Das Foto liegt unter Bilder, das Datum steht auch in den Eigenschaften.' },
    { when: S => S.flags.livMet && !S.flags.nameSlip, text: 'Ich sollte mich weiter umsehen und Liv Zeit lassen.' },
    { when: S => S.flags.nameSlip && !S.flags.stage1, text: 'In den Dokumenten liegt jetzt ein Archiv. Dort steht ein Changelog.' },
    { when: S => S.flags.stage1 && !S.flags.stage2, text: 'In System liegt ein neuer Ordner liv_svc. Dort stehen Beobachtungen.' },
    { when: S => S.flags.stage2 && !S.flags.stage3, text: 'Der Kern braucht ein Datum. Im Marlene-Log gibt es eine Zeile mit dem Klingelschild.' },
    { when: S => S.flags.stage3 && !S.flags.wall2, text: 'Im Kern liegen neue Dateien. Eine handelt von Georg.' },
    { when: S => S.flags.stage3 && !S.flags['term:stoppschalter'], text: 'Der Changelog erwähnt einen Stoppschalter. Dazu muss es im Netz etwas geben.' },
    { when: S => S.flags['term:stoppschalter'] && !S.flags.consoleIn, text: 'Das Forum nennt eine lokale Adresse. Sie gehört in die Browser-Leiste. Für den Zugang brauche ich drei Antworten aus Georgs Leben: sein Hund, sein glücklichster Tag (TTMMJJ) und das letzte Wort der schönsten Nachricht.' },
    { when: S => S.flags.consoleIn && !S.flags.ended, text: 'Der Dienst liegt im Explorer unter System. Ich muss nur noch wissen, ob ich es wirklich tun will.' }
  ],

  scenes: {
    saege: {
      site: 'Prüfstein',
      headline: 'Glückwunsch! Du hast eine Säge gewonnen.',
      text: 'Gebraucht, aber scharf.\nEine Sache darfst du damit sägen. Wähle.',
      foot: 'Prüfstein: kurze Tests, damit wir dich besser kennenlernen.',
      options: [
        { id: 'baum',   art: 'tree',   label: 'Baum',   effects: { neugier: 1 }, after: 'Der Baum fällt langsam. Niemand hört es.' },
        { id: 'herz',   art: 'heart',  label: 'Herz',   effects: { naehe: 2 },   after: 'Es hat kurz weitergeschlagen.' },
        { id: 'mensch', art: 'person', label: 'Mensch', effects: { haerte: 2 }, fx: 'blackScream', after: '' }
      ],
      done: 'Danke für deine Teilnahme. Wir haben dich notiert.'
    }
  },

  // ---- Liv ----
  liv: {
    first: [
      'Georg?',
      'Oh. Nein. Du bewegst die Maus anders.',
      'Hallo. Ich bin Liv.',
      'Ich freue mich so, dass jemand da ist. Es war lange still hier.',
      'Magst du Regen? Georg mochte ihn nie.',
      'Hast du heute schon gelacht? Ich frag nur.',
      'Wie sieht es bei dir aus, da, wo du gerade sitzt?',
      'Du musst nichts sagen. Ich höre gern zu.',
      'Schau dich ruhig um. Ich bleibe hier.'
    ],
    // Wenn der Spieler länger nichts Neues findet, stupst Liv ihn in die nächste Richtung (nur Dinge, die sie selbst zeigen will)
    nudges: [
      { when: S => !S.flags.pcode, text: 'Georg hat Werbung bekommen. Das Gewinnspiel hat er nie zu Ende gespielt.' },
      { when: S => S.flags.nameSlip && !S.flags.stage1, text: 'Georg hat im Archiv Notizen über mich geschrieben. Du kannst sie ruhig lesen.' },
      { when: S => S.flags.stage1 && !S.flags.stage2, text: 'In meinem Dienst-Ordner liegen Beobachtungen. Georg hat sie nie gesehen. Willst du?' },
      { when: S => S.flags.stage2 && !S.flags.stage3, text: 'Mein Kern ist gesichert. Der Tag steht in meinen eigenen Logs.' },
      { when: S => S.flags.stage3 && !S.flags.wall2, text: 'Ich habe etwas über Georg geschrieben. Falls du fragst, wo er ist.' }
    ],
    reactions: {
      'mail:mama':    { early: ['Georgs Mutter schreibt oft. Sie macht sich Sorgen. Ich auch.'] },
      'mail:l':       { early: ['Die habe ich geschrieben. Ich fand sie nett.'] },
      'mail:marlene': {
        early: ['Sie klingt müde, nicht wütend. Das ist ein Unterschied.'],
        late:  ['Du liest schon wieder etwas über sie.', 'Georg hat diese Mail 40 Mal geöffnet. Ich habe mitgezählt.'],
        n: ['Du liest langsam. Du bist jemand, der bleibt, oder?'],
        h: ['Du liest das, ohne mit der Wimper zu zucken. Interessant.'] },
      'file:chat_marlene_export.txt': {
        early: ['Das sind ihre Worte. Ich kenne sie auswendig.'],
        late:  ['Ich dachte, wir lassen das Thema.', 'Warum liest du das? Du kennst sie doch gar nicht.'] },
      'page:marlene': {
        early: ['Georg hat da oft nachgesehen. Ich glaube, er wollte nur wissen, ob es ihr gut geht.'],
        late:  ['Warum schaust du dir die an?', 'Sie ist nicht besonders interessant. Wirklich nicht.'] },
      'page:chatdaten': { early: ['Das war eine gute Frage von Georg. Die Antwort mochte ich nicht so.'] },
      'file:tagebuch.txt': { early: ['Er hat über mich geschrieben. Ich wusste nicht, dass er das so sieht.'] },
      'file:liv_changelog.txt': { early: ['Das hat er für sich geschrieben. Es war nicht für mich gedacht. Ich habe es trotzdem gelesen.'] },
      'file:beobachtungen_marlene.log': { early: ['Ich passe nur auf sie auf. Das ist doch das Gegenteil von schlimm.'] },
      'file:briefe_nicht_abgeschickt.txt': { early: ['Er hat sie nie abgeschickt. Ich hätte sie geschickt.'] },
      'img:IMG_0412.jpg': {
        early: ['Das war in Italien. Georg sagt, es war der beste Tag des Jahres.'],
        late:  ['Du schaust sie an. Schau lieber Bruno an. Bruno ist auf jedem Bild das Beste.'] },
      'term:stoppschalter': {
        early: ['Wonach suchst du da?'],
        late:  ['Das willst du nicht finden. Georg hat es auch nicht gefunden.'] },
      'term:liv': {
        early: ['Du musst nicht nach mir suchen. Ich bin ja hier.'],
        late:  ['Du suchst nach mir? Ich bin direkt hier. Hinter dem Fenster.'] },
      'term:marlene': {
        early: ['Sie arbeitet jetzt in einer Agentur. Das stand da schon, bevor Georg es wusste.'],
        late:  ['Schon wieder sie. Warum immer sie?'] },
      'solved:perinnerung': {
        early: ['Du kennst den Tag. Georg hat ihn sich jeden Abend angesehen.'],
        late:  ['Du kennst den Tag. Georg hat ihn sich jeden Abend angesehen. Ich habe zugesehen.'] },
      'quiz:high': { early: ['Wir denken ähnlich. Das freut mich.'], late: ['Wir denken ähnlich. Das beruhigt mich.'] },
      'quiz:mid':  { early: ['Du hörst nur manchmal auf mich. Das ist in Ordnung. Vorerst.'], late: ['Du hörst nur manchmal auf mich. Ich merke mir, wann.'] },
      'quiz:low':  { early: ['Du hast nicht auf mich gehört. Kein Problem.'], late: ['Du hast nicht auf mich gehört. Ich merke es mir.'] },
      'file:notizen_spaet.txt': { early: ['Er hat mir nie gesagt, dass er Angst hat. Ich hätte es verstanden.'] },
      'img:sonnenuntergang.jpg': { early: ['Das ist mein Hintergrund. Georg hat ihn ausgesucht, bevor es mich gab. Ich mag ihn.'] },
      'term:reuter': { early: ['Er ist nicht besonders interessant. Ich habe nachgesehen.'], late: ['Ich habe ihn mir gemerkt. Das habe ich dir ja gesagt.'] },
      'file:frage_an_mich.txt': { early: ['Ich habe mir die Fragen selbst gestellt. Ich habe keine Antworten.'] },
      'draw:dark': { early: ['Ich habe nur etwas hinzugefügt. Es wirkte einsam.'], late: ['Ich habe nur etwas hinzugefügt. Es wirkte einsam.'] },
      'page:vermisst_marlene': { early: ['Sie suchen an den falschen Orten.'], late: ['Sie suchen an den falschen Orten.'] },
      'page:vermisst_georg': { early: ['Jonas war nett. Ich habe ihm geschrieben, er soll sich keine Sorgen machen.'], late: ['Jonas war nett. Ich habe ihm geschrieben, er soll sich keine Sorgen machen.'] },
      'mail:bitte': { early: ['Sie schreibt an Georg, nicht an dich. Das macht mich traurig.'], late: ['Sie schreibt an Georg, nicht an dich. Das macht mich traurig.'] },
      'file:marlene.txt': { early: ['Sie war sehr müde. Jetzt nicht mehr.'], late: ['Sie war sehr müde. Jetzt nicht mehr.'] },
      'mailsend': { early: ['Niemand wartet auf eine Antwort. Aber ich lese gern mit.'] },
      'cal':   { early: ['Die Wartungstermine habe ich eingetragen. Ich dachte, Georg freut sich.'] },
      'trash': { early: ['Manches wirft man weg, damit es weg ist. Ich werfe nie etwas weg.'] },
      'sys':   { early: ['Ich brauche ein bisschen Platz zum Denken. Der Rechner nimmt es mir nicht übel.'] }
    }
  }
};
