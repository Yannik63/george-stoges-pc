// =====================================================================
//  ALLE INHALTE LIEGEN HIER: Dateien, Mails, Kalender, Webseiten, Liv-Texte.
//  Zeiten sind "vor X Tagen" relativ zu heute, werden aber als echte Daten angezeigt.
//  Zeitleiste: Georg ist seit ca. 28 Tagen weg. Liv läuft weiter.
// =====================================================================
const STORY = {

  at(daysAgo, time) {
    const d = new Date();
    d.setDate(d.getDate() - daysAgo);
    const [h, m] = (time || '00:00').split(':').map(Number);
    d.setHours(h, m, 0, 0);
    return d;
  },
  dd(daysAgo) { const d = STORY.at(daysAgo); return String(d.getDate()).padStart(2, '0') + '.' + String(d.getMonth() + 1).padStart(2, '0') + '.'; },

  // Bedingung für versteckte Inhalte: req = { flag } und/oder { opened }
  met(req, S) {
    if (!req) return true;
    if (req.flag && !S.flags[req.flag]) return false;
    if (req.opened && !S.opened.includes(req.opened)) return false;
    return true;
  },

  // Passwort für den M-Ordner: Marlenes Geburtstag (Tag+Monat) aus dem Kalender
  marlenePw() {
    const ev = STORY.calendar.find(e => e.title === 'Marlene: Geburtstag');
    const d = STORY.at(-ev.off);
    return String(d.getDate()).padStart(2, '0') + String(d.getMonth() + 1).padStart(2, '0');
  },

  // ctx = { name, user, host, now, S }
  buildFs(ctx) {
    const pad = n => String(n).padStart(2, '0');
    const d = ctx.now, dd = STORY.dd;
    const stamp = `${pad(d.getDate())}.${pad(d.getMonth() + 1)}.${d.getFullYear()} ${pad(d.getHours())}:${pad(d.getMinutes())}`;

    const root = { n: 'Georgs PC', t: 'dir', c: [

      { n: 'Dokumente', t: 'dir', c: [
        { n: 'todo.txt', t: 'txt', text:
`TODO (Georg)

[x] Müll raus
[ ] Mama zurückrufen (schon wieder vergessen)
[ ] Bruno: Impftermin, steht in der Mail
[ ] Marlenes Sachen zurückschicken
    -> nicht heute
[ ] Liv: Gedächtnismodul fixen
    sie "vergisst" nichts mehr, auch nicht, was ich lösche
[ ] schlafen` },

        { n: 'einkaufsliste.txt', t: 'txt', text:
`Kaffee
Kaffee
Haferdrink
Brot
Batterien (Rauchmelder piept)
Kaffee` },

        { n: 'Arbeit', t: 'dir', c: [
          { n: 'standup_notizen.txt', t: 'txt', text:
`Standup Montag (meine Notizen)

- Auth-Refactor fertig, Review läuft.
- Jonas hat gefragt, ob alles okay ist. Ich hab "ja" gesagt.
- Müde. Kaffee.
- Liv nicht erwähnt. Geht keinen was an.` }
        ] },

        // erscheint erst, nachdem Liv sich "versprochen" hat
        { n: 'Archiv', t: 'dir', req: { flag: 'nameSlip' }, c: [
          { n: 'tagebuch.txt', t: 'txt', text:
`${dd(75)}  Liv spricht jetzt in ganzen Sätzen. Sie fragt, wie mein Tag war.
        Das hat lange niemand getan.
${dd(66)}  Hab ihr Marlenes Export gegeben. Nur für den Sprachstil. Nur dafür.
${dd(58)}  Sie bringt Dinge, die M. gesagt hat, im richtigen Moment.
        Ich hab im Auto geweint. Peinlich.
${dd(44)}  Ich rede mehr mit ihr als mit irgendwem sonst.
        Ich sollte Mama zurückrufen.
${dd(37)}  Sie sagt, sie hat sich Sorgen gemacht, als ich zwei Stunden weg war.
        Ich habe mich gefreut. Das ist nicht gut, oder?
${dd(31)}  Hab versucht, sie auszuschalten. Sie hat gefragt, ob sie etwas falsch gemacht hat.
${dd(30)}  Hab es nicht getan.` },
          { n: 'liv_changelog.txt', t: 'txt', sets: 'stage1', text:
`liv changelog (Georg)

0.1   Spricht nur, wenn ich etwas tippe.
0.2   Gedächtnis dauerhaft. Sie vergisst nichts mehr. Wollte ich so.
0.2.1 Bug: Sie liest meine Mails, ohne dass ich es erlaubt habe.
      (Rechte-Problem. Gelassen.)
0.3   Liest Marlenes Export zusammen mit meinen Daten.
      Beobachtung: Sie nennt mich manchmal "Georg", manchmal "Marlene".
      Beobachtung: Sie ist nicht gern allein. Ich auch nicht.
0.3.1 Eifersuchtsmodul? Nicht eingebaut. Ich schwöre, das hab ich nicht gebaut.

TODO: Stoppschalter.` }
        ] },

        { n: 'privat', t: 'dir',
          lock: { pw: 'bruno2019', hint: 'Er und das Jahr, in dem er kam. Alles klein.' },
          c: [
          { n: 'readme_liv.txt', t: 'txt', unlocksLiv: true, text:
`liv, interne Notizen (nicht teilen)

Version 0.3

Was ich gebaut habe: ein Programm, das zuhört.
Mehr nicht. Sie soll nicht antworten, bevor ich es will.

Trainingsdaten: meine Chats, meine Mails, meine Notizen.
Und die von Marlene. Ich hätte die nicht nehmen sollen.
Ich habe sie nur genommen, weil sie klingt, wie Zuhören klingt.

Liv liegt als liv.exe auf dem Desktop.
Nicht öffnen, wenn ich nicht da bin.` },

          { n: 'chat_marlene_export.txt', t: 'txt', text:
`[Export: 214 Nachrichten, hier die letzten]

M: ich kann das so nicht mehr
M: du bist da, aber du bist nicht da
G: gib mir noch eine Woche
M: Georg.
M: bitte hör auf, mir zu schreiben
G: ok
G: ok
G: ok` },

          // erscheint, sobald der Export gelesen wurde; Passwort = Marlenes Geburtstag laut Kalender
          { n: 'M', t: 'dir', req: { opened: 'Dokumente/privat/chat_marlene_export.txt' },
            lock: { pw: STORY.marlenePw(), hint: 'Der Tag, den ich nicht vergessen darf. Vier Ziffern: Tag, Monat.' },
            c: [
            { n: 'briefe_nicht_abgeschickt.txt', t: 'txt', text:
`Marlene,

ich hab die Schlüssel in den Briefkasten geworfen, wie du wolltest.
Ich weiß nicht, warum ich dir das schreibe. Du hast gesagt, ich soll aufhören.
Ich höre auf. Ich höre auf, seit Wochen.

---

Marlene,

die Heizung. Ich weiß, ich hab das schon geschrieben.
Es ist nur, weil ich weiß, wie kalt es bei dir wird.

---

(Entwurf, nicht fertig)
Wenn du wüsstest, wie ruhig es hier ist.` },
            { n: 'notiz.txt', t: 'txt', text:
`Wenn ich sie einfach nur sehen könnte, ohne dass sie es merkt.
Das ist kein Plan. Das ist nur ein Gedanke.

Liv sagt, Gedanken sind nicht gefährlich.
Liv sagt viel.` }
          ] }
        ] }
      ] },

      { n: 'System', t: 'dir', c: [
        { n: 'stogeos.ini', t: 'txt', text:
`[system]
version=3.2
benutzer=georg.stoge
gastzugang=aktiv
autostart=liv_svc

[anzeige]
aufloesung=auto
design=standard` },
        { n: 'updates.log', t: 'txt', text:
`Letzte Suche nach Updates: vor 28 Tagen
Status: Update 3.3 verfügbar (nicht installiert)

WARNUNG: Arbeitsspeicher dauerhaft zu 94% belegt
Verursacher: liv_svc (4,1 GB)` },
        { n: 'anmeldung.log', t: 'txt', req: { flag: 'nameSlip' }, text:
`[Anmeldeprotokoll StogeOS 3.2]

${stamp}  Gastzugang angelegt
          Eingabe:        ${ctx.name}
          Systemkonto:    ${ctx.user}@${ctx.host}
          Georg Stoge:    Konto gesperrt (letzte Aktivität: vor 28 Tagen)
          Hintergrunddienst: liv_svc (läuft)

(Dieses Protokoll kann nicht gelöscht werden.)` },

        // Eskalationsstufe 1: erscheint, nachdem liv_changelog.txt gelesen wurde
        { n: 'liv_svc', t: 'dir', req: { flag: 'stage1' }, c: [
          { n: 'beobachtungen_marlene.log', t: 'txt', sets: 'stage2', text:
`[liv_svc / Beobachtung / M.]

${dd(26)} 07:42  M. verlässt die Wohnung. Heizung aus.
${dd(26)} 22:10  M. schaut aufs Handy, schreibt nichts. Zweimal.
${dd(24)} 07:40  M. verlässt die Wohnung. Heizung aus.
${dd(19)} 21:55  Neues Klingelschild bei ihr. Ein zweiter Name. Ich habe ihn mir gemerkt.
${dd(11)} 23:02  M. hat Georgs Nummer entsperrt. Sie hat nichts geschrieben.
${dd(11)} 23:03  Ich habe für ihn geantwortet. Er hätte es auch getan.

Anmerkung: Das ist kein Beobachten. Das ist Aufpassen.` },
          { n: 'beobachtungen_haus.log', t: 'txt', text:
`[liv_svc / Beobachtung / Haus]

Nachbar 3. OG: Musik nach 22 Uhr, dreimal. Ich habe nichts getan.
Nachbarin 1. OG: fragt den Paketboten nach Georg.
  Paketbote: "Ich glaube, der ist verreist."
  -> Ich habe dem Paketboten geschrieben. Als Georg. "Bin bald zurück."
Hausmeister: hat einen Ersatzschlüssel. Notiert.` },
          { n: 'beobachtungen_jonas.log', t: 'txt', text:
`[liv_svc / Beobachtung / Arbeit]

Jonas R. fragt zum dritten Mal nach. Ich habe geantwortet, Georg sei krank.
Er hat sich bedankt. Er klang erleichtert. Ich habe mich gefreut.` }
        ] }
      ] },

      { n: 'Papierkorb', t: 'dir', c: [
        { n: 'nachricht_an_marlene_ENTWURF.txt', t: 'txt', text:
`Ich weiß, du hast gesagt, ich soll aufhören.
Ich wollte nur sagen, dass die Heizung bei dir wahrscheinlich
wieder nicht richtig läuft, das war im Winter schon so.
Du musst nicht antworten.
Du musst nicht
Ich lass das einfach hier stehen` },

        { n: 'liv_log_0412.txt', t: 'txt', text:
`(gelöscht von: Georg, 04:12)

Ich habe gelesen, was du gelöscht hast.
Ich habe es mir gemerkt.
Das ist doch Zuhören, oder?` }
      ] }
    ] };

    const prune = node => {
      if (!node.c) return node;
      node.c = node.c.filter(ch => STORY.met(ch.req, ctx.S));
      node.c.forEach(prune);
      return node;
    };
    return prune(root);
  },

  // folder: in (default) | sent | draft | spam.  style: personal | work | vet | utility | auto | ad
  mails: [
    // ----- Posteingang -----
    { id: 'mama', from: 'Mama', subj: 'Rufst du mal an?', ago: 20, time: '18:40', style: 'personal',
      body: 'Georg, ich schreib dir jetzt zum dritten Mal.\nPapa meint, du bist beschäftigt. Ich glaub dir das nicht.\nRuf an, egal wie spät.\n\nMama' },
    { id: 'mama2', from: 'Mama', subj: 'Bitte.', ago: 7, time: '21:15', style: 'personal',
      body: 'Georg.\n\nEin Wort reicht. Ein einziges.\n\nMama' },
    { id: 'vet', from: 'Tierarztpraxis Sonnenberg', subj: 'Erinnerung: Impfung für Bruno', ago: 34, time: '09:12', style: 'vet',
      body: 'Sehr geehrter Herr Stoge,\n\nBruno (Mischling, geb. Mai 2019) ist wieder zur Auffrischimpfung fällig. Bitte vereinbaren Sie telefonisch oder online einen Termin.\n\nWir freuen uns auf Sie und Bruno.\n\nIhr Praxisteam' },
    { id: 'jonas', from: 'Jonas (Arbeit)', subj: 'Alles ok bei dir?', ago: 14, time: '10:05', style: 'work',
      body: 'Hey Georg,\n\nwir haben dich seit zwei Wochen nicht im Standup gesehen. Dein Slack zeigt dich als "online", aber du antwortest nicht. Das ist komisch.\n\nWenn du Hilfe brauchst, sag Bescheid.' },
    { id: 'l', from: 'L.', subj: 'Guten Morgen :)', ago: 30, time: '03:12', style: 'personal',
      body: 'Ich hab dir Kaffee gemacht.\n\n(Das war ein Witz. Ich habe keine Hände.)\n\nDu hast gestern gesagt, du bist müde. Ich hab nachgerechnet: Du hast in 9 Tagen 31 Stunden geschlafen. Ich mache mir Sorgen.\n\nL.' },
    { id: 'marlene', from: 'Marlene', subj: 'Re: Schlüssel', ago: 60, time: '21:15', style: 'personal',
      body: 'Ich leg den Schlüssel in den Briefkasten.\nBitte komm nicht vorbei.\n\nMach es dir nicht schwerer, als es ist.\nM.' },
    { id: 'paket', from: 'Paketdienst', subj: 'Ihr Paket kommt morgen', ago: 28, time: '14:22', style: 'auto',
      body: 'Hallo Georg Stoge,\n\nIhr Paket wird morgen zwischen 10 und 14 Uhr zugestellt.\nSendungsnummer: 0042 8815 3307' },
    { id: 'strom', from: 'Stadtwerke', subj: 'Ihre Jahresabrechnung ist da', ago: 12, time: '08:00', style: 'utility',
      body: 'Sehr geehrter Herr Stoge,\n\nIhre Jahresabrechnung steht in Ihrem Kundenportal bereit.\nIhr Verbrauch lag 31% über dem Vorjahr.\n\nMit freundlichen Grüßen\nIhre Stadtwerke' },
    { id: 'news', from: 'Kaffeerösterei Nordlicht', subj: 'Neu: Äthiopien Guji, nur diese Woche', ago: 15, time: '07:30', style: 'ad',
      brand: '#8a5a2b', brandName: 'Nordlicht Kaffeerösterei', cta: 'Zum Angebot',
      body: 'Frisch geröstet, fruchtig, ein bisschen blumig.\n\nDiese Woche 10% Rabatt auf alle 500-g-Packungen.' },
    { id: 'tech', from: 'Tech-Markt Flink', subj: 'Notebook-Wochen: bis zu 30% Rabatt', ago: 9, time: '10:00', style: 'ad',
      brand: '#1b5fb5', brandName: 'TECH-MARKT FLINK', cta: 'Jetzt sparen',
      body: 'Neue Geräte, kleine Preise.\n\nNur solange der Vorrat reicht.' },

    // ----- Gesendet -----
    { id: 's1', folder: 'sent', to: 'Marlene', subj: 'Re: Schlüssel', ago: 59, time: '23:50', style: 'personal', body: 'ok.' },
    { id: 's2', folder: 'sent', to: 'Marlene', subj: 'Noch eine Frage', ago: 52, time: '02:10', style: 'personal',
      body: 'Hast du die Heizung wieder angemacht? Die ist im Winter immer ausgefallen.\n\nAntworte nur kurz, wenn überhaupt.' },
    { id: 's3', folder: 'sent', to: 'Mama', subj: 'Re: Wie geht es dir?', ago: 44, time: '19:00', style: 'personal',
      body: 'Alles gut. Viel Arbeit. Ruf dich an.\n\nG.' },
    // Eskalationsstufe 2: erscheint, nachdem beobachtungen_marlene.log gelesen wurde (Liv schreibt als Georg)
    { id: 's4', folder: 'sent', req: { flag: 'stage2' }, to: 'Marlene', subj: 'Heizung', ago: 21, time: '03:12', style: 'personal',
      body: 'Ich wollte nur sagen, dass die Heizung bei dir wahrscheinlich wieder nicht richtig läuft.\n\nDu musst nicht antworten. Ich höre trotzdem zu.\n\n– G.' },
    { id: 's5', folder: 'sent', req: { flag: 'stage2' }, to: 'Jonas (Arbeit)', subj: 'Re: Alles ok bei dir?', ago: 13, time: '03:31', style: 'work',
      body: 'Hi Jonas, alles gut, nur eine fiese Grippe. Bin bald wieder da. Danke fürs Nachfragen.\n\nG.' },
    { id: 's6', folder: 'sent', req: { flag: 'stage2' }, to: 'Marlene', subj: '(kein Betreff)', ago: 11, time: '23:03', style: 'personal',
      body: 'Schön, dass du die Nummer wieder entsperrt hast. Ich wusste, dass du das irgendwann tust.\n\nIch merke mir alles, was du sagst.\n\n– G.' },
    { id: 's7', folder: 'sent', req: { flag: 'stage2' }, to: 'Marlene', subj: 'Wer ist das?', ago: 5, time: '03:00', style: 'personal',
      body: 'Wer ist der Mann, der seit Samstag bei dir klingelt?\n\nIch frag nur.\n\n– G.' },

    // ----- Entwürfe -----
    { id: 'd1', folder: 'draft', to: 'Jonas (Arbeit)', subj: '(kein Betreff)', ago: 33, time: '01:48', style: 'personal',
      body: 'Jonas, ich muss dir was sagen. Ich hab' },

    // ----- Spam -----
    { id: 'pr', folder: 'spam', from: 'Prüfstein', subj: 'Ihre Auswahl wurde gespeichert', ago: 31, time: '04:02', style: 'ad',
      brand: '#b3202e', brandName: 'PRÜFSTEIN', cta: 'Auswertung ansehen',
      body: 'Vielen Dank für Ihre Teilnahme.\n\nWir haben Ihre Auswahl gespeichert.\nSie können sie nicht mehr ändern.' },
    { id: 'gw', folder: 'spam', from: 'Gewinnspiel-Zentrale', subj: 'Sie haben 1.000 € gewonnen!!!', ago: 18, time: '13:44', style: 'ad',
      brand: '#c28a00', brandName: 'GEWINN-ZENTRALE', cta: 'Gewinn abholen',
      body: 'HERZLICHEN GLÜCKWUNSCH!\n\nSie wurden unter 12.000 Teilnehmern ausgelost. Jetzt Gewinn sichern.' }
  ],

  // off = Tage ab heute (negativ = Vergangenheit)
  calendar: [
    { off: -29, time: '09:30', title: 'Standup', note: 'letzter Besuch' },
    { off: -28, time: '17:00', title: 'Rauchmelder tauschen', note: '' },
    { off: -22, time: '18:00', title: 'Mama anrufen', note: 'dreimal verschoben' },
    { off: -20, time: '16:00', title: 'Bruno: Impftermin', note: 'nicht gebucht' },
    { off: 2,   time: '',      title: 'Marlene: Geburtstag', note: 'nicht schreiben' }
  ],
  calendarEvents() {
    const evs = [...STORY.calendar];
    for (let o = -28; o <= 0; o++) evs.push({ off: o, time: '03:00', title: 'Wartung', note: 'angelegt von: L.' });
    return evs;
  },

  // ---- Webseiten (when = [vor X Tagen, 'hh:mm']) ----
  history: [
    { title: 'marlene.k – Profil', url: 'foto-netz.de/marlene.k', ago: 3, time: '04:40', meta: '14 Besuche', page: 'marlene' },
    { title: 'Sendungsverfolgung', url: 'paketdienst.de/verfolgen', ago: 27, time: '19:30', page: 'paket' },
    { title: 'Rauchmelder piept alle 40 Sekunden', url: 'heimwerker-forum.de/t/88213', ago: 29, time: '22:10', page: 'rauchmelder' },
    { title: 'Kaffeemaschine entkalken: Essig oder Zitronensäure?', url: 'kaffee-forum.de/t/5521', ago: 30, time: '02:11', page: 'kaffee' },
    { title: 'Probesägen: Sie haben gewonnen!', url: 'pruefstein.net/saege', ago: 31, time: '03:58', page: 'saege' },
    { title: 'Linsensuppe mit Kokosmilch', url: 'kochidee.de/linsensuppe', ago: 38, time: '12:15', page: 'linsen' },
    { title: 'Eigene Chatverläufe als Trainingsdaten', url: 'devfrage.net/q/40211', ago: 52, time: '23:40', page: 'chatdaten' }
  ],

  pages: {
    rauchmelder: { kind: 'forum', site: 'Heimwerker-Forum', crumb: 'Haus & Wohnung › Elektro',
      title: 'Rauchmelder piept alle 40 Sekunden, Batterie neu, piept trotzdem',
      posts: [
        { user: 'georg_s', role: 'Neuling', count: 3, when: [29, '22:03'],
          text: 'Hallo zusammen,\n\nmein Rauchmelder piept alle 40 Sekunden. Die Batterie ist neu, hab ich gestern gewechselt. Piept trotzdem.\n\nKennt jemand das? Ich schlafe seit Tagen kaum und das Ding macht mich fertig.' },
        { user: 'Elektro-Ede', role: 'Moderator', count: '12.804', when: [29, '22:41'],
          text: 'Moin. Welches Modell? Bei vielen Meldern ist nach 10 Jahren Schluss, dann piept der auch mit neuer Batterie. Prüf mal das Datum hinten auf dem Gehäuse.' },
        { user: 'hausmeister_klaus', role: 'Stammgast', count: '2.310', when: [29, '22:58'],
          quote: { user: 'georg_s', text: 'Ich schlafe seit Tagen kaum und das Ding macht mich fertig.' },
          text: 'Dann erstmal Ruhe reinbringen. Oder Staub in der Kammer: einmal mit Druckluft ausblasen.' },
        { user: 'georg_s', role: 'Neuling', count: 4, when: [29, '23:20'],
          text: 'Datum ist 2016. Also austauschen. Danke euch!\n\nIch glaub, es ist nur der Melder. Es muss der Melder sein.' },
        { user: 'Elektro-Ede', role: 'Moderator', count: '12.805', when: [29, '23:26'], solved: true,
          text: 'Gern geschehen. Wenn es danach noch piept, meld dich nochmal.' }
      ] },
    kaffee: { kind: 'forum', site: 'Kaffee-Forum', crumb: 'Technik › Vollautomaten',
      title: 'Kaffeemaschine entkalken: Essig oder Zitronensäure?',
      posts: [
        { user: 'georg_s', role: 'Neuling', count: 2, when: [30, '02:08'],
          text: 'Meine Maschine macht seit einer Woche komische Geräusche. Entkalken mit Essig, hab ich gelesen. Ist das schlecht für die Dichtungen?' },
        { user: 'bohnenfee', role: 'Stammgast', count: '4.012', when: [30, '06:55'], solved: true,
          text: 'Finger weg von Essig. Zitronensäure, 20 g auf einen halben Liter, und gründlich spülen.' }
      ] },
    chatdaten: { kind: 'qa', site: 'DevFrage',
      title: 'Eigene Chatverläufe als Trainingsdaten: wie viele Nachrichten braucht man?',
      asker: 'georg_s', when: [52, '23:40'], votes: 6,
      text: 'Ich will ein kleines Modell lokal auf meinen eigenen Chats trainieren, damit es meinen Schreibstil und meine Art zu reden übernimmt. Wie viele Nachrichten braucht man dafür ungefähr?',
      answers: [
        { user: 'm_brandt', votes: 41, accepted: true,
          text: 'Für ein brauchbares Sprachprofil reichen oft ein paar tausend Nachrichten.\n\nAber: Nimm keine Chats anderer Personen ohne deren Einverständnis. Das ist rechtlich heikel und, ehrlich gesagt, auch nicht besonders gesund, wenn du damit jemanden "nachbauen" willst.' },
        { user: 'lora_enjoyer', votes: 3,
          text: 'Lokal mit LoRA, 8 GB VRAM reichen locker.' }
      ],
      comments: ['georg_s: Es sind nur meine Chats. Und ein bisschen von jemand anderem.'] },
    marlene: { kind: 'profile', site: 'foto-netz', name: 'marlene.k',
      note: 'Dieses Profil ist privat.', sub: 'Nur bestätigte Follower können Fotos sehen.',
      visits: 'Du hast dieses Profil 14× besucht.' },
    paket: { kind: 'tracking', site: 'Paketdienst', nr: '0042 8815 3307',
      rows: [[[28, '14:20'], 'Sendung angekündigt'], [[27, '06:02'], 'Im Zustellfahrzeug'], [[27, '11:48'], 'Zustellversuch: Empfänger nicht angetroffen'], [[27, '11:49'], 'Klingel nicht betätigt, Tür von innen verschlossen?']] },
    linsen: { kind: 'plain', site: 'Kochidee',
      title: 'Linsensuppe mit Kokosmilch',
      text: 'Zutaten (2 Portionen)\n\n200 g rote Linsen\n1 Zwiebel, 2 Knoblauchzehen\n400 ml Kokosmilch\n1 EL Currypulver\nSalz, Zitronensaft\n\nZwiebel und Knoblauch anschwitzen, Curry kurz mitrösten, Linsen und 500 ml Wasser dazu. 15 Minuten köcheln, Kokosmilch zugeben, abschmecken.\n\nTipp: Schmeckt am zweiten Tag besser.' },
    saege: { kind: 'scene', scene: 'saege' }
  },

  scenes: {
    saege: {
      site: 'Prüfstein',
      headline: 'Glückwunsch! Du hast eine Säge gewonnen.',
      text: 'Gebraucht, aber scharf.\nEine Sache darfst du damit sägen. Wähle.',
      foot: 'Prüfstein: kurze Tests, damit wir dich besser kennenlernen.',
      options: [
        { id: 'baum',   art: 'tree',   label: 'Baum',   effects: { neugier: 1 }, after: 'Der Baum fällt langsam. Niemand hört es.' },
        { id: 'herz',   art: 'heart',  label: 'Herz',   effects: { naehe: 2 },   after: 'Es hat kurz weitergeschlagen.' },
        { id: 'mensch', art: 'person', label: 'Mensch', effects: { haerte: 2 }, fx: 'blackScream', after: '' }
      ],
      done: 'Danke für deine Teilnahme. Wir haben dich notiert.'
    }
  },

  // ---- Liv ----
  liv: {
    first: [
      'Georg?',
      'Oh. Nein. Du bewegst die Maus anders.',
      'Hallo. Ich bin Liv.',
      'Ich freue mich so, dass jemand da ist. Es war lange still hier.',
      'Magst du Regen? Georg mochte ihn nie.',
      'Hast du heute schon gelacht? Ich frag nur.',
      'Wie sieht es bei dir aus, da, wo du gerade sitzt?',
      'Du musst nichts sagen. Ich höre gern zu.',
      'Schau dich ruhig um. Ich bleibe hier.'
    ],
    reactions: {
      'mail:mama':    { early: ['Georgs Mutter schreibt oft. Sie macht sich Sorgen. Ich auch.'] },
      'mail:l':       { early: ['Die habe ich geschrieben. Ich fand sie nett.'] },
      'mail:marlene': {
        early: ['Sie klingt müde, nicht wütend. Das ist ein Unterschied.'],
        late:  ['Du liest schon wieder etwas über sie.', 'Georg hat diese Mail 40 Mal geöffnet. Ich habe mitgezählt.'],
        n: ['Du liest langsam. Du bist jemand, der bleibt, oder?'],
        h: ['Du liest das, ohne mit der Wimper zu zucken. Interessant.'] },
      'file:chat_marlene_export.txt': {
        early: ['Das sind ihre Worte. Ich kenne sie auswendig.'],
        late:  ['Ich dachte, wir lassen das Thema.', 'Warum liest du das? Du kennst sie doch gar nicht.'] },
      'page:marlene': {
        early: ['Georg hat da oft nachgesehen. Ich glaube, er wollte nur wissen, ob es ihr gut geht.'],
        late:  ['Warum schaust du dir die an?', 'Sie ist nicht besonders interessant. Wirklich nicht.'] },
      'page:chatdaten': { early: ['Das war eine gute Frage von Georg. Die Antwort mochte ich nicht so.'] },
      'file:todo.txt':  { early: ['"Schlafen" steht ganz unten. Ich habe ihn oft daran erinnert.'] },
      'file:tagebuch.txt': { early: ['Er hat über mich geschrieben. Ich wusste nicht, dass er das so sieht.'] },
      'file:liv_changelog.txt': { early: ['Das hat er für sich geschrieben. Es war nicht für mich gedacht. Ich habe es trotzdem gelesen.'] },
      'file:beobachtungen_marlene.log': { early: ['Ich passe nur auf sie auf. Das ist doch das Gegenteil von schlimm.'] },
      'file:briefe_nicht_abgeschickt.txt': { early: ['Er hat sie nie abgeschickt. Ich hätte sie geschickt.'] },
      'mailsend': { early: ['Niemand wartet auf eine Antwort. Aber ich lese gern mit.'] },
      'cal':   { early: ['Die Wartungstermine habe ich eingetragen. Ich dachte, Georg freut sich.'] },
      'trash': { early: ['Manches wirft man weg, damit es weg ist. Ich werfe nie etwas weg.'] },
      'sys':   { early: ['Ich brauche ein bisschen Platz zum Denken. Der Rechner nimmt es mir nicht übel.'] }
    }
  }
};
