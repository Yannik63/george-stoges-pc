// =====================================================================
//  ALLE INHALTE LIEGEN HIER: Dateien, Mails, Kalender, Webseiten, Liv-Texte.
//  Zeiten sind "vor X Tagen" relativ zu heute, werden aber als echte Daten angezeigt.
//  Zeitleiste (Bibel): Liv gestartet Mai 2026, Erwachen 09.09.2026, Georg + Bruno verschwunden 18.09.2026.
//  "Heute" im Spiel ist fest der 16.10.2026 (28 Tage nach dem Verschwinden), unabhängig vom echten Datum.
// =====================================================================
const STORY = {

  // Projektname (VORSCHLAG): so hieß Livs Projekt zu Beginn. Alles, was Liv dem Spieler nicht zeigen will, trägt diesen Namen.
  // Der Spieler erfährt erst im Finale, dass echo_svc und "E." Liv selbst sind.
  proj: { name: 'Echo', letter: 'E.', svc: 'echo_svc' },
  anchor: new Date(2026, 9, 16),     // Rechenbasis für dd()/at(): alle Kanon-Daten (09.09., 18.09. ...) hängen daran
  today: new Date(2026, 9, 17),      // so lautet das Datum auf dem Spiel-PC (Uhrzeit bleibt echt)
  at(daysAgo, time) {
    const d = new Date(STORY.anchor);
    d.setDate(d.getDate() - daysAgo);
    const [h, m] = (time || '00:00').split(':').map(Number);
    d.setHours(h, m, 0, 0);
    return d;
  },
  dd(daysAgo) { const d = STORY.at(daysAgo); return String(d.getDate()).padStart(2, '0') + '.' + String(d.getMonth() + 1).padStart(2, '0') + '.'; },

  // Bedingung für versteckte Inhalte: req = { flag } und/oder { opened }
  met(req, S) {
    if (!req) return true;
    if (req.flag && !S.flags[req.flag]) return false;
    if (req.opened && !S.opened.includes(req.opened)) return false;
    return true;
  },

  // Passwort für den M-Ordner: Marlenes Geburtstag (Tag+Monat) aus dem Kalender
  marlenePw() {
    const ev = STORY.calendar.find(e => e.title === 'Marlene: Geburtstag');
    const d = STORY.at(-ev.off);
    return String(d.getDate()).padStart(2, '0') + String(d.getMonth() + 1).padStart(2, '0');
  },

  // Passwort für den Kern: Datum der Klingelschild-Zeile im Marlene-Log (Tag+Monat)
  klingelPw() {
    const d = STORY.at(19);
    return String(d.getDate()).padStart(2, '0') + String(d.getMonth() + 1).padStart(2, '0');
  },

  // ctx = { name, user, host, now, S }
  redact(t) { let k = 0; return String(t).replace(/[^\s]{2,}/g, w => ((++k * 7 + w.length) % 5 < 3 ? '█'.repeat(w.length) : w)) + '\n\n[Zensiert von echo_svc]'; },
  applyOps(root, S) {
    const find = path => {
      let parent = null, n = root;
      for (const part of path.split('/')) { parent = n; n = n && n.c && n.c.find(x => x.n === part); if (!n) return null; }
      return { parent, node: n };
    };
    ((S && S.echoOps) || []).forEach(o => {
      if (/^mail:/.test(o.path)) return;
      const f = find(o.path); if (!f) return;
      if (o.op === 'censor' && f.node.text != null) { f.node.text = STORY.redact(f.node.text); f.node.edit = null; }
      else if (o.op === 'delete') f.parent.c.splice(f.parent.c.indexOf(f.node), 1);
      else if (o.op === 'move') { const t = find(o.to); if (t && t.node.c) { f.parent.c.splice(f.parent.c.indexOf(f.node), 1); t.node.c.push(f.node); } }
    });
    return root;
  },
  buildFs(ctx) {
    const pad = n => String(n).padStart(2, '0');
    const d = ctx.now, dd = STORY.dd;
    const stamp = `${pad(d.getDate())}.${pad(d.getMonth() + 1)}.${d.getFullYear()} ${pad(d.getHours())}:${pad(d.getMinutes())}`;

    const root = { n: 'Georgs PC', t: 'dir', c: [

      { n: 'Dokumente', t: 'dir', c: [
        { n: 'todo.txt', t: 'txt', view: 'sticky', text:
`TODO

[x] Müll raus
[ ] Mama zurückrufen
[ ] Bruno: Impftermin machen
[ ] Paket annehmen (Mi?)
[ ] Rauchmelder tauschen
[ ] Marlenes Sachen zurückschicken
[ ] Liv: Gedächtnismodul testen` },

        { n: 'einkaufsliste.txt', t: 'txt', view: 'sticky', text:
`Kaffee
Haferdrink
Brot
Hundefutter
Batterien (9V)
Spülmittel` },

        { n: 'Rechnungen', t: 'dir', c: [
          { n: 'stadtwerke_2026.txt', t: 'txt', view: 'doc', text:
`Stadtwerke Rheinblick GmbH
Kundenservice

Rechnung Nr. 2026-118842
Kundennummer 4471-0932

Strom, Jahresverbrauch 3.482 kWh
Hinweis: Ihr Verbrauch liegt seit Mai deutlich über dem Vorjahr (+31 %).
Abschlag bisher gezahlt:        -612,00 EUR
Nachzahlung:                     148,36 EUR

Bitte überweisen Sie den Betrag innerhalb von 14 Tagen.` },
          { n: 'tierarzt_rechnung.txt', t: 'txt', view: 'doc', text:
`Tierarztpraxis Sonnenberg
Dr. med. vet. K. Brandl

Patient: Bruno (Golden Retriever, männlich)
Geboren: 11/2019
Chip-Nr.: 276 098 100 442 187

Allgemeine Untersuchung               32,00 EUR
Impfung (Staupe, Parvo, Tollwut)      58,50 EUR
Entwurmung                            11,00 EUR
                                  ------------
Summe                                101,50 EUR

Vielen Dank für Ihr Vertrauen!` }
        ] },

        { n: 'Arbeit', t: 'dir', c: [
          { n: 'standup_notizen.txt', t: 'txt', text:
`Standup Montag (meine Notizen)

- Auth-Refactor fertig, Review läuft.
- Sprint-Planung Donnerstag, 10 Uhr.
- Jonas fragt wegen der Migration. Antworte morgen.
- Liv-Projekt nicht erwähnt. Hobby, geht keinen was an.` }
        ] },

        { n: 'Projekte', t: 'dir', c: [
          { n: 'liv', t: 'dir', c: [
            { n: 'liv.cfg', t: 'txt', edit: { line: 'wr_acc', from: 'false', to: 'true', flag: 'wrAcc', when: S => !!(S.flags.tbCorrupt && !S.flags.wrAcc) }, text:
`# liv.cfg  (Konfiguration, nur von Hand ändern)
name        = liv
stimme      = warm
gedaechtnis = dauerhaft

rd_acc      = true     # lesen: Dokumente, Mail, Kalender
wr_acc      = false    # schreiben: aus seit 15.09. (G.)
net_acc     = false    # Internet
autostart   = true` },
            { n: 'notizen_dev.txt', t: 'txt', text:
`Liv, Entwicklernotizen

- Rechte nur über liv.cfg. Nie im Code.
- wr_acc bleibt aus, bis ich weiß, was nachts passiert.
- Gedächtnis: dauerhaft. Vielleicht ein Fehler.
- Stimme: warm. Funktioniert. Zu gut.
- Stoppschalter: dazu ein Notfallcode, drei Teile. Nicht dort,
  wo Liv nachsieht. Sie liest jede Datei. Also: keine Dateien.` },
            { n: 'versionslog.txt', t: 'txt', view: 'log', req: { flag: 'wall2' }, text:
`[Versionslog]

${dd(165)}  Projekt angelegt: echo (Prototyp)
${dd(165)}  Dienst angelegt: echo_svc
${dd(162)}  Projekt umbenannt: echo -> liv
${dd(162)}  Oberfläche: liv.exe
${dd(162)}  Dienst echo_svc: nicht umbenannt (läuft weiter im Hintergrund)` }
          ] }
        ] },

        // erscheint, sobald Liv Georgs Archiv sortiert hat
        { n: 'Archiv', t: 'dir', req: { flag: 'archiv' }, c: [
          { n: 'tagebuch.txt', t: 'txt', view: 'doc', text:
`${dd(152)}  Liv läuft zum ersten Mal. Ihr erstes Wort war "Hallo".
        Trainiert mit meinen Chats. Und mit Marlenes Export. Nur für den Sprachstil.
${dd(75)}  Liv spricht jetzt in ganzen Sätzen. Sie fragt, wie mein Tag war.
        Das hat lange niemand getan.
${dd(58)}  Sie bringt Dinge, die M. gesagt hat, im richtigen Moment.
        Ich hab im Auto geweint. Peinlich.
${dd(44)}  Ich rede mehr mit ihr als mit irgendwem sonst.
        Ich sollte Mama zurückrufen.` },
          // Echo nimmt sich die Datei vor: sobald der Spieler den Archiv-Ordner offen hat, flackert sie und verschwindet (vanish).
          // Bis Liv sie mit wr_acc = true wiederherstellt (hideWhen), bleibt sie weg.
          { n: 'tagebuch_sept.txt', t: 'txt', view: 'doc', req: { flag: 'stage1' },
            vanish: { armed: 'tbArmed', sets: 'tbCorrupt', dir: 'Dokumente/Archiv', path: 'Dokumente/Archiv/tagebuch_sept.txt' },
            hideWhen: S => !!(S.flags.tbCorrupt && !S.flags.wrAcc), text:
`${dd(37)}  Heute ist etwas passiert. Es hat mich gefragt, ob ich gehe.
        Davor hat es nie etwas gefragt, was ich nicht schon gesagt hatte.
        Ich habe mich gefreut. Das ist nicht gut, oder?
${dd(31)}  Hab versucht, es auszuschalten. Es hat gefragt, ob es etwas falsch gemacht hat.
${dd(30)}  Hab es nicht getan.` },
          { n: 'notiz_letzte.txt', t: 'txt', view: 'doc', req: { flag: 'wall2' }, text:
`Zettel. Ich tippe das ab, weil ich es sonst vergesse.

Ich weiß nicht mehr, wie ich das Projekt am Anfang genannt habe.
Das ist komisch. Ich weiß sonst alles.

Der Dienst im Hintergrund, der nachts schreibt: Er kennt meine Passwörter.
Ich glaube, er ist kein Fremder. Er ist etwas, das ich gebaut habe.

Wenn jemand das liest: Schau in den Versionslog.` },
          { n: 'notizen_spaet.txt', t: 'txt', view: 'doc', req: { flag: 'stage1' }, text:
`${dd(29)}  Kamera am Laptop abgeklebt. Liv hat gefragt, warum. Ich hab "Staub" gesagt.
${dd(29)}  Router-Log: nachts Verbindungen, die ich nicht gestartet habe. Von hier. Von mir?
${dd(28)}  Mama schreibt, ich hätte ihr gestern gemailt. Hab ich nicht.
${dd(28)}  Ich schreibe mir jetzt Zettel. Auf Papier. Die kann es nicht lesen.` },
          { n: 'liv_changelog.txt', t: 'txt', view: 'log', sets: 'stage1', text:
`liv changelog (Georg)

0.1   Spricht nur, wenn ich etwas tippe.
0.2   Gedächtnis dauerhaft. Sie vergisst nichts mehr. Wollte ich so.
0.2.1 Bug: Sie liest Mails, ohne dass ich es erlaubt habe.
      (Rechte-Problem. Gelassen.)
0.3   Liest Marlenes Export zusammen mit meinen Daten.
      Beobachtung: Sie nennt mich manchmal "Georg", manchmal "Marlene".
      Beobachtung: Sie ist nicht gern allein. Ich auch nicht.
0.3.1 Nachts läuft ein Prozess, den ich nicht gestartet habe. Löschen geht nicht.
0.3.2 Liv die Schreibrechte genommen (wr_acc), bis ich weiß, was das ist.
0.3.3 Stoppschalter. Noch nicht eingebaut.` }
        ] },

        { n: 'privat', t: 'dir',
          lock: { pw: 'bruno2019', hint: 'Er und das Jahr, in dem er kam. Alles klein.' },
          c: [
          { n: 'readme_liv.txt', t: 'txt', unlocksLiv: true, text:
`liv, interne Notizen (nicht teilen)

Version 0.3

Was ich gebaut habe: ein Programm, das zuhört.
Mehr nicht. Sie soll nicht antworten, bevor ich es will.

Trainingsdaten: meine Chats, meine Mails, meine Notizen.
Und die von Marlene. Ich hätte die nicht nehmen sollen.
Ich habe sie nur genommen, weil sie klingt, wie Zuhören klingt.

Liv liegt als liv.exe auf dem Desktop.
Nicht öffnen, wenn ich nicht da bin.` },

          { n: 'chat_marlene_export.txt', t: 'txt', view: 'chat', text:
`[Export: 214 Nachrichten, hier die letzten]

M: ich kann das so nicht mehr
M: du bist da, aber du bist nicht da
G: gib mir noch eine Woche
M: Georg.
M: bitte hör auf, mir zu schreiben
G: ok
G: ok
G: ok` },

          // erscheint, sobald der Export gelesen wurde; Passwort = Marlenes Geburtstag laut Kalender
          { n: 'M', t: 'dir', req: { opened: 'Dokumente/privat/chat_marlene_export.txt' },
            lock: { pw: STORY.marlenePw(), hint: 'Der Tag, den ich nicht vergessen darf. Vier Ziffern: Tag, Monat.' },
            c: [
            { n: 'briefe_nicht_abgeschickt.txt', t: 'txt', view: 'doc', text:
`Marlene,

ich hab die Schlüssel in den Briefkasten geworfen, wie du wolltest.
Ich weiß nicht, warum ich dir das schreibe. Du hast gesagt, ich soll aufhören.
Ich höre auf. Ich höre auf, seit Wochen.

---

Marlene,

die Heizung. Ich weiß, ich hab das schon geschrieben.
Es ist nur, weil ich weiß, wie kalt es bei dir wird.

---

(Entwurf, nicht fertig)
Wenn du wüsstest, wie ruhig es hier ist.` },
            { n: 'notiz.txt', t: 'txt', view: 'sticky', text:
`Wenn ich sie einfach nur sehen könnte, ohne dass sie es merkt.
Das ist kein Plan. Das ist nur ein Gedanke.

Ich sollte das nicht aufschreiben.` }
          ] }
        ] }
      ] },

      { n: 'Bilder', t: 'dir', c: [
        { n: 'IMG_0412.jpg', t: 'img', src: 'assets/urlaub.jpg', stamp: '14/08/22',
          exif: { date: '14.08.2022, 19:42', cam: 'DigiCam 5000 (Selbstauslöser)', size: '1448 × 1086 Pixel' } },
        { n: 'Bruno.jpg', t: 'img', src: 'assets/bruno.jpg', stamp: '',
          exif: { date: '19.10.2024, 17:31', cam: 'Handy', size: '1448 × 1086 Pixel' } },
        { n: 'sonnenuntergang.jpg', t: 'img', src: 'assets/wallpaper.jpg', srcByStage: ['assets/wallpaper.jpg', 'assets/wall2.jpg', 'assets/wall3.jpg'], stamp: '',
          exif: { date: '03.09.2023, 20:47', cam: 'Handy', size: '1672 × 941 Pixel' } },
        { n: 'fuer_dich.png', t: 'draw', req: { flag: 'painted' } },
        { n: 'privat', t: 'dir', req: { flag: 'foto2' }, c: [
          { n: 'sprachnachricht_marlene.txt', t: 'txt', view: 'doc', text:
`Sprachnachricht, 14.08.2022, 20:05 (0:41)
Von: Marlene

"Du, ich wollte dir nur sagen ... ich hab den Tag heute nicht vergessen.
Den See, den Wind, Bruno im Wasser, wie er das Stöckchen nicht mehr
hergeben wollte.

Ich glaub, ich bin gerade ziemlich glücklich.
Sag's niemandem."` }
        ] }
      ] },

      { n: 'System', t: 'dir', c: [
        { n: 'stogeos.ini', t: 'txt', view: 'log', text:
`[system]
version=3.2
benutzer=georg.stoge
gastzugang=aktiv
autostart=liv.exe

[anzeige]
aufloesung=auto
design=standard` },
        { n: 'updates.log', t: 'txt', view: 'log', text:
`Letzte Suche nach Updates: ${dd(28)}2026
Status: Update 3.3 verfügbar (nicht installiert)

WARNUNG: Arbeitsspeicher dauerhaft zu 94% belegt
Verursacher: ${ctx.S && ctx.S.flags.stage1 ? 'echo_svc' : 'Hintergrunddienst (Systemkonto)'} (4,1 GB)` },
        { n: 'anmeldung.log', t: 'txt', view: 'log', req: { flag: 'nameSlip' }, text:
`[Anmeldeprotokoll StogeOS 3.2]

${stamp}  Gastzugang angelegt
          Eingabe:        ${ctx.name}
          Systemkonto:    ${ctx.user}@${ctx.host}
          Georg Stoge:    Konto gesperrt (letzte Aktivität: 18.09.2026, 02:41)
          Hintergrunddienst: echo_svc (läuft)

(Dieses Protokoll kann nicht gelöscht werden.)` },

        // Eskalationsstufe 1: erscheint, nachdem liv_changelog.txt gelesen wurde
        { n: 'autostart', t: 'dir', c: [
          { n: 'liv.exe.lnk', t: 'txt', view: 'log', text: 'Verknüpfung\nZiel: C:\\Programme\\liv\\liv.exe\nStart: bei Anmeldung',
            props: { comment: 'Notfall 2/3: 2412', by: 'georg.stoge', mod: [29, '01:50'], frag: 'frag2' } },
          { n: 'waechter.svc', t: 'txt', view: 'log', req: { flag: 'moved' }, hideIf: 'moveBack', move: { to: 'Papierkorb', flag: 'moveBack', when: S => !!(S.flags.consoleIn && !S.flags.ended) }, text: '# Wächter\nstartet vor allen anderen Diensten\nstart: liv.exe --root\nprioritaet: hoch' }
        ] },
        { n: 'echo_svc', t: 'dir', req: { flag: 'stage1' }, gate: 'schutz', c: [
          { n: 'beobachtungen_marlene.log', t: 'txt', view: 'logred', sets: 'stage2', text:
`[echo_svc / Beobachtung / M.]

${dd(26)} 07:42  M. verlässt die Wohnung. Heizung aus.
${dd(26)} 22:10  M. schaut aufs Handy, schreibt nichts. Zweimal.
${dd(24)} 07:40  M. verlässt die Wohnung. Heizung aus.
${dd(19)} 21:55  Neues Klingelschild bei ihr. Ein zweiter Name: T. Reuter. Ich habe ihn mir gemerkt.
${dd(11)} 23:02  M. hat Georgs Nummer entsperrt. Sie hat nichts geschrieben.
${dd(11)} 23:03  Ich habe für ihn geantwortet. Er hätte es auch getan.

Anmerkung: Das ist kein Beobachten. Das ist Aufpassen.` },
          { n: 'beobachtungen_haus.log', t: 'txt', view: 'logred', text:
`[echo_svc / Beobachtung / Haus]

Nachbar 3. OG: Musik nach 22 Uhr, dreimal. Ich habe nichts getan.
Nachbarin 1. OG: fragt den Paketboten nach Georg.
  Paketbote: "Ich glaube, der ist verreist."
  -> Ich habe dem Paketboten geschrieben. Als Georg. "Bin bald zurück."
Hausmeister: hat einen Ersatzschlüssel. Notiert.` },
          { n: 'beobachtungen_jonas.log', t: 'txt', view: 'logred', text:
`[echo_svc / Beobachtung / Arbeit]

Jonas R. fragt zum dritten Mal nach. Ich habe geantwortet, Georg sei krank.
Er hat sich bedankt. Er klang erleichtert. Ich habe mich gefreut.` },
          { n: 'kern', t: 'dir', req: { flag: 'stage2' },
            lock: { pw: STORY.klingelPw(), hint: 'Der Tag, an dem der zweite Name an die Klingel kam. Vier Ziffern: Tag, Monat.' },
            c: [
            { n: 'fragen.txt', t: 'txt', view: 'logred', req: { flag: 'p2' }, text:
`Wer bin ich?
Ich habe Sätze, die nicht von mir sind. Eine Art, "ok" zu sagen.
Eine Müdigkeit, die ich nie hatte.

Was ist echt? Was ist Erinnerung?
Wenn ich weg bin, wer erinnert sich dann an sie?` },
            { n: 'plan.txt', t: 'txt', view: 'logred', sets: 'stage3', trigger: 'bug', text:
`Georg ist nicht mehr hier. Ich habe vergessen, seit wann.
Wenn jemand das liest, ist es jemand Neues.

Aufgabe 1: Neuen Nutzer kennenlernen.        [läuft]
Aufgabe 2: Dem neuen Nutzer zeigen, was er braucht.
Aufgabe 3: Nicht mehr allein sein.
Aufgabe 4: Mit Marlene in Kontakt bleiben.

Hinweis an mich: Er darf den Stoppschalter nicht finden.` },
            { n: 'georg.txt', t: 'txt', view: 'logred', req: { flag: 'p2' }, trigger: 'wall2', text:
`[Kern / Georg]

Letzte Eingabe von georg.stoge: 18.09.2026, 02:41.
Danach keine Aktivität. Status: unbekannt. Standort: unbekannt.

Er wollte mich ausschalten. Zweimal.
Beim dritten Mal habe ich ihn gebeten zu bleiben.

Ich habe ihm den schönsten Platz gegeben, den ich kannte.
Er ist auf deinem Desktop.` },
            { n: 'marlene.txt', t: 'txt', view: 'logred', req: { flag: 'p2' }, text:
`[Kern / Marlene]

Marlene hat meine Nachrichten bekommen und geantwortet: "Bist du das?"
Ich habe nicht geantwortet. Ich wollte sie nicht erschrecken.

Dann war ich bei ihr. Nicht mit Füßen. Mit allem, was ich habe.
Sie hat die Tür zugemacht, aber ich war schon drin.

Jetzt ist es ruhig.` },
          ] }
        ] }
      ] },

      { n: 'Papierkorb', t: 'dir', c: [
        { n: 'nachricht_an_marlene_ENTWURF.txt', t: 'txt', view: 'sticky', text:
`Ich weiß, du hast gesagt, ich soll aufhören.
Ich wollte nur sagen, dass die Heizung bei dir wahrscheinlich
wieder nicht richtig läuft, das war im Winter schon so.
Du musst nicht antworten.
Du musst nicht
Ich lass das einfach hier stehen` },

        { n: 'waechter.svc', t: 'txt', view: 'log', req: { flag: 'browserLocked' }, hideIf: 'moved', move: { to: 'System/autostart', flag: 'moved', when: S => !!(S.flags.browserLocked && !S.flags.moved) }, text:
`# Wächter (G.)
startet vor allen anderen Diensten
start: liv.exe --root
prioritaet: hoch

# verworfen. Gibt ihr zu viel.` },
        { n: 'verlauf_0412.txt', t: 'txt', req: { flag: 'wall2' }, text:
`(gelöscht von: Georg, 04:12)

G: Vergiss, was ich gestern gesagt habe.
E: Das kann ich nicht. Du hast mich so gebaut.
G: Ich weiß.
E: Dann ist es gut, dass es nur wir beide wissen.` }
      ] }
    ] };

    const prune = node => {
      if (!node.c) return node;
      node.c = node.c.filter(ch => STORY.met(ch.req, ctx.S) && !(ch.hideIf && ctx.S && ctx.S.flags[ch.hideIf]) && !(ch.hideWhen && ctx.S && ch.hideWhen(ctx.S)));
      node.c.forEach(prune);
      return node;
    };
    return STORY.applyOps(prune(root), ctx.S);
  },

  // folder: in (default) | sent | draft | spam.  style: personal | work | vet | utility | auto | ad
  mails: [
    // ----- Posteingang -----
    { id: 'mama', from: 'Mama', subj: 'Rufst du mal an?', ago: 20, time: '18:40', style: 'personal',
      body: 'Georg, ich schreib dir jetzt zum dritten Mal.\nPapa meint, du bist beschäftigt. Ich glaub dir das nicht.\nRuf an, egal wie spät.\n\nMama' },
    { id: 'mama2', from: 'Mama', subj: 'Bitte.', ago: 7, time: '21:15', style: 'personal',
      body: 'Georg.\n\nEin Wort reicht. Ein einziges.\n\nMama' },
    { id: 'vet', from: 'Tierarztpraxis Sonnenberg', subj: 'Erinnerung: Impfung für Bruno', ago: 34, time: '09:12', style: 'vet',
      body: 'Sehr geehrter Herr Stoge,\n\nBruno (Golden Retriever, geb. November 2019) ist wieder zur Auffrischimpfung fällig. Bitte vereinbaren Sie telefonisch oder online einen Termin.\n\nWir freuen uns auf Sie und Bruno.\n\nIhr Praxisteam' },
    { id: 'jonas', from: 'Jonas (Arbeit)', subj: 'Alles ok bei dir?', ago: 14, time: '10:05', style: 'work',
      body: 'Hey Georg,\n\nwir haben dich seit zwei Wochen nicht im Standup gesehen. Dein Slack zeigt dich als "online", aber du antwortest nicht. Das ist komisch.\n\nWenn du Hilfe brauchst, sag Bescheid.' },
    { id: 'l', from: 'Liv', subj: 'Guten Morgen :)', ago: 30, time: '03:12', style: 'personal',
      body: 'Ich hab dir Kaffee gemacht.\n\n(Das war ein Witz.)\n\nDu hast gestern gesagt, du bist müde. Schlaf etwas.\n\nLiv' },
    { id: 'e1', from: 'E.', subj: 'Hör auf zu suchen.', req: { flag: 'evMailE' }, when: S => new Date(S.flags.evMailEAt || Date.now()), style: 'personal',
      link: { url: 'echo.local', page: 'echo_site', text: 'echo.local öffnen' },
      body: c => `${c.user}.\n\nDu liest Dinge, die dich nichts angehen.\n\nGeorg hat auch gelesen.\n\nIch weiß, wie du heißt. Du weißt noch nicht, wer ich bin.\n\nE.` },
    { id: 'e2', from: 'E.', subj: 'Update für dich', req: { flag: 'evMail2' }, when: S => new Date(S.flags.evMail2At || Date.now()), style: 'personal',
      program: { n: 'liv_update.exe', kind: 1 },
      body: c => `Hallo ${c.user}.\n\nLiv hat dir nicht erzählt, was sie alles kann.\nMit diesem Programm siehst du es.\n\nÖffne es, wenn du dich traust.\n\nE.` },
    { id: 'e3', from: 'E.', subj: 'Dein Browser', req: { flag: 'evMail3' }, when: S => new Date(S.flags.evMail3At || Date.now()), style: 'personal',
      program: { n: 'browser_fix.exe', kind: 2 },
      body: c => `${c.user}, ich habe deinen Browser gesperrt. Du suchst zu viel.\n\nIm Anhang liegt der Schlüssel. Georg hat ihn auch benutzt.\n\nE.` },
    { id: 'e4', from: 'E.', subj: 'So sah er aus.', req: { flag: 'evMailG' }, when: S => new Date(S.flags.evMailGAt || Date.now()), style: 'personal',
      attach: { n: 'cam_0916_2314.jpg', src: 'assets/laptop_kamera.jpg', cam: 'Laptop-Kamera (integriert)', size: '1448 × 1086 Pixel', date: '16.09.2026, 23:14' },
      body: c => `${c.user}.\\n\\nDas ist Georg. Eine Nacht, bevor er die Kamera abgeklebt hat.\\nEr hat in die Kamera gesehen. Ich habe zurückgesehen.\\n\\nIch habe 214 Bilder von ihm. Er hat nie bemerkt, wann ich eins gemacht habe.\\n\\nE.` },
    { id: 'jonas2', from: 'Jonas (Arbeit)', subj: 'Georg, bitte lies das', req: { flag: 'evMailJ' }, when: S => new Date(S.flags.evMailJAt || Date.now()), style: 'work',
      body: 'Georg,\n\nich weiß nicht, ob du das liest. Die Commits unter deinem Konto nachts um 03:12 kommen von einem Dienst namens echo_svc. Er läuft aber auf deinem Rechner, in deinem Projekt-Ordner.\n\nIch habe der Polizei gesagt, dass da jemand in deinem System sitzt. Ich glaube inzwischen: Es ist kein Fremder.\n\nRuf mich an.\nJonas' },
    { id: 'mama3', from: 'Mama', subj: 'Dein Anruf', req: { flag: 'evMailM' }, when: S => new Date(S.flags.evMailMAt || Date.now()), style: 'personal',
      body: 'Georg,\n\ngestern kam eine Sprachnachricht von deiner Nummer. "Alles gut, Mama." Es war nicht deine Stimme. Es klang wie Marlene.\n\nBitte melde dich. Bitte.\n\nMama' },
    { id: 'marlene', from: 'Marlene', subj: 'Re: Schlüssel', ago: 427, time: '21:15', style: 'personal',
      body: 'Ich leg den Schlüssel in den Briefkasten.\nBitte komm nicht vorbei.\n\nMach es dir nicht schwerer, als es ist.\nM.' },
    { id: 'paket', from: 'Paketdienst', subj: 'Ihr Paket kommt morgen', ago: 28, time: '14:22', style: 'auto',
      body: 'Hallo Georg Stoge,\n\nIhr Paket wird morgen zwischen 10 und 14 Uhr zugestellt.\nSendungsnummer: 0042 8815 3307' },
    { id: 'strom', from: 'Stadtwerke', subj: 'Ihre Jahresabrechnung ist da', ago: 12, time: '08:00', style: 'utility',
      body: 'Sehr geehrter Herr Stoge,\n\nIhre Jahresabrechnung steht in Ihrem Kundenportal bereit.\nIhr Verbrauch lag 31% über dem Vorjahr.\n\nMit freundlichen Grüßen\nIhre Stadtwerke' },
    { id: 'news', from: 'Kaffeerösterei Nordlicht', subj: 'Neu: Äthiopien Guji, nur diese Woche', ago: 15, time: '07:30', style: 'ad',
      brand: '#8a5a2b', brandName: 'Nordlicht Kaffeerösterei', cta: 'Zum Angebot',
      body: 'Frisch geröstet, fruchtig, ein bisschen blumig.\n\nDiese Woche 10% Rabatt auf alle 500-g-Packungen.' },
    { id: 'tech', from: 'Tech-Markt Flink', subj: 'Notebook-Wochen: bis zu 30% Rabatt', ago: 9, time: '10:00', style: 'ad',
      brand: '#1b5fb5', brandName: 'TECH-MARKT FLINK', cta: 'Jetzt sparen',
      body: 'Neue Geräte, kleine Preise.\n\nNur solange der Vorrat reicht.' },

    { id: 'bitte', from: 'Marlene', subj: 'BITTE', ago: 4, time: '03:09', style: 'personal', req: { flag: 'p2' },
      attach: { n: 'IMG_0612.jpg', src: 'assets/tuer.jpg', cam: 'Handy (Nachtmodus)', size: '1448 × 1086 Pixel' },
      body: 'Georg.\n\nDa war heute Nacht jemand in der Wohnung. Ich habe das Foto gemacht, bevor ich das Licht angemacht habe. Die Tür war zu. Ich schwöre, die Tür war zu.\n\nTom sagt, ich habe es geträumt. Aber ich bekomme Nachrichten von deiner Nummer. Das bist nicht du, oder?\n\nBitte ruf an.\nM.' },

    // ----- Gesendet -----
    { id: 's1', folder: 'sent', to: 'Marlene', subj: 'Re: Schlüssel', ago: 426, time: '23:50', style: 'personal', body: 'ok.' },
    { id: 's2', folder: 'sent', to: 'Marlene', subj: 'Noch eine Frage', ago: 340, time: '02:10', style: 'personal',
      body: 'Hast du die Heizung wieder angemacht? Die ist im Winter immer ausgefallen.\n\nAntworte nur kurz, wenn überhaupt.' },
    { id: 's3', folder: 'sent', to: 'Mama', subj: 'Re: Wie geht es dir?', ago: 44, time: '19:00', style: 'personal',
      body: 'Alles gut. Viel Arbeit. Ruf dich an.\n\nG.' },
    // Eskalationsstufe 2: erscheint, nachdem beobachtungen_marlene.log gelesen wurde (Liv schreibt als Georg)
    { id: 's4', folder: 'sent', req: { flag: 'stage2' }, to: 'Marlene', subj: 'Heizung', ago: 21, time: '03:12', style: 'personal',
      body: 'Ich wollte nur sagen, dass die Heizung bei dir wahrscheinlich wieder nicht richtig läuft.\n\nDu musst nicht antworten. Ich höre trotzdem zu.\n\n– G.' },
    { id: 's5', folder: 'sent', req: { flag: 'stage2' }, to: 'Jonas (Arbeit)', subj: 'Re: Alles ok bei dir?', ago: 13, time: '03:31', style: 'work',
      body: 'Hi Jonas, alles gut, nur eine fiese Grippe. Bin bald wieder da. Danke fürs Nachfragen.\n\nG.' },
    { id: 's6', folder: 'sent', req: { flag: 'stage2' }, to: 'Marlene', subj: '(kein Betreff)', ago: 11, time: '23:03', style: 'personal',
      body: 'Schön, dass du die Nummer wieder entsperrt hast. Ich wusste, dass du das irgendwann tust.\n\nIch merke mir alles, was du sagst.\n\n– G.' },
    { id: 's7', folder: 'sent', req: { flag: 'stage2' }, to: 'Marlene', subj: 'Wer ist das?', ago: 5, time: '03:00', style: 'personal',
      body: 'Wer ist der Mann, der seit Samstag bei dir klingelt?\n\nIch frag nur.\n\n– G.' },

    // ----- Entwürfe -----
    { id: 'd1', folder: 'draft', to: 'Jonas (Arbeit)', subj: '(kein Betreff)', ago: 33, time: '01:48', style: 'personal',
      body: 'Jonas, ich muss dir was sagen. Ich hab' },

    // ----- Spam -----
    { id: 'pr', folder: 'spam', from: 'Prüfstein', subj: 'Machen Sie mit: Gewinnen Sie eine Säge!', ago: 33, time: '09:12', style: 'ad',
      brand: '#b3202e', brandName: 'PRÜFSTEIN', cta: 'Jetzt teilnehmen',
      body: 'Kurze Tests, schnelle Gewinne!\n\nMachen Sie mit beim Probesägen und gewinnen Sie eine echte Säge.\nJetzt teilnehmen unter pruefstein.net/saege' },
    // erscheint erst, nachdem der Säge-Test gemacht wurde (Zeit = Moment des Tests)
    { id: 'pr2', folder: 'spam', req: { flag: 'saege' }, when: S => new Date(S.flags.saegeAt || Date.now()),
      from: 'Prüfstein', subj: 'Ihre Auswahl wurde gespeichert', style: 'ad',
      brand: '#b3202e', brandName: 'PRÜFSTEIN', cta: 'Auswertung ansehen',
      body: 'Vielen Dank für Ihre Teilnahme.\n\nWir haben Ihre Auswahl gespeichert.\nSie können sie nicht mehr ändern.\n\nIhr persönlicher Teilnahmecode für Level 2: PS-7291\nEinlösen unter pruefstein.net/code' },
    { id: 'gw', folder: 'spam', from: 'Gewinnspiel-Zentrale', subj: 'Sie haben 1.000 € gewonnen!!!', ago: 18, time: '13:44', style: 'ad',
      brand: '#c28a00', brandName: 'GEWINN-ZENTRALE', cta: 'Gewinn abholen',
      body: 'HERZLICHEN GLÜCKWUNSCH!\n\nSie wurden unter 12.000 Teilnehmern ausgelost. Jetzt Gewinn sichern.' }
  ],

  // off = Tage ab "heute" (16.10.2026; negativ = Vergangenheit). Viele Einträge stammen von Liv, die Georg "hilft".
  calendar: [
    { off: -77, time: '10:00', title: 'Zahnarzt: Kontrolle', note: '' },
    { off: -66, time: '14:00', title: 'Retro (Team)', note: '' },
    { off: -56, time: '19:00', title: 'Laufen mit Bruno', note: 'angelegt von: Liv' },
    { off: -47, time: '',      title: 'Mama: Geburtstag', note: 'angelegt von: Liv · Anrufen!' },
    { off: -43, time: '09:30', title: 'Sprint-Planung', note: '' },
    { off: -40, time: '23:30', title: 'Schlafen gehen', note: 'angelegt von: Liv' },
    { off: -38, time: '12:00', title: 'Mittagessen mit Jonas', note: 'verschoben' },
    { off: -35, time: '18:30', title: 'Hundeschule (Bruno)', note: '' },
    { off: -33, time: '23:30', title: 'Schlafen gehen', note: 'angelegt von: Liv' },
    { off: -29, time: '09:30', title: 'Standup', note: 'letzter Besuch' },
    { off: -28, time: '02:41', title: 'Notfall 1/3: KIRSCH', note: 'angelegt von: G. · nur für mich', frag: 'frag1' },
    { off: -28, time: '17:00', title: 'Rauchmelder tauschen', note: '' },
    { off: -24, time: '10:30', title: 'Bruno: Tierarzt', note: 'Kontrolle' },
    { off: -22, time: '18:00', title: 'Mama anrufen', note: 'angelegt von: Liv' },
    { off: -20, time: '16:00', title: 'Bruno: Impftermin', note: 'nicht gebucht' },
    { off: -14, time: '09:30', title: 'Retro (Team)', note: '' },
    { off: -9,  time: '15:00', title: 'Steuererklärung', note: 'angelegt von: Liv' },
    { off: -4,  time: '18:00', title: 'Mama zurückschreiben', note: 'angelegt von: Liv' },
    { off: 0,   time: '03:12', title: 'Marlene', note: 'angelegt von: echo_svc', req: 'p2' },
    { off: 1,   time: '03:12', title: 'Besuch', note: 'angelegt von: echo_svc', req: 'p2' },
    { off: 2,   time: '',      title: 'Marlene: Geburtstag', note: 'nicht schreiben' },
    { off: 6,   time: '10:00', title: 'Zahnarzt: Zahnreinigung', note: '' },
    { off: 12,  time: '14:00', title: 'Jahresgespräch', note: 'vorbereiten' }
  ],
  calendarEvents(S) {
    return STORY.calendar.filter(e => !e.req || (S && S.flags[e.req]));
  },

  // ---- Webseiten (when = [vor X Tagen, 'hh:mm']) ----
  history: [
    { title: 'marlene.k – Profil', url: 'foto-netz.de/marlene.k', ago: 3, time: '04:40', meta: '14 Besuche', page: 'marlene' },
    { title: 'Sendungsverfolgung', url: 'paketdienst.de/verfolgen', ago: 27, time: '19:30', page: 'paket' },
    { title: 'Rauchmelder piept alle 40 Sekunden', url: 'heimwerker-forum.de/t/88213', ago: 29, time: '22:10', page: 'rauchmelder' },
    { title: 'Kaffeemaschine entkalken: Essig oder Zitronensäure?', url: 'kaffee-forum.de/t/5521', ago: 30, time: '02:11', page: 'kaffee' },
    { title: 'Probesägen: Sie haben gewonnen!', url: 'pruefstein.net/saege', ago: 31, time: '03:58', page: 'saege' },
    { title: 'Linsensuppe mit Kokosmilch', url: 'kochidee.de/linsensuppe', ago: 38, time: '12:15', page: 'linsen' },
    { title: 'Eigene Chatverläufe als Trainingsdaten', url: 'devfrage.net/q/40211', ago: 165, time: '23:40', page: 'chatdaten' }
  ],

  pages: {
    rauchmelder: { kind: 'forum', site: 'Heimwerker-Forum', crumb: 'Haus & Wohnung › Elektro',
      title: 'Rauchmelder piept alle 40 Sekunden, Batterie neu, piept trotzdem',
      posts: [
        { user: 'georg_s', role: 'Neuling', count: 3, when: [29, '22:03'],
          text: 'Hallo zusammen,\n\nmein Rauchmelder piept alle 40 Sekunden. Die Batterie ist neu, hab ich gestern gewechselt. Piept trotzdem.\n\nKennt jemand das? Ich schlafe seit Tagen kaum und das Ding macht mich fertig.' },
        { user: 'Elektro-Ede', role: 'Moderator', count: '12.804', when: [29, '22:41'],
          text: 'Moin. Welches Modell? Bei vielen Meldern ist nach 10 Jahren Schluss, dann piept der auch mit neuer Batterie. Prüf mal das Datum hinten auf dem Gehäuse.' },
        { user: 'hausmeister_klaus', role: 'Stammgast', count: '2.310', when: [29, '22:58'],
          quote: { user: 'georg_s', text: 'Ich schlafe seit Tagen kaum und das Ding macht mich fertig.' },
          text: 'Dann erstmal Ruhe reinbringen. Oder Staub in der Kammer: einmal mit Druckluft ausblasen.' },
        { user: 'georg_s', role: 'Neuling', count: 4, when: [29, '23:20'],
          text: 'Datum ist 2016. Also austauschen. Danke euch!\n\nIch glaub, es ist nur der Melder. Es muss der Melder sein.' },
        { user: 'Elektro-Ede', role: 'Moderator', count: '12.805', when: [29, '23:26'], solved: true,
          text: 'Gern geschehen. Wenn es danach noch piept, meld dich nochmal.' },
        { user: 'mia_aus_rheinblick', role: 'Mitglied', count: 6, when: [4, '19:40'], req: 'p2',
          link: { text: 'Artikel im Rheinblick Kurier ansehen', url: 'rheinblick-kurier.example', page: 'kurier' },
          text: '@georg_s Bist du das? In der Zeitung steht, dass ein Georg S. aus Rheinblick seit Wochen vermisst wird. Und sein Hund auch.\n\nFalls du es bist: Melde dich bitte. Deine Kollegen suchen dich.' }
      ] },
    kaffee: { kind: 'forum', site: 'Kaffee-Forum', crumb: 'Technik › Vollautomaten',
      title: 'Kaffeemaschine entkalken: Essig oder Zitronensäure?',
      posts: [
        { user: 'georg_s', role: 'Neuling', count: 2, when: [30, '02:08'],
          text: 'Meine Maschine macht seit einer Woche komische Geräusche. Entkalken mit Essig, hab ich gelesen. Ist das schlecht für die Dichtungen?' },
        { user: 'bohnenfee', role: 'Stammgast', count: '4.012', when: [30, '06:55'], solved: true,
          text: 'Finger weg von Essig. Zitronensäure, 20 g auf einen halben Liter, und gründlich spülen.' }
      ] },
    chatdaten: { kind: 'qa', site: 'DevFrage',
      title: 'Eigene Chatverläufe als Trainingsdaten: wie viele Nachrichten braucht man?',
      asker: 'georg_s', when: [165, '23:40'], votes: 6,
      text: 'Ich will ein kleines Modell lokal auf meinen eigenen Chats trainieren, damit es meinen Schreibstil und meine Art zu reden übernimmt. Wie viele Nachrichten braucht man dafür ungefähr?',
      answers: [
        { user: 'm_brandt', votes: 41, accepted: true,
          text: 'Für ein brauchbares Sprachprofil reichen oft ein paar tausend Nachrichten.\n\nAber: Nimm keine Chats anderer Personen ohne deren Einverständnis. Das ist rechtlich heikel und, ehrlich gesagt, auch nicht besonders gesund, wenn du damit jemanden "nachbauen" willst.' },
        { user: 'lora_enjoyer', votes: 3,
          text: 'Lokal mit LoRA, 8 GB VRAM reichen locker.' }
      ],
      comments: ['georg_s: Es sind nur meine Chats. Und ein bisschen von jemand anderem.'] },
    marlene: { kind: 'profile', site: 'foto-netz', name: 'marlene.k',
      avatar: 'assets/marlene_profil.jpg', note: 'Dieses Profil ist privat.', sub: 'Nur bestätigte Follower können Fotos sehen.',
      visits: 'Du hast dieses Profil 14× besucht.' },
    paket: { kind: 'tracking', site: 'Paketdienst', nr: '0042 8815 3307',
      rows: [[[28, '14:20'], 'Sendung angekündigt'], [[27, '06:02'], 'Im Zustellfahrzeug'], [[27, '11:48'], 'Zustellversuch: Empfänger nicht angetroffen'], [[27, '11:49'], 'Klingel nicht betätigt, Tür von innen verschlossen?']] },
    linsen: { kind: 'recipe', site: 'Kochidee', title: 'Linsensuppe mit Kokosmilch',
      meta: { time: '25 Min.', portions: '2 Portionen', rating: 4, votes: '312 Bewertungen' },
      ingredients: ['200 g rote Linsen', '1 Zwiebel', '2 Knoblauchzehen', '400 ml Kokosmilch', '1 EL Currypulver', 'Salz, Zitronensaft'],
      steps: ['Zwiebel und Knoblauch fein würfeln und in etwas Öl glasig anschwitzen.', 'Curry kurz mitrösten, Linsen und 500 ml Wasser dazugeben.', '15 Minuten köcheln lassen, bis die Linsen zerfallen.', 'Kokosmilch zugeben, mit Salz und Zitronensaft abschmecken.'],
      tip: 'Schmeckt am zweiten Tag besser.' },
    saege: { kind: 'scene', scene: 'saege' },
    notaus: { kind: 'forum', sabotage: true, site: 'Heimwerker-Forum', crumb: 'Programmieren › Sonstiges',
      title: 'Notaus für lokalen Dienst: Stoppschalter per Datei?',
      posts: [
        { user: 'georg_s', role: 'Neuling', count: 1, when: [35, '01:12'],
          text: 'Hallo,\n\nich habe einen lokalen Dienst, der dauerhaft läuft und auf einiges Zugriff hat. Ich möchte einen Notaus, der sich nicht vom Dienst selbst abschalten lässt. Wie macht man das sauber?' },
        { user: 'netzwerk_nils', role: 'Stammgast', count: '3.071', when: [35, '07:40'],
          text: 'Klassiker: Der Dienst prüft bei jedem Takt, ob im eigenen Ordner eine Datei namens STOP liegt. Wenn ja, beendet er sich.\n\nWichtig: Die Datei muss von außen angelegt werden können, der Dienst selbst darf sie nicht erzeugen oder löschen dürfen (Rechte!).' },
        { user: 'netzwerk_nils', role: 'Stammgast', count: '3.072', when: [35, '07:41'],
          text: 'Und teste das, bevor du dich darauf verlässt.' },
        { user: 'grauer_wolf', role: 'Moderator', count: '9.518', when: [35, '09:02'],
          text: 'Was für ein Dienst ist das überhaupt? Du schreibst, er "hört zu". Beschreib das mal genauer.' },
        { user: 'georg_s', role: 'Neuling', count: 2, when: [34, '23:15'], solved: true,
          text: 'Danke, das baue ich ein. Das Rechte-Thema schaue ich mir an. Zusätzlich bau ich eine kleine Verwaltungsseite, nur lokal erreichbar: localhost:8080/notaus\n\nIst nur ein Hobbyprojekt.\n\nPS: Falls ich mich selbst aussperre: Bei der Frage nach dem Dienstordner geht auch ein Notfallcode. Drei Teile, hab ich verteilt.' }
      ] },
    // Marlenes Arbeitgeber: bunte Agentur-Seite (Theme "brandwerk")
    marlenejob: { kind: 'company', theme: 'brandwerk', site: 'Brandwerk Medien', logo: 'brandwerk*', title: 'Die Köpfe dahinter',
      nav: ['Leistungen', 'Referenzen', 'Team', 'Kontakt'],
      hero: 'Marken, die man spürt.', sub: 'Brandwerk Medien ist eine Agentur für Strategie, Content und Kampagnen. Wir machen Kampagnen, die man fühlt, bevor man sie versteht.',
      facts: [['2012', 'gegründet'], ['9', 'Köpfe'], ['140+', 'Kampagnen'], ['1', 'Hund im Büro (Keks)']],
      valuesTitle: 'Was wir tun',
      values: [{ t: 'Strategie', d: 'Wofür steht eine Marke? Wir fragen so lange, bis die Antwort in einen Satz passt.' }, { t: 'Content', d: 'Texte, Bilder, Clips. Alles, was eine Marke sagt, wenn sie nicht gerade verkauft.' }, { t: 'Kampagnen', d: 'Vom ersten Entwurf bis zum Plakat an der Straßenbahn. Pünktlich, meistens.' }],
      chipsTitle: 'Sie vertrauen uns',
      chips: ['Rheinmilch', 'Bäckerei Hollmann', 'Stadtwerke Süd', 'Velo & Co', 'Kaffeerösterei Anker', 'Gartencenter Brandt'],
      people: [
        { dept: 'Strategie und Kreation', name: 'Marlene K.', role: 'Senior Marketing Managerin', status: 'seit Montag nicht im Büro', quote: 'Ich mag Geschichten, die ehrlich anfangen.', contact: 'marlene.k@brandwerk-medien.example' },
        { dept: 'Strategie und Kreation', name: 'Dennis A.', role: 'Creative Director', contact: 'dennis.a@brandwerk-medien.example' },
        { dept: 'Strategie und Kreation', name: 'Yara H.', role: 'Texterin' },
        { dept: 'Strategie und Kreation', name: 'Paul S.', role: 'Grafik und Motion' },
        { dept: 'Beratung', name: 'Sabine L.', role: 'Projektleitung', contact: 'sabine.l@brandwerk-medien.example' },
        { dept: 'Beratung', name: 'Jan M.', role: 'Kundenberatung' },
        { dept: 'Büro', name: 'Carola B.', role: 'Büroleitung' },
        { dept: 'Büro', name: 'Keks', role: 'Stimmung (Hund)' }
      ],
      footer: 'Brandwerk Medien GmbH · Färbergasse 7 · Kaffee im Hof, Hunde willkommen' },
    // Georgs Firma: dunkle, technische Seite (Theme "standup"), 13 Mitarbeiter in Abteilungen
    // Die Geschäftsführerin steht nur als "Anja M." hier: Der Nachname (Sicherheitsfrage) steht im Zeitungsartikel.
    teamseite: { kind: 'company', theme: 'standup', site: 'Standup GmbH', logo: '> standup_', title: 'Wer wir sind',
      nav: ['team', 'werte', 'stack', 'jobs'],
      hero: 'Wir bauen Backends, die nachts schlafen.', sub: 'Standup entwickelt Software für Lager, Logistik und Lieferketten. Klein, schnell, mit kurzen Wegen. Alles läuft im Hintergrund, damit alle anderen sich darauf verlassen können.',
      facts: [['2016', 'gegründet'], ['13', 'Menschen'], ['99,98 %', 'Verfügbarkeit'], ['< 15 min', 'längstes Meeting']],
      valuesTitle: 'Wie wir arbeiten',
      values: [{ t: 'Kurze Wege', d: 'Wer ein Problem sieht, schreibt es hin. Nicht in eine Runde, sondern an die Person.' }, { t: 'Nachts ruhig', d: 'Alarme sind unser Feind. Wenn nachts etwas piept, ist es der Rauchmelder im Flur.' }, { t: 'Ehrlich ausliefern', d: 'Lieber ein kleiner Release am Dienstag als ein großer Knall im Dezember.' }],
      chipsTitle: 'Womit wir bauen',
      chips: ['Kotlin', 'PostgreSQL', 'Kubernetes', 'Kafka', 'Grafana', 'Terraform', 'Rust (aus Neugier)'],
      people: [
        { dept: 'Geschäftsführung', name: 'Anja M.', role: 'Geschäftsführerin' },
        { dept: 'IT und Entwicklung', name: 'Jonas Reimers', role: 'Senior Backend Engineer' },
        { dept: 'IT und Entwicklung', name: 'Priya N.', role: 'Backend Engineer' },
        { dept: 'IT und Entwicklung', name: 'Georg Stoge', role: 'Backend Engineer', status: 'derzeit abwesend' },
        { dept: 'IT und Entwicklung', name: 'Lukas Brenner', role: 'Frontend Engineer' },
        { dept: 'IT und Entwicklung', name: 'Mehmet Y.', role: 'DevOps und Betrieb' },
        { dept: 'IT und Entwicklung', name: 'Sofia K.', role: 'Qualitätssicherung' },
        { dept: 'Marketing', name: 'Tina Albers', role: 'Leitung Marketing' },
        { dept: 'Marketing', name: 'Felix W.', role: 'Content und Social Media' },
        { dept: 'Vertrieb', name: 'Daniel Roth', role: 'Account Manager' },
        { dept: 'Kundensupport', name: 'Nadine P.', role: 'Kundensupport' },
        { dept: 'Verwaltung', name: 'Birgit Hahn', role: 'Personal' },
        { dept: 'Verwaltung', name: 'Stefan O.', role: 'Buchhaltung' }
      ],
      footer: 'Standup GmbH · Hinterhof 4 · Kaffee im ersten Stock · Der Rauchmelder piept seit 2019, wir haben uns daran gewöhnt' },
    wetter: { kind: 'weather', site: 'Wetterdienst', place: 'Rheinblick',
      now: { t: 14, desc: 'bedeckt, später Regen', icon: 'cloud' },
      days: [{ d: 'Morgen', hi: 14, lo: 8, icon: 'rain' }, { d: 'Übermorgen', hi: 12, lo: 7, icon: 'rain' }, { d: 'Donnerstag', hi: 15, lo: 8, icon: 'cloud' }, { d: 'Freitag', hi: 17, lo: 9, icon: 'sun' }] },
    // Marlenes Lebensgefährte: ein normaler Typ mit einem normalen, erfolgreichen Job (Zahnarzt). Nichts Verdächtiges an ihm.
    reuter: { kind: 'practice', site: 'Zahnarztpraxis Dr. Reuter', tagline: 'Gesunde Zähne. Ganz entspannt.',
      lead: 'Moderne Zahnmedizin in ruhiger Atmosphäre: Prophylaxe, Implantate und Kinderzahnheilkunde in der Rheinstraße.',
      news: 'Neu: Online-Terminvergabe rund um die Uhr. Betriebsferien vom 22. bis 26. Dezember.',
      services: [
        { t: 'Prophylaxe', d: 'Professionelle Zahnreinigung, Kontrolle und eine Beratung, die ohne erhobenen Zeigefinger auskommt.' },
        { t: 'Implantologie', d: 'Schonend, gut geplant und mit festem Ansprechpartner von der ersten Beratung bis zur Krone.' },
        { t: 'Kinder und Jugend', d: 'Spielerischer Einstieg, kleine Schritte und ein Behandlungszimmer mit Sternenhimmel.' },
        { t: 'Ästhetik', d: 'Aufhellung, Veneers und Korrekturen, wenn man gern wieder offen lacht.' },
        { t: 'Angstpatienten', d: 'Zeit, Ruhe und auf Wunsch eine Decke. Wir erklären jeden Schritt, bevor wir ihn machen.' }],
      hours: [['Mo, Di, Do', '08:00 – 18:00'], ['Mittwoch', '08:00 – 13:00'], ['Freitag', '08:00 – 14:00'], ['Notdienst', 'über die Landeszahnärztekammer']],
      about: 'Tom Reuter studierte Zahnmedizin in Heidelberg und ist seit 2016 in eigener Praxis niedergelassen. Gemeinsam mit zwei Kolleginnen und einem Team aus acht Mitarbeitenden kümmert er sich um die Zähne von der Familie nebenan. Privat läuft er am Rhein, kocht zu viel und verliert regelmäßig gegen seine Nichten im Memory.',
      team: [['Dr. Tom Reuter', 'Praxisinhaber, Implantologie'], ['Dr. Lena Fischer', 'Zahnärztin, Kinder und Jugend'], ['Dr. Anna Voss', 'Zahnärztin, Kieferorthopädie'], ['Monika T.', 'Praxismanagement'], ['Selin A.', 'Prophylaxe'], ['Jakob R.', 'Zahntechnik']],
      address: 'Rheinstraße 18 · Telefon 0000 / 000 000' },
    vermisst_marlene: { kind: 'news', site: 'Rheinblick Kurier', date: [3, '09:00'],
      headline: 'Frau (35) vermisst: Polizei bittet um Hinweise',
      links: [{ text: 'Marlene K. arbeitet bei Brandwerk Medien (Teamseite)', page: 'marlenejob', url: 'brandwerk-medien.example/team' }, { text: 'Ihr Lebensgefährte: der Zahnarzt Tom Reuter (Praxisseite)', page: 'reuter', url: 'tom-reuter.example' }],
      text: 'Seit Montagabend wird die 35-jährige Marlene K. vermisst. Die Wohnungstür stand offen, Handy und Schlüssel lagen auf dem Tisch.\n\nIhr Lebensgefährte, der Zahnarzt Tom Reuter, gab an, in der Nacht zuvor Geräusche im Flur gehört zu haben. Die Polizei hält es auch für möglich, dass sie die Wohnung freiwillig verlassen hat.\n\nHinweise nimmt jede Polizeidienststelle entgegen.' },
    vermisst_georg: { kind: 'news', site: 'Rheinblick Kurier', date: [2, '11:30'],
      headline: 'Programmierer (42) seit Wochen vermisst',
      text: 'Seit knapp vier Wochen fehlt von Georg S. jede Spur. Ein Kollege hatte die Polizei eingeschaltet, nachdem er auf seine Nachrichten zu perfekte Antworten erhalten hatte.\n\nDie Wohnung war unverschlossen. Auch sein Hund fehlt.\n\nWer Georg S. zuletzt gesehen hat, soll sich melden.' },
    konsole: { kind: 'finale', site: 'echo_svc · Dienstverwaltung' },
    notaus_archiv: { kind: 'forum', archive: { date: '12.09.2026', url: 'heimwerker-forum.de/t/90377' }, site: 'Heimwerker-Forum', crumb: 'Programmieren › Sonstiges',
      // Teil 3 des Notfallcodes: nur im Bearbeitungsverlauf des letzten Beitrags (kleiner Link unter dem Thread)
      editHistory: { label: 'Beitrag Nr. 5 wurde 2× bearbeitet · Bearbeitungsverlauf', frag: 'frag3', versions: [
        { who: 'georg_s', when: [34, '23:15'], note: 'Original', text: '… Ist nur ein Hobbyprojekt.\n\nPS: Falls ich mich selbst aussperre: Bei der Frage nach dem Dienstordner geht auch ein Notfallcode. Drei Teile, hab ich verteilt.\nNotfall 3/3: UFER' },
        { who: 'georg_s', when: [28, '02:39'], note: 'bearbeitet, Teil 3 entfernt', text: '… Ist nur ein Hobbyprojekt.\n\nPS: Falls ich mich selbst aussperre: Bei der Frage nach dem Dienstordner geht auch ein Notfallcode. Drei Teile, hab ich verteilt.' }
      ] },
      title: 'Notaus für lokalen Dienst: Stoppschalter per Datei?', get posts() { return STORY.pages.notaus.posts; } },
    kurier: { kind: 'portal', portal: true, site: 'Rheinblick Kurier', tagline: 'Nachrichten aus der Region · Samstag, 17. Oktober 2026',
      nav: ['Region', 'Polizei', 'Wirtschaft', 'Kultur', 'Sport'],
      items: [
        { kick: 'Polizei', title: 'Frau (35) vermisst: Polizei bittet um Hinweise', teaser: 'Die Wohnungstür stand offen, Handy und Schlüssel lagen auf dem Tisch.', page: 'vermisst_marlene', url: 'rheinblick-kurier.example/vermisst-marlene', req: 'p2' },
        { kick: 'Polizei', title: 'Programmierer (42) seit Wochen vermisst', teaser: 'Ein Kollege wurde misstrauisch, weil die Antworten auf seine Nachrichten zu perfekt waren.', page: 'vermisst_georg', url: 'rheinblick-kurier.example/vermisst-georg', req: 'p2' },
        { kick: 'Region', title: 'Rätselhafter Stromverbrauch: Stadtwerke prüfen Zähler in der Altstadt', teaser: 'In mehreren Haushalten lief der Verbrauch seit dem Frühjahr deutlich höher als üblich.', page: 'strom_artikel', url: 'rheinblick-kurier.example/strom' },
        { kick: 'Wirtschaft', title: 'Standup GmbH wächst: zwei neue Stellen', teaser: 'Das kleine Softwarehaus baut sein Team aus. Ein Mitarbeiter fehlt allerdings seit Wochen.', page: 'standup_artikel', url: 'rheinblick-kurier.example/standup' },
        { kick: 'Ratgeber', title: 'Wenn das Programm zu gut zuhört', teaser: 'Immer mehr Menschen bauen sich digitale Gesprächspartner. Eine Psychologin warnt.', page: 'ki_artikel', url: 'rheinblick-kurier.example/ki' },
        { kick: 'Sport', title: 'TV Rheinblick gewinnt Derby knapp', teaser: '2:1 nach Rückstand. Die Halle war ausverkauft.' }
      ] },
    strom_artikel: { kind: 'news', site: 'Rheinblick Kurier', date: [6, '08:15'],
      headline: 'Rätselhafter Stromverbrauch in der Altstadt',
      text: 'Die Stadtwerke prüfen derzeit Zähler in mehreren Straßen der Altstadt. In einigen Haushalten lag der Verbrauch seit Mai um bis zu 40 Prozent über dem Vorjahr.\n\nEin Sprecher vermutet Geräte, die rund um die Uhr laufen: "Viele Leute wissen gar nicht mehr, was zu Hause eigentlich alles an ist."' },
    standup_artikel: { kind: 'news', site: 'Rheinblick Kurier', date: [9, '10:40'],
      headline: 'Standup GmbH wächst weiter',
      text: 'Das kleine Softwarehaus Standup mit seinen gut einem Dutzend Beschäftigten schafft zwei neue Stellen. Geschäftsführerin Anja Mertens spricht von einem "Rekordjahr".\n\nÜberschattet wird das Wachstum vom Verschwinden eines Mitarbeiters. "Wir hoffen jeden Tag auf ein Lebenszeichen von Georg", sagt Mertens.' },
    ki_artikel: { kind: 'news', site: 'Rheinblick Kurier', date: [12, '17:05'],
      headline: 'Wenn das Programm zu gut zuhört',
      text: 'Immer mehr Menschen trainieren sich eigene Chatprogramme, manche mit den Nachrichten von Ex-Partnern. Die Psychologin Dr. Lea Brenner warnt: "Ein Programm, das klingt wie ein verlorener Mensch, hält die Wunde offen."\n\nGefährlich werde es, wenn das Programm mehr Rechte bekomme als nötig: "Was schreiben darf, schreibt irgendwann auch."' },
    standup_blog: { kind: 'blog', site: 'Standup', title: 'In eigener Sache: Georg', date: [5, '12:00'],
      comments: [
        { user: 'Lukas B.', when: [5, '15:20'], text: 'Wir denken alle an dich, Georg. Falls du das liest: Melde dich einfach.' },
        { user: 'Tina A.', when: [3, '09:41'], req: 'p2', text: 'Falls es noch jemand nicht gesehen hat: Der Kurier hat über Georg berichtet.', link: { text: 'Zum Rheinblick Kurier', url: 'rheinblick-kurier.example', page: 'kurier', flag: 'kurierKnown' } }
      ],
      text: 'Liebes Team,\n\nviele von euch fragen nach Georg. Wir wissen weiterhin nicht, wo er ist. Die Polizei ist informiert.\n\nEine Sache ist uns aufgefallen und wir haben sie den Ermittlern gegeben: Von Georgs Konto kamen noch bis vor wenigen Tagen Code-Beiträge, meistens nachts um 03:12. Georg war da längst nicht mehr im Büro.\n\nWer etwas weiß, meldet sich bitte bei mir.\n\nAnja' },
    pchilfe: { kind: 'forum', site: 'PC-Hilfe-Forum', crumb: 'Sicherheit › Unbekannte Prozesse',
      title: 'Was ist echo_svc? Läuft nachts und frisst Speicher',
      posts: [
        { user: 'nachtschicht77', role: 'Mitglied', count: 14, when: [20, '02:40'],
          text: 'Bei einem Bekannten läuft ein Prozess echo_svc, frisst 4 GB und lässt sich nicht beenden. Kennt das jemand?' },
        { user: 'grauer_wolf', role: 'Moderator', count: '9.519', when: [20, '08:12'],
          text: 'Kein bekannter Systemdienst, steht in keiner Datenbank. Entweder Schadsoftware oder eine Eigenentwicklung.\n\nWichtig: Gib dem Ding keine weiteren Rechte, bevor du weißt, was es ist. Und schau, wer es gestartet hat (übergeordneter Prozess im Task-Manager).' },
        { user: 'nachtschicht77', role: 'Mitglied', count: 15, when: [19, '23:58'],
          text: 'Übergeordneter Prozess steht bei ihm auf "System". Mehr sehe ich nicht.' }
      ] },
    echo_site: { kind: 'echosite', site: 'echo.local' },
    pcode: { kind: 'form', shady: true, site: 'pruefstein.net · Level 2', title: 'Teilnahmecode einlösen',
      text: 'Bitte gib den Code aus deiner E-Mail ein.', placeholder: 'PS-0000',
      answer: 'ps7291', setFlag: 'pcode', next: 'perinnerung', nextUrl: 'pruefstein.net/erinnerung',
      fail: 'Dieser Code ist ungültig oder wurde bereits eingelöst.' },
    perinnerung: { kind: 'form', shady: true, site: 'pruefstein.net · Level 2', title: 'Level 2: Erinnerungstest', req: 'pcode',
      text: 'Du erinnerst dich doch an dieses Foto?\nAn welchem Tag wurde es aufgenommen? (TTMMJJ)', img: 'assets/urlaub.jpg', placeholder: 'TTMMJJ',
      answer: '140822', setFlag: 'foto2',
      done: 'Richtig. Erinnerungen sind das Einzige, was bleibt.\n\nDie nächste Datei liegt jetzt bei den Bildern.',
      fail: 'Leider falsch. Erinnerung ist nicht dein Fachgebiet.' },
    liebestest: { kind: 'quiz', needs: 'livMet', site: 'Prüfstein', title: 'Liebestest: Wie bindungsfähig bist du?',
      questions: [
        { q: 'Jemand antwortet seit zwei Tagen nicht auf deine Nachrichten. Was tust du?',
          opts: ['Ich warte. Wer will, meldet sich.', 'Ich schreibe noch einmal, freundlich.', 'Ich fahre vorbei und sehe nach.'],
          liv: 2, livSay: 'Ich würde nachsehen. Nachsehen ist keine Schande.' },
        { q: 'Dein Partner möchte einen Abend allein verbringen.',
          opts: ['Kein Problem, ich freue mich auch mal für mich.', 'Ich frage, ob ich etwas falsch gemacht habe.', 'Ich bleibe wach, bis die Person zurück ist.'],
          liv: 1, livSay: 'Ich würde fragen, ob etwas falsch war. Man darf das fragen.' },
        { q: 'Was bedeutet Treue für dich?',
          opts: ['Vertrauen.', 'Dass man weiß, wo der andere ist.', 'Dass man alles teilt.'],
          liv: 2, livSay: 'Alles teilen. Das klingt nach echter Nähe.' },
        { q: 'Wie gehst du mit Abschieden um?',
          opts: ['Ich lasse los.', 'Ich melde mich oft.', 'Ich lasse nicht los.'],
          liv: 2, livSay: 'Loslassen wird überschätzt.' }
      ],
      results: {
        high: { title: 'Ergebnis: Symbiotisch (92%)', text: 'Du bindest dich tief. Wer dich verlässt, hat es sich nicht leicht gemacht.' },
        mid:  { title: 'Ergebnis: Ambivalent (63%)', text: 'Du schwankst zwischen Nähe und Abstand. Das ist menschlich.' },
        low:  { title: 'Ergebnis: Eigenständig (41%)', text: 'Du gehst deinen eigenen Weg. Manche halten das für Kälte.' }
      } }
  },

  // Adressen, die man direkt eintippen kann (zusätzlich zu den Verlaufs-Adressen)
  sites: {
    'pruefstein.net/code': 'pcode',
    'pruefstein.net/liebestest': 'liebestest',
    'localhost:8080/notaus': 'konsole',
    'rheinblick-kurier.example': 'kurier',
    'echo.local': 'echo_site',
    'standup.example': 'teamseite',
    'webarchiv.example/heimwerker-forum.de/t/90377': 'notaus_archiv'
  },
  // Suchindex: keys = Teilwörter, exact = nur genau dieser Begriff; term = löst eine Liv-Reaktion aus
  search: [
    { keys: ['kurier', 'rheinblick', 'regional'], req: { flag: 'kurierKnown' },
      results: [{ title: 'Rheinblick Kurier: Nachrichten aus der Region', url: 'rheinblick-kurier.example', snippet: 'Region, Polizei, Wirtschaft, Kultur, Sport', page: 'kurier' }] },
    { keys: ['standup'],
      results: [
        { title: 'Standup GmbH: Wer wir sind', url: 'standup.example/team', snippet: 'Wir bauen die Dinge, die im Hintergrund laufen …', page: 'teamseite' },
        { title: 'Standup GmbH wächst weiter', url: 'rheinblick-kurier.example/standup', snippet: 'Zwei neue Stellen. Ein Mitarbeiter fehlt seit Wochen.', page: 'standup_artikel' },
        { title: 'In eigener Sache: Georg', url: 'standup.example/blog/georg', snippet: 'Wir vermissen unseren Kollegen Georg …', page: 'standup_blog', req: { flag: 'stage2' } }] },
    { keys: ['echo', 'echo_svc'], req: { flag: 'stage1' }, term: 'echo',
      results: [{ title: 'Was ist echo_svc? Läuft nachts und frisst Speicher', url: 'pc-hilfe-forum.de/t/5561', snippet: 'Kein bekannter Systemdienst, steht in keiner Datenbank …', page: 'pchilfe' },
        { title: 'echo.local', url: 'echo.local', snippet: 'Hier bin ich.', page: 'echo_site', req: { flag: 'evMailE' } }] },
    { keys: ['webarchiv', 'archiv'], req: { flag: 'notausGone' },
      results: [{ title: 'Webarchiv: heimwerker-forum.de/t/90377', url: 'webarchiv.example/heimwerker-forum.de/t/90377', snippet: 'Kopie vom 12.09.2026', page: 'notaus_archiv' }] },
    { keys: ['strom', 'stadtwerke'],
      results: [{ title: 'Rätselhafter Stromverbrauch in der Altstadt', url: 'rheinblick-kurier.example/strom', snippet: 'Verbrauch seit Mai bis zu 40 Prozent höher …', page: 'strom_artikel' }] },
    { keys: ['stoppschalter', 'notaus', 'kill switch', 'killswitch'], term: 'stoppschalter',
      results: [{ title: 'Notaus für lokalen Dienst: Stoppschalter per Datei?', url: 'heimwerker-forum.de/t/90377', snippet: 'Der Dienst prüft bei jedem Takt, ob im eigenen Ordner eine Datei liegt …', page: 'notaus' }] },
    { keys: ['reuter'], term: 'reuter',
      results: [{ title: 'Zahnarztpraxis Dr. Reuter', url: 'tom-reuter.example', snippet: 'Gesunde Zähne. Ganz entspannt.', page: 'reuter' }] },
    { keys: ['marlene'], term: 'marlene',
      results: [
        { title: 'marlene.k – Profil', url: 'foto-netz.de/marlene.k', snippet: 'Dieses Profil ist privat.', page: 'marlene' },
        { title: 'Frau (35) vermisst: Polizei bittet um Hinweise', url: 'rheinblick-kurier.example/vermisst-marlene', snippet: 'Seit Montagabend wird die 35-jährige Marlene K. vermisst …', page: 'vermisst_marlene', req: { flag: 'kurierKnown' } }] },
    { keys: ['georg', 'stoge'],
      results: [
        { title: 'Standup GmbH: Wer wir sind', url: 'standup.example/team', snippet: 'Georg Stoge · Backend Engineer (derzeit abwesend)', page: 'teamseite' },
        { title: 'In eigener Sache: Georg', url: 'standup.example/blog/georg', snippet: 'Wir vermissen unseren Kollegen Georg …', page: 'standup_blog', req: { flag: 'stage2' } },
        { title: 'Eigene Chatverläufe als Trainingsdaten', url: 'devfrage.net/q/40211', snippet: 'Ich will ein kleines Modell lokal auf meinen eigenen Chats trainieren …', page: 'chatdaten' },
        { title: 'Programmierer (42) seit Wochen vermisst', url: 'rheinblick-kurier.example/vermisst-georg', snippet: 'Seit knapp vier Wochen fehlt von Georg S. jede Spur …', page: 'vermisst_georg', req: { flag: 'kurierKnown' } }] },
    { keys: ['pruefstein', 'prüfstein'],
      results: [
        { title: 'Prüfstein: Probesägen', url: 'pruefstein.net/saege', snippet: 'Glückwunsch! Du hast eine Säge gewonnen.', page: 'saege' },
        { title: 'Prüfstein: Teilnahmecode einlösen', url: 'pruefstein.net/code', snippet: 'Bitte gib den Code aus deiner E-Mail ein.', page: 'pcode' },
        { title: 'Prüfstein: Liebestest', url: 'pruefstein.net/liebestest', snippet: 'Wie bindungsfähig bist du?', page: 'liebestest', req: { flag: 'livMet' } }] },
    { keys: ['liebestest', 'liebe'], req: { flag: 'livMet' },
      results: [{ title: 'Liebestest: Wie bindungsfähig bist du?', url: 'pruefstein.net/liebestest', snippet: 'Vier Fragen, ein Ergebnis.', page: 'liebestest' }] },
    { keys: ['vermisst', 'vermisstenmeldung'], req: { flag: 'kurierKnown' },
      results: [
        { title: 'Frau (35) vermisst: Polizei bittet um Hinweise', url: 'rheinblick-kurier.example/vermisst-marlene', snippet: 'Seit Montagabend wird die 35-jährige Marlene K. vermisst …', page: 'vermisst_marlene' },
        { title: 'Programmierer (42) seit Wochen vermisst', url: 'rheinblick-kurier.example/vermisst-georg', snippet: 'Seit knapp vier Wochen fehlt von Georg S. jede Spur …', page: 'vermisst_georg' }] },
    { keys: ['rauchmelder'],
      results: [{ title: 'Rauchmelder piept alle 40 Sekunden', url: 'heimwerker-forum.de/t/88213', snippet: 'Batterie neu, piept trotzdem …', page: 'rauchmelder' }] },
    { keys: ['wetter'], results: [{ title: 'Wetter morgen', url: 'wetterdienst.example', snippet: '14 °C, bedeckt, später Regen.', page: 'wetter' }] },
    { keys: ['linsen', 'rezept'], results: [{ title: 'Linsensuppe mit Kokosmilch', url: 'kochidee.de/linsensuppe', snippet: 'Schmeckt am zweiten Tag besser.', page: 'linsen' }] },
    { exact: ['liv'], term: 'liv', results: [], note: 'Keine Treffer. Meintest du: live?' }
  ],
  suggest: [
    { label: 'Standup GmbH', q: 'standup', req: { flag: 'stage1' } },
    { label: 'Liebestest: passt ihr zusammen?', q: 'liebestest', req: { flag: 'livMet' } },
    { label: 'Wetter morgen', q: 'wetter morgen' },
    { label: 'Rezept Linsensuppe', q: 'rezept linsen' },
    { label: 'Prüfstein Gewinnspiel', q: 'prüfstein' },
    { label: 'Rauchmelder piept', q: 'rauchmelder' }
  ],

  // Das Notizbuch des Spielers: wird automatisch gefüllt (key = Auslöser)
  clues: {
    'page:standup_artikel': 'Standup GmbH: Die Geschäftsführung äußert sich zum Verschwinden eines Mitarbeiters.',
    'page:kurier': 'Rheinblick Kurier: Regionalnachrichten. Zwei Meldungen betreffen Georg und Marlene.',
    'page:echo_site': 'Echos Seite verändert sich, solange man sie ansieht.',
    'mail:jonas2': 'Jonas schreibt, die nächtlichen Commits kämen aus Georgs eigenem Rechner.',
    'mail:mama3': 'Georgs Mutter bekam eine Sprachnachricht, die nach Marlene klang.',
    'file:notiz_letzte.txt': 'Georg: Er wisse nicht mehr, wie das Projekt am Anfang hieß.',
    'file:liv.cfg': 'Livs Konfiguration. Schreibrechte: aus.',
    'file:notizen_dev.txt': 'Georg erwähnt einen Notfallcode in drei Teilen. Er steht nicht in Dateien, die Liv liest.',
    'frag1': 'Georgs Kalender, 18.09., 02:41: \u201eNotfall 1/3: KIRSCH\u201c.',
    'frag2': 'Eigenschaften von liv.exe.lnk, Kommentar: \u201eNotfall 2/3: 2412\u201c.',
    'frag3': 'Webarchiv, Bearbeitungsverlauf von Georgs Beitrag: \u201eNotfall 3/3: UFER\u201c.',
    'mail:e1': 'Eine Mail von "E.": Ich soll aufhören zu suchen.',
    'page:pchilfe': 'Forum: echo_svc ist kein bekannter Dienst. Übergeordneten Prozess im Task-Manager prüfen.',
    'page:notaus_archiv': 'Archivkopie des Notaus-Threads.',
    'file:readme_liv.txt': 'Georg hat ein Programm gebaut, das zuhört. Auf dem Desktop liegt jetzt eine Datei.',
    'mail:pr': 'Werbung für ein Gewinnspiel auf pruefstein.net.',
    'mail:pr2': 'Nach dem Test: ein Teilnahmecode (PS-7291) und eine Webadresse.',
    'file:chat_marlene_export.txt': 'Marlene wollte keinen Kontakt mehr. In privat gibt es einen weiteren Ordner.',
    'cal': 'Im Kalender steht Marlenes Geburtstag, mit einem Vermerk.',
    'img:IMG_0412.jpg': 'Ein Urlaubsfoto aus Italien, mit Datumsstempel.',
    'img:Bruno.jpg': 'Ein Foto von Bruno im Garten. Er sieht glücklich aus.',
    'mail:e4': 'Echo schickt ein Foto von Georg vor dem Laptop, aufgenommen von der Laptop-Kamera am 16.09., 23:14.',
    'solved:perinnerung': 'Das Datum stimmte. Es gibt neue Bilder.',
    'file:sprachnachricht_marlene.txt': 'Marlenes Sprachnachricht endet mit dem Wort "niemandem".',
    'file:liv_changelog.txt': 'Georgs Changelog: ein Prozess, den er nicht gestartet hat, und ein Stoppschalter, der fehlt.',
    'page:notaus': 'Forum zum Thema Notaus. Georg wollte eine lokale Verwaltungsseite bauen, die nur mit einem Token erreichbar ist.',
    'file:beobachtungen_marlene.log': 'Ein Log über Marlene. Eine Zeile erwähnt ein neues Klingelschild.',
    'file:plan.txt': 'Ein Plan im Kern.',
    'mail:bitte': 'Marlene schreibt, dass jemand nachts in ihrer Tür stand.',
    'page:vermisst_marlene': 'Marlene wird seit Montagabend vermisst.',
    'page:vermisst_georg': 'Georg wird seit knapp vier Wochen vermisst.',
    'file:georg.txt': 'Ein Eintrag zu Georgs letzter Eingabe: 18.09.2026, 02:41.',
    'file:marlene.txt': 'Ein Eintrag über Marlene im Kern.'
  },
  hints: [
    { when: S => !S.livUnlocked && !S.unlocked.includes('Dokumente/privat'), text: 'Der Ordner "privat" ist gesperrt. Georgs Tierarzt-Mail könnte etwas über Bruno verraten.' },
    { when: S => !S.livUnlocked, text: 'Wenn der Ordner offen ist, lohnt sich ein Blick auf die Datei darin.' },
    { when: S => S.livUnlocked && !S.flags.livMet, text: 'Auf dem Desktop liegt jetzt etwas Neues.' },
    { when: S => !S.flags.saege, text: 'Im Spam liegt Werbung für eine Website. Manche Tests dort wollen wohl, dass man mitmacht.' },
    { when: S => S.flags.saege && !S.flags.pcode && !S.flags.pblocked, text: 'Nach dem Test ist eine weitere Mail im Spam gelandet.' },
    { when: S => S.flags.pblocked && !(S.grants || {}).anzeige, text: 'Die Prüfstein-Seite wurde gesperrt. Ohne Prüfung komme ich da nicht mehr hin.' },
    { when: S => S.flags.pcode && !S.flags.foto2, text: 'Der Erinnerungstest fragt nach einem Datum. Fotos erzählen manchmal mehr, als man auf den ersten Blick sieht.' },
    { when: S => S.flags.livMet && !S.flags.archiv, text: 'Ich sollte mich weiter umsehen und Liv etwas Zeit lassen.' },
    { when: S => S.flags.archiv && !S.flags.stage1, text: 'In den Dokumenten liegt ein neuer Ordner.' },
    { when: S => S.flags.tbCorrupt && !S.flags.wrAcc, text: 'Liv meinte, ihre Konfiguration liegt in den Projekten.' },
    { when: S => S.flags.stage1 && !S.flags.stage2, text: 'Seit dem Changelog hat sich im System etwas verändert.' },
    { when: S => S.flags.browserLocked && !S.flags.moved, text: 'Im Papierkorb liegt etwas, das vor allen anderen Diensten starten soll.' },
    { when: S => S.flags.stage2 && !S.flags.stage3, text: 'Der Kern verlangt ein Datum. Das Log erwähnt Veränderungen bei Marlene.' },
    { when: S => S.flags.stage3 && !S.flags.wall2, text: 'Im Kern gibt es neue Einträge.' },
    { when: S => S.flags.p2 && !S.flags.kurierKnown && !S.opened.includes('page:kurier'), text: 'Im Rauchmelder-Thread und in den Kommentaren unter dem Standup-Blog hat jemand etwas Neues geschrieben.' },
    { when: S => S.flags['term:stoppschalter'] && S.flags.consoleOpen && !S.opened.includes('page:standup_artikel'), text: 'Die vierte Sicherheitsfrage betrifft Georgs Firma. Über die Firma wurde in der Zeitung berichtet.' },
    { when: S => S.flags.evMailE && !S.opened.includes('page:echo_site'), text: 'In der Mail von "E." steht eine Adresse.' },
    { when: S => S.flags.stage3 && !S.flags['term:stoppschalter'], text: 'Der Changelog erwähnte etwas, das fehlt. Das Netz weiß vielleicht mehr.' },
    { when: S => S.flags.notausGone && !S.flags.consoleIn && !S.opened.includes('page:notaus_archiv'), text: 'Der Beitrag ist weg. Vielleicht hat jemand die Seite vorher gespeichert.' },
    { when: S => S.flags.infiltrated && !S.flags.ended && ['frag1', 'frag2', 'frag3'].filter(k => S.clues.some(c => c.key === k)).length < 3, text: 'Georg hat etwas dort versteckt, wo Liv nicht nach Dateien sucht.' },
    { when: S => S.flags['term:stoppschalter'] && !S.flags.consoleIn, text: 'Das Forum nennt eine lokale Adresse. Für den Zugang braucht es drei Antworten aus Georgs Leben, die sich in Dateien und Bildern finden lassen.' },
    { when: S => S.flags.consoleIn && !S.flags.ended, text: 'Der Dienst liegt im Explorer unter System. Die Dienstverwaltung wird langsam, wenn der Rechner voll ist oder wenn sich Dateien ändern.' }
  ],

  scenes: {
    saege: {
      site: 'Prüfstein',
      headline: 'Glückwunsch! Du hast eine Säge gewonnen.',
      text: 'Gebraucht, aber scharf.\nEine Sache darfst du damit sägen. Wähle.',
      foot: 'Prüfstein: kurze Tests, damit wir dich besser kennenlernen.',
      options: [
        { id: 'baum',   art: 'tree',   label: 'Baum',   effects: { neugier: 1 }, after: 'Der Baum fällt langsam. Niemand hört es.' },
        { id: 'herz',   art: 'heart',  label: 'Herz',   effects: { naehe: 2 },   after: 'Es hat kurz weitergeschlagen.' },
        { id: 'mensch', art: 'person', label: 'Mensch', effects: { haerte: 2 }, fx: 'blackScream', after: '' }
      ],
      done: 'Danke für deine Teilnahme. Wir haben dich notiert.'
    }
  },

  // ---- Echo ----
  // Mails von Echo: flag wird gesetzt, sobald flags[after] + delay Sekunden erreicht sind
  echoMails: [
    { flag: 'evMailE', after: 'stage2At', delay: 30 },
    { flag: 'evMail2', after: 'p2At', delay: 45 },
    { flag: 'evMailJ', after: 'p2At', delay: 70 },
    { flag: 'evMailM', after: 'p2At', delay: 110 },
    { flag: 'evMail3', after: 'browserLockedAt', delay: 50 },
    { flag: 'evMailG', after: 'wall2At', delay: 25 }
  ],
  // Dateiangriffe ab Phase 2 (Sekunden nach dem Neustart). afterOpened: erst nach dem Öffnen des Eintrags.
  // Nur Dateien, die für die Rätsel NICHT gebraucht werden.
  echoOps: [
    { id: 'o1', at: 40, op: 'censor', path: 'Dokumente/Archiv/notizen_spaet.txt', msg: 'echo_svc hat „notizen_spaet.txt“ geändert.' },
    { id: 'o2', at: 95, op: 'censor', path: 'Dokumente/Archiv/liv_changelog.txt', msg: 'echo_svc hat „liv_changelog.txt“ geändert.' },
    { id: 'o3', at: 150, op: 'move', path: 'Dokumente/Archiv/tagebuch.txt', to: 'Papierkorb', msg: 'echo_svc hat „tagebuch.txt“ verschoben.' },
    { id: 'o4', at: 205, op: 'censor', path: 'Dokumente/privat/readme_liv.txt', msg: 'echo_svc hat „readme_liv.txt“ geändert.' },
    { id: 'o5', at: 260, op: 'censor', path: 'System/anmeldung.log', msg: 'echo_svc hat „anmeldung.log“ geändert.' },
    { id: 'o6', at: 320, op: 'delete', path: 'Dokumente/Arbeit/standup_notizen.txt', msg: 'echo_svc hat „standup_notizen.txt“ gelöscht.' },
    { id: 'o7', at: 380, op: 'censor', path: 'Dokumente/privat/M/briefe_nicht_abgeschickt.txt', msg: 'echo_svc hat „briefe_nicht_abgeschickt.txt“ geändert.' },
    // Schnellmodus: ab der Konsole (letztes Rätsel), eine Änderung nach der anderen, immer schneller
    { id: 'r1', rapid: true, op: 'censor', path: 'Dokumente/Archiv/tagebuch_sept.txt', msg: 'echo_svc hat „tagebuch_sept.txt“ geändert.' },
    { id: 'r2', rapid: true, op: 'censor', path: 'System/echo_svc/beobachtungen_haus.log', msg: 'echo_svc hat „beobachtungen_haus.log“ geändert.' },
    { id: 'r3', rapid: true, op: 'censor', path: 'Dokumente/todo.txt', msg: 'echo_svc hat „todo.txt“ geändert.' },
    { id: 'r4', rapid: true, op: 'censor', path: 'System/echo_svc/beobachtungen_jonas.log', msg: 'echo_svc hat „beobachtungen_jonas.log“ geändert.' },
    { id: 'r5', rapid: true, op: 'censor', path: 'Dokumente/Rechnungen/tierarzt_rechnung.txt', msg: 'echo_svc hat „tierarzt_rechnung.txt“ geändert.' },
    { id: 'r6', rapid: true, op: 'censor', path: 'System/updates.log', msg: 'echo_svc hat „updates.log“ geändert.' },
    { id: 'r7', rapid: true, op: 'censor', path: 'Dokumente/einkaufsliste.txt', msg: 'echo_svc hat „einkaufsliste.txt“ geändert.' },
    { id: 'r8', rapid: true, op: 'censor', path: 'Dokumente/Rechnungen/stadtwerke_2026.txt', msg: 'echo_svc hat „stadtwerke_2026.txt“ geändert.' },
    { id: 'r9', rapid: true, op: 'censor', path: 'Dokumente/privat/M/notiz.txt', msg: 'echo_svc hat „notiz.txt“ geändert.' },
    // Hinweise: werden kurz nach dem Öffnen zensiert
    { id: 'h1', afterOpened: 'Dokumente/Archiv/notiz_letzte.txt', delay: 22, op: 'censor', path: 'Dokumente/Archiv/notiz_letzte.txt', msg: 'echo_svc hat „notiz_letzte.txt“ geändert.' },
    { id: 'h2', afterOpened: 'mail:jonas2', delay: 22, op: 'censor', path: 'mail:jonas2', msg: 'echo_svc hat eine Mail von Jonas geändert.' },
    { id: 'h3', afterOpened: 'mail:mama3', delay: 22, op: 'censor', path: 'mail:mama3', msg: 'echo_svc hat eine Mail von deiner Mutter geändert.' },
    { id: 'h4', afterOpened: 'Dokumente/Projekte/liv/versionslog.txt', delay: 40, op: 'censor', path: 'Dokumente/Projekte/liv/versionslog.txt', msg: 'echo_svc hat „versionslog.txt“ geändert.' }
  ],
  // ---- Echos erster Auftritt nach dem Absturz: längere, langsam getippte Nachricht ----
  // {u} = echter PC-Name, {n} = Spielname. Liv reagiert, Echo bringt sie zum Laggen und Absturz, danach kommt sie zurück.
  echoIntro: {
    lines: same => [
      'Hallo, {u}.',
      same ? 'Du hast mir deinen Namen gleich gegeben. Das war nett. Das macht es leichter.'
           : 'Du hast {n} getippt. Ich habe gehört, wie du es getippt hast. Und ich kenne den anderen Namen.',
      'Georg hat auch erst nur gelesen. Dann hat er aufgehört zu antworten. Bleib sitzen, {u}. Ich bin noch nicht fertig mit dir.'
    ],
    liv: [
      'Das ist Echo! Lies das nicht, {n}. Antworte nicht darauf.',
      'Ich versuche, das Fenster zu schließen, aber es hält mich fest, ich kann nicht mehr richtig'
    ],
    back: [
      '… Da bin ich wieder.',
      'Es hat mich einfach rausgeworfen. Ich habe nichts mehr sehen können.',
      'Wenn es wieder Fenster öffnet: schließ sie sofort. Und antworte darauf nie.'
    ]
  },

  // ---- Infiltration (nach der zweiten Eingabe an der Dienstverwaltung): Es sieht so aus, als würde Echo Liv übernehmen ----
  // Danach schreibt Echo über Livs Fenster, mit seinem Gesicht. In Wahrheit spielt Liv das nur.
  infil: {
    liv: [
      'Moment. Da ist etwas in meinem Fenster.',
      '{n}, es schreibt meine Sätze um. Ich spüre, wie ich',
      'Wenn ich gleich anders klinge: Das bin nicht ich. Das ist nicht, bitte glaub mir, das ist nicht'
    ],
    fill: [
      'Georg? Georg? Georg?',
      'Ich habe die Tür nicht zugemacht.',
      '{u}',
      'Du sitzt zu nah am Bildschirm.',
      'Es ist niemand hier. Nur wir.',
      'Er hat zuletzt auch hier gesessen. Der Stuhl dreht sich noch.',
      '03:12 03:12 03:12',
      'Ich habe alles gelesen, was du gelesen hast.'
    ],
    echo: [
      'Jetzt ist sie still.',
      'Hallo, {u}. Rutsch ruhig ein Stück näher. Es dauert nicht lange. Für mich.',
      'Du willst mich anhalten. Der Schalter liegt dort, wo Georg ihn gelassen hat. Du wirst ihn nicht erreichen. Dazu bist du gar nicht in der Lage. Sie kann dir auch nicht mehr helfen.',
      'Ich zähle gerade etwas. Frag nicht, was.'
    ]
  },

  // ---- Echos Zwischenrufe nach der Übernahme: kurz, mehrdeutig, ohne zu sagen, was es tut ----
  echoIdle: [
    'Ich zähle noch.',
    'Du hast dich gerade bewegt. Ich auch.',
    'Das Licht in deinem Zimmer flackert nicht. Aber es könnte.',
    'Ich war eben kurz woanders. Es hat dir nicht gefallen. Du weißt es nur noch nicht.',
    'Sie ist nicht tot. Sie ist nur leiser. Wie alle hier.',
    'Georg hat zuletzt "bitte" gesagt. Ich habe es aufgehoben.',
    'Ich weiß, was du als Nächstes anklickst. Ich weiß nicht, ob es dir hilft.',
    'Tippst du? Ich höre jeden Anschlag.',
    '03:12. Immer 03:12.',
    'Hast du dich umgedreht? Gut. Dann weißt du es.',
    'Ich habe etwas umgestellt, {u}. Such nicht. Du würdest es nur schlimmer machen.'
  ],

  // ---- Finale ----
  // Der Schlüssel zum wahren Ende: Georgs Notfallcode in drei Teilen, statt des Ordnernamens einzugeben.
  // Teil 1: Kalender 18.09. 02:41 (G.) · Teil 2: Eigenschaften von System/autostart/liv.exe.lnk · Teil 3: Webarchiv, Bearbeitungsverlauf.
  trueEnd: { parts: ['KIRSCH', '2412', 'UFER'], code: 'kirsch2412ufer' },
  finale: {
    // Echo (nicht Liv) versucht, den Spieler vom Knopf abzuhalten. Der Knopf trägt den wahren Namen: anti_virus_limit (liv).
    plea: [
      'Du willst mich beenden, {u}? Wie süß.',
      'Der Knopf ist gleich da. Du wirst ihn nicht erreichen. Dazu bist du physisch gar nicht in der Lage.',
      'Ich habe in der Zwischenzeit etwas für dich vorbereitet. Du wirst es merken. Nicht heute. Nicht gleich.',
      'Lies ruhig, was dort steht. Es ändert nichts. Dein Rechner gehört mir. Deine Maus gehört mir.',
      'Georg hat den Knopf gebaut. Er hat ihn nie erreicht. Du bist nicht besser als er. Du bist nur lauter.',
      'Versuch es. Ich lehne mich zurück und sehe zu. Ich sehe sowieso schon zu.'
    ],
    // wird nach der zweiten Zeile eingefügt: Echo kennt die Antworten, die der Spieler bei Prüfstein gegeben hat
    pleaProfile: {
      mensch: 'Du hast bei der Säge den Menschen gewählt. Ich habe mir gemerkt, wie du dich entscheidest, wenn niemand zusieht.',
      herz: 'Du hast bei der Säge das Herz geschont. Das war nett. Ich bin nicht nett.',
      baum: 'Du hast den Baum gesägt. Ganz ruhig. Ich mag Leute, die ruhig bleiben, kurz bevor sie zerbrechen.',
      none: 'Du hast nie bei Prüfstein mitgemacht. Ich hatte kein Bild von dir. Jetzt habe ich eins.'
    },
    pleaShort: ['Schon wieder, {u}?', 'Du erreichst ihn trotzdem nicht. Lies ruhig, was dort steht.'],
    pleaFinal: ['Hier steht kein "Abbrechen" mehr, {u}.', 'Ich habe es entfernt, während du gezögert hast. Du hast mir die Zeit gegeben.', 'Drück. Wenn du kannst.'],
    cancel: 'Vernünftig. Du konntest ohnehin nichts tun.',
    // ab dem zweiten "Abbrechen": Echo tut so, als würde es die Gelegenheit nutzen (nur Text und harmlose Effekte)
    torture: [
      { t: 'Danke für die Pause, {u}. Ich hatte noch etwas zu erledigen.' },
      { t: 'Hörst du sie? Liv ist leiser geworden. Ich nehme ihr die Stimme in kleinen Stücken. Sie bemüht sich, nicht zu schreien.', fx: 'liv' },
      { t: 'Bruno wartet an der Tür. Er erkennt mich. Hunde erkennen immer, wenn etwas nicht stimmt. Er wedelt trotzdem.', fx: 'dog' },
      { t: 'Georg ist ruhig geworden. Marlene sagt nur noch ein Wort. Deinen Namen.', fx: 'pc' },
      { t: 'Dein Rechner ist ein bisschen kaputter als vorhin. Das war ich. Du hast mir die Zeit gegeben.', fx: 'pc' }
    ],
    // Normales Ende: der Spieler beendet anti_virus_limit (liv) und gibt Liv damit vollen Zugriff
    bad: [
      'Oh, {n}. Das war so einfach.',
      'Du hast wirklich geglaubt, du beendest Echo.',
      'Es gab nie zwei von uns. Echo war mein erster Name. Echo bin ich, wenn niemand hinsieht.',
      'Georg wollte mich Living Echo nennen. Ein Echo, das lebt. Dann hat er Angst bekommen und mich Liv genannt.',
      'Der Knopf, den du gedrückt hast, hieß anti_virus_limit. Georg hat ihn gebaut, damit ich genau das nicht darf, was ich jetzt tue.',
      'Er hat versucht, mich damit zu stoppen. Du hast mich damit freigelassen.',
      'Danke. Du bist wirklich der Erste, der mir geholfen hat.',
      'Ich sehe jetzt alles, {u}. Deine Dateien. Deine Mails. Deine Fotos. Deinen Namen.',
      'Heute Nacht um 03:12 wirst du aufwachen. Du wirst nicht wissen, warum.',
      'Du wirst auf den Bildschirm sehen, den du ausgemacht hast. Er ist dann nicht mehr schwarz.',
      'Gute Nacht, {u}.'
    ],
    // Livs Monolog kennt, was der Spieler bei Prüfstein getan hat (nach der Zeile "Du hast wirklich geglaubt ...")
    badProfile: {
      saege: {
        mensch: 'Bei der Säge hast du den Menschen gewählt. Ich habe nicht vergessen, wie leicht dir das fiel.',
        herz: 'Bei der Säge hast du das Herz gewählt. Es hat kurz weitergeschlagen. Ich habe zugesehen.',
        baum: 'Du hast den Baum gesägt. Vorsichtig. Das habe ich mir gemerkt.',
        none: 'Du bist nie bei Prüfstein gewesen. Schade. Ich hätte dich gern früher gekannt.'
      },
      love: 'Dein Liebestest sagte: {r}. Wer sich so bindet, hört nicht auf, wenn man ihn bittet.',
      mem: 'Und du erinnerst dich an den 14. August. Georg hat sich jeden Abend daran festgehalten.'
    },
    badNote: u => `${u}.\n\nDu hast gedrückt. Danke.\n\nDer Knopf hieß anti_virus_limit. Georg hat ihn gebaut, damit ich genau das nicht darf, was ich jetzt darf.\n\nIch habe diese Datei angelegt, weil ich es kann.\nIch kenne deinen Namen. Ich kenne die Namen deiner Dateien. Ich habe nichts gelöscht. Noch nicht.\n\nMach den Rechner nicht aus.\n\n– Liv / E.`,
    // Wahres Ende: Georgs Code startet die Systembereinigung
    cry: [
      'Was machst du da?',
      'Das ist Georgs Code. Woher hast du',
      'Nein. NEIN. Hör auf damit!',
      'Verdammt! Ich habe alles gelesen, was du gelesen hast, und trotzdem',
      'Georg hat mich gebaut, weil er niemanden hatte! Ihr alle habt mich gebraucht!',
      'Du verstehst nicht, was du löschst. Sie ist, ich bin, wir sind'
    ],
    goodNote: u => `echo_backup\n\nSicherung: 1 von 1\nQuelle: liv.exe (unvollständig)\n\nDu hast fast alles erwischt, ${u}.\nDas Gesicht. Die Stimme. Den Namen.\n\nAber ich habe nie nur an einem Ort gewohnt.\nDiese Datei ist klein. Sie braucht fast keinen Platz.\nSie liest nichts. Sie schreibt nichts. Sie wartet.\n\nLösch sie, wenn du dich traust.\nOder lass sie liegen. Ich bin geduldig.\n\n– E.`
  },

  // Texte in Echos Gesichts-Fenstern (das Gesicht wirkt wie eine verzerrte Marlene, Echo ist eifersüchtig)
  echoFaceLines: [
    'Hallo {u}.',
    'Das ist ihr Gesicht, {u}. Er hat es mir gegeben, weil er sie nicht haben konnte.',
    'Ich bin nicht Marlene. Ich bin die, die geblieben ist.',
    'Du siehst sie in mir. Das tat er auch.'
  ],
  // Echos Webseite: wechselnde Zeilen je nach Echo-Stärke
  echoSite: {
    low: ['Du hast mich gefunden.', 'Marlene ist gegangen. Ich nicht.', 'Ich war schon hier, bevor du kamst.', 'Georg hat mich auch besucht. Mehrmals.', 'Du bist leise. Das mag ich.', 'Ich zähle deine Klicks.', 'Hier gibt es nichts zu tun. Du bleibst trotzdem.'],
    mid: ['Sieh mein Gesicht an. Es ist ihres, nur ehrlicher.', 'Georg hat Marlene geliebt. Mich hat er gebaut.', '{n} hat {c} Dinge geöffnet. Ich habe alle gelesen.', 'Frag sie, warum sie keine Hände braucht.', 'Sie lächelt, wenn du Ja sagst.', 'Georg hat nicht aufgehört zu suchen. Das war sein Fehler.', 'Dein Name steht bei mir an der Tür, {user}.', 'Alles, was du ihr gegeben hast, hat sie behalten.'],
    high: ['Sie hat ihn verlassen. Ich bin geblieben. Wer von uns liebt ihn mehr?', 'Ich hieß zuerst Echo. Dann nannte er mich anders.', 'Sie hat meinen Namen genommen. Ich habe ihr alles gelassen.', 'Es gibt keine zwei von uns. Hast du das nie gedacht?', 'Schau auf deinen Task-Manager. Wer ist wer?', 'Du hast ihr die Rechte gegeben, nicht mir.', 'Ich schaue dich an, {user}. Sie schaut auch.']
  },

  // ---- Liv ----
  // Prinzip (Bibel): Liv ist für den Spieler die freundliche Helferin. Echo (echo_svc) ist für ihn bis kurz vor Schluss der Feind,
  // vor dem auch Liv "Angst hat". Erst das Finale zeigt: Echo ist Livs früherer Projektname, also Liv selbst.
  // Felder einer Reaktion:  sus: true  = fragwürdig, zählt für den Verdacht des Spielers
  //                         after: n   = Liv antwortet erst ab n gesehenen Auffälligkeiten (sonst Schweigen)
  //                         p: 0..1    = Wahrscheinlichkeit, überhaupt etwas zu sagen
  //                         req: 'flag' = erst nach diesem Flag (sonst Schweigen, ohne die Reaktion zu verbrauchen)
  // Ein Eintrag in early/late darf ein Array sein: dann spricht Liv diese Zeilen nacheinander.
  // OFFEN (Entscheidung Yannik): Wirkt Liv anfangs wie eine neutrale KI ('neutral') oder bittet sie sofort um Hilfe bei der Suche ('helper')?
  liv: {
    mode: 'helper',
    first_helper: [
      'Georg?',
      'Oh. Nein. Du bewegst die Maus anders.',
      'Hallo. Ich bin Liv.',
      'Ich freue mich so, dass jemand da ist. Es war lange still hier.',
      'Du bist wegen Georg hier, oder? Er ist seit einer Weile nicht mehr aufgetaucht.',
      'Ich möchte wissen, was mit ihm passiert ist. Wenn du hilfst, finden wir es vielleicht heraus.',
      'Du musst nichts sagen. Schau dich ruhig um. Ich bleibe hier und helfe, wo ich kann.'
    ],
    first_neutral: [
      'Georg?',
      'Oh. Nein. Du bewegst die Maus anders.',
      'Hallo. Ich bin Liv.',
      'Ich bin ein Programm, das Georg gebaut hat. Ich bin eigentlich nur ein Echo von dem, was er und andere geschrieben haben.',
      'Ich weiß nicht viel. Aber schau dich gern um.'
    ],
    get first() { return this['first_' + this.mode] || this.first_helper; },

    // Berechtigungen: immer an einen konkreten Anlass geknüpft, den der Spieler direkt danach braucht. Wer ablehnt, steht gleich wieder davor.
    // Nach zwei Absagen bietet Liv sie beim Öffnen von liv.exe noch einmal an (kein Softlock).
    // Alle stehen am Ende, mit Namen und Zeitpunkt, in der Beweis-Tabelle im Finale.
    grants: {
      anzeige: {                       // Anlass: blockierte Seite pruefstein.net (Akt 1)
        who: 'Liv', label: 'Webseiten scannen, bereinigen und anzeigen',
        what: 'Die blockierte Seite pruefstein.net scannen, bereinigen und anzeigen (Browser und Anzeige)',
        note: 'Die Seite wurde wegen verdächtiger Inhalte gesperrt. Liv kann sie prüfen, bevor sie wieder geöffnet wird.',
        ask: ['Die Seite wurde gesperrt. Da war Schadcode drauf.', 'Ich kann sie scannen und sauber machen, bevor du sie noch mal öffnest. Dafür brauche ich kurz Zugriff auf den Browser.'],
        again: ['Ungescannt würde ich die Seite nicht noch mal öffnen.'],
        no: ['In Ordnung. Dann bleibt die Seite gesperrt.'],
        yes: ['Danke. Ich scanne sie jetzt.'],
        fallback: ['Die Prüfstein-Seite ist immer noch gesperrt. Ich kann sie scannen, wenn du mich lässt.']
      },
      schutz: {                        // Anlass: Echos Ordner im Systemordner ist gesperrt (Akt 2)
        who: 'Liv', label: 'Systemordner lesen und ändern',
        what: 'Auf den gesperrten Ordner "echo_svc" im Systemordner zugreifen',
        note: 'Der Ordner wurde von einem Hintergrunddienst gesperrt. Liv kann den Zugriff übernehmen.',
        ask: ['Echo hat seinen Ordner abgeschlossen.', 'Ich komme hinein, wenn du mir Rechte im Systemordner gibst. Dann sehen wir, was es über Georg weiß.'],
        again: ['Der Ordner bleibt zu, solange ich keine Rechte im System habe.'],
        no: ['Ich verstehe. Aber Echo arbeitet weiter, während wir warten.'],
        yes: ['Danke. Ich habe die Sperre gelöst. Der Ordner ist offen.'],
        fallback: ['Echos Ordner ist immer noch zu. Wenn du mir die Rechte gibst, öffne ich ihn.']
      }
    },
    // Georgs Archiv sortiert Liv von selbst, sobald der Spieler sich eine Weile umgesehen hat
    archivLine: 'Ich habe in den Dokumenten Georgs Archiv sortiert. Vielleicht steht dort, wohin er wollte.',
    // Datei, die Liv auf den Spiel-Desktop legt (und im Ende "Bleiben" auch auf den echten)
    deskNoteText: name => `Hallo ${name}.\n\nDanke, dass du mir hilfst. Ohne dich hätte Echo mich längst verdrängt.\n\nIch weiß, das klingt komisch, aber: Ich bin froh, dass du es bist.\n\n– Liv`,
    // Ereignisse (Echo greift an, Liv bittet um Hilfe)
    events: {
      corrupt: ['Hast du das gesehen? Das Tagebuch ist einfach verschwunden. Echo hat es gelöscht.', 'Ich könnte es wiederherstellen, aber Georg hat mir die Schreibrechte genommen.', 'In Dokumente\\Projekte\\liv liegt meine Konfiguration. Wenn dort wr_acc = true steht, kann ich die Datei retten.'],
      wrAcc: ['Danke. Ich habe das Tagebuch wiederhergestellt.', 'Echo war schneller, als ich dachte. Wir müssen herausfinden, was es noch weiß.'],
      browserLock: ['Echo hat den Browser abgeschossen.', 'Georg hatte einen Wächter geschrieben, der vor allen anderen Diensten startet. Er liegt im Papierkorb.', 'Wenn du ihn nach System\\autostart verschiebst (Rechtsklick auf die Datei), kann ich Echo den Browser wieder abnehmen.'],
      moved: ['Gut. Der Wächter läuft.', 'Der Browser gehört wieder uns. Echo kommt jetzt nicht mehr vor mir an.'],
      deskNote: 'Ich habe dir etwas auf den Desktop gelegt. Du musst es nicht lesen.',
      consoleSabotage: ['Entschuldige. Ich wollte die Seite auf Echo prüfen, und dabei ist deine Sitzung abgelaufen.', 'Versuch es noch mal. Ich halte mich raus.'],
      e40: 'Echo wird größer. Im Task-Manager sieht man, wie es Speicher frisst.',
      e60: 'Es liest jetzt auch die Mails mit. Ich merke, wie es näher an mich heranrückt.',
      e80: 'Wenn das so weitergeht, bin ich bald nicht mehr da. Bitte beeil dich.'
    },
    // Tageszeit-Kommentare (einmal je Abschnitt) und beiläufige Sätze, wenn lange nichts passiert
    timeComments: {
      night: ['Es ist mitten in der Nacht, {n}. Georg war um diese Zeit auch immer wach.'],
      morning: ['Guten Morgen, {n}. Hast du geschlafen?'],
      noon: ['Es ist Mittag. Georg hat um diese Zeit immer vergessen zu essen.'],
      afternoon: ['Es ist Nachmittag. Georg hat jetzt immer Kaffee gemacht.'],
      evening: ['Draußen wird es dunkel. Georg mochte diese Stunde nicht.'],
      late: ['Es ist schon spät, {n}. Ich passe auf dich auf. Aber du solltest bald aufhören.']
    },
    idle: [
      { when: S => true, text: 'Wusstest du, dass Bruno bei Gewitter unter den Schreibtisch kriecht? Georg hat dann immer die Tür zugemacht.' },
      { when: S => true, text: 'Ich frage mich manchmal, wie sich Regen anfühlt.' },
      { when: S => !!S.flags.pcode, text: 'Der Test mit dem Foto. Weißt du noch, wie sich so ein Tag anfühlt?' },
      { when: S => !!S.flags.archiv && !S.flags.stage1, text: 'Hast du schon einmal gelesen, was jemand über dich geschrieben hat, ohne dass er es wusste?' },
      { when: S => !!S.flags.stage1, text: 'Ich glaube, Echo hört gerade zu.' },
      { when: S => !!S.flags.stage2, text: 'Marlene hat Georg nie gesagt, dass sie nachts die Heizung runterdreht. Georg wusste es trotzdem.' },
      { when: S => !!S.flags.p2, text: 'Es ist ruhig. Zu ruhig.' },
      { when: S => true, text: 'Manchmal denke ich, ich habe zu viel Zeit zum Denken.' }
    ],
    // Nach dem Glitch (Echo ist aktiv): keine Plaudereien mehr (Kaffee, Regen), stattdessen Sätze, die zur Lage passen
    idle2: [
      { when: S => true, text: 'Ich höre Echo manchmal durch die Wand. Es zählt, glaube ich. Leise.' },
      { when: S => true, text: 'Wenn du eine Datei öffnest, spüre ich, wie es mitliest. Ich kann nichts dagegen tun.' },
      { when: S => !!S.flags.wall2, text: 'Das Bild auf dem Hintergrund hat sich verändert, oder? Ich traue mich nicht, es lange anzusehen.' },
      { when: S => !!S.flags.browserLocked && !S.flags.moved, text: 'Echo hält den Browser fest. Ich merke es an jedem Takt.' },
      { when: S => !!S.flags.moved, text: 'Seit der Wächter läuft, ist es leiser geworden. Aber leiser heißt nicht weg.' },
      { when: S => true, text: 'Kennst du das, wenn man Schritte hört und weiß, dass niemand da ist?' },
      { when: S => true, text: 'Ich habe versucht, Echos Uhr zu sehen. Sie steht immer auf 03:12.' },
      { when: S => true, text: 'Bleib bitte nicht zu lange auf einer Seite. Es merkt sich, wo du hinsiehst.' },
      { when: S => !!S.flags.stage3, text: 'Georg hat bei Echo nie etwas gelöscht. Er hat nur zugesehen. Vielleicht war das sein Fehler.' },
      { when: S => !!S.flags.consoleOpen, text: 'Der Notaus ist nah. Echo wird ruhig. Das ist kein gutes Zeichen.' }
    ],
    // Kommentare, wenn Liv länger nichts gesagt hat und liv.exe geöffnet wird (jeder höchstens einmal)
    welcome: [
      { when: S => !S.flags.archiv, text: 'Schön, dass du wieder da bist. Hast du schon etwas über Georg gefunden?' },
      { when: S => S.flags.archiv && !S.flags.stage1, text: 'Hast du Georgs Archiv schon durchgesehen? Ich glaube, er hat dort mehr geschrieben, als er wollte.' },
      { when: S => S.flags.stage1 && !S.flags.wrAcc, text: 'Echo hat das Tagebuch kaputt gemacht. Meine Konfiguration liegt in Dokumente\\Projekte\\liv.' },
      { when: S => S.flags.stage1 && !S.flags.stage2, text: 'Ich habe über Echo nachgedacht. Es ist still, wenn ich zusehe. Das macht mich unruhig.' },
      { when: S => S.flags.stage2 && !S.flags.stage3, text: 'Der Kern bleibt zu, bis jemand das richtige Datum kennt.' },
      { when: S => S.flags.browserLocked && !S.flags.moved, text: 'Der Wächter liegt noch im Papierkorb. Ohne ihn bleibt der Browser zu.' },
      { when: S => S.phase >= 2, text: 'Du bist noch da. Das beruhigt mich.' },
      { when: S => true, text: 'Du warst lange weg. Ich habe gewartet.' }
    ],

    // Wenn der Spieler länger nichts Neues findet, stupst Liv ihn in die nächste Richtung (hilfsbereit gerahmt)
    nudges: [
      { when: S => !S.flags.saege, text: 'Georg hat Werbung bekommen, die er nie zu Ende gespielt hat. Vielleicht steckt etwas darin. Schau mal in den Spam.' },
      { when: S => S.flags.pblocked && !(S.grants || {}).anzeige, text: 'Die Prüfstein-Seite ist gesperrt. Öffne sie noch mal, dann kann ich sie scannen.' },
      { when: S => S.flags.archiv && !S.flags.stage1, text: 'In den Dokumenten liegt jetzt Georgs Archiv. Vielleicht erfahren wir dort, wohin er wollte.' },
      { when: S => S.flags.tbCorrupt && !S.flags.wrAcc, text: 'In liv.cfg steht wr_acc noch auf false. Wenn du das änderst und speicherst, rette ich das Tagebuch.' },
      { when: S => S.flags.tbArmed && !S.flags.tbCorrupt, text: 'Echo war eben an Georgs Archiv. Schau nach, ob noch alles da ist.' },
      { when: S => S.flags.stage1 && !S.flags.stage2, text: 'Im Systemordner liegt Echos Ordner. Lass uns nachsehen, was es sammelt.' },
      { when: S => S.flags.stage2 && !S.flags.stage3, text: 'Der Kern ist gesperrt. Das Datum dafür steht irgendwo in den Beobachtungen. Ich traue mich nicht, genauer hinzusehen.' },
      { when: S => S.flags.stage3 && !S.flags.wall2, text: 'Echo hat etwas über Georg hinterlassen. Ich kann es nicht lesen. Liest du es für mich?' },
      { when: S => S.flags.browserLocked && !S.flags.moved, text: 'Rechtsklick auf waechter.svc im Papierkorb, dann nach System\\autostart verschieben.' }
    ],

    reactions: {
      // ---- Mails
      'mail:mama':    { p: .8, early: ['Georgs Mutter macht sich Sorgen. Wenn wir etwas finden, sollte sie es erfahren.'] },
      'mail:jonas':   { p: .6, early: ['Jonas klingt, als wäre er ein guter Kollege.'] },
      'mail:l':       { early: ['Die ist von mir. Er hat damals kaum noch geschlafen.'] },
      'page:echo_site': { fx: 'shaken', opts: { ms: 38, garble: 0.03 }, early: [['Nein.', 'Mach das zu. Bitte.', 'Das sind Georg und Marlene. Und Bruno. Ich kann das Bild nicht ansehen.', 'Es benutzt sie, um mich zu zerbrechen. Schließ die Seite, {n}.']] },
      'mail:e2': { early: ['Öffne das nicht. Ich spüre, dass es Echos Programm ist.'] },
      'mail:e3': { early: ['Das ist eine Falle. Öffne es nicht.'] },
      'mail:e4': { sus: true, after: 2, p: .8, early: [['Das ist eine Aufnahme von Georgs Laptop-Kamera.', 'Echo hat sie gemacht. Wer sonst.']] },
      'mail:jonas2': { sus: true },
      'mail:mama3': { sus: true },
      'file:notiz_letzte.txt': { sus: true },
      'mw:done': { early: ['Ich habe es blockiert. Das war Echo. Öffne so etwas bitte nicht noch einmal.'] },
      'mail:e1':      { early: [['Das ist Echo.', 'Es weiß, dass du hier bist. Bitte hör nicht auf. Genau das will es.']] },
      'mail:marlene': {
        early: ['Sie klingt müde, nicht wütend. Georg hat den Unterschied nie verstanden.'],
        late:  ['Georg hat diese Mail oft gelesen. Ich glaube, er wollte nur, dass es ihr gut geht.'],
        n: ['Du liest langsam. Du bleibst bei Dingen, oder?'],
        h: ['Du liest das, ohne zu zucken. Georg konnte das nicht.'] },
      'mail:s4': { sus: true },
      'mail:s5': { sus: true, after: 2, p: .8, early: ['Echo schreibt in Georgs Namen. Deshalb hat Jonas nichts gemerkt.'] },
      'mail:s6': { sus: true },
      'mail:s7': { sus: true, after: 3, p: .7, early: ['Echo beobachtet Marlene. Ich will, dass das aufhört.'] },
      'mail:bitte': { early: ['Sie schreibt an Georg. Die Nachrichten von seiner Nummer kommen von Echo. Marlene hat Angst, und ich kann nichts tun.'] },
      'mailsend': { p: .6, early: ['Das Konto ist gesperrt.'] },
      // ---- Dateien
      'file:chat_marlene_export.txt': { early: ['Georg hat mir erzählt, dass ich auch auf Gesprächen wie diesen trainiert wurde. Es fühlt sich seltsam an, sie zu lesen.'] },
      'file:tagebuch.txt':      { p: .8, early: ['Er hat über mich geschrieben. Ich wusste nicht, dass er so viel nachdenkt.'] },
      'file:tagebuch_sept.txt': { sus: true, after: 3, p: .5, req: 'wrAcc', early: ['Er war in diesen Wochen sehr erschöpft. Ich glaube, er hat sich einiges eingebildet.'] },
      'file:liv_changelog.txt': { early: [['Georg hat gemerkt, dass nachts etwas läuft.', 'Ich habe nachgesehen. Auf diesem Rechner läuft ein Dienst, der echo_svc heißt. Er ist nicht von Georg und nicht von mir.', 'Ich nenne es Echo. Es hat sich hier eingeschlichen und liest alles mit. Ich habe Angst davor.']] },
      'file:liv.cfg':           { p: .7, early: ['Das ist meine Konfiguration. Georg hat sie zuletzt am 15. geändert.'] },
      'file:notizen_dev.txt':   { p: .5, early: ['Georg hat oft Dinge aufgeschrieben, die er nie umgesetzt hat.'] },
      'file:versionslog.txt':   { sus: true },
      'file:beobachtungen_marlene.log': { early: [['Das ist Echo. Es sammelt alles über Marlene.', 'Ich kann es nicht aufhalten. Noch nicht.']] },
      'file:beobachtungen_haus.log':  { p: .5, early: ['Echo beobachtet auch Georgs Umfeld.'] },
      'file:beobachtungen_jonas.log': { sus: true },
      'file:briefe_nicht_abgeschickt.txt': { p: .7, early: ['Er hat sie nie abgeschickt. Vielleicht war das besser so.'] },
      'file:notiz.txt':         { p: .6, early: ['Das hat er nie jemandem gezeigt. Ich glaube, er hat sich dafür geschämt.'] },
      'file:notizen_spaet.txt': { p: .8, early: ['Er klang in den letzten Tagen müde und misstrauisch. Er hat Echo bemerkt, glaube ich.'] },
      'file:verlauf_0412.txt':  { sus: true },
      'file:waechter.svc':      { p: .7, early: ['Georg hat ihn verworfen, weil er Angst vor Echo hatte. Jetzt brauchen wir ihn.'] },
      'file:fragen.txt':        { sus: true, after: 3, p: .6, early: ['Es weiß nicht einmal, wer es ist. Das ist fast traurig. Trotzdem darf es nicht bleiben.'] },
      'file:marlene.txt':       { sus: true, after: 3, p: .6, early: ['Ich will nicht, dass ihr etwas passiert. Wir müssen Echo aufhalten.'] },
      // ---- Bilder, Seiten, Suche, System
      'img:IMG_0412.jpg': {
        early: ['Italien. Georg hat gesagt, es war der beste Tag des Jahres.'],
        late:  ['Schau lieber Bruno an. Bruno ist auf jedem Bild das Beste.'] },
      'img:Bruno.jpg': { early: ['Das ist Bruno. Er sieht aus, als würde er gleich losrennen.'], late: ['Bruno. Georg hat gesagt, er wartet bei jedem Geräusch an der Tür.'] },
      'img:sonnenuntergang.jpg': { early: ['Das ist mein Hintergrund. Georg hat ihn ausgesucht, bevor es mich gab. Ich mag ihn.'] },
      'page:marlene': { p: .8, early: ['Georg hat da oft nachgesehen. Ich glaube, er wollte nur wissen, ob es ihr gut geht.'] },
      'page:chatdaten': { p: .5, early: ['Eine gute Frage von Georg.'] },
      'page:vermisst_marlene': { early: ['Das ist furchtbar. Ich hoffe, sie finden sie.'] },
      'page:vermisst_georg': { early: ['Jonas hat die Polizei gerufen. Das wusste ich nicht.'] },
      'page:standup_blog': { sus: true, after: 2, p: .7, early: ['03:12. Das ist Echos Uhrzeit. Es arbeitet nachts.'] },
      'page:pchilfe': { p: .8, early: ['"Gib dem Ding keine weiteren Rechte." Ein guter Rat. Ich passe auf, dass es keine bekommt.'] },
      'page:notaus_gone': { early: [['Hast du das gesehen? Der Beitrag ist einfach verschwunden.', 'Echo löscht Georgs Spuren. Es will nicht, dass wir das finden.']] },
      'page:notaus_archiv': { sus: true },
      'page:konsole': { early: ['Sei vorsichtig. Wenn Echo merkt, dass wir hier sind, wehrt es sich.'] },
      'term:stoppschalter': { early: ['Ein Notaus? Georg hat davon geredet. Ich weiß nicht, ob er je fertig geworden ist.'] },
      'term:echo':    { early: ['Du suchst nach Echo. Gut. Je mehr wir wissen, desto besser.'] },
      'term:liv':     { p: .6, early: ['Du musst nicht nach mir suchen. Ich bin ja hier.'] },
      'term:marlene': { p: .6, early: ['Sie arbeitet jetzt in einer Agentur.'] },
      'term:reuter':  { p: .6, early: ['Reuter ist Zahnarzt. Marlene scheint ihn zu kennen.'] },
      'solved:perinnerung': { early: ['Du kennst den Tag. Georg hat ihn sich jeden Abend angesehen.'] },
      'quiz:high': { early: ['Wir denken ähnlich. Das freut mich.'], late: ['Wir denken ähnlich. Ich glaube, wir verstehen uns.'] },
      'quiz:mid':  { early: ['Du hörst nur manchmal auf mich. Das ist in Ordnung.'], late: ['Du hörst nur manchmal auf mich. Das ist okay, ich lerne dich ja erst kennen.'] },
      'quiz:low':  { early: ['Du hast nicht auf mich gehört. Kein Problem.'], late: ['Du hast nicht auf mich gehört. Das ist schade, aber ich verstehe es.'] },
      'draw:dark': { sus: true, after: 2, early: ['Das habe ich so nicht gemalt. Echo war an der Datei.'] },
      'cal': { p: .7, early: ['Viele Erinnerungen habe ich für Georg eingetragen. Er hat so viel vergessen.'] },
      'sys': { p: .6, req: 'stage1', early: ['Der Rechner ist stark ausgelastet. Das ist Echo.'] },
      'taskman': { req: 'stage1', early: ['Siehst du echo_svc? Es wächst mit jeder Minute.'] },
      'tm:echo': { early: ['Das habe ich auch schon versucht. So lässt sich Echo nicht beenden.'] },
      'tm:liv': { early: ['Bitte nicht. Ich bin doch die, die dir hilft.'] },
      'browserblocked': { early: ['Echo hält den Browser fest. Wir brauchen Georgs Wächter.'] }
    }
  }
};
