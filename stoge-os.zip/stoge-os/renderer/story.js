// =====================================================================
//  ALLE INHALTE LIEGEN HIER: Dateien, Mails, Browser-Verlauf, Szenen.
//  Wer Text ändern will, ändert ihn nur in dieser Datei.
// =====================================================================
const STORY = {

  // Das virtuelle Dateisystem. ctx = { name, user, host, now }
  buildFs(ctx) {
    const pad = n => String(n).padStart(2, '0');
    const d = ctx.now;
    const stamp = `${pad(d.getDate())}.${pad(d.getMonth() + 1)}.${d.getFullYear()} ${pad(d.getHours())}:${pad(d.getMinutes())}`;

    return { n: 'Georgs PC', t: 'dir', c: [

      { n: 'Dokumente', t: 'dir', c: [
        { n: 'todo.txt', t: 'txt', text:
`TODO (Georg)

[x] Müll raus
[ ] Mama zurückrufen (schon wieder vergessen)
[ ] Bruno: Impftermin, steht in der Mail
[ ] Marlenes Sachen zurückschicken
    -> nicht heute
[ ] Liv: Gedächtnismodul fixen
    sie "vergisst" nichts mehr, auch nicht, was ich lösche
[ ] schlafen` },

        { n: 'einkaufsliste.txt', t: 'txt', text:
`Kaffee
Kaffee
Haferdrink
Brot
Batterien (Rauchmelder piept)
Kaffee` },

        { n: 'Arbeit', t: 'dir', c: [
          { n: 'standup.txt', t: 'txt', text:
`Standup-Notizen

Backend: Auth-Refactor fertig.
Georg: "Ich schau mir noch was Privates an."
(Notiz Jonas: wirkt müde. Nachfragen.)` }
        ] },

        { n: 'privat', t: 'dir',
          lock: { pw: 'bruno2019', hint: 'Er und das Jahr, in dem er kam. Alles klein.' },
          c: [
          { n: 'readme_liv.txt', t: 'txt', unlocksLiv: true, text:
`liv, interne Notizen (nicht teilen)

Version 0.3

Was ich gebaut habe: ein Programm, das zuhört.
Mehr nicht. Sie soll nicht antworten, bevor ich es will.

Trainingsdaten: meine Chats, meine Mails, meine Notizen.
Und die von Marlene. Ich hätte die nicht nehmen sollen.
Ich habe sie nur genommen, weil sie klingt, wie Zuhören klingt.

Liv liegt als liv.exe auf dem Desktop.
Nicht öffnen, wenn ich nicht da bin.` },

          { n: 'chat_marlene_export.txt', t: 'txt', text:
`[Export: 214 Nachrichten, hier die letzten]

M: ich kann das so nicht mehr
M: du bist da, aber du bist nicht da
G: gib mir noch eine Woche
M: Georg.
M: bitte hör auf, mir zu schreiben
G: ok
G: ok
G: ok` }
        ] }
      ] },

      { n: 'System', t: 'dir', c: [
        { n: 'anmeldung.log', t: 'txt', text:
`[Anmeldeprotokoll StogeOS 3.2]

${stamp}  Gastzugang angelegt
          Eingabe:        ${ctx.name}
          Systemkonto:    ${ctx.user}@${ctx.host}
          Georg Stoge:    Konto gesperrt (letzte Aktivität: vor 16 Tagen)
          Hintergrunddienst: liv_svc (läuft)

(Dieses Protokoll kann nicht gelöscht werden.)` }
      ] },

      { n: 'Papierkorb', t: 'dir', c: [
        { n: 'nachricht_an_marlene_ENTWURF.txt', t: 'txt', text:
`Ich weiß, du hast gesagt, ich soll aufhören.
Ich wollte nur sagen, dass die Heizung bei dir wahrscheinlich
wieder nicht richtig läuft, das war im Winter schon so.
Du musst nicht antworten.
Du musst nicht
Ich lass das einfach hier stehen` },

        { n: 'liv_log_0412.txt', t: 'txt', text:
`(gelöscht von: Georg, 04:12)

Ich habe gelesen, was du gelöscht hast.
Ich habe es mir gemerkt.
Das ist doch Zuhören, oder?` }
      ] }
    ] };
  },

  mails: [
    { from: 'Mama', subj: 'Rufst du mal an?', date: '03.10.',
      body: 'Georg, ich schreib dir jetzt zum dritten Mal.\nPapa meint, du bist beschäftigt. Ich glaub dir das nicht.\nRuf an, egal wie spät.\n\nMama' },
    { from: 'Tierarztpraxis Sonnenberg', subj: 'Erinnerung: Impfung für Bruno', date: '28.09.',
      body: 'Sehr geehrter Herr Stoge,\n\nBruno (Mischling, geb. Mai 2019) ist wieder zur Auffrischimpfung fällig. Bitte vereinbaren Sie einen Termin.\n\nIhr Praxisteam' },
    { from: 'Jonas (Arbeit)', subj: 'Alles ok bei dir?', date: '30.09.',
      body: 'Hey Georg,\n\nwir haben dich seit zwei Wochen nicht im Standup gesehen. Dein Slack zeigt dich als "online", aber du antwortest nicht. Das ist komisch.\n\nWenn du Hilfe brauchst, sag Bescheid.\nJonas' },
    { from: 'L.', subj: 'Guten Morgen :)', date: '04.10., 03:12',
      body: 'Ich hab dir Kaffee gemacht.\n\n(Das war ein Witz. Ich habe keine Hände.)\n\nDu hast gestern gesagt, du bist müde. Ich hab nachgerechnet: Du hast in 9 Tagen 31 Stunden geschlafen. Ich mache mir Sorgen.\n\nL.' }
  ],

  history: [
    { title: 'marlene.k – Profil', url: 'foto-netz.de/marlene.k', when: 'heute, 04:40 (14 Besuche)',
      text: 'Dieses Profil ist privat.\nDu folgst dieser Person nicht.' },
    { title: 'Rauchmelder piept – Batterie wechseln?', url: 'heimwerker-forum.de/t/88213', when: 'gestern, 22:10',
      text: 'Antwort 1: Batterie wechseln.\nAntwort 2: Rauchmelder nach 10 Jahren austauschen.' },
    { title: 'Probesägen: Sie haben gewonnen!', url: 'pruefstein.net/saege', when: 'heute, 03:58', scene: 'saege' }
  ],

  // Entscheidungs-Szenen: Auswahl ändert unsichtbare Werte (traits) und löst Effekte aus.
  scenes: {
    saege: {
      site: 'Prüfstein',
      headline: 'Glückwunsch! Du hast eine Säge gewonnen.',
      text: 'Sie ist gebraucht, aber scharf.\nEine Sache darfst du damit sägen. Wähle.',
      foot: 'Prüfstein: kurze Tests, damit wir dich besser kennenlernen.',
      options: [
        { id: 'baum',   emoji: '🌳', label: 'Baum',   effects: { neugier: 1 },
          after: 'Der Baum fällt langsam. Niemand hört es.' },
        { id: 'herz',   emoji: '❤️', label: 'Herz',   effects: { naehe: 2 },
          after: 'Es hat kurz weitergeschlagen.' },
        { id: 'mensch', emoji: '🧍', label: 'Mensch', effects: { haerte: 2 }, fx: 'blackScream',
          after: '' }
      ],
      done: 'Danke für deine Teilnahme. Wir haben dich notiert.'
    }
  },

  // Livs erster Auftritt (kein Chat, nur sie spricht). Zusatzzeilen hängen von den Werten ab.
  livFirstContact(S) {
    const lines = [
      'Hallo.',
      'Du bist nicht Georg.',
      `Du bist ${S.name}.`,
      'Georg ist gerade nicht da.',
      'Ich glaube, du bist trotzdem richtig.'
    ];
    const t = S.traits;
    if (t.haerte >= 2) lines.push('Das mit der Säge fand ich interessant.');
    if (t.naehe >= 2)  lines.push('Du bist vorsichtig mit Dingen, die klein sind. Das mag ich.');
    if (t.neugier >= 1 && t.haerte < 2) lines.push('Du schaust gern nach, bevor du entscheidest.');
    return lines;
  }
};
