const { app, BrowserWindow, ipcMain } = require('electron');
const path = require('path');
const fs = require('fs');
const os = require('os');

const stateFile = () => path.join(app.getPath('userData'), 'stoge-state.json');

function readState() {
  try { return JSON.parse(fs.readFileSync(stateFile(), 'utf8')); } catch { return null; }
}

function createWindow(phase = 1) {
  const w = new BrowserWindow({
    fullscreen: !process.env.STOGE_WINDOWED,
    width: 1280,
    height: 800,
    backgroundColor: '#000000',
    autoHideMenuBar: true,
    title: phase >= 2 ? 'liv' : 'StogeOS 3.2',
    webPreferences: {
      preload: path.join(__dirname, 'preload.js'),
      contextIsolation: true,
      nodeIntegration: false
    }
  });
  w.setMenu(null);
  w.loadFile(path.join(__dirname, 'renderer', 'index.html'));

  // Sicherheitsnetz: Das Spiel ist IMMER beendbar.
  w.webContents.on('before-input-event', (event, input) => {
    if (input.type !== 'keyDown') return;
    if (input.key === 'F11') w.setFullScreen(!w.isFullScreen());
    if (input.control && input.shift && input.key.toLowerCase() === 'q') app.quit();
  });
  return w;
}

// ---- Systemzugriff: bewusst klein und harmlos gehalten ----

// Windows-Benutzername, Rechnername
ipcMain.handle('sys:info', () => ({
  user: os.userInfo().username,
  host: os.hostname(),
  platform: process.platform
}));

// Nur DATEINAMEN vom Desktop, niemals Inhalte
ipcMain.handle('sys:desktopFiles', () => {
  try {
    return fs.readdirSync(app.getPath('desktop'))
      .filter(n => !n.startsWith('.') && n.toLowerCase() !== 'desktop.ini')
      .slice(0, 200);
  } catch { return []; }
});

// Nur .txt-Dateien auf den Desktop, überschreibt nie etwas Vorhandenes
ipcMain.handle('sys:writeDesktop', (e, name, content) => {
  try {
    let base = path.basename(String(name)).replace(/[^\w\-. äöüÄÖÜß]/g, '_').slice(0, 80);
    base = base.replace(/\.txt$/i, '') || 'Notiz';
    const dir = app.getPath('desktop');
    let file = base + '.txt';
    let i = 2;
    while (fs.existsSync(path.join(dir, file))) file = `${base} (${i++}).txt`;
    fs.writeFileSync(path.join(dir, file), String(content).slice(0, 20000), 'utf8');
    return file;
  } catch { return null; }
});

// Fake-Neustart: neues Fenster öffnen, altes schließen (gleicher Prozess, kein echter Neustart)
ipcMain.handle('sys:fakeRestart', (e, phase) => {
  const old = BrowserWindow.fromWebContents(e.sender);
  createWindow(phase || 2);
  if (old) old.destroy();
});

ipcMain.handle('sys:saveState', (e, s) => {
  try { fs.writeFileSync(stateFile(), JSON.stringify(s)); } catch {}
});
ipcMain.handle('sys:loadState', () => readState());
ipcMain.handle('sys:resetState', () => {
  try { fs.unlinkSync(stateFile()); } catch {}
});
ipcMain.handle('sys:quit', () => app.quit());

app.whenReady().then(() => {
  const saved = readState();
  createWindow(saved && saved.phase ? saved.phase : 1);
});
app.on('window-all-closed', () => app.quit());
