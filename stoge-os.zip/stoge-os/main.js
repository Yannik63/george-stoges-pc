const { app, BrowserWindow, ipcMain } = require('electron');
const path = require('path');
const fs = require('fs');
const os = require('os');

// ---- Stabilität: genau eine Instanz, saubere Beendigung, keine Prozesse im Hintergrund ----
if (!app.requestSingleInstanceLock()) { app.exit(0); }
app.on('second-instance', () => {
  const w = BrowserWindow.getAllWindows()[0];
  if (w) { if (w.isMinimized()) w.restore(); w.focus(); }
});

const stateFile = () => path.join(app.getPath('userData'), 'stoge-state.json');

function readState() {
  try { return JSON.parse(fs.readFileSync(stateFile(), 'utf8')); } catch { return null; }
}

const windowed = !!process.env.STOGE_WINDOWED;

function createWindow(phase = 1) {
  const w = new BrowserWindow({
    show: false,                      // erst zeigen, wenn bereit (verhindert halbes Vollbild)
    fullscreen: !windowed,
    width: 1280,
    height: 800,
    backgroundColor: '#000000',
    autoHideMenuBar: true,
    title: phase >= 2 ? 'liv' : 'StogeOS 3.2',
    webPreferences: {
      preload: path.join(__dirname, 'preload.js'),
      contextIsolation: true,
      nodeIntegration: false,
      backgroundThrottling: true,      // im Hintergrund drosseln
      spellcheck: false
    }
  });
  w.setMenu(null);
  w.once('ready-to-show', () => {
    if (!windowed) w.setFullScreen(true);
    w.show(); w.focus();
  });
  w.loadFile(path.join(__dirname, 'renderer', 'index.html'));

  // Sicherheitsnetz: Das Spiel ist IMMER beendbar.
  w.webContents.on('before-input-event', (event, input) => {
    if (input.type !== 'keyDown') return;
    if (input.key === 'F11') w.setFullScreen(!w.isFullScreen());
    if (input.control && input.shift && input.key.toLowerCase() === 'q') quitAll();
  });
  // Absturz des Renderers: nicht hängen bleiben, sauber beenden
  w.webContents.on('render-process-gone', () => quitAll());
  w.on('unresponsive', () => quitAll());
  return w;
}

// Alles schließen und den Prozess wirklich beenden (auch GPU- und Hilfsprozesse)
let quitting = false;
function quitAll() {
  if (quitting) return; quitting = true;
  for (const w of BrowserWindow.getAllWindows()) { try { w.destroy(); } catch {} }
  app.quit();
  setTimeout(() => app.exit(0), 1500);   // falls etwas hängt: hart beenden
}

// ---- Systemzugriff: bewusst klein und harmlos gehalten ----
ipcMain.handle('sys:info', () => ({
  user: os.userInfo().username,
  host: os.hostname(),
  platform: process.platform
}));

// Nur DATEINAMEN vom Desktop, niemals Inhalte
ipcMain.handle('sys:desktopFiles', () => {
  try {
    return fs.readdirSync(app.getPath('desktop'))
      .filter(n => !n.startsWith('.') && n.toLowerCase() !== 'desktop.ini')
      .slice(0, 200);
  } catch { return []; }
});

// Nur .txt-Dateien auf den Desktop, überschreibt nie etwas Vorhandenes, höchstens 3 pro Sitzung
let desktopWrites = 0;
ipcMain.handle('sys:writeDesktop', (e, name, content) => {
  try {
    if (desktopWrites >= 3) return null;
    let base = path.basename(String(name)).replace(/[^\w\-. äöüÄÖÜß]/g, '_').slice(0, 80);
    base = base.replace(/\.txt$/i, '') || 'Notiz';
    const dir = app.getPath('desktop');
    let file = base + '.txt';
    let i = 2;
    while (fs.existsSync(path.join(dir, file)) && i < 20) file = `${base} (${i++}).txt`;
    if (fs.existsSync(path.join(dir, file))) return null;
    fs.writeFileSync(path.join(dir, file), String(content).slice(0, 20000), 'utf8');
    desktopWrites++;
    return file;
  } catch { return null; }
});

// Fake-Neustart: neues Fenster öffnen, altes schließen (gleicher Prozess, kein echter Neustart)
ipcMain.handle('sys:fakeRestart', (e, phase) => {
  const old = BrowserWindow.fromWebContents(e.sender);
  createWindow(phase || 2);
  if (old) old.destroy();
});

ipcMain.handle('sys:saveState', (e, s) => {
  try {
    const tmp = stateFile() + '.tmp';
    fs.writeFileSync(tmp, JSON.stringify(s));
    fs.renameSync(tmp, stateFile());      // atomar: kein halb geschriebener Spielstand
  } catch {}
});
ipcMain.handle('sys:loadState', () => readState());
ipcMain.handle('sys:resetState', () => {
  try { fs.unlinkSync(stateFile()); } catch {}
});
ipcMain.handle('sys:quit', () => quitAll());

app.whenReady().then(() => {
  const saved = readState();
  createWindow(saved && saved.phase ? saved.phase : 1);
});
app.on('window-all-closed', () => quitAll());
app.on('before-quit', () => { quitting = true; });
