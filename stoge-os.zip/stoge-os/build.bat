@echo off
cd /d "%~dp0"
if not exist node_modules call npm install
call npm run dist
echo.
echo Fertig. Die .exe liegt im Ordner dist\
pause
