@echo off
cd /d "%~dp0"
if not exist node_modules call npm install
call npm run dist
echo.
echo Fertig. Starte das Spiel mit dist\win-unpacked\StogeOS.exe
echo (Den ganzen Ordner win-unpacked zusammen lassen. Er wird nicht bei jedem Start entpackt.)
pause
