@echo off
REM Zum Testen: startet im Fenster statt im Vollbild
cd /d "%~dp0"
if not exist node_modules call npm install
set STOGE_WINDOWED=1
call npm start
